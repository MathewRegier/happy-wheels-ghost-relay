Jimbob's Multiplayer Mod 0.4.1
Created by Jimbob
Discord: jimbob1111

Need help? Add me on Discord: jimbob1111


You must install the launcher first
-----------------------------------
Happy Wheels is not moddable until you run the Happy Wheels Mod Launcher.
Do not only drop this folder in. Install the launcher first.

Launcher download:
https://gamebanana.com/tools/24249


What this is
------------
Race friends on the same Happy Wheels level.

Ghost Multiplayer shows other players as ghosts you can see. They do
not push you.

Shared Physics is experimental. Everyone shares one world, so you can
see each other and bump for real. The host runs the physics.

Custom character skins show on other players when both of you have the
same character pack from Jimbob's Custom Characters.


Requirements
------------
- Windows
- A legal Steam copy of Happy Wheels 1.99.1
- Steam installed
- Happy Wheels Mod Launcher (link above)
- Close Happy Wheels before installing
- Every player needs this same 0.4.1 version


Install
-------
1. Download and install the Happy Wheels Mod Launcher:
   https://gamebanana.com/tools/24249
2. Unzip the launcher, close Happy Wheels, and run
   "Happy Wheels Mod Launcher.exe".
3. Let it find your Steam Happy Wheels folder and install the mods loader.
   This is what makes the game moddable.
4. In the launcher, check Jimbob's Multiplayer Mod and install.
   Or unzip this file and copy the "jimbobs-multiplayer" folder into:
   your Happy Wheels folder \ mods
   Example:
   C:\Program Files (x86)\Steam\steamapps\common\Happy Wheels\mods\jimbobs-multiplayer
5. Fully quit Happy Wheels if it was open, then launch it from Steam.
6. Open the Multiplayer menu.


Play
----
1. Type your name. This is the name other players see.
2. Choose Host or Join.
3. Host: pick Ghost Multiplayer or Shared Physics, then choose how many
   players the room allows (2 to 16).
4. Host: share the room code.
5. Join: paste that room code.
6. Host picks a level and brings everyone there.
7. Wait until everyone has selected a character.
8. Host presses Ready. Guests answer Yes or Not yet.
9. After GO, play as usual.

Shared Physics has a switch, "Players bump into each other". It starts
on. The host can turn it off during a level and riders pass through
each other right away.

The scoreboard counts a death each time someone respawns.

Changing character in Ghost Multiplayer keeps you in the same race.
In Shared Physics, pick a new character from the in-race list, including
custom characters when that mod is installed.


What's new in 0.4.1
-------------------
- Shared Physics limb breaks stay in sync, including shoulders, elbows, hips, and knees.
- A character that falls out of sync is rebuilt instead of pausing the race.
- Blood bursts still play after the hit destroys the body part.
- Your own key bindings are used for movement and restart.
- Shared Physics, an experimental shared world.
- Ghost Multiplayer still works.
- Host or Join, then pick the mode.
- Room size from 2 to 16 players. The stats page shows 3/12 when 3
  people are in a room of 12.
- Shared Physics bump switch, on by default, and it works mid-level.
- The scoreboard adds a death on every respawn.
- Changing character in Ghost Multiplayer no longer drops you from the race.
- The relay stats page shows the room code, the mode, and how full the
  room is.


Updates
-------
Open the Happy Wheels Mod Launcher again later to check for updates.

A Steam update or "Verify integrity of game files" can remove the
mods loader. If that happens, run the launcher again first, then
reinstall this mod.


Credits
-------
Created by Jimbob
Discord: jimbob1111

If you need any help, add me on Discord: jimbob1111
