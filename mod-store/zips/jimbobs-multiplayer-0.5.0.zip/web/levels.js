(() => {
  'use strict';
  const api = window.HWJimbobLevels = {errors: []};

  function post(fields) {
    const body = new URLSearchParams();
    for (const [key, value] of Object.entries(fields)) {
      if (value != null && value !== '') body.set(key, String(value));
    }
    return fetch('/get_level.hw', {
      method: 'POST',
      headers: {'content-type': 'application/x-www-form-urlencoded'},
      body,
    });
  }

  function rowsFromXml(text) {
    if (!text || /<\s*html/i.test(text.slice(0, 80)) || /^\s*failure/i.test(text)) return [];
    const doc = new DOMParser().parseFromString(text, 'text/xml');
    return [...doc.getElementsByTagName('lv')].map((node) => ({
      id: node.getAttribute('id') || '',
      name: node.getAttribute('ln') || 'Untitled',
      author: node.getAttribute('un') || '',
      plays: node.getAttribute('ps') || node.getAttribute('pc') || '',
      featured: node.getAttribute('df') || '',
    })).filter((row) => /^[1-9][0-9]{0,8}$/.test(row.id));
  }

  function featuredTime(value) {
    const text = String(value || '');
    if (text.length < 19) return null;
    const parts = [text.slice(0, 4), text.slice(5, 7), text.slice(8, 10), text.slice(11, 13), text.slice(14, 16), text.slice(17, 19)].map(Number);
    if (parts.some((part) => !Number.isFinite(part))) return null;
    return new Date(parts[0], parts[1] - 1, parts[2], parts[3], parts[4], parts[5]).getTime();
  }

  function orderFeatured(rows) {
    const now = Date.now();
    const recent = [];
    const older = [];
    for (const row of rows) {
      const time = featuredTime(row.featured);
      if (time != null && (now - time) / 86400000 < 14) recent.push(row);
      else older.push(row);
    }
    return recent.concat(older);
  }

  async function list(options) {
    const page = Math.max(1, Number(options?.page) || 1);
    const tab = options?.tab === 'custom' ? 'custom' : 'featured';
    const fields = {page};
    const sortby = options?.sortby || 'date';
    const query = String(options?.query || '').trim();
    if (tab === 'featured') fields.action = 'get_featured';
    else if (options?.jhwmp && !query) {
      fields.action = 'search_by_name';
      fields.sterm = 'JHWMP';
      fields.sortby = sortby;
    } else if (query) {
      fields.action = options?.by === 'author' ? 'search_by_user' : 'search_by_name';
      fields.sterm = query;
      fields.sortby = sortby;
    } else {
      fields.action = 'get_all';
      fields.sortby = sortby;
    }
    if (tab === 'custom' && options?.asof) fields.asof = options.asof;
    const text = await (await post(fields)).text();
    let rows = rowsFromXml(text);
    if (tab === 'featured') rows = orderFeatured(rows);
    if (tab === 'custom' && options?.jhwmp) rows = rows.filter((row) => /jhwmp/i.test(row.name + ' ' + row.author));
    return rows;
  }

  function jmpTexts(xml) {
    return String(xml || '').match(/#jmp[^\r\n<]*/gi) || [];
  }

  async function sha256(buffer) {
    const digest = await crypto.subtle.digest('SHA-256', buffer);
    return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, '0')).join('');
  }

  async function inspect(id, hint) {
    if (!/^[1-9][0-9]{0,8}$/.test(String(id || ''))) throw Error('Enter a level id.');
    const response = await post({action: 'get_record', level_id: id});
    if (!response.ok) throw Error('That level could not be loaded.');
    const buffer = await response.arrayBuffer();
    const text = new TextDecoder().decode(buffer);
    if (/^\s*failure/i.test(text) || /<\s*html/i.test(text.slice(0, 80))) throw Error('That level could not be loaded.');
    const hash = await sha256(buffer);
    const courseApi = window.HWJimbobCourse;
    const compiled = courseApi ? courseApi.compile(jmpTexts(text).map((line) => ({text: line, x: 0, y: 0}))) : null;
    const core = window.HWGhostCore;
    return {
      meta: {
        protocol: core.VERSION,
        level: String(id),
        hash,
        title: String(hint?.name || ('Level ' + id)).slice(0, 80),
        author: String(hint?.author || '').slice(0, 40),
      },
      rules: {
        waitSec: compiled?.waitSec || null,
        seats: compiled?.seats || null,
        rider: compiled?.rider || null,
        lingerMs: compiled?.lingerMs || null,
      },
    };
  }

  api.list = list;
  api.inspect = inspect;
})();
