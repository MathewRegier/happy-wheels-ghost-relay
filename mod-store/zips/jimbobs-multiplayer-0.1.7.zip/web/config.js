// Player build settings. Rebuild with tools/setup.py after changing these defaults.
window.HWGhostConfig = Object.freeze({
  development: false,
  version: '0.1.7',
  defaultRelayUrl: 'wss://web-production-79ef3.up.railway.app'
});
