# Jimbob's Multiplayer · 0.7.9

Ghost racing, host-run Shared Physics, public rooms, Steam invites and chat. The Multiplayer Maps tab loads Jimbob Maps: browse, preview, or open a JM code, and everyone in the room gets the same verified revision.

Players do not need Builder. This update also plays published tycoon and Studio maps, and lets one person start a solo room. Survival maps still need at least two players. Solo rooms stay off the public browser.

Install with the Happy Wheels Mod Launcher, or unzip and copy the `jimbobs-multiplayer` folder into the game's `mods` folder. Fully quit every Happy Wheels window, then launch through Steam. Everyone in a room should use 0.7.9. The title screen Multiplayer button opens the lobby, and Newest and All time in Choose a level open inside the picker. Install the launcher, press Install, then update this mod.

See README.txt for install steps and the full update notes.

Compatibility update: Happy Wheels 1.99.3. Includes the shared game bridge, restored previews and verified sprite-layout compatibility for older skins. Fully quit and restart Happy Wheels after installing.
