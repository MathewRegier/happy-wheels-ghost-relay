(() => {
  'use strict';
  window.HWMultiplayerUI=(lab,actions)=>{
    const config=window.HWGhostConfig;
    const read=(key,fallback)=>{try{return localStorage.getItem(key)||fallback;}catch{return fallback;}};
    const save=(key,value)=>{try{localStorage.setItem(key,value);}catch{}};
    let opened=false,step='choice',mode='ghost',lastPlayers='',lastChat='',lastCode=null,lastStart=null,goUntil=0;
    const screen=document.createElement('section');screen.id='hw-multiplayer';screen.hidden=true;
    screen.setAttribute('aria-label','Multiplayer');
    screen.innerHTML=`<style>
      #hw-multiplayer{position:fixed;inset:0;z-index:9999;background:radial-gradient(ellipse at 20% 0%,#32434d,#172127 75%);color:#f2eee3;overflow:auto;font:17px/1.45 Georgia,serif;box-sizing:border-box;padding:clamp(20px,5vh,56px) max(24px,calc((100vw - 1040px)/2))}
      #hw-multiplayer[hidden],#hw-mp-access[hidden]{display:none!important}
      #hw-multiplayer *{box-sizing:border-box}#hw-multiplayer h1{font:clamp(32px,6vw,58px)/1.1 'Clarendon LT Std Bold',Georgia,serif;color:#fd8081;margin:0 0 12px;text-shadow:0 3px 2px #0008}
      #hw-multiplayer .eyebrow{font:12px/1.4 Georgia,serif;letter-spacing:3px;text-transform:uppercase;color:#b4c5cd;margin:0 0 8px}
      #hw-multiplayer select{font:inherit;background:#101b21;color:#fff;border:1px solid #657d89;padding:12px;margin:7px 0 16px;width:100%}#hw-multiplayer button,#hw-multiplayer input{font:inherit}#hw-multiplayer button{cursor:pointer;border:1px solid #6c8793;background:transparent;color:#bce0f3;padding:9px 18px;border-radius:2px}#hw-multiplayer button:hover{background:#314551}#hw-multiplayer button:focus-visible,#hw-multiplayer input:focus-visible{outline:2px solid #fd8081;outline-offset:3px}#hw-multiplayer button:disabled{opacity:.45;cursor:default}
      #hw-multiplayer .primary{background:#a4d8ef;color:#16222a;border-color:#a4d8ef}#hw-multiplayer .primary:hover{background:#d0ecf8}#hw-multiplayer .back{float:right;border:0;padding:5px;color:#ddd5c7}#hw-multiplayer .tabs{display:flex;gap:24px;border-bottom:1px solid #60717a;margin:30px 0 24px}#hw-multiplayer .tabs button{border:0;border-bottom:3px solid transparent;border-radius:0;padding:10px 4px;font-size:23px;color:#b5bfc3}#hw-multiplayer .tabs button[aria-selected=true]{color:#fd8081;border-bottom-color:#fd8081}
      #hw-multiplayer .choice{display:flex;flex-direction:column;gap:12px;margin:8px 0 18px}#hw-multiplayer .choice button{text-align:left;padding:16px 18px;background:#101b21;border:1px solid #657d89;color:#f2eee3}#hw-multiplayer .choice b{display:block;font-size:22px;color:#fd8081}#hw-multiplayer .choice span{display:block;color:#b4c5cd;font-size:15px;margin-top:6px}#hw-multiplayer .choice small{color:#e8d7bc;font-size:14px;letter-spacing:.04em}
      #hw-multiplayer .size-row{display:flex;align-items:center;gap:14px;margin:8px 0 12px}#hw-multiplayer .size-row input{margin:0;accent-color:#fd8081}#hw-multiplayer .size-row b{font-size:28px;color:#fff;min-width:2ch}
      #hw-multiplayer .warn{color:#fd8081;font-size:15px}#hw-multiplayer details.advanced{margin-top:28px;font-size:13px;color:#8ea0a8}#hw-multiplayer details.advanced summary{color:#8ea0a8}
      #hw-multiplayer .switch{display:flex;align-items:center;gap:10px;margin:16px 0;color:#f2eee3}#hw-multiplayer .switch input{width:auto;margin:0;accent-color:#a4d8ef}
      #hw-multiplayer input{width:100%;background:#101b21;border:1px solid #657d89;color:#fff;padding:12px;margin:7px 0 16px}#hw-multiplayer label{display:block;color:#ddd5c7}#hw-multiplayer p{margin:12px 0 20px}#hw-multiplayer .muted{color:#b4c5cd;font-size:15px}#hw-multiplayer .actions{display:flex;flex-wrap:wrap;gap:10px;margin:18px 0}#hw-multiplayer #mp-status{min-height:24px;color:#e8d7bc;margin:18px 0;font-size:16px}#hw-multiplayer #mp-status:empty{display:none!important}#hw-multiplayer details{border-top:1px solid #465b65;margin-top:26px;padding-top:14px;color:#b4c5cd;font-size:15px}#hw-multiplayer summary{cursor:pointer}#hw-multiplayer details label{margin-top:12px}#hw-multiplayer .room-code{font:clamp(18px,4vw,30px)/1.4 Georgia,serif;letter-spacing:2px;color:#fff;user-select:all}#hw-multiplayer ul{list-style:none;padding:0;margin:20px 0}#hw-multiplayer li{display:flex;justify-content:space-between;gap:15px;border-bottom:1px solid #40545e;padding:10px 0}#hw-multiplayer li span:last-child{color:#a4d8ef;font-size:14px}#hw-multiplayer [hidden]{display:none!important}
      #hw-multiplayer .lobby-grid{display:grid;grid-template-columns:1fr 1fr;gap:18px;align-items:stretch}#hw-multiplayer .panel{background:#101b21;border:1px solid #657d89;padding:16px 18px;min-height:0}#hw-multiplayer .panel h2{margin:0 0 12px;font:15px/1.2 Georgia,serif;color:#fd8081;letter-spacing:.12em;text-transform:uppercase}#hw-multiplayer .panel .muted{margin:6px 0 10px}
      #hw-multiplayer .player-card{display:flex;align-items:center;justify-content:flex-start;gap:12px;border-bottom:1px solid #40545e;padding:10px 0}#hw-multiplayer .player-card img,#hw-multiplayer .avatar-fallback{width:48px;height:48px;border-radius:4px;background:#24343c;object-fit:cover;flex:none}#hw-multiplayer .avatar-fallback{display:flex;align-items:center;justify-content:center;color:#fd8081;font:700 18px/1 Georgia,serif}#hw-multiplayer .player-card b{display:block;color:#f2eee3}#hw-multiplayer .player-card .meta{color:#a4d8ef;font-size:14px}#hw-multiplayer #mp-players{margin:0}
      #hw-multiplayer #mp-chat-log{height:190px;overflow:auto;background:#0c151a;border:1px solid #40545e;padding:8px 10px;margin:0 0 8px;font-size:15px}#hw-multiplayer #mp-chat-log p{margin:0 0 8px}#hw-multiplayer #mp-chat-log .who{color:#fd8081}#hw-multiplayer #mp-chat-form{display:flex;gap:8px;margin:0}#hw-multiplayer #mp-chat-form input{margin:0;flex:1}#hw-multiplayer #mp-chat-form button{flex:none}
      @media (max-width:800px){#hw-multiplayer .lobby-grid{grid-template-columns:1fr}}
      #hw-mp-access{position:fixed;right:14px;top:12px;z-index:9998;border:1px solid #758895;background:#1c2930ed;color:#fd8081;padding:9px 16px;font:17px Georgia,serif;cursor:pointer}#hw-mp-toast{pointer-events:none;position:fixed;left:50%;bottom:22px;transform:translateX(-50%);z-index:9998;background:#172127e8;color:#f5e8d2;padding:8px 15px;font:16px Georgia,serif;max-width:80%;text-align:center}#hw-mp-toast:empty{display:none}#hw-mp-count{pointer-events:none;position:fixed;inset:0;z-index:10001;display:flex;align-items:center;justify-content:center;font:900 clamp(96px,18vw,180px)/1 Georgia,serif;color:#fd8081;text-shadow:0 6px 0 #0008,0 0 40px #000a;letter-spacing:4px}#hw-mp-count[hidden]{display:none!important}#hw-mp-count.go{color:#a4d8ef;font-size:clamp(72px,14vw,140px)}
      #hw-mp-readyask{position:fixed;inset:0;z-index:10003;display:flex;align-items:center;justify-content:center;background:#0b1216c4;color:#f2eee3;font:18px/1.45 Georgia,serif;padding:24px}
      #hw-mp-readyask[hidden]{display:none!important}
      #hw-mp-readyask .card{width:min(420px,92vw);background:#172127;border:1px solid #6c8793;padding:28px 24px 22px;text-align:center;box-shadow:0 16px 40px #000a}
      #hw-mp-readyask h2{margin:0 0 10px;font:clamp(28px,5vw,40px)/1.1 Georgia,serif;color:#fd8081}
      #hw-mp-readyask p{margin:0 0 20px;color:#ddd5c7}
      #hw-mp-readyask .actions{display:flex;justify-content:center;flex-wrap:wrap;gap:10px}
      #hw-mp-readyask button{font:inherit;cursor:pointer;border:1px solid #6c8793;background:transparent;color:#bce0f3;padding:9px 18px}
      #hw-multiplayer #mp-level-list{display:flex;flex-direction:column;gap:8px;max-height:280px;overflow:auto;margin-top:8px}
      #hw-multiplayer #mp-level-list button{text-align:left}
      #hw-multiplayer #mp-search-row,#hw-multiplayer #mp-id-row{display:flex;gap:8px;align-items:center}
      #hw-multiplayer #mp-search-row input,#hw-multiplayer #mp-id-row input{margin:0;flex:1}
      #hw-multiplayer #mp-search-kind{width:auto;margin:0}
      #hw-mp-results{position:fixed;inset:0;z-index:10004;display:flex;align-items:center;justify-content:center;background:#0b1216d0;color:#f2eee3;font:18px/1.45 Georgia,serif}
      #hw-mp-results[hidden]{display:none!important}
      #hw-mp-results .card{width:min(520px,94vw);background:#172127;border:1px solid #6c8793;padding:28px 24px;box-shadow:0 16px 40px #000a}
      #hw-mp-results h2{margin:0 0 12px;color:#fd8081;font:clamp(28px,5vw,42px)/1.1 Georgia,serif}
      #hw-mp-results li{display:flex;justify-content:space-between;gap:12px;border-bottom:1px solid #40545e;padding:8px 0}
      #hw-mp-chartags{position:fixed;inset:0;pointer-events:none;z-index:10002}
      #hw-mp-chartags[hidden]{display:none!important}
      #hw-mp-chartags .pick{position:absolute;pointer-events:none;display:flex;flex-direction:column;align-items:center;gap:2px}
      #hw-mp-chartags .names{display:flex;flex-direction:column;align-items:center;gap:2px;transform:translateY(-100%);margin-top:-8px}
      #hw-mp-chartags .name{font:700 13px/1.15 Georgia,serif;color:#fff;padding:1px 6px;border-radius:6px;text-shadow:0 1px 0 #000;white-space:nowrap}
      #hw-mp-chartags .box{border:3px solid #8dff8a;border-radius:8px;box-shadow:0 0 0 2px #102018}
      #hw-mp-chartags .box.you{border:4px solid #ffe14a;box-shadow:0 0 0 2px #3a2d08}
      #hw-mp-restartvote{position:fixed;right:14px;top:68px;z-index:10006;width:min(350px,calc(100vw - 28px));padding:18px;background:#172127f5;border:1px solid #6c8793;box-shadow:0 10px 30px #0008;color:#f2eee3;font:16px/1.4 Georgia,serif}
      #hw-mp-restartvote[hidden]{display:none!important}#hw-mp-restartvote h2{margin:0 0 8px;color:#fd8081;font:26px/1.1 Georgia,serif}#hw-mp-restartvote p{margin:8px 0}#hw-mp-restartvote .actions{display:flex;gap:10px;margin-top:14px}
      #hw-mp-restartvote button{cursor:pointer;font:inherit;padding:8px 18px;border:1px solid #6c8793;background:#243640;color:#bce0f3}#hw-mp-restartvote button:disabled{opacity:.5;cursor:default}#hw-mp-restartvote button:focus-visible{outline:2px solid #fd8081;outline-offset:3px}
      #hw-multiplayer #mp-settings{position:fixed;inset:0;z-index:10008;display:flex;align-items:center;justify-content:center;background:#0b1216c4;padding:24px}
      #hw-multiplayer #mp-settings .card{width:min(560px,94vw);max-height:min(86vh,720px);overflow:auto;background:#17272f;border:2px solid #0d171c;border-radius:14px;box-shadow:0 6px 0 #0d171c;padding:26px 24px 20px}
      #hw-multiplayer #mp-settings h2{margin:0 0 8px;color:#f2cb64;font:700 32px/1.1 Georgia,serif}
      #hw-multiplayer #mp-settings .hint{margin:0 0 14px}
    </style>
    <button class="back" id="mp-back">Close</button><p class="eyebrow">Jimbob's Multiplayer</p><h1 id="mp-title">Multiplayer</h1>
    <div id="mp-entry">
      <section id="mp-step-choice">
        <div id="mp-room-browser"></div>
      </section>
      <section id="mp-step-mode" hidden>
        <p class="muted">Pick how the room plays.</p>
        <div class="choice"><button type="button" id="mp-pick-ghost"><b>Ghost Multiplayer</b><span>Race the same level. Friends show up as ghosts you can see, but you can't bump them.</span></button><button type="button" id="mp-pick-shared"><b>Shared Physics <small>Experimental</small></b><span>One shared world. You see each other and can bump for real.</span></button></div>
        <div class="actions"><button type="button" id="mp-mode-back">Back</button></div>
      </section>
      <section id="mp-step-size" hidden>
        <label for="mp-room-name">Room name</label><input id="mp-room-name" maxlength="48" placeholder="Give your room a name" autocomplete="off">
        <div class="mp-form-grid"><div><label for="mp-visibility">Who can find your room?</label><select id="mp-visibility"><option value="public">Public · listed in the browser</option><option value="friends">Friends only · invite or code</option></select></div><div><label for="mp-host-password">Password (optional)</label><input id="mp-host-password" type="password" maxlength="64" autocomplete="new-password" placeholder="Leave empty for no password"></div></div>
        <p class="muted" id="mp-privacy-note">Public rooms appear in the browser. Anyone can join unless you set a password.</p>
        <label for="mp-size">How many players</label>
        <div class="size-row"><input id="mp-size" type="range" min="2" max="16" value="4" step="1"><b id="mp-size-value">4</b></div>
        <p class="warn" id="mp-size-warn" hidden></p>
        <div class="actions"><button class="primary" id="mp-create" type="button">Create room</button><button type="button" id="mp-size-back">Back</button></div>
      </section>
      <section id="mp-step-code" hidden>
        <form id="mp-join"><p class="muted" id="mp-join-note">Enter the 16-character code from your friend.</p><label for="mp-code">Room code</label><input id="mp-code" maxlength="16" autocomplete="off" spellcheck="false" placeholder="Code from your friend"><label for="mp-join-password">Password (if the room has one)</label><input id="mp-join-password" type="password" maxlength="64" autocomplete="off" placeholder="Room password"><div class="actions"><button class="primary" id="mp-connect" type="submit">Join room</button><button type="button" id="mp-code-back">Back</button></div></form>
      </section>
    </div>
    <div id="mp-lobby" hidden>
      <div class="lobby-grid">
        <section class="panel" aria-label="Room">
          <h2>Room</h2>
          <p id="mp-lobby-name"></p><p class="mp-room-note" id="mp-room-privacy"></p>
          <p class="muted" id="mp-room-kind"></p>
          <div class="mp-mode-buttons" role="group" aria-label="Multiplayer mode"><button id="mp-lobby-ghost" type="button">Ghost Multiplayer</button><button id="mp-lobby-shared" type="button">Shared Physics</button></div><p class="muted" id="mp-mode-note"></p>
          <p class="muted" id="mp-steam-note" hidden></p>
          <p class="mp-code-label">Room code</p>
          <div class="room-code" id="mp-room-code"></div>
          <div class="actions"><button id="mp-copy" type="button">Copy</button><button id="mp-steam" type="button">Invite Steam friends</button><button id="mp-leave" type="button">Leave</button></div>
        </section>
        <section class="panel" aria-label="Players">
          <h2>Players</h2>
          <ul id="mp-players" aria-label="Players"></ul>
        </section>
        <section class="panel" aria-label="Chat">
          <h2>Chat</h2>
          <div id="mp-chat-log" role="log" aria-live="polite"></div>
          <form id="mp-chat-form"><input id="mp-chat" maxlength="200" autocomplete="off" spellcheck="true" placeholder="Message the room"><button type="submit">Send</button></form>
        </section>
        <section class="panel" aria-label="Actions">
          <h2>Actions</h2>
          <p id="mp-level" class="muted"></p>
          <p id="mp-course" class="muted" hidden></p>
          <button id="mp-ready" class="primary" type="button">Ready</button>
          <button id="mp-not-ready" type="button">Not yet</button>
          <button id="mp-choose" type="button">Choose a level</button>
          <div class="mp-tools"><h3>Room tools</h3><div class="actions"><button id="mp-lock" type="button">Lock lobby</button><button id="mp-collide" type="button" hidden aria-pressed="true">Player Collisions: On</button><button id="mp-summon" type="button">Reset players</button><button id="mp-world-reset" type="button" hidden>Reset world</button><button id="mp-request-restart" type="button" hidden>Vote to restart</button><button id="mp-retry-load" type="button" hidden>Retry loading</button><button id="mp-lobby-return" type="button">Back to lobby</button></div></div>
        </section>
      </div>
    </div>
    <p id="mp-status" role="status" aria-live="polite"></p>
    <section id="mp-settings" hidden aria-label="Advanced server settings"><div class="card"><h2>Advanced server settings</h2><p class="muted hint">Press Escape to close.</p><label for="mp-server">Server address</label><input id="mp-server" spellcheck="false"><label for="mp-maps-server">Jimbob Maps address (optional)</label><input id="mp-maps-server" placeholder="Uses your multiplayer server when blank" spellcheck="false"><label for="mp-chat-key">In-game chat key</label><input id="mp-chat-key" maxlength="1" autocapitalize="off" spellcheck="false" aria-describedby="mp-chat-key-note"><div class="actions"><button id="mp-save" type="button">Save</button><button id="mp-server-default" type="button">Use default server</button><button id="mp-local" type="button">Test localhost</button><button id="mp-second-settings" type="button">Open second window</button><button id="mp-settings-close" type="button">Close</button></div><p id="mp-chat-key-note" class="muted">The chat key defaults to T. It is taken before Happy Wheels sees it, so it does not type the letter or fire a control. If you remap the game, choose a chat key that is not accelerate, brake, or restart. Test localhost sets Multiplayer and Jimbob Maps to port 19798. Start the local Maps service first.</p></div></section>`;
    const ask=document.createElement('section');ask.id='hw-mp-readyask';ask.hidden=true;ask.setAttribute('aria-label','Ready check');
    ask.innerHTML=`<div class="card"><h2>Ready?</h2><p id="mp-ready-copy">The host is ready. Are you ready to race?</p><div class="actions"><button class="primary" id="mp-ready-yes">Yes</button><button id="mp-ready-no">Not yet</button></div></div>`;
    const access=document.createElement('button');access.id='hw-mp-access';access.textContent='Multiplayer';access.hidden=true;access.tabIndex=-1;
    const toast=document.createElement('div');toast.id='hw-mp-toast';
    const count=document.createElement('div');count.id='hw-mp-count';count.hidden=true;count.setAttribute('aria-live','assertive');
    const hud=document.createElement('div');hud.id='hw-mp-hud';hud.hidden=true;hud.innerHTML=`<style>
      #hw-mp-hud{pointer-events:none;position:fixed;inset:0;z-index:9996;font:14px/1.2 Georgia,serif;color:#f3ead6}
      #hw-mp-board{pointer-events:auto}
      #hw-mp-hud[hidden]{display:none!important}
      #hw-mp-board{position:absolute;top:12px;left:12px;min-width:220px;background:#121916e6;border:1px solid #3b4a44;box-shadow:0 8px 24px #0008;padding:10px 12px 8px}
      #hw-mp-board .stamp{display:inline-block;border:1px solid #fd7f7c;color:#fd7f7c;font:700 10px/1 Georgia,serif;letter-spacing:.16em;text-transform:uppercase;padding:3px 6px;margin-bottom:8px}
      #hw-mp-board table{width:100%;border-collapse:collapse}
      #hw-mp-board th{font:700 10px/1 Georgia,serif;letter-spacing:.08em;text-transform:uppercase;color:#8b968e;text-align:left;padding:0 8px 6px 0}
      #hw-mp-board th:nth-child(2),#hw-mp-board th:nth-child(3),#hw-mp-board td:nth-child(2),#hw-mp-board td:nth-child(3){text-align:right}
      #hw-mp-board td{padding:4px 8px 4px 0;border-top:1px solid #2a3530;white-space:nowrap}
      #hw-mp-board tbody tr{cursor:pointer}
      #hw-mp-board tbody tr:hover td{color:#fd7f7c}
      #hw-mp-board .watching td{color:#a4d8ef}
      #hw-mp-spec{margin-top:8px;color:#9aa79e;font:11px/1.3 Georgia,serif}
      #hw-mp-board .you{color:#c8e6c0}
      #hw-mp-board .dead{color:#fd7f7c}
      #hw-mp-track{position:absolute;left:8%;right:8%;bottom:18px;height:54px}
      #hw-mp-ghost{position:absolute;left:50%;top:-30px;transform:translateX(-50%);z-index:80;background:#121916f2;border:1px solid #fd7f7c;color:#f3ead6;padding:4px 12px;font:700 13px/1.2 Georgia,serif;letter-spacing:.04em;white-space:nowrap;pointer-events:none;text-shadow:0 1px 0 #000}
      #hw-mp-ghost[hidden]{display:none!important}
      #hw-mp-track .rail{position:absolute;left:0;right:0;top:32px;height:8px;background:linear-gradient(90deg,#1a2320,#3b4a44 12%,#fd7f7c 92%,#f3ead6);border:1px solid #2a3530;box-shadow:inset 0 1px 0 #fff2}
      #hw-mp-track .racer{position:absolute;top:0;transform:translateX(-50%);text-align:center;width:72px}
      #hw-mp-track .tag{display:block;font:700 11px/1 Georgia,serif;text-shadow:0 1px 0 #000,1px 0 0 #000,-1px 0 0 #000,0 -1px 0 #000;margin-bottom:3px;white-space:nowrap}
      #hw-mp-track .head{display:inline-block;width:22px;height:22px;border-radius:50%;border:2px solid #f3ead6;box-shadow:0 0 0 1px #0008,0 2px 6px #0008;opacity:.78;position:relative}
      #hw-mp-track .head:after{content:"";position:absolute;left:6px;top:5px;width:8px;height:6px;border-radius:50%;background:#fff6}
      #hw-mp-track .you .head{opacity:1;box-shadow:0 0 0 2px #fd7f7c,0 2px 6px #0008}
    </style><aside id="hw-mp-board" aria-label="Race scoreboard"><div class="stamp">Live board</div><table><thead><tr><th>Racer</th><th>Died</th><th>Best</th></tr></thead><tbody></tbody></table><p class="spec" id="hw-mp-spec" hidden></p></aside><div id="hw-mp-track" aria-label="Race progress"><div class="rail"></div><div class="markers"></div><div id="hw-mp-ghost" hidden></div></div>`;
    document.body.append(screen,access,toast,count,hud,ask);
    const restartAsk=document.createElement('section');restartAsk.id='hw-mp-restartvote';restartAsk.hidden=true;restartAsk.setAttribute('aria-label','Restart vote');
    restartAsk.innerHTML='<h2>Restart the match?</h2><p id="mp-restart-requester"></p><p id="mp-restart-progress" role="status" aria-live="polite"></p><p id="mp-restart-time"></p><div class="actions"><button id="mp-restart-yes" type="button">Yes</button><button id="mp-restart-no" type="button">No</button></div>';
    document.body.append(restartAsk);
    const playChat=document.createElement('section');
    playChat.id='hw-mp-playchat';
    playChat.dataset.state='hidden';
    playChat.setAttribute('aria-label','In-game chat');
    playChat.innerHTML=`<style>
      #hw-mp-playchat{position:fixed;left:12px;bottom:16px;z-index:9996;width:clamp(240px,34vw,420px);max-width:calc(100vw - 16px);color:#f3ead6;font:15px/1.35 Georgia,serif;opacity:0;pointer-events:none;transition:opacity 300ms linear}
      #hw-mp-playchat.above-hud{bottom:84px}
      #hw-mp-playchat[data-state=history],#hw-mp-playchat[data-state=typing]{opacity:1}
      #hw-mp-playchat[data-state=history]{pointer-events:none}
      #hw-mp-playchat[data-state=history] .log,#hw-mp-playchat[data-state=history] form,#hw-mp-playchat[data-state=history] .jump,#hw-mp-playchat[data-state=typing]{pointer-events:auto}
      #hw-mp-playchat.fade{opacity:0}
      #hw-mp-playchat[data-state=hidden]{visibility:hidden}
      #hw-mp-playchat .log{max-height:7.4em;overflow:auto;background:#121916cc;border:1px solid #3b4a44;border-left:3px solid #fd7f7c;padding:6px 8px;box-shadow:0 8px 20px #0006}
      #hw-mp-playchat p{margin:0 0 4px;overflow-wrap:anywhere;word-break:break-word}
      #hw-mp-playchat .who{color:#fd7f7c;font-weight:700}
      #hw-mp-playchat form{display:none;gap:6px;margin-top:6px}
      #hw-mp-playchat[data-state=history] form,#hw-mp-playchat[data-state=typing] form{display:flex}
      #hw-mp-playchat input{flex:1;min-width:0;background:#101b21;color:#f3ead6;border:1px solid #657d89;padding:6px 8px;font:inherit}
      #hw-mp-playchat button{background:#a4d8ef;color:#16222a;border:0;padding:6px 10px;font:inherit;cursor:pointer}
      #hw-mp-playchat .jump{display:block;margin-top:4px;background:#121916f2;color:#f3ead6;border:1px solid #fd7f7c}
      #hw-mp-playchat .jump[hidden]{display:none!important}
      #hw-mp-playchat .notice{margin:4px 0 0;color:#fd7f7c;background:#121916f2;padding:4px 8px}
      #hw-mp-playchat .notice[hidden]{display:none!important}
      @media (prefers-reduced-motion:reduce){#hw-mp-playchat{transition:none}}
    </style><div class="log" role="log" aria-live="polite"></div><button type="button" class="jump" hidden>New messages</button><form><input maxlength="200" autocomplete="off" spellcheck="true" aria-label="Chat message" placeholder="Message the room"><button type="submit">Send</button></form><p class="notice" hidden></p>`;
    document.body.append(playChat);
    const playLog=playChat.querySelector('.log');
    const playInput=playChat.querySelector('input');
    const playJump=playChat.querySelector('.jump');
    const playNotice=playChat.querySelector('.notice');
    let playRows=0,chatMode='hidden',chatTimer=0,chatKey=String(read('hw-mp-chat-key','t')||'t').slice(0,1).toLowerCase()||'t';
    const reduceMotion=window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches;
    function chatKeyNow(){return /^[a-z0-9]$/i.test(chatKey)?chatKey:'t';}
    function editable(node){const tag=(node?.tagName||'').toLowerCase();return tag==='input'||tag==='textarea'||tag==='select'||node?.isContentEditable;}
    function modalOwnsKeys(){const pickerOpen=picker&&!picker.hidden;const askOpen=ask&&!ask.hidden;return !screen.hidden||pickerOpen||askOpen;}
    function focusGame(){try{playInput.blur();}catch{}try{(appView()||document.querySelector('canvas'))?.focus?.();}catch{}}
    function appView(){return document.querySelector('canvas');}
    function setChatMode(next){
      chatMode=next;
      playChat.dataset.state=next==='hidden'?'hidden':next==='typing'?'typing':'history';
      if(next!=='history')playChat.classList.remove('fade');
      lab.setInputBlock?.('chat', next==='typing');
    }
    function armChatHide(){
      clearTimeout(chatTimer);
      playChat.classList.remove('fade');
      if(chatMode==='typing')return;
      setChatMode('history');
      chatTimer=setTimeout(()=>{
        if(chatMode==='typing')return;
        if(reduceMotion){setChatMode('hidden');return;}
        playChat.classList.add('fade');
        chatTimer=setTimeout(()=>{if(chatMode!=='typing')setChatMode('hidden');},320);
      },5000);
    }
    function openChat(){
      clearTimeout(chatTimer);
      playChat.classList.remove('fade');
      setChatMode('typing');
      playNotice.hidden=true;
      setTimeout(()=>{try{playInput.focus();}catch{}},0);
    }
    function closeChat(clearDraft){
      if(clearDraft)playInput.value='';
      if(chatMode==='hidden'&&!playInput.value){setChatMode('hidden');return;}
      setChatMode('history');
      focusGame();
      armChatHide();
    }
    playChat.addEventListener('transitionend',event=>{
      if(event.propertyName!=='opacity'||chatMode==='typing'||!playChat.classList.contains('fade'))return;
      setChatMode('hidden');
    });
    playInput.addEventListener('focus',()=>{if(chatMode!=='typing')openChat();});
    playJump.onclick=()=>{playLog.scrollTop=playLog.scrollHeight;playJump.hidden=true;};
    playChat.querySelector('form').onsubmit=event=>{
      event.preventDefault();
      const text=playInput.value;
      try{
        if(!actions.sendChat)throw Error('Chat is not connected.');
        actions.sendChat(text);
        playInput.value='';
        playNotice.hidden=true;
        closeChat(false);
      }catch(err){
        playNotice.hidden=false;
        playNotice.textContent=err.message||String(err);
      }
    };
    window.addEventListener('keydown',event=>{
      if(chatMode==='typing'&&playChat.contains(event.target)){
        if(event.key==='Escape'){event.preventDefault();event.stopPropagation();closeChat(false);return;}
        if(event.key==='Enter'){event.preventDefault();event.stopPropagation();playChat.querySelector('form').requestSubmit();return;}
        event.stopImmediatePropagation();
      }
      if(event.key!==chatKeyNow()&&event.key.toLowerCase()!==chatKeyNow())return;
      if(chatMode==='typing'||editable(event.target)||modalOwnsKeys())return;
      if(event.repeat||event.ctrlKey||event.altKey||event.metaKey||event.isComposing||event.key==='Process')return;
      if(!lab.lobby?.().room)return;
      event.preventDefault();event.stopImmediatePropagation();openChat();
    },true);
    window.addEventListener('blur',()=>{if(chatMode==='typing')closeChat(false);});
    const picker=document.createElement('section');
    picker.id='hw-level-picker';
    picker.hidden=true;
    picker.setAttribute('aria-label','Level selector');
    picker.innerHTML=`<style>
      #hw-level-picker{--ink:#0d171c;--paper:#f5eedb;--coral:#ff8582;--gold:#f2cb64;--sky:#acd7e8;position:fixed;inset:0;z-index:10006;display:flex;flex-direction:column;overflow:hidden;padding:clamp(20px,3vw,48px);background:radial-gradient(ellipse at 95% 0%,#45606c 0%,#283c47 35%,#1b2a32 75%);color:var(--paper);font:16px/1.45 Georgia,serif}
      #hw-level-picker[hidden]{display:none!important}
      #hw-level-picker *{box-sizing:border-box}
      #hw-level-picker .eyebrow{margin:0;text-align:center;letter-spacing:2px;font-weight:bold;text-transform:uppercase}
      #hw-level-picker h2{margin:6px 0 18px;text-align:center;font:900 clamp(40px,5vw,72px)/1.05 Georgia,serif;color:#fd8081;text-shadow:2px 3px 0 var(--ink)}
      #hw-level-picker .close{position:absolute;top:clamp(20px,3vw,48px);right:clamp(20px,3vw,48px);border:2px solid var(--ink);border-radius:8px;background:#17272f;box-shadow:0 3px 0 var(--ink);color:var(--paper);font:700 16px Georgia,serif;padding:9px 16px;cursor:pointer}
      #hw-level-picker .tabs{display:flex;flex-wrap:wrap;justify-content:center;gap:10px;margin:0 0 16px}
      #hw-level-picker .tabs button{border:2px solid var(--ink);border-radius:8px;background:#334d59;box-shadow:0 3px 0 var(--ink);color:var(--paper);font:700 16px Georgia,serif;padding:11px 18px;cursor:pointer}
      #hw-level-picker .tabs button[aria-selected=true]{background:var(--gold);color:var(--ink)}
      #hw-level-picker .section-note{margin:0 0 14px;text-align:center;color:#d0dce0}
      #hw-level-picker .section-note[hidden]{display:none!important}
      #hw-level-picker .filters{position:relative;z-index:4;display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin:0 0 16px;padding:14px;background:#20343f;border:2px solid var(--ink);border-radius:12px}
      #hw-level-picker .filters[hidden]{display:none!important}
      #hw-level-picker input,#hw-level-picker select{background:#111f26;color:var(--paper);border:2px solid #536b75;border-radius:7px;font:16px Georgia,serif;padding:10px 12px}
      #hw-level-picker .filters input{flex:1;min-width:180px}
      #hw-level-picker .pick{position:relative}
      #hw-level-picker .pick[hidden]{display:none!important}
      #hw-level-picker .native-select{position:absolute;width:1px;height:1px;margin:0;padding:0;opacity:0;pointer-events:none;overflow:hidden}
      #hw-level-picker .pick-face{position:relative;min-width:148px;text-align:left;background:#111f26;color:var(--paper);border:2px solid #536b75;border-radius:7px;box-shadow:none;font:16px Georgia,serif;padding:10px 34px 10px 12px}
      #hw-level-picker .pick-face:after{content:"";position:absolute;right:12px;top:50%;margin-top:-2px;border:5px solid transparent;border-top-color:var(--paper)}
      #hw-level-picker .pick-list{position:absolute;z-index:6;top:calc(100% + 6px);left:0;min-width:100%;max-height:220px;overflow:auto;display:flex;flex-direction:column;gap:2px;padding:6px;background:#111f26;border:2px solid #536b75;border-radius:8px;box-shadow:0 8px 0 #0d171c88}
      #hw-level-picker .pick-list[hidden]{display:none!important}
      #hw-level-picker .pick-item{text-align:left;background:transparent;border:0;box-shadow:none;padding:8px 10px;font:16px Georgia,serif}
      #hw-level-picker .pick-item:hover{background:#334d59}
      #hw-level-picker .pick-item[aria-selected=true]{color:var(--gold)}
      #hw-level-picker button{border:2px solid var(--ink);border-radius:8px;background:#334d59;box-shadow:0 3px 0 var(--ink);color:var(--paper);font:700 15px Georgia,serif;cursor:pointer}
      #hw-level-picker button:hover:enabled{background:#44616e}
      #hw-level-picker .filters button,#hw-level-picker .foot button{padding:10px 14px}
      #hw-level-picker .list{flex:1;min-height:0;overflow:auto;display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));grid-auto-rows:max-content;gap:18px;align-content:start;align-items:start;padding:2px 2px 16px}
      #hw-level-picker .card{display:flex;flex-direction:column;min-height:248px;background:#17272f;border:2px solid var(--ink);border-radius:12px;box-shadow:0 5px 0 #0d171c66;padding:22px 20px 18px}
      #hw-level-picker .card .mark{align-self:flex-start;margin-bottom:10px;padding:3px 8px;border-radius:999px;background:#13252e;color:var(--gold);font:700 12px Georgia,serif;letter-spacing:.06em}
      #hw-level-picker .card h3{margin:0 0 8px;font:700 26px/1.25 Georgia,serif;color:var(--paper);overflow-wrap:anywhere}
      #hw-level-picker .card p{margin:0;color:#b8cbd3;font-size:15px}
      #hw-level-picker .card .rating{margin-top:12px;color:var(--gold);font:700 20px Georgia,serif}
      #hw-level-picker .card .rating.none{color:#8ea0a8;font-weight:normal;font-size:16px}
      #hw-level-picker .reqs{display:flex;flex-wrap:wrap;gap:6px;margin:12px 0 14px}
      #hw-level-picker .reqs span{padding:3px 8px;border-radius:999px;background:#13252e;color:var(--sky);font:700 12px/1.3 Georgia,serif}
      #hw-level-picker .reqs .survival{color:#ffb0ad;background:#3a2428}
      #hw-level-picker .reqs .seats{color:var(--ink);background:var(--gold)}
      #hw-level-picker .reqs .wait{padding:0;background:transparent;color:#8ea0a8;font-weight:normal}
      #hw-level-picker .card button{margin-top:auto;align-self:flex-start;padding:9px 16px;background:var(--gold);color:var(--ink)}
      #hw-level-picker .card button:hover:enabled{background:#ffe298}
      #hw-level-picker .map-picture{flex:none;position:relative;width:calc(100% + 32px);aspect-ratio:16/9;margin:-16px -16px 8px;background:#12252d;display:grid;place-items:center;color:#f2cb64;font-weight:900;letter-spacing:2px;overflow:hidden;border-bottom:2px solid #0d171c}#hw-level-picker .map-picture img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}#hw-level-picker .map-code{font:12px Consolas,monospace;color:#acd7e8;overflow-wrap:anywhere}#hw-level-picker .empty{grid-column:1/-1;display:flex;align-items:center;justify-content:center;min-height:28vh;text-align:center;color:#b8cbd3;font-size:22px}
      #hw-level-picker .foot{display:flex;flex-wrap:wrap;gap:10px;align-items:center;padding-top:12px;border-top:2px solid #526b77}
      #hw-level-picker .foot input{width:150px}
      #hw-level-picker .note{margin-left:auto;color:#acbec7}
      #hw-level-picker .foot [hidden]{display:none!important}
      @media(min-width:2100px){#hw-level-picker .list{grid-template-columns:repeat(5,minmax(0,1fr))}}
      @media(max-width:720px){#hw-level-picker{padding:18px}#hw-level-picker h2{font-size:36px}#hw-level-picker .list{grid-template-columns:1fr}}
      @media(prefers-reduced-motion:reduce){#hw-level-picker button{transition:none}}
    </style>
    <p class="eyebrow">Jimbob's Multiplayer</p>
    <h2>Choose a level</h2>
    <button class="close" id="lvl-close" type="button">Close</button>
    <div class="tabs" id="lvl-tabs" role="tablist"><button type="button" data-tab="featured" aria-selected="true">Featured</button><button type="button" data-tab="custom">Custom maps</button><button type="button" data-tab="hosted">Multiplayer Maps</button></div>
    <p class="section-note" id="lvl-note" hidden>Community maps with previews, map codes, and multiplayer rules. Players only need Multiplayer.</p>
    <div class="filters" id="lvl-filters" hidden>
      <input id="lvl-search" placeholder="Search name or author">
      <div class="pick"><select id="lvl-by" class="native-select" tabindex="-1" aria-hidden="true"><option value="name">Name</option><option value="author">Author</option></select><button type="button" class="pick-face" aria-label="Search by" aria-expanded="false">Name</button><div class="pick-list" hidden role="listbox"></div></div>
      <div class="pick"><select id="lvl-sort" class="native-select" tabindex="-1" aria-hidden="true"><option value="newest">Newest</option><option value="oldest">Oldest</option><option value="rating">Rating</option><option value="plays">Plays</option></select><button type="button" class="pick-face" aria-label="Sort" aria-expanded="false">Newest</button><div class="pick-list" hidden role="listbox"></div></div>
      <div class="pick"><select id="lvl-when" class="native-select" tabindex="-1" aria-hidden="true"><option value="anytime">All time</option><option value="today">Today</option><option value="week">This week</option><option value="month">This month</option></select><button type="button" class="pick-face" aria-label="Uploaded" aria-expanded="false">All time</button><div class="pick-list" hidden role="listbox"></div></div>
      <button id="lvl-go" type="button">Search</button>
    </div>
    <div class="list" id="lvl-list"></div>
    <div class="foot">
      <button id="lvl-prev" type="button">Previous</button>
      <button id="lvl-next" type="button">Next</button>
      <input id="lvl-id" inputmode="numeric" placeholder="Level id" aria-label="Level id">
      <button id="lvl-id-go" type="button">Open id</button>
      <span class="note" id="lvl-page"></span>
    </div>`;
    document.body.append(picker);
    function closeFilterMenus(){
      for(const list of picker.querySelectorAll('.pick-list'))list.hidden=true;
      for(const face of picker.querySelectorAll('.pick-face'))face.setAttribute('aria-expanded','false');
    }
    function paintFilterMenu(select){
      const pick=select.closest('.pick');
      const face=pick?.querySelector('.pick-face');
      const list=pick?.querySelector('.pick-list');
      if(!face||!list)return;
      const chosen=[...select.options].find(option=>option.value===select.value&&!option.disabled)||[...select.options].find(option=>!option.disabled);
      if(chosen&&select.value!==chosen.value)select.value=chosen.value;
      face.textContent=chosen?.textContent||'';
      list.replaceChildren(...[...select.options].filter(option=>!option.disabled).map(option=>{
        const item=document.createElement('button');
        item.type='button';
        item.className='pick-item';
        item.setAttribute('role','option');
        item.textContent=option.textContent;
        item.setAttribute('aria-selected',option.value===select.value?'true':'false');
        item.onclick=event=>{
          event.stopPropagation();
          closeFilterMenus();
          if(select.value===option.value)return;
          select.value=option.value;
          select.dispatchEvent(new Event('change'));
        };
        return item;
      }));
    }
    for(const select of picker.querySelectorAll('.filters select')){
      const pick=select.closest('.pick');
      const face=pick.querySelector('.pick-face');
      face.onclick=event=>{
        event.stopPropagation();
        const open=pick.querySelector('.pick-list').hidden;
        closeFilterMenus();
        if(!open)return;
        paintFilterMenu(select);
        pick.querySelector('.pick-list').hidden=false;
        face.setAttribute('aria-expanded','true');
      };
      select.addEventListener('mousedown',event=>event.preventDefault());
      select.addEventListener('focus',()=>select.blur());
      paintFilterMenu(select);
    }
    picker.addEventListener('click',event=>{if(!event.target.closest('.pick'))closeFilterMenus();});
    picker.addEventListener('keydown',event=>{if(event.key==='Escape')closeFilterMenus();});
    const results=document.createElement('section');results.id='hw-mp-results';results.hidden=true;results.innerHTML='<div class="card"><h2>Results</h2><ul id="mp-results-list"></ul><div class="actions"><button class="primary" id="mp-again" type="button">Race again</button><button id="mp-next-map" type="button">Pick next map</button><button id="mp-results-lobby" type="button">Back to lobby</button></div></div>';
    const charTags=document.createElement('div');charTags.id='hw-mp-chartags';charTags.hidden=true;
    document.body.append(results,charTags);
    function hueFor(id){let h=0;for(const ch of String(id||''))h=ch.charCodeAt(0)+((h<<5)-h);return Math.abs(h)%360;}
    function paintHud(){
      const board=lab.raceBoard?.();
      const racing=!!board?.racing&&!!board.players?.length;
      hud.hidden=!racing||opened;
      if(!racing)return;
      const rows=[...board.players].sort((a,b)=>(b.best-a.best)||(a.deaths-b.deaths)||a.name.localeCompare(b.name));
      const body=hud.querySelector('#hw-mp-board tbody');
      body.replaceChildren(...rows.map(p=>{
        const tr=document.createElement('tr');
        if(p.id===board.spectateId)tr.className='watching';
        const name=document.createElement('td'),deaths=document.createElement('td'),progress=document.createElement('td');
        name.className=(p.you?'you':'')+(p.dead?' dead':'');name.textContent=p.name+(p.you?' (you)':'')+(p.finished?' · in':'');
        deaths.textContent=String(p.deaths);progress.textContent=Math.round((p.best||0)*100)+'%';tr.append(name,deaths,progress);
        tr.onclick=()=>lab.spectatePlayer?.(p.id);
        return tr;
      }));
      const spec=hud.querySelector('#hw-mp-spec');
      spec.hidden=!board.spectating;
      spec.textContent=board.spectating?(board.spectateName==='yourself'?'Watching yourself · [ ] cycle · click a name · R respawn':board.spectateName?'Spectating '+board.spectateName+' · [ ] cycle · click your name to return':'Finished · click a racer or press [ ] to spectate'):'';
      const linger=lab.lobby?.().lingerUntil;
      if(linger&&linger>Date.now())spec.hidden=false,spec.textContent=((spec.textContent?spec.textContent+' · ':'')+'Finish window '+Math.max(1,Math.ceil((linger-Date.now())/1000))+'s');
      const markers=hud.querySelector('#hw-mp-track .markers');
      markers.replaceChildren(...rows.map((p,i)=>{
        const node=document.createElement('div');
        node.className='racer'+(p.you?' you':'');
        const pct=Math.max(0,Math.min(1,p.progress||0))*100;
        node.style.left=pct+'%';
        node.style.zIndex=String(20+i);
        node.style.top=i%2?'6px':'0';
        const color=`hsl(${hueFor(p.id)} 58% 62%)`;
        const tag=document.createElement('span'),head=document.createElement('span');tag.className='tag';tag.textContent=p.name;head.className='head';head.style.background=color;node.append(tag,head);
        return node;
      }));
    }
    const el=id=>screen.querySelector('#mp-'+id);
    let joinBusy=false;
    const browser=window.HWRoomBrowser(el('room-browser'),{
      server:()=>el('server').value.trim(),
      host:()=>{el('room-name').value=playerName()+"'s room";showStep('mode');},
      solo:()=>{if(lab.lobby().connecting||joinBusy)return;mode='ghost';el('room-name').value=playerName()+"'s solo";el('visibility').value='friends';el('host-password').value='';connect('',{solo:true});},
      code:()=>joinCode(''),
      join:row=>{if(lab.lobby().connecting||joinBusy)return;mode=row.mode;joinCode(row.code,'',row.name);if(!row.passwordProtected)el('join').requestSubmit();else el('join-password').focus();}
    });
    const localRelayUrl='ws://127.0.0.1:19798';
    const railwayUrl=config.defaultRelayUrl||'wss://web-production-79ef3.up.railway.app';
    const savedServer=read('hw-mp-server','');
    el('maps-server').value=read('hw-maps-server','');
    el('server').value=savedServer||railwayUrl;
    let mapsSettingsRead=0,mapsSettingsReady=Promise.resolve();
    const run=fn=>async e=>{e?.preventDefault();try{await fn();}catch(err){actions.message(err.message||String(err));}refresh();};
    function playerName(){
      const steam=lab.lobby().steam;
      if(steam?.ok&&steam.name){save('hw-mp-name',steam.name);return steam.name;}
      return read('hw-mp-name','Racer');
    }
    function open(){
      opened=true;screen.hidden=false;refresh();
      if(!lab.lobby().room)showStep('choice');
      actions.steamStatus?.()?.then(()=>refresh());
    }
    function closeSettings(){mapsSettingsRead++;el('settings').hidden=true;}
    function toggleSettings(){
      const box=el('settings');
      box.hidden=!box.hidden;
      const ticket=++mapsSettingsRead;
      if(!box.hidden){
        el('server').focus();const initial=el('maps-server').value;
        mapsSettingsReady=(async()=>{
          try{
            const settings=await window.HWJimbobMaps.configure({});
            if(ticket===mapsSettingsRead&&!box.hidden&&el('maps-server').value===initial){el('maps-server').value=settings.base||'';save('hw-maps-server',settings.base||'');}
          }catch(err){if(ticket===mapsSettingsRead&&!box.hidden)actions.message(err.message||String(err));}
        })();
      }
    }
    function close(){opened=false;screen.hidden=true;browser.setActive(false);closeSettings();closePicker();el('host-password').value='';el('join-password').value='';document.activeElement?.blur();refresh();}
    function showStep(next){
      step=next;
      const titles={choice:'Multiplayer',mode:'Pick your mode',size:'Make it your room',code:'Join a room'};
      el('title').textContent=titles[next]||'Multiplayer';
      screen.classList.toggle('mp-centered',next==='mode'||next==='size'||next==='code');
      for(const name of ['choice','mode','size','code'])el('step-'+name).hidden=name!==next;
      closeSettings();
      browser.setActive(opened&&next==='choice'&&!lab.lobby().room);
      if(next==='code')el('code').focus();
    }
    function roomSize(){return Math.max(2,Math.min(16,Number(el('size').value)||2));}
    function paintSize(){
      const n=roomSize();
      el('size-value').textContent=String(n);
      const warn=mode==='shared'?n>4:n>8;
      el('size-warn').hidden=!warn;
      el('size-warn').textContent=warn?'More than '+(mode==='shared'?4:8)+' players can make the game inconsistent.':'';
    }
    async function connect(code,extra={}){
      if(joinBusy||lab.lobby().connecting)return;
      const address=el('server').value.trim();
      const solo=!!extra.solo;
      const options=code?{password:el('join-password').value}:{roomName:el('room-name').value.trim()||playerName()+"'s room",visibility:solo?'friends':el('visibility').value,password:solo?'':el('host-password').value,solo};
      if(options.password.length>64)throw Error('Use a password of up to 64 characters.');
      joinBusy=true;refresh();
      try{
        // Probe capability before creating a protected room on a possibly older relay.
        await window.HWRoomDirectory.listRooms(address);
        if(!opened||lab.lobby().room)return;
        actions.message(solo?'Creating your solo room\u2026':'Connecting\u2026');
        actions.connect(address,code,playerName(),solo?'ghost':mode,solo?1:roomSize(),options);
      }finally{joinBusy=false;refresh();}
    }
    function joinCode(code,address='',name=''){
      if(address){el('server').value=address;browser.reset();}
      open();el('code').value=String(code||'').trim().toUpperCase();el('join-password').value='';
      el('join-note').textContent=name?'Joining '+name+'. Enter the password if required.':'Enter the 16-character code from your friend. Passwords are required for protected rooms, including Steam invites.';
      showStep('code');
    }
    el('visibility').onchange=()=>{el('privacy-note').textContent=el('visibility').value==='friends'?'Hidden from the browser. Anyone with your invite or code can join; add a password for extra privacy.':'Public rooms appear in the browser. Anyone can join unless you set a password.';};
    el('pick-ghost').onclick=()=>{mode='ghost';showStep('size');paintSize();};
    el('pick-shared').onclick=()=>{mode='shared';showStep('size');paintSize();};
    el('mode-back').onclick=()=>showStep('choice');
    el('size').oninput=paintSize;
    el('size-back').onclick=()=>showStep('mode');
    el('create').onclick=run(()=>connect(''));
    el('join').onsubmit=run(()=>{const code=el('code').value.trim();if(!/^[a-f0-9]{16}$/i.test(code))throw Error('Enter the 16-character room code from your friend.');connect(code);});
    el('code-back').onclick=()=>{el('join-password').value='';showStep('choice');};
    el('back').onclick=close;access.onclick=open;
    el('leave').onclick=run(()=>{actions.leave();lastCode=null;lastChat='';showStep('choice');});
    function paintCollide(on, locked){const button=el('collide');button.setAttribute('aria-pressed',on?'true':'false');button.textContent='Player Collisions: '+(on?'On':'Off');button.disabled=!!locked;}
    el('collide').onclick=run(()=>{const next=el('collide').getAttribute('aria-pressed')!=='true';paintCollide(next,false);actions.setCollide(next);});
    el('lobby-ghost').onclick=run(()=>lab.setMode('ghost'));
    el('lobby-shared').onclick=run(()=>lab.setMode('shared'));
    function hideReadyAsk(){ask.hidden=true;}
    let closedLaunch=0;
    function hideForLevel(){opened=false;screen.hidden=true;browser.setActive(false);closeSettings();picker.hidden=true;document.activeElement?.blur();}
    function closeForTransition(id){
      if(!id||closedLaunch===id)return;
      closedLaunch=id;
      hideForLevel();
    }
    function clearRaceChrome(){
      restartAsk.hidden=true;
      results.hidden=true;
      charTags.hidden=true;
      charTags.replaceChildren();
      count.hidden=true;
      count.textContent='';
      hud.hidden=true;
    }
    function askReady(name){ask.querySelector('#mp-ready-copy').textContent=(name||'The host')+' is ready. Are you ready to race?';ask.hidden=false;}
    el('ready').onclick=run(()=>{
      if(lab.lobby().isHost)actions.ready();
      else (actions.readyVote||actions.ready)(true);
      close();
    });
    el('not-ready').onclick=run(()=>{actions.readyVote?.(false);close();});
    el('summon').onclick=run(actions.summon);
    el('world-reset').onclick=run(()=>actions.resetWorld());
    el('request-restart').onclick=run(()=>actions.requestRestartVote());
    restartAsk.querySelector('#mp-restart-yes').onclick=run(()=>actions.voteRestart(true));
    restartAsk.querySelector('#mp-restart-no').onclick=run(()=>actions.voteRestart(false));
    el('lobby-return').onclick=run(()=>actions.returnToLobby());
    el('retry-load').onclick=run(()=>actions.retryEntry());
    ask.querySelector('#mp-ready-yes').onclick=run(()=>{hideReadyAsk();(actions.readyVote||actions.ready)(true);});
    ask.querySelector('#mp-ready-no').onclick=run(()=>{hideReadyAsk();actions.readyVote?.(false);});
    el('choose').onclick=()=>openPicker();
    let pickerTab='featured',pickerPage=1,ruleSlots=0,pickerGeneration=0,hostedHasNext=false;
    const ruleWait=[];
    function withRuleSlot(work){
      return new Promise((resolve,reject)=>{
        const run=()=>{
          ruleSlots+=1;
          Promise.resolve().then(work).then(resolve,reject).finally(()=>{ruleSlots-=1;ruleWait.shift()?.();});
        };
        if(ruleSlots<3)run();else ruleWait.push(run);
      });
    }
    function paintRules(item,row){
      if(!/jhwmp/i.test(row.name))return;
      const box=document.createElement('div');
      box.className='reqs';
      const wait=document.createElement('span');
      wait.className='wait';
      wait.textContent='Reading rules…';
      box.append(wait);
      item.append(box);
      withRuleSlot(async()=>{
        if(!item.isConnected)return;
        const facts=await window.HWJimbobLevels.requirements(row.id,row);
        if(!item.isConnected)return;
        if(!facts.length){wait.textContent='No special rules';return;}
        box.replaceChildren(...facts.map(text=>{
          const chip=document.createElement('span');
          chip.textContent=text;
          if(text==='Survival')chip.className='survival';
          else if(/^(Solo|Forces )/.test(text))chip.className='seats';
          return chip;
        }));
      }).catch(()=>{if(item.isConnected)wait.textContent='Rules unavailable';});
    }
    function openPicker(){picker.hidden=false;loadPicker();}
    function closePicker(){picker.hidden=true;++pickerGeneration;}
    async function loadHostedPicker(ticket){
      const list=picker.querySelector('#lvl-list'),empty=document.createElement('p');empty.className='empty';empty.textContent='Loading multiplayer maps…';list.replaceChildren(empty);
      picker.querySelector('#lvl-filters').hidden=false;picker.querySelector('#lvl-note').hidden=false;
      picker.querySelector('#lvl-note').textContent='Community courses hosted on Jimbob Maps. Players only need Multiplayer.';
      picker.querySelector('#lvl-by').closest('.pick').hidden=true;picker.querySelector('#lvl-when').closest('.pick').hidden=true;
      picker.querySelector('#lvl-prev').hidden=false;picker.querySelector('#lvl-next').hidden=false;
      picker.querySelector('#lvl-id').placeholder='JM map code';picker.querySelector('#lvl-id').inputMode='text';
      picker.querySelector('#lvl-page').textContent='Page '+pickerPage;
      try{
        const result=await window.HWJimbobMaps.list({page:pickerPage,query:picker.querySelector('#lvl-search').value.trim(),sort:picker.querySelector('#lvl-sort').value});
        if(ticket!==pickerGeneration||picker.hidden)return;hostedHasNext=result.hasNext;
        picker.querySelector('#lvl-next').disabled=!hostedHasNext;picker.querySelector('#lvl-prev').disabled=pickerPage===1;
        if(!result.items.length){empty.textContent='No maps here yet. Publish your first course from Builder.';return;}
        list.replaceChildren(...result.items.map(row=>{
          const card=document.createElement('article');card.className='card hosted-card';
          const picture=document.createElement('div');picture.className='map-picture';picture.textContent='MULTIPLAYER MAPS';card.append(picture);
          if(row.preview)withRuleSlot(async()=>{if(ticket!==pickerGeneration||!card.isConnected)return;const src=await window.HWJimbobMaps.preview(row.meta);if(ticket!==pickerGeneration||!card.isConnected)return;const image=document.createElement('img');image.src=src;image.alt=row.name+' preview';picture.replaceChildren(image);}).catch(()=>{picture.textContent='Preview unavailable';});
          const title=document.createElement('h3');title.textContent=row.name;
          const by=document.createElement('p');by.textContent='by '+row.meta.author+' · revision '+row.meta.revision;
          const description=document.createElement('p');description.textContent=row.description;
          const rules=document.createElement('div');rules.className='reqs';
          for(const text of [row.rules?.play==='survival'?'Survival':'Race',row.rules?.seats?row.rules.seats+' players':'Players choose',row.rules?.rider?'Character '+row.rules.rider:'Any character']){const chip=document.createElement('span');chip.textContent=text;rules.append(chip);}
          const code=document.createElement('p');code.className='map-code';code.textContent=row.code;
          const button=document.createElement('button');button.textContent='Select map';button.type='button';
          button.onclick=run(async()=>{button.disabled=true;try{await actions.pickLevel(row);closePicker();}finally{button.disabled=false;}});
          card.append(title,by,description,rules,code,button);return card;
        }));
      }catch(e){if(ticket===pickerGeneration&&!picker.hidden)empty.textContent=e.message;}
    }
      async function loadPicker(){
        closeFilterMenus();
        const ticket=++pickerGeneration;
        const hosted=pickerTab==='hosted',sort=picker.querySelector('#lvl-sort');
        for(const option of sort.options){option.hidden=false;option.disabled=hosted&&!['newest','oldest'].includes(option.value);}
        if(hosted&&!['newest','oldest'].includes(sort.value))sort.value='newest';
        paintFilterMenu(sort);
        picker.querySelector('#lvl-search').placeholder=hosted?'Search map name or description':'Search name or author';
        picker.querySelector('#lvl-id').setAttribute('aria-label',hosted?'JM map code':'Level id');
        picker.querySelector('#lvl-id-go').textContent=hosted?'Use code':'Open id';
        for(const button of picker.querySelectorAll('#lvl-tabs button'))button.setAttribute('aria-selected',button.dataset.tab===pickerTab?'true':'false');
      if(pickerTab==='hosted')return loadHostedPicker(ticket);
      picker.querySelector('#lvl-by').closest('.pick').hidden=false;picker.querySelector('#lvl-when').closest('.pick').hidden=false;
      picker.querySelector('#lvl-note').textContent='Community maps with previews, map codes, and multiplayer rules. Players only need Multiplayer.';
      picker.querySelector('#lvl-id').placeholder='Level id';picker.querySelector('#lvl-id').inputMode='numeric';picker.querySelector('#lvl-next').disabled=false;picker.querySelector('#lvl-prev').disabled=false;
      const browsable=pickerTab==='custom';
      picker.querySelector('#lvl-filters').hidden=!browsable;
      picker.querySelector('#lvl-note').hidden=true;
      picker.querySelector('#lvl-prev').hidden=!browsable;
      picker.querySelector('#lvl-next').hidden=!browsable;
      for(const button of picker.querySelectorAll('#lvl-tabs button'))button.setAttribute('aria-selected',button.dataset.tab===pickerTab?'true':'false');
      picker.querySelector('#lvl-page').textContent=browsable?('Page '+pickerPage):'';
      const list=picker.querySelector('#lvl-list');
      const empty=document.createElement('p');empty.className='empty';empty.textContent='Loading maps…';
      list.replaceChildren(empty);
      try{
        let rows=browsable?await window.HWJimbobLevels.list({
          tab:'custom',
          page:pickerPage,
          query:picker.querySelector('#lvl-search').value.trim(),
          by:picker.querySelector('#lvl-by').value,
          sortby:picker.querySelector('#lvl-sort').value,
          uploaded:picker.querySelector('#lvl-when').value,
        }):(liveFeaturedRows()||await window.HWJimbobLevels.list({tab:'featured'}));
        if(!browsable&&rows.some(row=>!row.rating)){
          try{
            const listed=await window.HWJimbobLevels.list({tab:'featured'});
            const byId=new Map(listed.map(row=>[String(row.id),row.rating]));
            rows=rows.map(row=>row.rating?row:{...row,rating:byId.get(String(row.id))||''});
          }catch{}
        }
        if(ticket!==pickerGeneration||picker.hidden)return;
        if(!rows.length){empty.textContent='No maps on this page.';return;}
        list.replaceChildren(...rows.map(row=>{
          const item=document.createElement('article');
          item.className='card';
          if(/jhwmp/i.test(row.name)){const mark=document.createElement('span');mark.className='mark';mark.textContent='JHWMP';item.append(mark);}
          const title=document.createElement('h3');
          title.textContent=row.name;
          const meta=document.createElement('p');
          meta.textContent=(row.author?'by '+row.author:'Unknown author')+' · id '+row.id+(row.plays?' · '+row.plays+' plays':'');
          const multiplayer=/jhwmp/i.test(row.name);
          let rating=null;
          if(!multiplayer){
            rating=document.createElement('p');
            rating.className='rating';
            const score=Number(row.rating);
            if(Number.isFinite(score)&&score>0)rating.textContent='\u2605 '+Math.min(5,score).toFixed(1);
            else{rating.classList.add('none');rating.textContent='Unrated';}
          }
          const button=document.createElement('button');
          button.type='button';
          button.textContent='Select';
          button.onclick=run(async()=>{const picked=await window.HWJimbobLevels.inspect(row.id,row);await actions.pickLevel(picked);closePicker();});
          item.append(title,meta);
          if(rating)item.append(rating);
          paintRules(item,row);
          item.append(button);
          return item;
        }));
      }catch(err){empty.textContent=err.message||String(err);list.replaceChildren(empty);}
    }
    picker.querySelector('#lvl-close').onclick=closePicker;
    picker.querySelector('#lvl-tabs').onclick=event=>{const tab=event.target?.dataset?.tab;if(!tab)return;pickerTab=tab;pickerPage=1;loadPicker();};
    picker.querySelector('#lvl-go').onclick=run(()=>{pickerPage=1;return loadPicker();});
    picker.querySelector('#lvl-search').onkeydown=event=>{if(event.key==='Enter'){event.preventDefault();pickerPage=1;loadPicker();}};
    picker.querySelector('#lvl-sort').onchange=()=>{if(pickerTab!=='featured'){pickerPage=1;loadPicker();}};
    picker.querySelector('#lvl-when').onchange=()=>{if(pickerTab!=='featured'){pickerPage=1;loadPicker();}};
    picker.querySelector('#lvl-prev').onclick=()=>{pickerPage=Math.max(1,pickerPage-1);loadPicker();};
    picker.querySelector('#lvl-next').onclick=()=>{pickerPage+=1;loadPicker();};
    picker.querySelector('#lvl-id-go').onclick=run(async()=>{const code=picker.querySelector('#lvl-id').value.trim();const picked=pickerTab==='hosted'||/^JM-/i.test(code)?await window.HWJimbobMaps.inspect(code):await window.HWJimbobLevels.inspect(code);await actions.pickLevel(picked);closePicker();});
    el('lock').onclick=run(()=>actions.lockRoom(!lab.lobby().room?.locked));
    results.querySelector('#mp-again').onclick=run(()=>actions.raceAgain());
    results.querySelector('#mp-results-lobby').onclick=run(()=>actions.returnToLobby());
    results.querySelector('#mp-next-map').onclick=()=>{results.hidden=true;screen.hidden=false;opened=true;openPicker();};
    el('copy').onclick=run(async()=>{const code=lab.lobby().room?.code;if(!code)return;try{await navigator.clipboard.writeText(code);}catch{const input=document.createElement('textarea');input.value=code;screen.append(input);input.select();const ok=document.execCommand('copy');input.remove();if(!ok)throw Error('Select the room code and press Ctrl+C to copy.');}actions.message('Room code copied. Send it to your friends.');});
    el('steam').onclick=run(async()=>{await actions.steamInvite();actions.message('Steam invite window opened.');});
    el('chat-form').onsubmit=run(()=>{
      const box=el('chat');
      const text=box.value;
      if(!actions.sendChat)throw Error('Chat is not connected.');
      actions.sendChat(text);
      box.value='';
    });
    el('chat-key').value=chatKeyNow().toUpperCase();
    el('save').onclick=run(async()=>{
      await mapsSettingsReady;const url=new URL(el('server').value.trim());if(!['ws:','wss:'].includes(url.protocol))throw Error('Use a ws:// or wss:// server address.');const next=String(el('chat-key').value||'t').trim().slice(0,1).toLowerCase();if(!/^[a-z0-9]$/.test(next))throw Error('Use one letter or number for the chat key.');
      mapsSettingsRead++;const settings=await window.HWJimbobMaps.configure({base:el('maps-server').value.trim()});el('maps-server').value=settings.base;save('hw-maps-server',settings.base);chatKey=next;save('hw-mp-chat-key',chatKey);el('chat-key').value=chatKey.toUpperCase();save('hw-mp-server',url.href);browser.reset();closeSettings();actions.message('Settings saved. The chat key is '+chatKey.toUpperCase()+'. The server address applies to your next connection.');});
    el('server-default').onclick=()=>{el('server').value=railwayUrl;save('hw-mp-server',railwayUrl);browser.reset();};
    el('local').onclick=run(async()=>{
      mapsSettingsRead++;el('server').value=localRelayUrl;el('maps-server').value='http://127.0.0.1:19798';
      const settings=await window.HWJimbobMaps.configure({base:el('maps-server').value});
      el('maps-server').value=settings.base;save('hw-maps-server',settings.base);save('hw-mp-server',localRelayUrl);
      browser.reset();actions.message('Local Multiplayer and Jimbob Maps selected on port 19798. Start the Maps service first. This applies to your next connection.');
    });
    const openSecond=run(async()=>{if(!actions.openSecond)throw Error('Second window is not available.');await actions.openSecond();actions.message('Second window opened. Join this room from that window.');});
    el('second-settings').onclick=openSecond;
    el('settings-close').onclick=closeSettings;
    function typing(node){const tag=(node?.tagName||'').toLowerCase();return tag==='input'||tag==='textarea';}
    for(const event of ['keydown','keyup'])window.addEventListener(event,e=>{
      if(!opened){
        if(event==='keydown'&&!typing(e.target)){
          if(document.activeElement&&(screen.contains(document.activeElement)||document.activeElement===access))document.activeElement.blur();
          if(e.defaultPrevented)return;
          if(e.code==='KeyR'){
            if(lab.requestRestartVote?.()){e.preventDefault();e.stopImmediatePropagation();return;}
            lab.onLocalRestart?.();return;
          }
          if(e.key==='Escape'){lab.allowGameMenu?.();return;}
          if(e.key==='['||e.key===']'){e.preventDefault();e.stopImmediatePropagation();lab.cycleSpectate?.(e.key===']');}
        }
        return;
      }
      if(e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();if(event==='keydown'){if(!picker.hidden)closePicker();else if(!el('settings').hidden)closeSettings();else close();}return;}
      if(event==='keydown'&&e.key==='='&&!typing(e.target)&&picker.hidden){e.preventDefault();toggleSettings();}
      e.stopImmediatePropagation();
    },true);
    function nodeVisible(node){
      if(!node)return false;
      if(node.visible===false||node.alpha===0)return false;
      if(typeof node.worldVisible==='boolean'&&!node.worldVisible)return false;
      return true;
    }
    function collectTexts(node,out,depth,seen){
      if(!node||depth>8||seen.has(node)||!nodeVisible(node))return;
      seen.add(node);
      const text=node.text??node.textField?.text??node.label;
      if(text)out.push(String(text).replace(/\s+/g,' ').trim());
      for(const child of node.children||[])collectTexts(child,out,depth+1,seen);
      if(node.pixiSprite)collectTexts(node.pixiSprite,out,depth+1,seen);
      if(node.textField)collectTexts(node.textField,out,depth+1,seen);
    }
    function explorerOpen(hw){
      const texts=[];
      try{
        collectTexts(hw,texts,0,new Set());
        collectTexts(lab.state.rootApp?.stage,texts,0,new Set());
      }catch{}
      return texts.some(text=>/featured\s*levels?|user\s*(?:submitted\s*)?levels?|level\s*browser|play\s*now|view\s*level\s*replay/i.test(text));
    }
    function isTitleMenu(){
      window.HWNativeUI?.repair?.();
      const hw=lab.state.rootApp.screenManager.currentScreen?.happyWheels;
      return !!window.HWNativeUI?.titleVisible(hw,lab.state.currentSession)&&!explorerOpen(hw);
    }
    function titleButton(reference,label){
      const format=reference.textField?.defaultTextFormat||{};
      const button=new reference.constructor(label,format.size,format.color);
      try{if(button.bg&&reference.bg&&Number.isFinite(reference.bg.width)){button.bg.width=reference.bg.width;button.bg.height=reference.bg.height;}}catch{}
      try{if(button.textField&&reference.textField&&Number.isFinite(reference.textField.width))button.textField.width=reference.textField.width;}catch{}
      return button;
    }
    function armTitleButton(button){
      if(!button)return;
      if(!button.__jmpPixi){
        button.__jmpPixi=true;
        const fire=()=>{try{button.__jmpFire?.();}catch{}};
        for(const sprite of [button._pixiSprite||button.pixiSprite,button.textField?._pixiSprite||button.textField?.pixiSprite]){
          if(!sprite||sprite.__jmpArmed)continue;
          sprite.__jmpArmed=true;
          try{sprite.on('pointertap',fire);}catch{}
          try{sprite.on('pointerup',fire);}catch{}
        }
        try{button.textField?.addEventListener?.('click',fire);}catch{}
        try{button.textField?.addEventListener?.('mouseUp',fire);}catch{}
      }
      try{button.mouseEnabled=true;}catch{}
      try{button.buttonMode=true;}catch{}
    }
    function titleButtonReady(button){
      const width=[button?.bg?.width,button?._bgWidth,button?.width].find(n=>Number.isFinite(n)&&n>40&&n<800);
      return width!=null;
    }
    function showMenuButton(button,on){
      if(!button)return;
      for(const node of [button,button.pixiSprite,button.textField,button.textField?.pixiSprite]){
        if(!node)continue;
        try{node.visible=on;}catch{}
        try{node.renderable=on;}catch{}
        try{node.alpha=on?1:0;}catch{}
      }
      if(on)armTitleButton(button);
      else{
        try{button.mouseEnabled=false;}catch{}
        const sprite=button._pixiSprite||button.pixiSprite;
        if(sprite){try{sprite.eventMode='none';}catch{}try{sprite.interactive=false;}catch{}}
      }
    }
    function buttonAlive(button){
      if(!button||button.destroyed||button._destroyed)return false;
      const node=button.pixiSprite||button;
      return !!(node&&!node.destroyed&&!node._destroyed);
    }
    function placeMenuButton(menu,on){
      const button=menu.multiplayerBtn;
      if(!button)return;
      if(on&&!button.parent&&!button.pixiSprite?.parent){
        try{menu.addChild(button);}catch{}
      }
      const list=menu.buttons;
      const index=list?list.indexOf(button):-1;
      if(on){
        if(list&&index<0){
          const creator=menu.characterCreatorBtn;
          const at=creator&&list.includes(creator)?list.indexOf(creator):list.indexOf(menu.optionsBtn);
          list.splice(at<0?list.length:at,0,button);
          menu.spaceHeight=(menu.spaceHeight||0)+(menu.buttonSpacing||0);
          try{menu.organizeButtons();}catch{}
        }
        showMenuButton(button,true);
        button.x=menu.optionsBtn.x;
      }else{
        if(list&&index>=0){
          list.splice(index,1);
          menu.spaceHeight=Math.max(0,(menu.spaceHeight||0)-(menu.buttonSpacing||0));
          try{menu.organizeButtons();}catch{}
        }
        showMenuButton(button,false);
      }
    }
    function fitMenu(menu){
      const list=menu?.buttons;
      if(!Array.isArray(list)||list.length<2||typeof menu.organizeButtons!=='function')return;
      if(!Number.isFinite(menu.__jmpBaseSpacing))menu.__jmpBaseSpacing=menu.buttonSpacing;
      const base=menu.__jmpBaseSpacing;
      if(!Number.isFinite(base)||base<=0)return;
      const last=list[list.length-1];
      const node=last?.pixiSprite||last;
      const bounds=node?.getBounds?.();
      const height=lab.state.rootApp.renderer.screen?.height||lab.state.rootApp.renderer.height;
      if(!bounds||!height)return;
      const over=bounds.y+bounds.height-(height-8);
      const current=menu.buttonSpacing;
      let next=current;
      if(over>1)next=Math.max(base*0.62,current-Math.ceil(over/(list.length-1)));
      else if(over<-12&&current<base)next=Math.min(base,current+1);
      if(Math.abs(next-current)<0.5)return;
      menu.buttonSpacing=next;
      menu.spaceHeight=(list.length-1)*next;
      try{menu.organizeButtons();}catch{}
    }
    function menuButtonLive(){
      const menu=lab.state?.rootApp?.screenManager?.currentScreen?.happyWheels?.mainMenu;
      const button=menu?.multiplayerBtn;
      const node=button?.pixiSprite||button;
      return !!(isTitleMenu()&&buttonAlive(button)&&(button.parent||node?.parent)&&button.__jmpBound&&menu.buttons?.includes(button));
    }
    function retireMenuButton(menu){
      const button=menu?.multiplayerBtn;
      if(!button)return;
      try{button.removeEventListener?.('click',button.__jmpFire||button.__jmpOpen||open);}catch{}
      try{menu.removeChild?.(button);}catch{}
      const list=menu.buttons;
      const index=list?.indexOf(button);
      if(index>=0)list.splice(index,1);
      menu.multiplayerBtn=null;
    }
    function installMenu(){
      window.HWNativeUI?.repair?.();
      const menu=lab.state?.rootApp?.screenManager?.currentScreen?.happyWheels?.mainMenu;
      if(!menu?.optionsBtn||!Array.isArray(menu.buttons))return;
      const onTitle=isTitleMenu();
      const current=menu.multiplayerBtn;
      const belongs=current&&(current.parent===menu||current.pixiSprite?.parent===menu.pixiSprite||current.pixiSprite?.parent===menu);
      if(current&&(!buttonAlive(current)||!belongs||!current.__jmpBound||!titleButtonReady(current)))retireMenuButton(menu);
      if(menu.multiplayerBtn){
        const list=menu.buttons;
        const hits=list.filter(entry=>entry===menu.multiplayerBtn).length;
        if(onTitle&&hits!==1){
          for(let i=list.length-1;i>=0;i--)if(list[i]===menu.multiplayerBtn)list.splice(i,1);
          const creator=menu.characterCreatorBtn;
          const at=creator&&list.includes(creator)?list.indexOf(creator):list.indexOf(menu.optionsBtn);
          list.splice(at<0?list.length:at,0,menu.multiplayerBtn);
        }
        placeMenuButton(menu,onTitle);
        if(onTitle)fitMenu(menu);
        return;
      }
      if(!onTitle)return;
      const reference=menu.optionsBtn;
      const button=titleButton(reference,'MULTIPLAYER');
      button.x=reference.x;
      const fire=()=>open();
      button.__jmpOpen=fire;
      button.__jmpFire=fire;
      button.__jmpBound=true;
      button.addEventListener('click',fire);
      armTitleButton(button,reference);
      menu.multiplayerBtn=button;
      menu.addChild(button);
      const before=menu.characterCreatorBtn&&menu.buttons.includes(menu.characterCreatorBtn)?menu.characterCreatorBtn:reference;
      const at=menu.buttons.indexOf(before);
      menu.buttons.splice(at<0?menu.buttons.length:at,0,button);
      menu.spaceHeight+=menu.buttonSpacing;
      try{menu.organizeButtons();}catch{}
      fitMenu(menu);
    }
    function playerCard(p,s,room){
      const li=document.createElement('li');
      li.className='player-card';
      const avatar=s.avatars?.[p.id]||(p.id===s.selfId?(s.avatars?.self||s.steam?.avatar):'');
      if(avatar){
        const img=document.createElement('img');
        img.className='avatar';
        img.alt='';
        img.src=avatar;
        li.append(img);
      }else{
        const fallback=document.createElement('span');
        fallback.className='avatar-fallback';
        fallback.textContent=(p.name||'?').slice(0,1).toUpperCase();
        li.append(fallback);
      }
      const body=document.createElement('div');
      const name=document.createElement('b');
      name.textContent=p.name+(p.id===s.selfId?' (you)':'');
      const meta=document.createElement('span');
      meta.className='meta';
      const phase=p.id===s.selfId?s.phase:p.phase;
      const rider=p.character&&window.HWJimbobCourse?.riderName?.(p.character);
      const locked=room.rules?.rider&&!p.character;
      const step=!room.meta?'In lobby':!room.launched?(p.ready?'Ready':'In lobby'):rider?'Picked '+rider:phase==='ingame'||p.loaded?'On level':phase==='loading'?'Loading':locked?'Locked character':'Choosing a character';
      meta.textContent=[p.id===room.hostId?'Host':'',step].filter(Boolean).join(' \u00b7 ');
      body.append(name,meta);
      li.append(body);
      if(s.isHost&&p.id!==s.selfId&&!s.raceStart){
        const tools=document.createElement('div');
        tools.className='actions';
        const kick=document.createElement('button');
        kick.type='button';kick.textContent='Kick';
        kick.onclick=()=>actions.kick(p.id);
        const promote=document.createElement('button');
        promote.type='button';promote.textContent='Make host';
        promote.onclick=()=>actions.promote(p.id);
        tools.append(kick,promote);
        li.append(tools);
      }
      return li;
    }
    function paintChat(s){
      const log=el('chat-log');
      const key=JSON.stringify(s.chat||[]);
      if(key===lastChat)return;
      lastChat=key;
      log.replaceChildren(...(s.chat||[]).map(m=>{
        const p=document.createElement('p');
        const who=document.createElement('span');
        who.className='who';
        who.textContent=m.name||'Racer';
        p.append(who,document.createTextNode(': '+m.text));
        return p;
      }));
      log.scrollTop=log.scrollHeight;
    }
    function paintPlayChat(s){
      playChat.classList.toggle('above-hud', !!hud&&!hud.hidden);
      const rows=s.chat||[];
      if(!s.room){
        clearTimeout(chatTimer);
        if(playRows||playInput.value||chatMode!=='hidden'){
          playRows=0;playLog.replaceChildren();playInput.value='';playJump.hidden=true;playNotice.hidden=true;setChatMode('hidden');
        }
        return;
      }
      if(rows.length<playRows){playLog.replaceChildren();playRows=0;}
      const near=playLog.scrollHeight-playLog.scrollTop-playLog.clientHeight<28;
      const start=playRows;
      for(let i=start;i<rows.length;i++){
        const row=document.createElement('p');
        const who=document.createElement('span');
        who.className='who';
        who.textContent=rows[i].name||'Racer';
        row.append(who, document.createTextNode(' '+rows[i].text));
        playLog.append(row);
      }
      playRows=rows.length;
      if(playRows>start){
        if(near){playLog.scrollTop=playLog.scrollHeight;playJump.hidden=true;}
        else playJump.hidden=false;
        if(chatMode!=='typing')armChatHide();
      }
    }
    function paintResults(s){
      const rows=s.results;
      const show=Array.isArray(rows)&&rows.length&&!s.raceStart;
      results.hidden=!show;
      if(!show)return;
      const list=results.querySelector('#mp-results-list');
      list.replaceChildren(...rows.map(row=>{
        const li=document.createElement('li');
        const who=document.createElement('span');
        who.textContent=(row.place?row.place+'. ':'')+(row.name||'Racer');
        const time=document.createElement('span');
        time.textContent=row.finished&&row.time!=null?(row.time/1000).toFixed(2)+'s':'DNF';
        li.append(who,time);
        return li;
      }));
      results.querySelector('#mp-again').hidden=!s.isHost;
      results.querySelector('#mp-next-map').hidden=!s.isHost;
      results.querySelector('#mp-results-lobby').hidden=!s.isHost;
    }
    function iconChoice(icon){
      if(!icon)return null;
      if(icon.__customCharacter?.base)return {characterId:Number(icon.__customCharacter.base),skinId:String(icon.__customCharacter.id||'')};
      const index=Number(icon.index);
      if(Number.isInteger(index)&&index>=1&&index<=11)return {characterId:index,skinId:''};
      for(const key of ['characterID','characterId','charID','charId']){
        const n=Number(icon[key]);
        if(Number.isInteger(n)&&n>=1&&n<=11)return {characterId:n,skinId:''};
      }
      return null;
    }
    function badgeColor(id){
      const palette=['#ff5d73','#49c6ff','#ffe14a','#8dff8a','#d58bff','#ff9a4a','#7ee0c6','#ff8ad4'];
      let hash=0;
      for(const ch of String(id||''))hash=hash*33+ch.charCodeAt(0);
      return palette[Math.abs(hash)%palette.length];
    }
    function paintCharacterTags(s){
      actions.holdSelection?.();
      const room=s.room;
      const menu=lab.state?.rootApp?.screenManager?.currentScreen?.happyWheels?.sessionController?.characterMenu;
      const show=!!(room?.phase==='selecting'&&menu?.parent);
      charTags.hidden=!show;
      if(!show){charTags.replaceChildren();return;}
      const view=lab.state.rootApp.renderer.view||lab.state.rootApp.view;
      const rect=view?.getBoundingClientRect?.();
      const sw=lab.state.rootApp.renderer.screen?.width||lab.state.rootApp.renderer.width||rect?.width||1;
      const sh=lab.state.rootApp.renderer.screen?.height||lab.state.rootApp.renderer.height||rect?.height||1;
      const marks=[];
      for(const icon of menu.icons||[]){
        const choice=iconChoice(icon);
        if(!choice||!rect)continue;
        const picked=(room.players||[]).filter(player=>{
          const id=Number(player.confirmed??player.character);
          const skin=player.skin||'';
          return id===choice.characterId&&skin===choice.skinId;
        });
        if(!picked.length)continue;
        const node=icon.pixiSprite||icon;
        const bounds=node.getBounds?.();
        if(!bounds)continue;
        const left=rect.left+bounds.x*(rect.width/sw);
        const top=rect.top+bounds.y*(rect.height/sh);
        const width=bounds.width*(rect.width/sw);
        const height=bounds.height*(rect.height/sh);
        const pick=document.createElement('div');
        pick.className='pick';
        pick.style.left=Math.round(left)+'px';
        pick.style.top=Math.round(top)+'px';
        pick.style.width=Math.round(width)+'px';
        const names=document.createElement('div');
        names.className='names';
        const shown=picked.slice(0,3);
        for(const player of shown){
          const name=document.createElement('span');
          name.className='name';
          const you=player.id===s.selfId;
          name.textContent=(player.name||'Racer')+(you?' (You)':'');
          name.style.background=badgeColor(player.id);
          names.append(name);
        }
        if(picked.length>shown.length){
          const more=document.createElement('span');
          more.className='name';
          more.textContent='+'+(picked.length-shown.length)+' more';
          more.title=picked.map(player=>(player.name||'Racer')+(player.id===s.selfId?' (You)':'')).join('\n');
          more.style.background='#24323c';
          more.style.pointerEvents='auto';
          names.append(more);
        }
        const box=document.createElement('div');
        box.className='box'+(picked.some(player=>player.id===s.selfId)?' you':'');
        box.style.width=Math.round(width)+'px';
        box.style.height=Math.round(height)+'px';
        pick.append(names,box);
        marks.push(pick);
      }
      charTags.replaceChildren(...marks);
    }
    function refresh(){
      const s=lab.lobby(),room=s.room,host=room?.hostId===s.selfId;
      paintRestartVote(room,s.selfId);
      el('entry').hidden=!!room;el('lobby').hidden=!room;
      el('connect').disabled=s.connecting||joinBusy;el('create').disabled=s.connecting||joinBusy;
      browser.setActive(opened&&step==='choice'&&!room&&!s.connecting&&!joinBusy);
      el('status').textContent='';
      el('title').textContent=room?'Your lobby':({choice:'Multiplayer',mode:'Pick your mode',size:'Make it your room',code:'Join a room'}[step]||'Multiplayer');
      screen.classList.toggle('mp-centered',!room&&(step==='mode'||step==='size'||step==='code'));
      if(!room)hideReadyAsk();
      if(room){
        el('host-password').value='';el('join-password').value='';
        el('lobby-name').textContent=room.name||'Happy Wheels room';
        el('room-privacy').textContent=room.solo?'Solo · only you are in this room':(room.visibility==='public'?'Public · shown in the browser':'Friends only · invite or code')+(room.passwordProtected?' · Password protected':'');
        const modeLocked=!!(room.start||room.checking||(room.launchId&&!room.results));
        for(const [button,kind] of [['lobby-ghost','ghost'],['lobby-shared','shared']]){el(button).setAttribute('aria-pressed',String(room.mode===kind));el(button).disabled=!host||modeLocked||room.mode===kind;}
        const modeNote=!host?'The host chooses the mode.':modeLocked?'Back to lobby to change modes.':'';
        el('mode-note').hidden=!modeNote;el('mode-note').textContent=modeNote;
        el('room-code').textContent=room.code;
        const shared=room.mode==='shared';
        const alone=!!room.solo||(room.capacity===1&&room.players.length===1);
        el('room-kind').textContent=(shared?'Shared Physics · Experimental':'Ghost Multiplayer')+(alone?' · Solo':'');
        const steam=s.steam||{};
        const course=s.course;
        el('steam-note').hidden=!!steam.ok;
        el('steam-note').textContent=steam.ok?'':(steam.error||'Steam is unavailable. Using '+playerName()+' until Steam is connected.');
        el('collide').hidden=!shared||!host;
        if(course?.bump!=null)paintCollide(!!course.bump,true);
        else if(lastCode!==room.code)paintCollide(s.collide!==false,false);
        else el('collide').disabled=false;
        const players=JSON.stringify(room.players)+s.phase+s.allInGame+JSON.stringify(s.avatars);if(players!==lastPlayers){lastPlayers=players;el('players').replaceChildren(...room.players.map(p=>playerCard(p,s,room)));}
        paintChat(s);
        paintPlayChat(s);
        const pick=room.pick||room.meta;
        const rules=room.rules||{};
        const ruleBits=[];
        if(rules.play==='survival')ruleBits.push('last rider standing');
        if(rules.waitSec)ruleBits.push(rules.waitSec+'s countdown');
        if(rules.seats)ruleBits.push(rules.seats+' seats');
        if(rules.rider)ruleBits.push('locked '+(window.HWJimbobCourse?.riderName?.(rules.rider)||'rider'));
        if(rules.lingerMs)ruleBits.push(Math.round(rules.lingerMs/1000)+'s finish window');
        else if(pick)ruleBits.push('45s finish window');
        el('level').textContent=pick?( (pick.title||('Level '+pick.level))+(pick.author?' by '+pick.author:'')+' · '+pick.level+(ruleBits.length?' · '+ruleBits.join(' · '):'') ):'No level selected yet.';
        el('course').hidden=!course;
        el('course').textContent=course?(course.summary+(course.warnings?.length?' · '+course.warnings[0]:'')):'';
        el('choose').hidden=!host;el('lock').hidden=!host;el('lock').textContent=room.locked?'Unlock lobby':'Lock lobby';
        const away=!!(room.launchId||room.launched||room.phase==='selecting'||room.phase==='loading'||room.phase==='countdown'||room.phase==='racing'||room.phase==='results'||s.raceStart||s.inLevel);
        el('lobby-return').hidden=!host||!away;
        el('retry-load').hidden=!s.canRetry;
        el('summon').hidden=!host;el('summon').disabled=!s.inLevel||s.loading;
        const survival=rules.play==='survival'||course?.play==='survival';
        const canRestart=survival&&!!room.launchId&&!!(room.start||room.results);
        el('world-reset').hidden=!shared||!host||canRestart;el('world-reset').disabled=!s.inLevel||s.loading;
        el('request-restart').hidden=!canRestart;el('request-restart').disabled=!!room.restartVote;
        if(canRestart)el('summon').hidden=true;
        el('ready').hidden=!!s.raceStart||!!(room.launched&&room.gate);
        el('ready').disabled=host?(!s.canReady||s.ready):(!s.canVoteReady||s.ready);
        el('ready').textContent=s.ready?(alone?'Starting\u2026':'Waiting for players\u2026'):(alone?'Start':'Ready');
        el('not-ready').hidden=host||!!s.raceStart||s.ready;
        el('not-ready').disabled=!(s.canDecline||s.canVoteReady);
        const hostPlayer=room.players.find(p=>p.id===room.hostId);
        if(!host&&!s.ready&&!s.raceStart&&(s.readyCheck||s.checking))askReady(hostPlayer?.name);
        else if(host||s.ready||s.raceStart||!(s.readyCheck||s.checking))hideReadyAsk();
        if(pendingLevel&&host&&!room.launched&&!room.meta){
          const level=pendingLevel;pendingLevel=null;
          actions.pickLevel(level).catch(err=>actions.message(err.message||String(err)));
        }
        if(lastCode!==room.code){lastCode=room.code;lastChat='';open();return;}
      }
      const hw=lab.state.rootApp.screenManager.currentScreen?.happyWheels;
      const nativeMenu=!!(hw?.mainMenu&&!hw.sessionController&&!hw.editor&&window.HWNativeUI?.attached(hw.mainMenu)&&window.HWNativeUI?.visible(hw.mainMenu));
      access.hidden=opened||!hw||nativeMenu||menuButtonLive();
      toast.textContent='';
      const start=s.raceStart;const started=start&&start!==lastStart;lastStart=start;if(started)close();
      if(start&&!s.released&&s.remaining!=null){
        count.hidden=false;
        if(s.remaining>80){count.classList.remove('go');count.textContent=String(Math.max(1,Math.ceil(s.remaining/1000)));}
        else{count.classList.add('go');count.textContent='GO';goUntil=Date.now()+800;}
      }else if(Date.now()<goUntil){count.hidden=false;count.classList.add('go');count.textContent='GO';}
      else if(!count.hidden){count.hidden=true;count.textContent='';count.classList.remove('go');}
      paintHud();
      paintResults(s);
      paintCharacterTags(s);
    }
    function paintRestartVote(room,selfId){
      const vote=room?.restartVote;
      restartAsk.hidden=!vote;if(!vote)return;
      const players=vote.players||[],waiting=players.filter(p=>!p.yes),me=players.find(p=>p.id===selfId);
      const requester=players.find(p=>p.id===vote.requesterId)?.name||'A player';
      restartAsk.querySelector('#mp-restart-requester').textContent=requester+' requested a restart. Everyone must agree.';
      restartAsk.querySelector('#mp-restart-progress').textContent=(players.length-waiting.length)+' / '+players.length+' agreed'+(waiting.length?' · Waiting for '+waiting.map(p=>p.name).join(', '):'');
      restartAsk.querySelector('#mp-restart-time').textContent=(me?.yes?'You voted Yes. ':'')+Math.max(0,Math.ceil((vote.expiresAt-Date.now())/1000))+' seconds remaining';
      restartAsk.querySelector('#mp-restart-yes').disabled=!me||!!me.yes;
      restartAsk.querySelector('#mp-restart-no').disabled=!me;
    }
    let pendingLevel=null;
    function screenRoot(){
      return lab.state?.rootApp?.screenManager?.currentScreen?.happyWheels||null;
    }
    function isGameButton(node){
      return !!(node&&typeof node==='object'&&(node.pixiSprite||node.textField||typeof node.text==='string'));
    }
    let cachedButtonClass=null;
    function gameButtonClass(){
      if(cachedButtonClass)return cachedButtonClass;
      const req=lab.require||window.HWMod?.require;
      if(typeof req!=='function')return null;
      try{
        const ui=req(0x3432);
        if(ui&&typeof ui.Ch==='function'){cachedButtonClass=ui.Ch;return cachedButtonClass;}
      }catch{}
      return null;
    }
    function textButtonClass(menu){
      const panel=findUserPanel(menu?.levelBrowser);
      const samples=[panel?.viewReplaysButton,panel?.authorLevelsButton,menu?.levelBrowser?.searchButton];
      for(const sample of samples){
        if(isGameButton(sample)){cachedButtonClass=sample.constructor;return cachedButtonClass;}
      }
      return gameButtonClass()||window.HWJimbobLevels.buttonClass||null;
    }
    function findUserPanel(browser){
      if(!browser)return null;
      if(browser.playButton&&browser.viewReplaysButton)return browser;
      if(browser.levelSelection?.playButton)return browser.levelSelection;
      for(const key of Object.keys(browser)){
        const value=browser[key];
        if(!value||typeof value!=='object'||key==='parent')continue;
        if(value.levelSelection?.playButton)return value.levelSelection;
        if(value.playButton&&value.viewReplaysButton)return value;
      }
      return null;
    }
    function bindLobbyButton(btn, runClick){
      btn.interactive=true;
      btn.buttonMode=true;
      if('eventMode' in btn)btn.eventMode='static';
      const fire=event=>{event?.stopPropagation?.();runClick().catch(err=>actions.message(err.message||String(err)));};
      for(const name of ['pointerup','mouseup','pointertap','click']){
        try{btn.addEventListener?.(name, fire);}catch{}
      }
    }
    function positionDom(screen){
      const el=screen.__jmpLobby;
      const anchor=screen.__jmpAnchor?.pixiSprite||screen.__jmpAnchor;
      const view=lab.state?.rootApp?.renderer?.view||lab.state?.rootApp?.view;
      const rect=view?.getBoundingClientRect?.();
      const bounds=anchor?.getBounds?.();
      if(!el?.style||!rect)return;
      const sw=lab.state.rootApp.renderer.screen?.width||rect.width||1;
      const sh=lab.state.rootApp.renderer.screen?.height||rect.height||1;
      if(!bounds||!bounds.width){
        el.style.left=Math.round(rect.left+rect.width*0.58)+'px';
        el.style.top=Math.round(rect.top+rect.height*0.72)+'px';
      }else{
        el.style.left=Math.round(rect.left+bounds.x*(rect.width/sw))+'px';
        el.style.top=Math.round(rect.top+(bounds.y+bounds.height+6)*(rect.height/sh))+'px';
      }
      el.hidden=!screen.parent||screen.visible===false||screen.x<-40;
    }
    const LOBBY_GREEN=0x3fb53f;
    function paintFill(g,color){
      if(!g||typeof g!=='object')return;
      const data=g.geometry?.graphicsData||g.graphicsData;
      if(!Array.isArray(data)||!data.length)return;
      let changed=false;
      for(const item of data){
        if(item.fillStyle&&item.fillStyle.visible!==false&&item.fillStyle.color!==color){item.fillStyle.color=color;changed=true;}
        else if(typeof item.fillColor==='number'&&item.fillColor!==color){item.fillColor=color;changed=true;}
      }
      if(!changed)return;
      try{g.geometry?.invalidate?.();}catch{}
      if(typeof g.dirty==='number')g.dirty++;
      if(typeof g.clearDirty==='number')g.clearDirty++;
      if(g.geometry&&typeof g.geometry.dirty==='number')g.geometry.dirty++;
    }
    function tintButton(btn,color){
      const seen=new Set();
      const tint=0x6dff6d;
      const walk=(node,depth)=>{
        if(!node||typeof node!=='object'||seen.has(node)||depth>6)return;
        seen.add(node);
        const isText=typeof node.text==='string'||node._text!=null||node.style?.fontFamily;
        if(node.geometry||node.graphicsData)paintFill(node,color);
        if(node.graphics)paintFill(node.graphics,color);
        if(!isText&&node.texture&&typeof node.tint==='number'&&node.tint!==tint)node.tint=tint;
        for(const child of node.children||[])walk(child,depth+1);
        if(node.pixiSprite)walk(node.pixiSprite,depth+1);
      };
      walk(btn,0);
    }
    function placeLobbyButton(screen, anchor, label, color, runClick, layout){
      if(!anchor||!screen)return;
      if(screen.__jmpLobby?.style){
        if(!screen.__jmpCtor){positionDom(screen);return;}
        screen.__jmpLobby.remove();
        screen.__jmpLobby=null;
      }
      if(screen.__jmpLobby?.parent){tintButton(screen.__jmpLobby,color);return;}
      const Ctor=screen.__jmpCtor;
      let btn=null;
      if(Ctor){try{btn=new Ctor(label, color, layout?.width||0xa6, 0xffffff);}catch{btn=null;}}
      if(isGameButton(btn)){
        screen.__jmpLobby=btn;
        (anchor.parent||screen).addChild(btn);
        if(layout?.scale&&btn.scale?.set)btn.scale.set(layout.scale);
        else if(layout?.scale&&btn.pixiSprite?.scale?.set)btn.pixiSprite.scale.set(layout.scale);
        btn.x=layout?.x??anchor.x;
        btn.y=layout?.y??(anchor.y+30);
        if(btn.parent?.setChildIndex)btn.parent.setChildIndex(btn, btn.parent.children.length-1);
        bindLobbyButton(btn, runClick);
        tintButton(btn,color);
        layout?.after?.(btn);
        return;
      }
      const el=document.createElement('button');
      el.type='button';
      el.textContent=label;
      el.style.cssText='position:fixed;z-index:10020;background:#'+color.toString(16).padStart(6,'0')+';color:#fff;border:2px solid #2b241c;border-radius:4px;font:700 15px Trebuchet MS,sans-serif;padding:7px 12px;cursor:pointer';
      document.body.append(el);
      el.onclick=()=>runClick().catch(err=>actions.message(err.message||String(err)));
      screen.__jmpLobby=el;
      screen.__jmpAnchor=anchor;
      positionDom(screen);
    }
    function featuredRow(entry){
      const id=String(entry?.id??entry?._id??'');
      if(!/^[1-9][0-9]{0,8}$/.test(id))return null;
      return {
        id,
        name:String(entry.name||entry.level_name||entry._name||('Level '+id)),
        author:String(entry.author_name||entry.authorName||entry.author||entry.username||entry._author_name||''),
        plays:entry.plays||entry._plays||'',
        rating:entry.rating||entry.rg||entry._rating||'',
      };
    }
    function featuredLevelArray(featured){
      if(!featured)return null;
      const nodes=[featured.constructor,featured,Object.getPrototypeOf(featured)];
      for(const node of nodes){
        if(!node)continue;
        const direct=node.levelDataArray;
        if(Array.isArray(direct)&&direct.some(featuredRow))return direct;
        let fallback=null;
        try{
          for(const key of Object.keys(node)){
            const value=node[key];
            if(!Array.isArray(value)||!value.length||value.length>500||!value.some(featuredRow))continue;
            if(/levelData|featured/i.test(key))return value;
            fallback=fallback||value;
          }
        }catch{}
        if(fallback)return fallback;
      }
      return null;
    }
    function liveFeaturedRows(){
      const hw=screenRoot();
      const menu=hw?.mainMenu||hw;
      const featured=menu?.featuredMenu||hw?.featuredMenu;
      const data=featuredLevelArray(featured);
      if(!data?.length)return null;
      const rows=data.map(featuredRow).filter(Boolean);
      return rows.length?rows:null;
    }
    function featuredRecord(featured){
      const item=featured?.currentItem;
      const dataList=featuredLevelArray(featured);
      if(!item||!dataList)return null;
      let index=featured.featuredList?.indexOf?.(item)??-1;
      if(index<0){
        const saved=Number(featured.lastItemIndex??featured.constructor?.lastItemIndex);
        if(Number.isInteger(saved)&&saved>=0&&saved<dataList.length)index=saved;
      }
      if(index<0||index>=dataList.length)return null;
      return featuredRow(dataList[index]);
    }
    function installBrowserButtons(){
      const hw=screenRoot();
      if(!hw)return;
      const menu=hw.mainMenu||hw;
      const ctor=textButtonClass(menu);
      if(ctor)window.HWJimbobLevels.buttonClass=ctor;
      const featured=menu.featuredMenu||hw.featuredMenu;
      if(featured?.viewReplaysBtn&&featured.parent){
        featured.__jmpCtor=ctor||window.HWJimbobLevels.buttonClass;
        const play=featured.playBtn;
        const replays=featured.viewReplaysBtn;
        const size=Math.round(replays.width||0)||0x154;
        const lift=46;
        const layout={x:replays.x,y:replays.y-lift+4,width:size,after:()=>{
          if(featured.__jmpRaised)return;
          featured.__jmpRaised=true;
          if(play)play.y-=lift;
        }};
        placeLobbyButton(featured, replays, 'use in multiplayer lobby', LOBBY_GREEN, async()=>{
          const row=featuredRecord(featured);
          if(!row)throw Error('Select a featured level first.');
          await sendLevelToLobby(row.id, row);
        }, layout);
      }
      const panel=findUserPanel(menu.levelBrowser||hw.levelBrowser);
      if(panel&&panel.parent){
        panel.__jmpCtor=panel.viewReplaysButton?.constructor||ctor||window.HWJimbobLevels.buttonClass;
        const first=panel.viewReplaysButton||panel.authorLevelsButton||panel.copyUrlButton;
        const step=34;
        placeLobbyButton(panel, first, 'use in multiplayer lobby', LOBBY_GREEN, async()=>{
          const data=panel._levelDataObject;
          const id=String(data?.id??data?._id??'');
          if(!/^[1-9][0-9]{0,8}$/.test(id))throw Error('Select a level first.');
          await sendLevelToLobby(id, {id, name:data.name||data.level_name||data.ln||('Level '+id), author:data.authorName||data.author_name||data.username||data.un||'', authorId:data.author_id??data.authorId??data._author_id});
        }, {x:first.x,y:first.y,width:0xa6,after:()=>{
          if(panel.__jmpGrown)return;
          panel.__jmpGrown=true;
          for(const key of ['viewReplaysButton','authorLevelsButton','copyUrlButton']){
            const node=panel[key];
            if(node&&Number.isFinite(node.y))node.y+=step;
          }
          if(Number.isFinite(panel.fullHeight))panel.fullHeight+=step;
          if(Number.isFinite(panel.maskHeight))panel.maskHeight+=step;
          const list=panel.parent;
          if(list&&Number.isFinite(list.y)&&Number.isFinite(panel.y)){
            const bottom=list.y+panel.y+(panel.fullHeight||panel.maskHeight||0);
            const over=bottom-0x160;
            if(over>0)list.y-=over;
          }
          try{list?.organizeList?.();}catch{}
        }});
      }
    }
    async function sendLevelToLobby(id, hint){
      const picked=await window.HWJimbobLevels.inspect(id, hint);
      const lobby=lab.lobby();
      open();
      if(lobby.room&&!lobby.isHost)throw Error('Only the host can choose the lobby level.');
      if(lobby.room&&lobby.isHost){await actions.pickLevel(picked);return;}
      pendingLevel=picked;
      actions.message('Host a room and this level will be selected.');
    }
    setInterval(()=>{
      try{installBrowserButtons();}catch(e){if(lab.errors.length<30)lab.errors.push('Level lobby button: '+e.message);}
      try{installMenu();refresh();}catch(e){if(lab.errors.length<30)lab.errors.push('Multiplayer menu: '+e.message);}
    },200);
    return {open,close,refresh,joinCode,askReady,hideReadyAsk,hideForLevel,closeForTransition,clearRaceChrome};
  };
})();
