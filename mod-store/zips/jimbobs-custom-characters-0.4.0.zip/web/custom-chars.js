(() => {
  'use strict';
  const ROOT='./js/jimbobs-custom-characters/';
  const api=window.HWCustomCharacters={version:'0.2.0',errors:[],selected:null,preview:null,slots:0,painted:0};
  let requireGame,state,pixi,app,roster=[],committed=null;
  const assets=new Map(),skinned=new WeakMap();
  const report=e=>{const text=String(e?.message||e);if(!api.errors.includes(text))api.errors.push(text);console.error('[Custom characters]',text);};
  const safePath=s=>typeof s==='string'&&!s.includes('..')&&!s.includes('\\')&&!/^[a-z]+:|^\//i.test(s);
  const getMenu=()=>state?.rootApp?.screenManager?.currentScreen?.happyWheels?.sessionController?.characterMenu;
  function connectRuntime(){
    requireGame=window.HWGhost?.require||requireGame;
    if(!requireGame)for(const key of Object.keys(window)){
      const chunks=window[key];
      if(/^Tmu[A-Za-z0-9]+0$/.test(key)&&Array.isArray(chunks)&&chunks.push!==Array.prototype.push){chunks.push([['jimbob-custom-characters'],{},r=>{requireGame=r;}]);break;}
    }
    if(!requireGame)return false;
    for(const id of [35057,29552])try{const candidate=requireGame(id)?.w;if(candidate?.rootApp){state=candidate;break;}}catch{}
    if(!state?.rootApp?.renderer)return false;
    pixi=requireGame(99430);app=state.rootApp;return !!pixi.gPd;
  }
  async function loadAsset(entry){
    if(assets.has(entry.id))return assets.get(entry.id);
    const task=(async()=>{
      if(entry.profileFile&&window.HWNativeCharacter){const response=await fetch(ROOT+entry.profileFile);if(!response.ok)throw Error('Could not load native profile');entry.profile=HWNativeCharacter.validate(await response.json());}
      const urls=[...Object.values(pixi.WpD.TextureCache).map(t=>t?.baseTexture?.resource?.url),...performance.getEntriesByType('resource').map(r=>r.name)];
      const assetRoot=urls.find(u=>u&&/\/assets-[^/]+\//.test(u))?.match(/^(.*\/assets-[^/]+\/)/)?.[1];
      if(!assetRoot)throw Error('Game assets are not ready yet.');
      const response=await fetch(assetRoot+'animate/character'+entry.base+'/character'+entry.base+'.json');
      if(!response.ok)throw Error('Could not load the base character atlas.');
      const atlas=await response.json(),base=pixi.gPd.from(ROOT+entry.sheet).baseTexture;
      if(!base.valid)await new Promise((resolve,reject)=>{base.once('loaded',resolve);base.once('error',reject);});
      const sx=base.width/atlas.meta.size.w,sy=base.height/atlas.meta.size.h;
      if(Math.abs(sx-sy)>.005)throw Error(entry.name+': sheet aspect ratio must match the base atlas.');
      for(const item of Object.values(atlas.frames)){const f=item.frame;item.frame={x:f.x*sx,y:f.y*sy,w:f.w*sx,h:f.h*sy};}
      return {base,atlas,variants:new WeakMap()};
    })();
    assets.set(entry.id,task);try{const value=await task;assets.set(entry.id,value);return value;}catch(e){assets.delete(entry.id);throw e;}
  }
  function replacement(texture,entry,asset){
    if(asset.variants.has(texture))return asset.variants.get(texture);
    if(!(texture.baseTexture?.resource?.url||'').includes('/animate/character'+entry.base+'/'))return texture;
    const key=texture.textureCacheIds?.find(k=>asset.atlas.frames[k]),frame=asset.atlas.frames[key]?.frame;
    if(!frame)return texture;
    const result=new pixi.gPd(asset.base,new pixi.M_G(frame.x,frame.y,frame.w,frame.h),texture.orig.clone(),texture.trim?.clone(),texture.rotate);
    asset.variants.set(texture,result);skinned.set(result,texture);return result;
  }
  function paint(node,entry,asset){
    if(!node)return;
    if(node.texture){const current=node.texture,original=skinned.get(current)||current,next=entry&&asset?replacement(original,entry,asset):original;if(next!==current){node.texture=next;api.painted++;}}
    for(const child of node.children||[])paint(child,entry,asset);
  }
  function renderSkin(){
    const menu=getMenu(),entry=menu?.parent?menu.selectedIcon?.__customCharacter:committed;
    const session=menu?.parent?menu.session:state.currentSession,asset=entry&&assets.get(entry.id);
    if(window.HWNativeCharacter)HWNativeCharacter.hook(session?.character,()=>{const current=getMenu(),chosen=current?.parent?current.selectedIcon?.__customCharacter:committed;return chosen?.profile&&chosen.base===state.characterIndex?chosen:null;});
    api.preview=menu?.parent?entry?.id||null:null;
    if(session?.containerSprite&&(!entry||asset?.base))paint(session.containerSprite.pixiSprite,entry,asset);
  }
  async function addSlot(menu,empty,entry){
    const asset=await loadAsset(entry);if(!menu.parent)return;
    const icon=new menu.icons[0].constructor(entry.base);
    icon.__customCharacter=entry;icon.x=empty.x;icon.y=empty.y;
    icon.loaderBW.visible=false;icon.loaderColor.visible=false;
    let texture;
    if(entry.iconFrame){const f=asset.atlas.frames[entry.iconFrame]?.frame;if(!f)throw Error('Unknown portrait atlas frame: '+entry.iconFrame);texture=new pixi.gPd(asset.base,new pixi.M_G(f.x,f.y,f.w,f.h));}
    else texture=pixi.gPd.from(ROOT+entry.icon);
    const portrait=new pixi.kxk(texture);portrait.name=entry.name;portrait.eventMode='none';
    function sizePortrait(){const scale=40/Math.max(texture.width,texture.height);portrait.scale.set(scale);portrait.x=25-texture.width*scale/2;portrait.y=25-texture.height*scale/2;}
    sizePortrait();if(!texture.baseTexture.valid)texture.baseTexture.once('loaded',sizePortrait);
    icon.pixiSprite.addChild(portrait);
    icon.addEventListener('mouseOver',event=>{menu.iconMouseOverHandler(event);renderSkin();});
    icon.addEventListener('mouseDown',event=>{committed=entry;api.selected=entry.id;menu.iconMouseDownHandler(event);});
    menu.icons[menu.icons.indexOf(empty)]=icon;menu.iconHolder.removeChild(empty);menu.iconHolder.addChild(icon);
    const descriptor=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(icon),'selected');
    if(descriptor?.set)Object.defineProperty(icon,'selected',{get(){return descriptor.get?.call(this);},set(value){descriptor.set.call(this,value);this.loaderBW.visible=false;this.loaderColor.visible=false;portrait.alpha=value?1:.72;}});
    api.slots++;
  }
  function installMenu(menu){
    if(!menu?.parent||menu.__customInstalled)return;
    menu.__customInstalled=true;api.slots=0;
    const empty=menu.icons.filter(icon=>!icon.loaderColor&&!icon.loaderBW);
    for(const icon of menu.icons.filter(icon=>icon.loaderColor)){
      const nativeDown=menu.iconMouseDownHandler;
      icon.removeEventListener('mouseDown',nativeDown);
      icon.addEventListener('mouseDown',event=>{committed=null;api.selected=null;nativeDown(event);});
    }
    roster.slice(0,empty.length).forEach((entry,i)=>addSlot(menu,empty[i],entry).catch(report));
  }
  function folderPath(file){
    const value=String(file||'').replace(/^\.\//,'');
    return safePath(value)?value:'';
  }
  function fromFolder(folder,data){
    if(!data||!/^[a-z0-9][a-z0-9-]*$/i.test(folder))return null;
    const sheet=folderPath(data.sheet||'sheet.png');
    const icon=folderPath(data.icon||'icon.png');
    const base=Number(data.base);
    if(!sheet||!icon||!Number.isInteger(base)||base<1||base>11)return null;
    const entry={id:folder,name:String(data.name||folder),base,sheet:'characters/'+folder+'/'+sheet,icon:'characters/'+folder+'/'+icon};
    if(data.profileFile&&safePath(data.profileFile))entry.profileFile='characters/'+folder+'/'+data.profileFile;
    return entry;
  }
  async function loadRoster(){
    const index=await fetch(ROOT+'characters/index.json').then(r=>{if(!r.ok)throw Error('Could not load characters/index.json');return r.json();});
    const folders=index.characters||index;
    const entries=[];
    for(const folder of folders){
      try{
        const data=await fetch(ROOT+'characters/'+folder+'/character.json').then(r=>{if(!r.ok)throw Error('Missing character.json in '+folder);return r.json();});
        const entry=fromFolder(folder,data);
        if(entry)entries.push(entry);
        else report('Skipped '+folder+': character.json needs name, base 1-11, sheet, and icon.');
      }catch(error){report(error);}
    }
    return entries;
  }
  loadRoster().then(list=>{
    roster=list;
    const boot=setInterval(()=>{try{if(!connectRuntime())return;clearInterval(boot);const render=app.renderer.render;app.renderer.render=function(...args){try{installMenu(getMenu());renderSkin();}catch(e){report(e);}return render.apply(this,args);};api.diagnostics=()=>({selected:api.selected,preview:api.preview,slots:api.slots,painted:api.painted,errors:api.errors,base:state.characterIndex});}catch(e){report(e);}},100);
  }).catch(report);
})();
