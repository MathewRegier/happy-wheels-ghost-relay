Custom Characters Template
For Jimbob's Custom Characters · Discord jimbob1111


What you are making
-------------------
A new playable slot on Happy Wheels' Select your character grid.
Your character is a reskin of a vanilla ragdoll. Physics, joints,
and damage stay the same. Only the pictures change.

Tung Tung Tung Sahur is the working example: it clones Segway Guy
(base 2) and uses a custom sheet + icon.


What to drag in
---------------
One folder. The folder name is the character id.

  my-new-guy\
    character.json
    sheet.png
    icon.png

Drop that folder here:

  Happy Wheels\mods\jimbobs-custom-characters\web\characters\

Restart Happy Wheels. If the json is valid, it shows up on the
next empty square. You do not edit a master character list.


character.json
--------------
{
  "name": "My New Character",
  "base": 2,
  "sheet": "sheet.png",
  "icon": "icon.png"
}

  name    Label for the slot. Can have spaces.
  base    Which vanilla character to clone. Number 1-11.
  sheet   Sprite sheet file in this same folder.
  icon    Face icon file in this same folder.

Folder name rules: lowercase letters, numbers, dashes.
Example: tung-tung-sahur


base numbers
------------
1   Wheelchair Guy
2   Segway Guy
3   Irresponsible Dad
4   Effective Shopper
5   Moped Couple
6   Lawnmower Man      (two vanilla sheets, see vanilla folder)
7   Explorer Guy
8   Santa              (three vanilla sheets, see vanilla folder)
9   Pogo Stick Man
10  Irresponsible Mom
11  Helicopter Man

Start with 1-5, 7, or 9-11. Those are one sheet.


How to make a character
-----------------------
1. Pick a base. Open vanilla\02-segway-guy\ if you want a Segway
   clone like Tung Tung.

2. Copy vanilla\02-segway-guy\sheet.png into a new folder as
   sheet.png. Copy icon.png too, or draw your own face.

3. Paint over sheet.png. Keep the exact width and height. Do not
   move the parts. Leave empty pixels transparent.

4. Make icon.png. A small square face (about 64-128 pixels) is
   enough. This is the picture on the character grid.

5. Edit character.json. Set name and base. Keep sheet and icon
   file names matching the files in the folder.

6. Rename the folder to your-character-id.

7. Drag the folder into

     Happy Wheels\mods\jimbobs-custom-characters\web\characters\

8. Restart Happy Wheels and pick the new slot.


Folders in this template
------------------------
  example\tung-tung-sahur\
      Finished character. Sheet, icon, and json.

  vanilla\
      Official sheets and face icons for every base, so you
      have something to paint over. This folder stays in the
      local kit. It is not in the public launcher download.

  blank-character\
      Empty starter. Copy it, then replace the pictures.


Common mistakes
---------------
  Sheet size changed. Copy the vanilla sheet and paint on top.
  Parts moved. The game still cuts the old boxes out of the image.
  Missing character.json. The folder is ignored.
  base is not 1-11. The folder is ignored.
  Folder name has spaces. Use dashes.
  Dropped into the wrong place. It must go in web\characters\.
