(() => {
  'use strict';
  const PROTOCOL='lobby-directory-v1';
  async function listRooms(address){
    let url;try{url=new URL(address);}catch{throw Error('Enter a valid server address in Advanced settings.');}
    if(!['ws:','wss:'].includes(url.protocol)||url.username||url.password)throw Error('Use a ws:// or wss:// server address without credentials.');
    const bridge=window.hwGhostNet||window.hwGhostSteam;
    const result=bridge?.listRooms?await bridge.listRooms(url.href):await new Promise((resolve,reject)=>{
      const ws=new WebSocket(url.href);let done=false;
      const timer=setTimeout(()=>finish(Error('The room browser timed out. Try refreshing.')),10000);
      function finish(error,value){if(done)return;done=true;clearTimeout(timer);try{ws.close();}catch{}error?reject(error):resolve(value);}
      ws.onopen=()=>ws.send(JSON.stringify({type:'browse'}));
      ws.onerror=()=>finish(Error('Cannot reach the server. Check Advanced settings and try again.'));
      ws.onclose=()=>finish(Error('The server closed the browser connection. Try refreshing.'));
      ws.onmessage=event=>{try{
        if(typeof event.data!=='string'||event.data.length>128*1024)throw Error('Invalid response.');
        const data=JSON.parse(event.data);
        if(data.type==='error')return finish(Error(data.message==='Unknown message'?'This server needs the lobby browser update.':data.message));
        if(data.type==='directory')finish(null,data);
      }catch{finish(Error('Invalid room browser response.'));}};
    });
    if(result?.protocol!==PROTOCOL||!Array.isArray(result.rooms)||result.rooms.length>100)throw Error('This server needs the lobby browser update.');
    // Validate before rendering. Room titles and host names are always text, never HTML.
    if(!result.rooms.every(r=>r&&/^[A-F0-9]{16}$/.test(r.code)&&['ghost','shared'].includes(r.mode)&&Number.isInteger(r.players)&&r.players>=1&&Number.isInteger(r.capacity)&&r.capacity>=2&&r.capacity<=16&&r.players<=r.capacity&&typeof r.joinable==='boolean'))throw Error('Invalid room browser response.');
    return result;
  }
  window.HWRoomDirectory=Object.freeze({listRooms,PROTOCOL});
  window.HWRoomBrowser=(mount,actions)=>{
    mount.innerHTML=`<style>
      #hw-multiplayer{--ink:#0d171c;--paper:#f5eedb;--coral:#ff8582;--gold:#f2cb64;--mint:#b7dfb6;--sky:#acd7e8;padding:clamp(20px,3vw,48px);background:radial-gradient(ellipse at 95% 0%,#45606c 0%,#283c47 35%,#1b2a32 75%);font-size:16px}
      #hw-multiplayer h1{font-size:clamp(38px,4.6vw,76px);font-weight:900;letter-spacing:-2px;text-shadow:2px 3px 0 var(--ink);margin-bottom:20px}
      #hw-multiplayer .eyebrow{color:var(--paper);letter-spacing:2px;font-weight:bold}
      #hw-multiplayer button{border:2px solid #0d171c;border-radius:8px;background:#334d59;box-shadow:0 3px 0 #0d171c;color:var(--paper);font-weight:bold;transition:transform .12s,background .12s}
      #hw-multiplayer button:hover:enabled{background:#44616e;transform:translateY(-1px)}
      #hw-multiplayer button:active:enabled{transform:translateY(2px);box-shadow:none}
      #hw-multiplayer button:disabled{transform:none;opacity:.5}
      #hw-multiplayer button:focus-visible,#hw-multiplayer input:focus-visible,#hw-multiplayer select:focus-visible{outline:3px solid var(--gold);outline-offset:3px}
      #hw-multiplayer .primary{background:var(--gold);color:var(--ink);border-color:var(--ink)}#hw-multiplayer .primary:hover:enabled{background:#ffe298}
      #hw-multiplayer .back{background:#17272f;border:2px solid var(--ink);padding:9px 16px;margin-left:16px}
      #hw-multiplayer input,#hw-multiplayer select{border:2px solid #536b75;border-radius:7px;background:#111f26;color:var(--paper);min-width:0}
      #hw-multiplayer .panel{border:2px solid var(--ink);border-radius:12px;background:#17272f;box-shadow:0 5px 0 #0d171c66;padding:22px}
      #hw-multiplayer .panel h2{color:var(--gold);font-weight:bold;letter-spacing:1px}
      #hw-multiplayer #mp-step-mode,#hw-multiplayer #mp-step-size,#hw-multiplayer #mp-step-code{max-width:800px;margin:0 auto;padding:26px;background:#17272f;border:2px solid var(--ink);border-radius:14px;box-shadow:0 6px 0 var(--ink)}
      #hw-multiplayer .choice{display:grid;grid-template-columns:1fr 1fr;gap:16px}#hw-multiplayer .choice button{border:2px solid var(--ink);border-radius:10px;background:#243b46}
      #hw-multiplayer .lobby-grid{grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:22px}#hw-multiplayer .room-code{overflow-wrap:anywhere;color:var(--gold)}
      #hw-multiplayer .mpb-hero{display:flex;justify-content:space-between;align-items:center;gap:24px;margin:-6px 0 26px;padding-bottom:24px;border-bottom:2px solid #526b77}
      #hw-multiplayer .mpb-hero p{margin:0;color:#d0dce0;font-size:17px}#hw-multiplayer .mpb-hero strong{color:var(--paper);font-size:26px;display:block;margin-bottom:6px}
      #hw-multiplayer .mpb-actions{display:flex;flex-wrap:wrap;gap:12px}#hw-multiplayer .mpb-actions button{padding:13px 22px;white-space:nowrap;font-size:18px}
      #hw-multiplayer .mpb-layout{display:grid;grid-template-columns:220px minmax(0,1fr);gap:24px}
      #hw-multiplayer .mpb-aside{padding:22px;border:2px solid var(--ink);border-radius:12px;background:#17272f;align-self:start;box-shadow:0 5px 0 #0d171c66}
      #hw-multiplayer .mpb-aside h2{font-size:20px;margin:0 0 20px;color:var(--gold)}#hw-multiplayer .mpb-aside h3{font-size:17px;color:var(--paper);margin:18px 0 6px}
      #hw-multiplayer .mpb-aside p{font-size:14px;line-height:1.6;color:#b8cbd3;margin:0}
      #hw-multiplayer .mpb-wheel{width:100%;height:104px;margin-top:28px;display:block}
      #hw-multiplayer .mpb-board{min-width:0;background:#17272f;border:2px solid var(--ink);border-radius:12px;box-shadow:0 5px 0 #0d171c66;overflow:hidden}
      #hw-multiplayer .mpb-toolbar{display:flex;align-items:center;flex-wrap:wrap;gap:12px;padding:18px 20px;border-bottom:1px solid #415d6b;background:#20343f}
      #hw-multiplayer .mpb-toolbar label{flex:1;min-width:160px}#hw-multiplayer .mpb-toolbar input{width:100%;margin:0;padding:10px 12px}
      #hw-multiplayer .mpb-toolbar select{width:auto;margin:0;padding:10px;max-width:100%}#hw-multiplayer .mpb-toolbar button{padding:10px 15px}
      #hw-multiplayer .mpb-count{color:var(--gold);padding:0 20px;font:700 13px Georgia,serif;letter-spacing:.05em;margin:18px 0}
      #hw-multiplayer .mpb-rooms{min-height:32vh;padding:0 18px 18px;display:flex;flex-direction:column;gap:12px;max-height:55vh;overflow:auto}
      #hw-multiplayer .mpb-row{display:grid;grid-template-columns:54px minmax(0,1fr) 120px 92px 104px;align-items:center;gap:16px;padding:18px;background:#263e49;border:1px solid #4d6a77;border-radius:9px}
      #hw-multiplayer .mpb-number{color:var(--coral);font:900 27px Georgia,serif;border:2px solid var(--ink);border-radius:50%;width:46px;height:46px;background:#13252e;display:grid;place-items:center}
      #hw-multiplayer .mpb-name{font:700 20px Georgia,serif;color:var(--paper);margin:0 0 4px;overflow-wrap:anywhere}
      #hw-multiplayer .mpb-info{font:14px/1.5 Georgia,serif;color:#b9d0d9;margin:0;overflow-wrap:anywhere}
      #hw-multiplayer .mpb-mode{color:var(--sky);font-size:14px;font-weight:bold}#hw-multiplayer .mpb-mode small{display:block;color:#b4cbd4;font-size:12px;margin-top:4px}
      #hw-multiplayer .mpb-seats{font-size:21px;font-weight:bold;color:var(--paper)}#hw-multiplayer .mpb-seats small{display:block;font-size:13px;font-weight:normal;color:var(--mint);margin-top:3px}
      #hw-multiplayer .mpb-row button{padding:9px 12px;box-shadow:0 3px 0 var(--ink)}
      #hw-multiplayer .mpb-empty{flex:1;display:flex;align-items:center;justify-content:center;text-align:center;padding:38px 20px;min-height:28vh;flex-direction:column;color:#b8cbd3}
      #hw-multiplayer .mpb-empty strong{display:block;color:var(--paper);font-size:26px;margin-bottom:10px}#hw-multiplayer .mpb-empty p{max-width:460px;margin:0}
      #hw-multiplayer .mpb-error{color:var(--coral);margin:0 20px 18px;overflow-wrap:anywhere}#hw-multiplayer .mpb-foot{display:flex;gap:16px;justify-content:space-between;flex-wrap:wrap;padding:14px 20px;border-top:1px solid #415d6b;color:#acbec7;font-size:13px}
      #hw-multiplayer .mpb-foot span:first-child{color:var(--mint)}#hw-multiplayer .mpb-foot span:first-child:before{content:'● ';font-size:11px}
      #hw-multiplayer .mp-mode-buttons{display:flex;gap:10px;flex-wrap:wrap;margin:12px 0}#hw-multiplayer .mp-mode-buttons [aria-pressed=true]{background:var(--gold);color:var(--ink)}
      #hw-multiplayer .mp-mode-buttons [aria-pressed=true]:disabled{opacity:1}
      #hw-multiplayer .mp-room-note{font-size:14px;color:var(--mint)}#hw-multiplayer .mp-form-grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}
      @media(min-width:1600px){#hw-multiplayer .mpb-layout{grid-template-columns:270px minmax(0,1fr)}#hw-multiplayer .mpb-row{padding:24px;grid-template-columns:54px minmax(0,1fr) 170px 120px 130px}.mpb-rooms{min-height:40vh}}
      @media(max-width:1100px){#hw-multiplayer .mpb-layout{grid-template-columns:1fr}#hw-multiplayer .mpb-aside{display:none}#hw-multiplayer .mpb-hero{align-items:flex-start}#hw-multiplayer .mpb-hero strong{font-size:21px}#hw-multiplayer .mpb-row{gap:12px;grid-template-columns:40px minmax(0,1fr) 105px 72px 92px}#hw-multiplayer .mpb-number{width:36px;height:36px;font-size:22px}}
      @media(max-width:800px){#hw-multiplayer .lobby-grid{grid-template-columns:1fr}}
      @media(max-width:620px){#hw-multiplayer{padding:18px}#hw-multiplayer h1{letter-spacing:-1px}#hw-multiplayer .mpb-hero{flex-direction:column;gap:16px}#hw-multiplayer .mpb-row{grid-template-columns:36px minmax(0,1fr) 85px;padding:12px}#hw-multiplayer .mpb-mode{grid-column:2;font-size:13px}#hw-multiplayer .mpb-seats{grid-column:3;grid-row:1;font-size:17px}#hw-multiplayer .mpb-row button{grid-column:3;grid-row:2}#hw-multiplayer .mpb-name{font-size:17px}#hw-multiplayer .mpb-rooms{padding:0 12px 12px}#hw-multiplayer .choice,#hw-multiplayer .mp-form-grid{grid-template-columns:1fr}#hw-multiplayer .mpb-toolbar{padding:12px}#hw-multiplayer .mpb-toolbar select{flex:1}#hw-multiplayer #mp-step-size,#hw-multiplayer #mp-step-code,#hw-multiplayer #mp-step-mode{padding:18px}}
      @media(prefers-reduced-motion:reduce){#hw-multiplayer button{transition:none}}
    </style>
    <div class="mpb-hero"><div><strong>Good company. Terrible landings.</strong><p>Find a public room and jump into the chaos.</p></div><div class="mpb-actions"><button class="primary" type="button" data-action="host">+ Host a room</button><button type="button" data-action="code">Join with code</button></div></div>
    <div class="mpb-layout"><aside class="mpb-aside"><h2>Pick your kind of chaos</h2><h3>Ghost Multiplayer</h3><p>Your own run, with everyone in sight. Race together without colliding.</p><h3>Shared Physics</h3><p>One world. Real collisions. A little friendly sabotage.</p><svg class="mpb-wheel" viewBox="0 0 190 110" aria-hidden="true"><path d="M8 94h174" stroke="#526c79" stroke-width="3" stroke-dasharray="7 5"/><circle cx="48" cy="63" r="29" fill="#12222b" stroke="#f2cb64" stroke-width="7"/><circle cx="139" cy="63" r="29" fill="#12222b" stroke="#f2cb64" stroke-width="7"/><path d="m48 63 34-44 24 44H48l31-37m27 37 33-39m-12-8h23M80 18h-15" stroke="#ff8582" stroke-width="6" fill="none" stroke-linecap="round"/><path d="m177 12-9-6v23" stroke="#acd7e8" stroke-width="3" fill="none"/></svg></aside>
    <section class="mpb-board" aria-label="Public rooms"><div class="mpb-toolbar"><label><span class="sr-only" style="position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%)">Search rooms</span><input data-search type="search" placeholder="Search rooms, hosts or levels" maxlength="80"></label><select data-filter aria-label="Filter by mode"><option value="all">All modes</option><option value="ghost">Ghost Multiplayer</option><option value="shared">Shared Physics</option></select><button data-refresh type="button">Refresh</button></div><p class="mpb-count" data-count>PUBLIC ROOMS</p><div class="mpb-rooms" data-rooms></div><p class="mpb-error" data-error role="status" hidden></p><div class="mpb-foot"><span data-health>Connecting to server</span><span>Friends-only rooms use invites or codes.</span></div></section></div>`;
    const get=selector=>mount.querySelector(selector),list=get('[data-rooms]'),error=get('[data-error]'),health=get('[data-health]');
    let active=false,timer=0,token=0,busy=false,rows=[],lastKey='',loaded=false,failed=false;
    function empty(title,copy){const box=document.createElement('div');box.className='mpb-empty';const strong=document.createElement('strong'),p=document.createElement('p');strong.textContent=title;p.textContent=copy;box.append(strong,p);list.replaceChildren(box);}
    function paint(){
      const query=get('[data-search]').value.trim().toLowerCase(),filter=get('[data-filter]').value;
      const visible=rows.filter(r=>(filter==='all'||r.mode===filter)&&[r.name,r.host,r.level?.title].join(' ').toLowerCase().includes(query));
      get('[data-count]').textContent=visible.length+' PUBLIC ROOM'+(visible.length===1?'':'S')+(rows.length!==visible.length?' · '+rows.length+' total':'');
      const key=JSON.stringify([visible,loaded,failed,query,filter]);if(key===lastKey)return;lastKey=key;
      if(!visible.length){empty(!loaded?(failed?'Couldn’t load the rooms':'Finding your next race…'):rows.length?'No matching rooms':'The track is all yours',!loaded?'Refresh to try again, or check Advanced server settings.':rows.length?'Try another search or mode.':'No public rooms right now. Host one and get things rolling!');return;}
      const focusCode=document.activeElement?.dataset?.roomCode;
      const scroll=list.scrollTop;
      list.replaceChildren(...visible.map((r,i)=>{
        const row=document.createElement('article');row.className='mpb-row';
        const number=document.createElement('div');number.className='mpb-number';number.textContent=String(i+1).padStart(2,'0');number.setAttribute('aria-hidden','true');
        const main=document.createElement('div'),name=document.createElement('h3'),info=document.createElement('p');name.className='mpb-name';name.textContent=String(r.name||'Happy Wheels room').slice(0,48);info.className='mpb-info';info.textContent='Hosted by '+String(r.host||'Racer').slice(0,24)+' · '+String(r.level?.title||'Choosing a level').slice(0,80);main.append(name,info);
        const mode=document.createElement('div');mode.className='mpb-mode';mode.textContent=r.mode==='shared'?'Shared Physics':'Ghost Multiplayer';const privacy=document.createElement('small');privacy.textContent=r.passwordProtected?'Password required':'No password';mode.append(privacy);
        const seats=document.createElement('div');seats.className='mpb-seats';seats.textContent=r.players+' / '+r.capacity;const state=document.createElement('small');state.textContent=String(r.status||'Open').slice(0,20);seats.append(state);
        const join=document.createElement('button');join.type='button';join.className=r.joinable?'primary':'';join.disabled=!r.joinable||failed;join.dataset.roomCode=r.code;join.textContent=r.joinable?(r.passwordProtected?'Unlock':'Join'):String(r.status||'Unavailable').slice(0,20);join.setAttribute('aria-label','Join '+name.textContent);join.onclick=()=>actions.join(r);
        row.append(number,main,mode,seats,join);return row;
      }));
      list.scrollTop=scroll;if(focusCode){const btn=[...list.querySelectorAll('button')].find(b=>b.dataset.roomCode===focusCode);btn?.focus({preventScroll:true});}
    }
    async function refresh(){
      if(!active||busy)return;busy=true;const id=token;
      get('[data-refresh]').disabled=true;get('[data-refresh]').textContent='Refreshing…';
      try{
        const result=await listRooms(actions.server());if(!active||id!==token)return;
        rows=result.rooms;loaded=true;failed=false;error.hidden=true;health.textContent='Live · updates every 8 seconds';paint();
      }catch(e){if(!active||id!==token)return;failed=true;error.hidden=false;error.textContent=e.message||'Could not load rooms.';health.textContent='Connection unavailable · refresh to retry';paint();}
      finally{busy=false;get('[data-refresh]').disabled=false;get('[data-refresh]').textContent='Refresh';if(active)timer=setTimeout(refresh,8000);}
    }
    get('[data-search]').oninput=paint;get('[data-filter]').onchange=paint;
    get('[data-refresh]').onclick=()=>{clearTimeout(timer);refresh();};
    get('[data-action=host]').onclick=actions.host;get('[data-action=code]').onclick=actions.code;
    function setActive(value){if(active===value)return;active=value;token++;clearTimeout(timer);if(value){paint();refresh();}}
    function reset(){rows=[];loaded=false;failed=false;lastKey='';error.hidden=true;token++;clearTimeout(timer);paint();if(active&&!busy)refresh();}
    paint();return {setActive,refresh,reset};
  };
})();
