/* Independent pixel editor: edits never change the native atlas layout. */
(() => {
  'use strict';
  function flood(data,width,height,x,y,color,tolerance=0,lockAlpha=true){
    x=Math.floor(x);y=Math.floor(y);if(x<0||y<0||x>=width||y>=height)return;
    const start=(y*width+x)*4,target=Array.from(data.slice(start,start+4));
    if(lockAlpha&&target[3]===0)return;
    const seen=new Uint8Array(width*height),queue=new Int32Array(width*height);let head=0,tail=0;
    queue[tail++]=y*width+x;seen[y*width+x]=1;
    const srcA=color[3];
    while(head<tail){const n=queue[head++],i=n*4;
      if(Math.max(...target.map((v,k)=>Math.abs(v-data[i+k])))>tolerance)continue;
      if(lockAlpha){
        const keep=data[i+3];
        for(let k=0;k<3;k++)data[i+k]=Math.round(data[i+k]*(1-srcA)+color[k]*srcA);
        data[i+3]=keep;
      }else{
        const dstA=data[i+3]/255,outA=srcA+dstA*(1-srcA);
        for(let k=0;k<3;k++)data[i+k]=outA?Math.round((color[k]*srcA+(data[i+k]/255)*dstA*(1-srcA))/outA*255):0;
        data[i+3]=Math.round(outA*255);
      }
      const px=n%width;for(const next of [px>0?n-1:-1,px<width-1?n+1:-1,n-width,n+width])if(next>=0&&next<width*height&&!seen[next]){seen[next]=1;queue[tail++]=next;}
    }
  }
  function region(sheet,item){
    const f=item.frame,c=document.createElement('canvas');c.width=item.rotated?f.h:f.w;c.height=item.rotated?f.w:f.h;
    const ctx=c.getContext('2d');if(item.rotated){ctx.translate(0,c.height);ctx.rotate(-Math.PI/2);}
    ctx.drawImage(sheet,f.x,f.y,f.w,f.h,0,0,f.w,f.h);return c;
  }
  function commit(sheet,item,part){
    const f=item.frame,ctx=sheet.getContext('2d');ctx.save();ctx.clearRect(f.x,f.y,f.w,f.h);ctx.translate(f.x,f.y);
    if(item.rotated){ctx.translate(f.w,0);ctx.rotate(Math.PI/2);}ctx.drawImage(part,0,0);ctx.restore();
  }
  class History{
    constructor(limit=48*1024*1024){this.limit=limit;this.undoStack=[];this.redoStack=[];this.bytes=0;}
    entry(keyOrTx,before,after){
      if(typeof keyOrTx==='string')return {key:keyOrTx,before,after,changes:[{key:keyOrTx,before,after}]};
      const changes=keyOrTx.changes||[];
      const first=changes[0];
      return {...keyOrTx,key:keyOrTx.key||first?.key,before:keyOrTx.before||first?.before,after:keyOrTx.after||first?.after,changes};
    }
    size(entry){return entry.changes.reduce((n,change)=>n+change.before.data.length+change.after.data.length,0);}
    drop(list){while(list.length){const entry=list.pop();this.bytes-=this.size(entry);}}
    push(keyOrTx,before,after){
      const entry=this.entry(keyOrTx,before,after);
      if(!entry.changes.length||entry.changes.every(change=>change.before.data.every((v,i)=>v===change.after.data[i])))return false;
      this.drop(this.redoStack);
      this.undoStack.push(entry);this.bytes+=this.size(entry);
      while(this.bytes>this.limit&&this.undoStack.length>1){const old=this.undoStack.shift();this.bytes-=this.size(old);}
      return true;
    }
    undo(){const entry=this.undoStack.pop();if(entry)this.redoStack.push(entry);return entry;}
    redo(){const entry=this.redoStack.pop();if(entry)this.undoStack.push(entry);return entry;}
  }
  function partPoint(instance,lx,ly){
    const det=instance.a*instance.d-instance.b*instance.c;
    if(!det||!instance.partW||!instance.partH)return null;
    const x=lx-instance.tx,y=ly-instance.ty;
    const sx=(instance.d*x-instance.c*y)/det,sy=(-instance.b*x+instance.a*y)/det;
    if(sx<instance.dx||sy<instance.dy||sx>=instance.dx+instance.dw||sy>=instance.dy+instance.dh)return null;
    const u=(sx-instance.dx)/instance.dw,v=(sy-instance.dy)/instance.dh;
    const px=Math.floor(u*instance.partW),py=Math.floor(v*instance.partH);
    if(px<0||py<0||px>=instance.partW||py>=instance.partH)return null;
    return {key:instance.key,x:px,y:py,u,v};
  }
  function partPixelToCharacter(instance,px,py){
    const u=(px+0.5)/instance.partW,v=(py+0.5)/instance.partH;
    const sx=instance.dx+u*instance.dw,sy=instance.dy+v*instance.dh;
    return {x:instance.a*sx+instance.c*sy+instance.tx,y:instance.b*sx+instance.d*sy+instance.ty};
  }
  function brushCover(dist,radius){
    const edge=0.75;
    if(dist<=radius-edge)return 1;
    if(dist>=radius)return 0;
    return (radius-dist)/edge;
  }
  function segmentDistance(px,py,x0,y0,x1,y1){
    const dx=x1-x0,dy=y1-y0,len=dx*dx+dy*dy;
    let t=len?((px-x0)*dx+(py-y0)*dy)/len:0;
    t=Math.max(0,Math.min(1,t));
    return Math.hypot(px-(x0+t*dx),py-(y0+t*dy));
  }
  function frontPart(instances,lx,ly,opaque){
    for(let i=instances.length-1;i>=0;i--){
      const hit=partPoint(instances[i],lx,ly);
      if(!hit)continue;
      if(opaque&&!opaque(hit))continue;
      if(!hit.key)return {blocked:true};
      return hit;
    }
    return null;
  }
  function stampMax(mask,width,height,x0,y0,x1,y1,radius){
    const r=Math.max(0.5,radius),step=Math.max(1,r/3);
    const dist=Math.hypot(x1-x0,y1-y0),count=Math.max(1,Math.ceil(dist/step));
    for(let i=0;i<=count;i++){
      const cx=x0+(x1-x0)*i/count,cy=y0+(y1-y0)*i/count;
      const xStart=Math.max(0,Math.floor(cx-r)),xEnd=Math.min(width-1,Math.ceil(cx+r));
      const yStart=Math.max(0,Math.floor(cy-r)),yEnd=Math.min(height-1,Math.ceil(cy+r));
      for(let y=yStart;y<=yEnd;y++)for(let x=xStart;x<=xEnd;x++){
        const fall=1-Math.hypot(x+0.5-cx,y+0.5-cy)/r;
        if(fall<=0)continue;
        const index=y*width+x;
        if(fall>mask[index])mask[index]=fall;
      }
    }
  }
  function composite(original,mask,color,opacity,erase){
    const out=new Uint8ClampedArray(original);
    for(let i=0,p=0;p<mask.length;p++,i+=4){
      const cover=mask[p]*opacity;
      if(cover<=0)continue;
      if(erase){out[i+3]=Math.round(original[i+3]*(1-cover));continue;}
      for(let k=0;k<3;k++)out[i+k]=Math.round(original[i+k]*(1-cover)+color[k]*cover);
    }
    return out;
  }
  const api={flood,region,commit,History,partPoint,partPixelToCharacter,frontPart,brushCover,segmentDistance,stampMax,composite};
  if(typeof module!=='undefined')module.exports=api;else window.HWCreatorPaint=api;
})();
