(() => {
  'use strict';
  const names=['Wheelchair Guy','Segway Guy','Irresponsible Dad','Effective Shopper','Moped Couple','Lawnmower Man','Explorer Guy','Santa','Pogo Stick Man','Irresponsible Mom','Helicopter Man'];
  const P=window.HWCreatorPaint;
  let panel,model,part,key,history,dirty=false,busy=false,tool='brush',zoom=1,stroke=null,preview=null,loadToken=0,returnFocus;
  const $=id=>panel.querySelector('[data-id="'+id+'"]');
  const canvas=(w,h)=>Object.assign(document.createElement('canvas'),{width:w,height:h});
  const image=url=>new Promise((resolve,reject)=>{const i=new Image();i.onload=()=>resolve(i);i.onerror=()=>reject(Error('The template image could not be loaded.'));i.src=url;});
  const button=(label,fn,cls='')=>{const b=document.createElement('button');b.type='button';b.textContent=label;b.className=cls;b.onclick=fn;return b;};
  function status(text){$('status').textContent=text;}
  function error(e){status(e?.message||String(e));console.error('[Character creator]',e);}
  function css(){
    if(document.getElementById('hw-creator-style'))return;
    const style=document.createElement('style');style.id='hw-creator-style';style.textContent=`
    #hw-character-creator{position:fixed;inset:0;z-index:30000;background:#11191cf5;color:#eee7d7;font:14px "Trebuchet MS",sans-serif;display:flex;flex-direction:column;isolation:isolate;--line:#425156;--accent:#ff9083;--muted:#b0bfc0}
    #hw-character-creator *{box-sizing:border-box}#hw-character-creator [hidden]{display:none!important}
    #hw-character-creator button,#hw-character-creator input,#hw-character-creator select{font:inherit;color:inherit}
    #hw-character-creator button{border:1px solid var(--line);background:#223035;border-radius:5px;padding:9px 12px;cursor:pointer}
    #hw-character-creator button:hover{background:#34474c;border-color:#aabdc1}#hw-character-creator button:focus-visible,#hw-character-creator input:focus-visible{outline:3px solid #ffd277;outline-offset:2px}
    #hw-character-creator button:disabled{opacity:.4;cursor:default}#hw-character-creator button.active{border-color:var(--accent);background:#533a37;color:#ffe3d9}
    #hw-character-creator .primary{background:var(--accent);border-color:var(--accent);color:#231b19;font-weight:bold}#hw-character-creator .primary:hover{background:#ffb1a6}
    #hw-character-creator header{display:flex;align-items:center;gap:22px;padding:16px 24px;border-bottom:1px solid var(--line);background:#192428}
    #hw-character-creator h1{font:bold 26px Georgia,serif;color:var(--accent);margin:0}#hw-character-creator h2{font:26px Georgia,serif;margin:0 0 10px}
    #hw-character-creator .steps{flex:1;color:var(--muted)}#hw-character-creator .step{color:#f7deab}
    #hw-character-creator .choose{display:grid;grid-template-columns:minmax(290px,1fr) minmax(290px,1fr);gap:32px;padding:30px;overflow:auto;flex:1;min-height:0}
    #hw-character-creator .templates{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px;margin-top:20px}
    #hw-character-creator .templates button{text-align:left;display:flex;align-items:center;gap:10px;min-height:57px}#hw-character-creator .templates span{color:var(--accent);font:21px Georgia,serif}
    #hw-character-creator .template-preview{display:flex;flex-direction:column;min-height:300px;background:radial-gradient(ellipse at 50% 70%,#45545a,#263237 65%);border:1px solid var(--line);border-radius:10px;padding:22px;align-items:center}
    #hw-character-creator .template-preview canvas{width:100%;max-width:620px;min-height:0;flex:1;object-fit:contain}
    #hw-character-creator p{color:var(--muted);line-height:1.55;margin:8px 0}#hw-character-creator .editor{display:grid;grid-template-columns:205px minmax(250px,1fr) 280px;flex:1;min-height:0}
    #hw-character-creator aside{padding:16px;overflow:auto;border-right:1px solid var(--line);background:#192428}#hw-character-creator .right{border-right:0;border-left:1px solid var(--line)}
    #hw-character-creator .label{display:block;color:#f4d8ac;font-size:11px;letter-spacing:1.5px;text-transform:uppercase;margin:15px 0 8px}
    #hw-character-creator .tools{display:grid;grid-template-columns:1fr 1fr;gap:6px}#hw-character-creator .tools button{padding:10px 5px}
    #hw-character-creator input[type=range]{width:100%;accent-color:var(--accent)}#hw-character-creator input[type=color]{width:100%;height:38px;border:0;background:none;padding:0;cursor:pointer}
    #hw-character-creator input[type=text],#hw-character-creator input[type=search]{width:100%;background:#111b1e;border:1px solid var(--line);border-radius:4px;padding:10px}
    #hw-character-creator .swatches{display:flex;gap:5px;flex-wrap:wrap;margin-top:8px}#hw-character-creator .swatches button{width:23px;height:23px;min-width:0;padding:0;border-radius:50%}
    #hw-character-creator .work{min-width:0;min-height:0;display:flex;flex-direction:column}.workbar{padding:10px 12px;display:flex;gap:8px;align-items:center;border-bottom:1px solid var(--line);flex-wrap:wrap}.workbar strong{flex:1}
    #hw-character-creator .viewport{flex:1;overflow:auto;min-height:0;display:grid;place-items:start center;padding:24px;background:#131e22}
    #hw-character-creator .viewport canvas{touch-action:none;image-rendering:pixelated;box-shadow:0 8px 40px #0008;background-color:#344147;background-image:linear-gradient(45deg,#425057 25%,transparent 25%),linear-gradient(-45deg,#425057 25%,transparent 25%),linear-gradient(45deg,transparent 75%,#425057 75%),linear-gradient(-45deg,transparent 75%,#425057 75%);background-size:16px 16px;background-position:0 0,0 8px,8px -8px,-8px 0;cursor:crosshair}
    #hw-character-creator .previewbox{background:radial-gradient(ellipse,#4b595d,#253237);border:1px solid var(--line);border-radius:6px;overflow:hidden}#hw-character-creator .previewbox canvas{width:100%;display:block;cursor:crosshair}
    #hw-character-creator .parts{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px;margin-top:10px}.parts button{padding:5px!important;min-width:0}.parts canvas{width:100%;height:55px;object-fit:contain;image-rendering:auto}.parts small{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:10px}
    #hw-character-creator footer{display:flex;gap:18px;align-items:center;min-height:48px;padding:10px 24px;border-top:1px solid var(--line);background:#192428}#hw-character-creator footer span{flex:1;color:var(--muted)}
    #hw-character-creator .check{display:flex;gap:8px;align-items:center;font-size:12px;line-height:1.4;margin:12px 0}#hw-character-creator .saving{display:flex;gap:10px;align-items:center}#hw-character-creator .saving input{width:210px}
    #hw-character-creator .confirm{position:absolute;inset:0;background:#000b;display:grid;place-items:center;z-index:3}.confirm>div{background:#223035;padding:28px;border:1px solid var(--line);border-radius:8px;max-width:460px}.confirm button{margin:12px 8px 0 0}
    @media(max-width:1000px){#hw-character-creator .editor{grid-template-columns:155px minmax(180px,1fr) 210px}#hw-character-creator header{gap:10px;padding:10px}#hw-character-creator .steps{display:none}#hw-character-creator aside{padding:10px}#hw-character-creator .saving input{width:150px}}
    @media(max-width:680px){#hw-character-creator .editor{grid-template-columns:130px minmax(180px,1fr)}#hw-character-creator .right{grid-column:1/-1;max-height:220px;display:flex;gap:12px}.right .previewbox{min-width:150px}.right .parts{display:flex;overflow:auto}.parts button{min-width:70px}#hw-character-creator .choose{grid-template-columns:1fr}#hw-character-creator h1{font-size:20px}}
    `;document.head.append(style);
  }
  function confirmDiscard(action){
    if(!dirty)return action();
    const cover=document.createElement('div');cover.className='confirm';cover.setAttribute('role','alertdialog');cover.setAttribute('aria-label','Discard unsaved changes?');
    const box=document.createElement('div'),h=document.createElement('h2'),p=document.createElement('p');h.textContent='Keep your changes?';p.textContent='Your character has unsaved edits. Save it first, or discard these edits to continue.';
    box.append(h,p,button('Keep editing',()=>cover.remove()),button('Discard edits',()=>{cover.remove();dirty=false;action();}));cover.append(box);panel.append(cover);box.querySelector('button').focus();
  }
  function close(){if(busy)return;confirmDiscard(()=>{++loadToken;disposePreview();panel.remove();panel=null;returnFocus?.focus?.();});}
  function open(){
    if(panel)return;css();returnFocus=document.activeElement;panel=document.createElement('section');panel.id='hw-character-creator';panel.setAttribute('role','dialog');panel.setAttribute('aria-modal','true');panel.setAttribute('aria-label','Character creator');
    panel.innerHTML=`<header><h1>Character creator</h1><div class="steps"><span class="step" data-id="step">01 / Choose a template</span> &nbsp; → &nbsp; Paint &nbsp; → &nbsp; Play</div><div class="saving" data-id="saving" hidden><input data-id="name" type="text" maxlength="60" aria-label="Character name" placeholder="Name your character"><button class="primary" data-id="save">Save character</button></div><button data-id="close" aria-label="Close character creator">Close</button></header>
    <div class="choose" data-id="choose"><div><h2>What character do you want to clone?</h2><p>Choose the movement and body you like. Make the artwork yours.</p><div class="templates" data-id="templates"></div></div><div class="template-preview"><h2 data-id="template-name">Choose your starting character</h2><canvas data-id="template-canvas" width="700" height="650"></canvas><p data-id="template-hint">Original movement. Your own colours.</p><button class="primary" data-id="edit" disabled>Use this character →</button></div></div>
    <div class="editor" data-id="editor" hidden><aside><button data-id="back">← Templates</button><span class="label">Paint tools</span><div class="tools" data-id="tools"></div><label class="label" for="hw-creator-color">Colour</label><input id="hw-creator-color" data-id="color" type="color" value="#ed7d6d"><div class="swatches" data-id="swatches"></div><label class="label">Brush size <output data-id="size-out">8 px</output></label><input data-id="size" aria-label="Brush size" type="range" min="1" max="80" value="8"><label class="label">Opacity <output data-id="opacity-out">100%</output></label><input data-id="opacity" aria-label="Opacity" type="range" min="1" max="100" value="100"><label class="label">Fill tolerance <output data-id="tolerance-out">20</output></label><input data-id="tolerance" aria-label="Fill tolerance" type="range" min="0" max="150" value="20"><label class="check"><input data-id="alpha" type="checkbox" checked>Keep paint inside existing artwork</label><div class="tools"><button data-id="undo">Undo</button><button data-id="redo">Redo</button></div><p>Ctrl+Z / Ctrl+Y<br>B brush · E eraser<br>F fill · I eyedropper</p></aside>
    <main class="work"><div class="workbar"><strong data-id="part-title">Choose a body part</strong><button data-id="full">Show full body</button><button data-id="atlas">Sprite map</button><button data-id="zoom-out" aria-label="Zoom out">−</button><span data-id="zoom">100%</span><button data-id="zoom-in" aria-label="Zoom in">+</button><button data-id="fit">Fit</button></div><div class="viewport" data-id="viewport"><canvas data-id="paint" width="600" height="600"></canvas></div></main>
    <aside class="right"><div><span class="label">Live preview · click a part</span><div class="previewbox"><canvas data-id="live" width="500" height="580"></canvas></div><p>Every stroke updates your character.</p></div><div><label class="label">Body parts & damage frames</label><input data-id="search" type="search" aria-label="Find texture part" placeholder="Find a part…"><div class="parts" data-id="parts"></div></div></aside></div>
    <footer><span data-id="status" role="status" aria-live="polite">Choose a template to begin.</span><small>Native body parts · original physics</small></footer>`;
    document.body.append(panel);$('close').onclick=close;dirty=false;model=null;history=new P.History();
    names.forEach((name,i)=>{const b=button('',()=>showTemplate(i+1,true));b.innerHTML='<span>'+String(i+1).padStart(2,'0')+'</span>';b.append(document.createTextNode(name));b.dataset.base=i+1;b.addEventListener('pointerenter',()=>showTemplate(i+1,false));b.addEventListener('focus',()=>showTemplate(i+1,false));$('templates').append(b);});
    $('edit').onclick=edit;$('back').onclick=()=>confirmDiscard(()=>{disposePreview();model=null;key=null;part=null;enterEditor=false;$('editor').hidden=true;$('choose').hidden=false;$('saving').hidden=true;$('step').textContent='01 / Choose a template';$('edit').disabled=!selectedBase;status('Choose a template to begin.');});
    const toolLabel={brush:'Brush',eraser:'Eraser',select:'Select part',fill:'Fill',eyedropper:'Eyedropper'};
    for(const t of Object.keys(toolLabel)){const b=button(toolLabel[t],()=>setTool(t));b.dataset.tool=t;$('tools').append(b);}setTool('brush');
    ['#ed7d6d','#f3ca69','#80bfa0','#729fc5','#b292c7','#f1dfca','#573c32','#263036','#ffffff','#111111'].forEach(color=>{const b=button('',()=>{$('color').value=color;});b.style.background=color;b.setAttribute('aria-label',color);$('swatches').append(b);});
    for(const name of ['size','opacity','tolerance'])$(name).oninput=()=>$(name+'-out').textContent=$(name).value+(name==='size'?' px':name==='opacity'?'%':'');
    $('undo').onclick=()=>undo(false);$('redo').onclick=()=>undo(true);$('search').oninput=filterParts;
    $('full').onclick=()=>showView('body');$('atlas').onclick=()=>showView('atlas');$('fit').onclick=fit;$('zoom-in').onclick=()=>scale(zoom*1.25);$('zoom-out').onclick=()=>scale(zoom/1.25);
    $('save').onclick=save;$('name').oninput=()=>{markDirty();};
    const c=$('paint');c.onpointerdown=pointerDown;c.onpointermove=pointerMove;c.onpointerup=pointerUp;c.onpointercancel=pointerUp;c.onlostpointercapture=pointerUp;
    $('live').onclick=e=>pickPreview(e,$('live'));
    panel.addEventListener('keydown',keydown);panel.addEventListener('keyup',e=>e.stopPropagation());panel.addEventListener('pointerdown',e=>e.stopPropagation());
    $('close').focus();
    if(!window.hwCharacterCreator)status('Restart the game after installing this update to enable the creator’s save connection.');
  }
  const templateCache=new Map();
  let selectedBase=0,docRev=0,renderQueued=false;
  let savedDepth=0,unsavedName=false;
  function noteHistory(){docRev++;dirty=unsavedName||history.undoStack.length!==savedDepth;}
  function markDirty(){unsavedName=true;docRev++;dirty=true;}
  function showTemplate(base,select){
    if(busy)return;
    if(select&&dirty&&base!==model?.base){confirmDiscard(()=>showTemplate(base,true));return;}
    const token=++loadToken;
    if(select){selectedBase=base;for(const b of $('templates').children)b.classList.toggle('active',Number(b.dataset.base)===base);$('edit').disabled=true;}
    const cached=templateCache.get(base);
    if(cached?.snapshot&&!select){if(token!==loadToken)return;blitSnapshot(cached.snapshot,cached.bounds,$('template-canvas'));$('template-name').textContent=cached.data.name;status('Looking at '+cached.data.name+'. Click it to select that character.');return;}
    status('Loading '+names[base-1]+'…');
    loadTemplate(base,token,select);
  }
  async function loadTemplate(base,token,select){
    try{
      if(!window.hwCharacterCreator)throw Error('Restart the game to load the character creator connection.');
      let cached=templateCache.get(base);
      if(!cached){
        const data=await window.hwCharacterCreator.template(base),img=await image(data.sheet);if(!panel||token!==loadToken)return;
        const sheet=canvas(img.width,img.height);sheet.getContext('2d').drawImage(img,0,0);
        cached={data,sheet,snapshot:null,bounds:null};templateCache.set(base,cached);
      }
      if(!panel||token!==loadToken)return;
      const sheet=select?copyCanvas(cached.sheet):cached.sheet;
      disposePreview();
      model={...cached.data,sheet,frames:Object.entries(cached.data.atlas.frames),view:'body',labels:new Map(),parts:new Map(),docId:select?++docRev:model?.docId||0};
      for(const [k] of model.frames)model.labels.set(k,pretty(k));
      try{buildPreview();}catch(e){disposePreview();error(e);return;}
      if(!panel||token!==loadToken){disposePreview();return;}
      cached.snapshot=copyCanvas(preview.snapshot);cached.bounds=preview.bounds;
      blitSnapshot(preview.snapshot,preview.bounds,$('template-canvas'));
      $('template-name').textContent=cached.data.name;$('template-hint').textContent='Clone this character’s artwork, movement, and body parts.';
      if(select&&selectedBase===base){$('edit').disabled=false;status('Ready. Choose “Use this character” to start painting.');if(enterEditor){enterEditor=false;revealEditor();}}
      else{if(selectedBase!==base)disposePreview();status('Looking at '+cached.data.name+'. Click it to select that character.');}
    }catch(e){if(panel&&token===loadToken)error(e);}
  }
  function copyCanvas(source){const copy=canvas(source.width,source.height);copy.getContext('2d').drawImage(source,0,0);return copy;}
  let enterEditor=false;
  function revealEditor(){
    $('choose').hidden=true;$('editor').hidden=false;$('saving').hidden=false;$('step').textContent='02 / Make it yours';$('name').value='My '+model.name;history=new P.History();dirty=false;unsavedName=false;savedDepth=0;docRev++;makeParts();showView('body');blitPreview($('live'));status('Draw on the character. The brush paints each visible part.');
  }
  function edit(){if(!selectedBase||busy)return;if(preview&&model?.base===selectedBase){revealEditor();return;}enterEditor=true;showTemplate(selectedBase,true);}
  function setTool(t){
    tool=t;if(!panel)return;
    for(const b of $('tools').children){b.classList.toggle('active',b.dataset.tool===t);b.setAttribute('aria-pressed',b.dataset.tool===t?'true':'false');}
    if(t==='select')status('Select part: click a visible piece to edit that texture alone.');
    else if(t==='fill')status('Fill stays inside the texture you click.');
    else if(model?.view==='body')status('Draw across the character. Each visible part keeps its own texture.');
    else if(key)status('Painting '+label(key)+' with the '+t+'.');
  }
  function pretty(key){
    const base=String(key).split('/').pop().replace(/\.[a-z0-9]+$/i,'').replace(/[_-]+/g,' ').replace(/([a-z])([A-Z])/g,'$1 $2').replace(/\s+/g,' ').trim();
    return base.replace(/\b[a-z]/g,ch=>ch.toUpperCase())||'Texture';
  }
  function label(k){return model.labels.get(k)||pretty(k);}
  function makeParts(){
    $('parts').replaceChildren();for(const [k,item] of model.frames){const b=button('',()=>select(k));b.dataset.key=k;b.title=k;
      const c=canvas(100,75),p=P.region(model.sheet,item),ctx=c.getContext('2d'),s=Math.min(90/p.width,65/p.height);ctx.drawImage(p,(100-p.width*s)/2,(75-p.height*s)/2,p.width*s,p.height*s);
      const text=document.createElement('small');text.textContent=label(k);b.append(c,text);$('parts').append(b);
    }filterParts();
  }
  function filterParts(){const search=$('search').value.toLowerCase();for(const b of $('parts').children)b.hidden=!(label(b.dataset.key)+' '+b.dataset.key).toLowerCase().includes(search);}
  function select(k){if(stroke)pointerUp();key=k;part=ensurePart(k);model.view='part';$('part-title').textContent=label(k);for(const b of $('parts').children)b.classList.toggle('active',b.dataset.key===k);renderWork();fit();const shared=preview?.pose?.items?.filter(item=>item.key===k).length||0;status(shared>1?'Painting '+label(k)+'. This texture is shared by multiple parts.':'Painting '+label(k)+'. Other texture pieces are protected.');}
  function showView(view){if(stroke)pointerUp();model.view=view;const lock=$('alpha');if(lock)lock.disabled=view==='body';if(view==='body')$('part-title').textContent=tool==='select'?'Click a visible part':'Draw on the character';else if(view==='atlas')$('part-title').textContent='Sprite map · click a texture';else if(key)$('part-title').textContent=label(key);renderWork();fit();}
  function scale(value){zoom=Math.max(.1,Math.min(16,value));const c=$('paint');c.style.width=c.width*zoom+'px';c.style.height=c.height*zoom+'px';$('zoom').textContent=Math.round(zoom*100)+'%';}
  function fit(){const box=$('viewport'),c=$('paint');scale(Math.min((box.clientWidth-48)/c.width,(box.clientHeight-48)/c.height,model.view==='part'?6:1));}
  function renderWork(){
    if(!model)return;const c=$('paint');
    if(model.view==='body'){c.width=700;c.height=760;blitPreview(c);}
    else{const source=model.view==='atlas'?model.sheet:part;c.width=source.width;c.height=source.height;c.getContext('2d').drawImage(source,0,0);}
    scale(zoom);
  }
  function point(e,c=$('paint')){const r=c.getBoundingClientRect();return {x:(e.clientX-r.left)*c.width/r.width,y:(e.clientY-r.top)*c.height/r.height};}
  function rgba(){const h=$('color').value;return [parseInt(h.slice(1,3),16),parseInt(h.slice(3,5),16),parseInt(h.slice(5,7),16),Number($('opacity').value)/100];}
  function ensurePart(k){
    if(!model.parts)model.parts=new Map();
    let piece=model.parts.get(k);
    if(!piece){piece=P.region(model.sheet,model.atlas.frames[k]);model.parts.set(k,piece);}
    return piece;
  }
  function commitPart(k){const piece=model.parts?.get(k);if(!piece)return;P.commit(model.sheet,model.atlas.frames[k],piece);if(key===k)part=piece;thumb(k);}
  function thumb(k){const b=[...($('parts')?.children||[])].find(n=>n.dataset.key===k),piece=model.parts?.get(k);if(!b||!piece)return;const c=b.querySelector('canvas'),ctx=c.getContext('2d'),s=Math.min(90/piece.width,65/piece.height);ctx.clearRect(0,0,100,75);ctx.drawImage(piece,(100-piece.width*s)/2,(75-piece.height*s)/2,piece.width*s,piece.height*s);}
  function publishSheet(){preview?.base?.update?.();if(preview)preview.samples=null;schedulePreview();}
  function characterPoint(e,c=$('paint')){
    const at=point(e,c),m=c.__creatorMap;if(!m)return null;
    return {x:m.bounds.x+(at.x-m.x)/m.scale,y:m.bounds.y+(at.y-m.y)/m.scale};
  }
  function partAlpha(k,x,y,source){
    const data=source||ensurePart(k).getContext('2d').getImageData(0,0,ensurePart(k).width,ensurePart(k).height).data;
    const piece=ensurePart(k),px=Math.round(x),py=Math.round(y);
    if(px<0||py<0||px>=piece.width||py>=piece.height)return 0;
    return data[(py*piece.width+px)*4+3];
  }
  function visibleHit(lx,ly,alphas){
    const instances=preview?.pose?.items||[];
    return P.frontPart(instances,lx,ly,hit=>{
      if(!hit.key)return true;
      const data=alphas?.get(hit.key);
      return partAlpha(hit.key,hit.x,hit.y,data)>16;
    });
  }
  function applyMasks(masks,originals,color,opacity,erase){
    for(const [k,mask] of masks){
      const piece=ensurePart(k),before=originals.get(k);
      const after=P.composite(before.data,mask,color,opacity,erase);
      piece.getContext('2d').putImageData(new ImageData(after,piece.width,piece.height),0,0);
      commitPart(k);
    }
  }
  function pickPreview(e,c){
    const at=characterPoint(e,c||$('paint'));
    if(!at)return;
    const hit=visibleHit(at.x,at.y);
    if(hit)select(hit.key);else status('Click directly on a body part, or choose its tile on the right.');
  }
  function bodyPointerDown(e){
    const at=characterPoint(e);if(!at)return;
    if(tool==='select'){const hit=visibleHit(at.x,at.y);if(hit)select(hit.key);else status('Click a visible part.');return;}
    if(tool==='eyedropper'){sampleCharacter(at);return;}
    if(tool==='fill'){fillCharacter(at);return;}
    const alphas=new Map();
    for(const item of preview.pose?.items||[]){
      if(!item.key||alphas.has(item.key))continue;
      const piece=ensurePart(item.key);
      alphas.set(item.key,piece.getContext('2d').getImageData(0,0,piece.width,piece.height).data);
    }
    stroke={kind:'body',docId:model.docId,tool,color:rgba(),opacity:Number($('opacity').value)/100,size:Number($('size').value),last:at,alphas,masks:new Map(),originals:new Map()};
    $('paint').setPointerCapture(e.pointerId);
    extendBody(at);
  }
  function extendBody(at){
    const from=stroke.last,radius=Math.max(0.5,stroke.size/2),instances=preview.pose?.items||[];
    for(const inst of instances){
      if(!inst.key)continue;
      const piece=ensurePart(inst.key);
      let x0=piece.width,y0=piece.height,x1=-1,y1=-1,steps=Math.max(1,Math.ceil(Math.hypot(at.x-from.x,at.y-from.y)));
      for(let i=0;i<=steps;i++){
        const cx=from.x+(at.x-from.x)*i/steps,cy=from.y+(at.y-from.y)*i/steps;
        for(const [ox,oy] of [[0,0],[-radius,0],[radius,0],[0,-radius],[0,radius],[-radius,-radius],[radius,radius],[-radius,radius],[radius,-radius]]){
          const hit=P.partPoint(inst,cx+ox,cy+oy);if(!hit)continue;
          if(hit.x<x0)x0=hit.x;if(hit.y<y0)y0=hit.y;if(hit.x>x1)x1=hit.x;if(hit.y>y1)y1=hit.y;
        }
      }
      if(x1<0)continue;
      x0=Math.max(0,x0-1);y0=Math.max(0,y0-1);x1=Math.min(piece.width-1,x1+1);y1=Math.min(piece.height-1,y1+1);
      if(!stroke.masks.has(inst.key)){
        stroke.masks.set(inst.key,new Float32Array(piece.width*piece.height));
        stroke.originals.set(inst.key,piece.getContext('2d').getImageData(0,0,piece.width,piece.height));
      }
      const mask=stroke.masks.get(inst.key);
      for(let py=y0;py<=y1;py++)for(let px=x0;px<=x1;px++){
        const char=P.partPixelToCharacter(inst,px,py);
        const cover=P.brushCover(P.segmentDistance(char.x,char.y,from.x,from.y,at.x,at.y),radius);
        if(cover<=0)continue;
        const owner=visibleHit(char.x,char.y,stroke.alphas);
        if(!owner||owner.blocked||owner.key!==inst.key)continue;
        const index=py*piece.width+px;
        if(cover>mask[index])mask[index]=cover;
      }
    }
    applyMasks(stroke.masks,stroke.originals,stroke.color,stroke.opacity,stroke.tool==='eraser');
    stroke.last=at;publishSheet();
  }
  function finishBodyStroke(){
    const changes=[];
    for(const [k,before] of stroke.originals){
      const piece=ensurePart(k),after=piece.getContext('2d').getImageData(0,0,piece.width,piece.height);
      if(before.data.some((v,i)=>v!==after.data[i]))changes.push({key:k,before,after});
    }
    if(changes.length&&history.push({docId:stroke.docId,type:stroke.tool,changes}))noteHistory();
    const count=changes.length;
    stroke=null;updateHistory();publishSheet();
    if(count)status(count>1?'Updated '+count+' textures. One undo puts them all back.':'Updated 1 texture.');
  }
  function sampleCharacter(at){
    const hit=visibleHit(at.x,at.y);if(!hit){status('Eyedropper only samples the character.');return;}
    const piece=ensurePart(hit.key),px=Math.max(0,Math.min(piece.width-1,Math.round(hit.x))),py=Math.max(0,Math.min(piece.height-1,Math.round(hit.y)));
    const data=piece.getContext('2d').getImageData(px,py,1,1).data;
    $('color').value='#'+[...data.slice(0,3)].map(v=>v.toString(16).padStart(2,'0')).join('');
    status('Colour picked from the character.');
  }
  function fillCharacter(at){
    const hit=visibleHit(at.x,at.y);if(!hit){status('Fill stays inside a texture. Click the character.');return;}
    const piece=ensurePart(hit.key),ctx=piece.getContext('2d'),before=ctx.getImageData(0,0,piece.width,piece.height);
    const data=new Uint8ClampedArray(before.data);
    P.flood(data,piece.width,piece.height,hit.x,hit.y,rgba(),Number($('tolerance').value),$('alpha').checked);
    ctx.putImageData(new ImageData(data,piece.width,piece.height),0,0);commitPart(hit.key);
    const after=ctx.getImageData(0,0,piece.width,piece.height);
    if(history.push({docId:model.docId,type:'fill',changes:[{key:hit.key,before,after}]}))noteHistory();
    publishSheet();updateHistory();status('Fill stays inside this texture.');
  }
  function pointerDown(e){
    if(!model||busy||e.button!==0)return;e.preventDefault();
    if(model.view==='body'){bodyPointerDown(e);return;}
    const at=point(e);if(model.view==='atlas'){const found=model.frames.find(([,v])=>at.x>=v.frame.x&&at.x<v.frame.x+v.frame.w&&at.y>=v.frame.y&&at.y<v.frame.y+v.frame.h);if(found)select(found[0]);return;}
    if(tool==='select'){status('Select part works on the full character. Press B to paint this texture.');return;}
    const ctx=part.getContext('2d'),before=ctx.getImageData(0,0,part.width,part.height);
    if(tool==='eyedropper'){const x=Math.min(part.width-1,Math.max(0,Math.floor(at.x))),y=Math.min(part.height-1,Math.max(0,Math.floor(at.y))),i=(y*part.width+x)*4;$('color').value='#'+[...before.data.slice(i,i+3)].map(v=>v.toString(16).padStart(2,'0')).join('');status('Colour picked. Press B to paint.');return;}
    if(tool==='fill'){const data=ctx.getImageData(0,0,part.width,part.height);P.flood(data.data,part.width,part.height,at.x,at.y,rgba(),Number($('tolerance').value),$('alpha').checked);ctx.putImageData(data,0,0);record(before);return;}
    stroke={before,layer:canvas(part.width,part.height),last:at,tool,color:$('color').value,size:Number($('size').value),opacity:Number($('opacity').value)/100,lock:$('alpha').checked};$('paint').setPointerCapture(e.pointerId);dab(at,at);
  }
  function dab(a,b){
    const s=stroke,ctx=s.layer.getContext('2d');ctx.strokeStyle=s.color;ctx.fillStyle=s.color;ctx.lineWidth=s.size;ctx.lineCap='round';ctx.lineJoin='round';ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke();ctx.beginPath();ctx.arc(b.x,b.y,s.size/2,0,Math.PI*2);ctx.fill();
    const target=part.getContext('2d');target.putImageData(s.before,0,0);target.save();target.globalAlpha=s.opacity;target.globalCompositeOperation=s.tool==='eraser'?'destination-out':s.lock?'source-atop':'source-over';target.drawImage(s.layer,0,0);target.restore();
    commitPart(key);showPartSurface();publishSheet();
  }
  function showPartSurface(){
    if(model?.view!=='part'||!part)return;
    const c=$('paint');
    if(c.width!==part.width||c.height!==part.height){c.width=part.width;c.height=part.height;scale(zoom);}
    c.getContext('2d').clearRect(0,0,c.width,c.height);c.getContext('2d').drawImage(part,0,0);
  }
  function pointerMove(e){if(!stroke)return;if(stroke.kind==='body'){const at=characterPoint(e);if(at)extendBody(at);return;}const at=point(e);dab(stroke.last,at);stroke.last=at;}
  function pointerUp(){if(!stroke)return;if(stroke.kind==='body'){finishBodyStroke();return;}const before=stroke.before;stroke=null;record(before);}
  function record(before){const after=part.getContext('2d').getImageData(0,0,part.width,part.height);commitPart(key);if(history.push({docId:model.docId,type:tool,changes:[{key,before,after}]}))noteHistory();showPartSurface();publishSheet();updateHistory();}
  function updateHistory(){$('undo').disabled=!history.undoStack.length;$('redo').disabled=!history.redoStack.length;}
  function undo(redo){
    if(busy)return;
    if(stroke)pointerUp();
    const entry=redo?history.redo():history.undo();
    if(!entry||(entry.docId&&entry.docId!==model.docId))return;
    const changes=entry.changes||[{key:entry.key,before:entry.before,after:entry.after}];
    for(const change of changes){const piece=ensurePart(change.key);piece.getContext('2d').putImageData(redo?change.after:change.before,0,0);commitPart(change.key);}
    noteHistory();
    if(model.view==='part'&&key){part=ensurePart(key);showPartSurface();}
    publishSheet();updateHistory();
  }
  function refresh(){P.commit(model.sheet,model.atlas.frames[key],part);preview?.base?.update?.();schedulePreview();const b=[...$('parts').children].find(b=>b.dataset.key===key);if(b){const c=b.querySelector('canvas'),ctx=c.getContext('2d'),s=Math.min(90/part.width,65/part.height);ctx.clearRect(0,0,100,75);ctx.drawImage(part,(100-part.width*s)/2,(75-part.height*s)/2,part.width*s,part.height*s);}}
  function keydown(e){
    e.stopPropagation();
    if(e.key==='Tab'){const nodes=[...panel.querySelectorAll('button,input')].filter(n=>!n.disabled&&n.getClientRects().length),first=nodes[0],last=nodes.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus();}return;}
    if(e.key==='Escape'){e.preventDefault();close();return;}
    if(['INPUT','TEXTAREA'].includes(e.target.tagName))return;
    if(busy)return;
    const k=e.key.toLowerCase();if((e.ctrlKey||e.metaKey)&&['z','y','s'].includes(k)){e.preventDefault();if(k==='s')save();else undo(k==='y'||e.shiftKey);return;}
    if(model&&(model.view==='part'||model.view==='body')){const t={b:'brush',e:'eraser',f:'fill',i:'eyedropper',s:'select'}[k];if(t){e.preventDefault();setTool(t);}}
  }
  // The native character menu builds module 58640, then start() keeps simulating.
  // Assemble that session, settle it, and remove its enterFrame listener.
  const PREVIEW_SESSION=58640,SETTLE_STEPS=24;
  function pixiRoot(session){return session?.pixiSprite||session?._pixiSprite||null;}
  function disposePreview(){
    const current=preview;preview=null;if(!current)return;
    const state=current.rt?.state,sprite=pixiRoot(current.session);
    if(state&&current.session&&state.currentSession===current.session)state.currentSession=current.savedSession??null;
    try{if(current.holder?.parent)current.holder.parent.removeChild(current.holder);}catch{}
    try{if(sprite?.parent)sprite.parent.removeChild(sprite);}catch{}
    try{current.session?.die?.();}catch{}
    try{current.session?.destroy?.();}catch{}
    for(const t of current.textures?.values?.()||[])try{t.destroy(false);}catch{}
    try{current.base?.destroy?.();}catch{}
  }
  function freezeSimulation(session){
    const step=typeof session.run30fps==='function'?session.run30fps.bind(session):typeof session.run==='function'?session.run.bind(session):null;
    if(step)for(let i=0;i<SETTLE_STEPS;i++){try{step();}catch{break;}}
    try{session._character?.paint?.();}catch{}
    const run=session.run;
    if(typeof run==='function'&&session.listeners&&typeof session.removeEventListener==='function'){
      for(const type of Object.keys(session.listeners)){
        const list=session.listeners[type];
        if(Array.isArray(list)&&list.some(item=>item?.listener===run))session.removeEventListener(type,run);
      }
    }
    try{session.removeEventListener?.('enterFrame',run);}catch{}
  }
  function atlasKey(texture){
    const ids=texture?.textureCacheIds||(texture?.textureCacheId?[texture.textureCacheId]:null);
    const named=ids?.find(k=>model.atlas.frames[k]);
    if(named)return named;
    const f=texture?.frame;if(!f)return null;
    let best=null,score=1e9;
    for(const [k,item] of Object.entries(model.atlas.frames)){
      const a=item.frame,dw=Math.min(Math.abs(a.w-f.width)+Math.abs(a.h-f.height),Math.abs(a.w-f.height)+Math.abs(a.h-f.width));
      const dp=Math.abs(a.x-f.x)+Math.abs(a.y-f.y);
      if(dw<3&&dp<score){score=dp;best=k;}
    }
    return score<6?best:null;
  }
  function dressPreview(){
    const {session,rt,base,textures,hits}=preview,seen=new Set(),names=new Map();
    hits.length=0;
    const character=session._character;
    if(character)for(const [name,value] of Object.entries(character)){
      if(value?.pixiSprite)names.set(value.pixiSprite,name);
      if(Array.isArray(value))for(const item of value)if(item?.pixiSprite)names.set(item.pixiSprite,name);
    }
    function visit(sprite){
      if(!sprite||seen.has(sprite))return;seen.add(sprite);
      const name=names.get(sprite)||sprite._flashSprite?.name||sprite.name||'';
      if(/shapeGuide|shapeRef/i.test(String(name))){sprite.visible=false;return;}
      if(sprite.texture&&sprite.visible!==false){
        const owned=[...textures.values()].includes(sprite.texture);
        const k=owned?[...textures.entries()].find(([,t])=>t===sprite.texture)?.[0]:atlasKey(sprite.texture);
        if(k&&!owned&&sprite.texture.orig?.clone){
          let t=textures.get(k);
          if(!t){const f=model.atlas.frames[k].frame,o=sprite.texture;t=new rt.pixi.gPd(base,new rt.pixi.M_G(f.x,f.y,f.w,f.h),o.orig.clone(),o.trim?.clone?.()||o.trim,o.rotate||0);textures.set(k,t);}
          sprite.texture=t;
          if(name)model.labels.set(k,pretty(String(name).replace(/MCs?$/,'').replace(/([a-z])([A-Z])/g,'$1 $2')));
        }
        if(k)hits.push({node:sprite,key:k});
      }
      for(const child of sprite.children||[])visit(child);
    }
    visit(pixiRoot(session));
  }
  function buildPreview(){
    const rt=window.HWCustomCharacters.creatorRuntime();if(!rt?.app?.stage)throw Error('The game is still loading. Try again in a moment.');
    const Preview=rt.require(PREVIEW_SESSION)?.v,source=rt.require(1050)?.iG?.(model.base);
    if(typeof Preview!=='function'||!source?.pixiMovieClip)throw Error('This game build does not expose the character preview.');
    const state=rt.state,savedIndex=state.characterIndex,savedSession=state.currentSession;
    state.characterIndex=model.base;
    let session,holder;
    try{
      session=new Preview(source);
      const sprite=pixiRoot(session);
      if(!sprite?.emit)throw Error('This game build does not expose the character preview.');
      state.currentSession=session;
      holder=new rt.pixi.mcf();holder.renderable=false;holder.position.set(4000,4000);
      rt.app.stage.addChild(holder);holder.addChild(sprite);
      session.visible=false;session.scaleX=session.scaleY=1;session.x=0;session.y=0;
      session.create();
      freezeSimulation(session);
      session.visible=true;
    }catch(e){
      try{holder?.parent?.removeChild(holder);}catch{}
      try{session?.die?.();}catch{}
      throw e;
    }finally{
      state.characterIndex=savedIndex;
      state.currentSession=savedSession??null;
    }
    const texture=rt.pixi.gPd.from(model.sheet);
    preview={rt,session,holder,savedSession,base:texture.baseTexture,textures:new Map(),hits:[],bounds:null,snapshot:null};
    dressPreview();
    captureSnapshot();
  }
  function partBounds(root){
    const inv=root.worldTransform.clone();inv.invert();
    let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity,count=0;
    function walk(node){
      if(!node||node.visible===false)return;
      const tex=node.texture,b=tex&&node.getBounds?.();
      if(b&&b.width>1&&b.height>1&&b.width<2200&&b.height<2200&&tex.width<2200&&tex.height<2200){
        for(const [x,y] of [[b.x,b.y],[b.x+b.width,b.y],[b.x,b.y+b.height],[b.x+b.width,b.y+b.height]]){
          const lx=inv.a*x+inv.c*y+inv.tx,ly=inv.b*x+inv.d*y+inv.ty;
          if(lx<minX)minX=lx;if(ly<minY)minY=ly;if(lx>maxX)maxX=lx;if(ly>maxY)maxY=ly;
        }
        count++;
      }
      for(const child of node.children||[])walk(child);
    }
    walk(root);
    if(!count)return null;
    const pad=18;
    return {x:minX-pad,y:minY-pad,width:Math.max(1,maxX-minX+pad*2),height:Math.max(1,maxY-minY+pad*2)};
  }
  function textureSource(tex){return tex?.baseTexture?.resource?.source||tex?.baseTexture?.source||null;}
  function drawFrame(ctx,source,tex,dx,dy,dw,dh){
    const frame=tex.frame,rot=tex.rotate||0;
    if(!frame||!source)return;
    if(rot===2){ctx.translate(dx+dh,dy);ctx.rotate(Math.PI/2);ctx.drawImage(source,frame.x,frame.y,frame.width,frame.height,0,0,dh,dw);}
    else if(rot===6){ctx.translate(dx,dy+dw);ctx.rotate(-Math.PI/2);ctx.drawImage(source,frame.x,frame.y,frame.width,frame.height,0,0,dh,dw);}
    else if(rot===4||rot===8){ctx.translate(dx+dw,dy+dh);ctx.rotate(Math.PI);ctx.drawImage(source,frame.x,frame.y,frame.width,frame.height,0,0,dw,dh);}
    else ctx.drawImage(source,frame.x,frame.y,frame.width,frame.height,dx,dy,dw,dh);
  }
  function captureSnapshot(){
    const root=pixiRoot(preview.session);
    root.position.set(0,0);root.scale.set(1,1);root.updateTransform();
    const inv=root.worldTransform.clone();inv.invert();
    const sprites=[];
    function walk(node){
      if(!node||node.visible===false||node.worldAlpha===0)return;
      const tex=node.texture,source=textureSource(tex);
      if(source&&tex.frame&&tex.width>1&&tex.height>1&&tex.width<2200&&tex.height<2200)sprites.push(node);
      for(const child of node.children||[])walk(child);
    }
    walk(root);
    if(!sprites.length)throw Error('The character preview has no visible parts.');
    let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
    const placed=sprites.map(sprite=>{
      const tex=sprite.texture,anchorX=sprite.anchor?.x||0,anchorY=sprite.anchor?.y||0;
      const origW=tex.orig?.width||tex.width,origH=tex.orig?.height||tex.height,trim=tex.trim;
      const dx=-anchorX*origW+(trim?trim.x:0),dy=-anchorY*origH+(trim?trim.y:0);
      const dw=trim?trim.width:origW,dh=trim?trim.height:origH;
      const local=inv.clone();local.append(sprite.worldTransform);
      for(const [x,y] of [[dx,dy],[dx+dw,dy],[dx,dy+dh],[dx+dw,dy+dh]]){
        const lx=local.a*x+local.c*y+local.tx,ly=local.b*x+local.d*y+local.ty;
        if(lx<minX)minX=lx;if(ly<minY)minY=ly;if(lx>maxX)maxX=lx;if(ly>maxY)maxY=ly;
      }
      const owned=[...preview.textures.values()].includes(tex);
      const frameKey=owned?[...preview.textures.entries()].find(([,t])=>t===tex)?.[0]:atlasKey(tex);
      return {sprite,local,dx,dy,dw,dh,key:frameKey};
    });
    const pad=18,width=Math.max(1,Math.ceil(maxX-minX+pad*2)),height=Math.max(1,Math.ceil(maxY-minY+pad*2));
    if(!preview.pose){
      preview.pose={minX,minY,width,height,pad,items:placed.map(item=>{
        const frame=model.atlas.frames[item.key];
        const partW=frame?(frame.rotated?frame.frame.h:frame.frame.w):item.dw;
        const partH=frame?(frame.rotated?frame.frame.w:frame.frame.h):item.dh;
        return {key:item.key,a:item.local.a,b:item.local.b,c:item.local.c,d:item.local.d,tx:item.local.tx,ty:item.local.ty,dx:item.dx,dy:item.dy,dw:item.dw,dh:item.dh,partW,partH,sprite:item.sprite};
      })};
      preview.quads=preview.pose.items.filter(item=>item.key);
      preview.bounds={x:minX-pad,y:minY-pad,width,height};
      preview.full=preview.bounds;
    }
    const pose=preview.pose;
    const snap=preview.snapshot?.width===pose.width&&preview.snapshot?.height===pose.height?preview.snapshot:canvas(pose.width,pose.height);
    const ctx=snap.getContext('2d');
    ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,pose.width,pose.height);
    ctx.translate(pose.pad-pose.minX,pose.pad-pose.minY);
    for(const item of pose.items){
      ctx.save();
      ctx.transform(item.a,item.b,item.c,item.d,item.tx,item.ty);
      ctx.globalAlpha=item.sprite.worldAlpha??1;
      try{drawFrame(ctx,textureSource(item.sprite.texture),item.sprite.texture,item.dx,item.dy,item.dw,item.dh);}catch{}
      ctx.restore();
    }
    preview.snapshot=snap;
  }
  function lockFraming(){captureSnapshot();}
  function schedulePreview(){
    if(!preview||renderQueued)return;
    renderQueued=true;
    const doc=model?.docId;
    requestAnimationFrame(()=>{
      renderQueued=false;
      if(!preview?.session||model?.docId!==doc)return;
      try{captureSnapshot();paintVisiblePreviews();}catch(e){error(e);}
    });
  }
  function paintVisiblePreviews(){
    if(!preview?.snapshot)return;
    if($('editor').hidden)blitPreview($('template-canvas'));
    else{blitPreview($('live'));if(model?.view==='body')blitPreview($('paint'));}
  }
  function blitSnapshot(image,bounds,target){
    const ctx=target.getContext('2d');
    const scale=Math.min((target.width-44)/Math.max(1,image.width),(target.height-44)/Math.max(1,image.height));
    const x=(target.width-image.width*scale)/2,y=(target.height-image.height*scale)/2;
    ctx.clearRect(0,0,target.width,target.height);
    ctx.drawImage(image,x,y,image.width*scale,image.height*scale);
    target.__creatorMap={x,y,scale,bounds};
  }
  function blitPreview(target){if(preview?.snapshot&&target)blitSnapshot(preview.snapshot,preview.bounds,target);}
  function textureSample(texture){
    const source=texture.baseTexture?.resource?.source||texture.baseTexture?.source;
    if(!source)return null;
    if(preview.samples?.has(texture.baseTexture))return preview.samples.get(texture.baseTexture);
    const sample=canvas(source.width||texture.baseTexture.width,source.height||texture.baseTexture.height);
    try{sample.getContext('2d').drawImage(source,0,0);}catch{return null;}
    preview.samples=preview.samples||new Map();
    preview.samples.set(texture.baseTexture,sample);
    return sample;
  }
  function spriteOpaque(sprite,wx,wy){
    if(sprite.visible===false||sprite.worldAlpha===0)return false;
    const inv=sprite.worldTransform?.clone?.();if(!inv?.invert)return false;inv.invert();
    const lx=inv.a*wx+inv.c*wy+inv.tx,ly=inv.b*wx+inv.d*wy+inv.ty;
    const tex=sprite.texture;if(!tex)return false;
    const anchorX=sprite.anchor?.x||0,anchorY=sprite.anchor?.y||0;
    const origW=tex.orig?.width||tex.width,origH=tex.orig?.height||tex.height;
    const px=lx+anchorX*origW,py=ly+anchorY*origH;
    if(px<0||py<0||px>=origW||py>=origH)return false;
    const trim=tex.trim;
    let u,v;
    if(trim){
      if(px<trim.x||py<trim.y||px>=trim.x+trim.width||py>=trim.y+trim.height)return false;
      u=(px-trim.x)/Math.max(1,trim.width);v=(py-trim.y)/Math.max(1,trim.height);
    }else{u=px/origW;v=py/origH;}
    const frame=tex.frame;if(!frame)return true;
    const rot=tex.rotate||0;
    let ax,ay;
    if(rot===2){ax=frame.x+v*frame.width;ay=frame.y+(1-u)*frame.height;}
    else if(rot===6){ax=frame.x+(1-v)*frame.width;ay=frame.y+u*frame.height;}
    else if(rot===4||rot===8){ax=frame.x+(1-u)*frame.width;ay=frame.y+(1-v)*frame.height;}
    else{ax=frame.x+u*frame.width;ay=frame.y+v*frame.height;}
    const sample=textureSample(tex);if(!sample)return true;
    const image=sample.getContext('2d').getImageData(Math.max(0,Math.min(sample.width-1,Math.floor(ax))),Math.max(0,Math.min(sample.height-1,Math.floor(ay))),1,1).data;
    return image[3]>16;
  }
  function lockEditing(locked){
    if(!panel)return;
    for(const id of ['name','undo','redo','back','save','close','full','atlas']){const node=$(id);if(node)node.disabled=locked;}
    for(const node of panel.querySelectorAll('.templates button, .tools button, .swatches button'))node.disabled=locked;
    $('paint').style.pointerEvents=locked?'none':'';
  }
  async function save(){
    if(!model||busy)return;if(stroke)pointerUp();const name=$('name').value.trim();if(!name){$('name').focus();status('Give your character a name first.');return;}
    const rev=docRev,sheet=model.sheet.toDataURL('image/png'),base=model.base;
    busy=true;lockEditing(true);status('Saving your character…');
    try{
      captureSnapshot();
      const icon=canvas(128,128);blitPreview(icon);
      const result=await window.hwCharacterCreator.save({name,base,sheet,icon:icon.toDataURL('image/png'),id:model.characterId||undefined});
      const placed=await window.HWCustomCharacters.addCreated(result);
      model.characterId=result.id;
      if(docRev===rev){savedDepth=history.undoStack.length;unsavedName=false;dirty=false;}
      if(result.published===false)status('Saved, but it could not be published into the game yet. Save again to retry.');
      else if(placed?.available===false)status('Saved, but no character slot is available.');
      else status('Saved “'+name+'”. It is now available in character selection.');
      $('step').textContent='03 / Ready to play';
    }catch(e){error(e);}finally{busy=false;if(panel)lockEditing(false);}
  }
  function install(){
    const rt=window.HWCustomCharacters?.creatorRuntime?.(),menu=rt?.state.rootApp.screenManager.currentScreen?.happyWheels?.mainMenu;
    if(!menu?.optionsBtn||!Array.isArray(menu.buttons))return;
    const session=rt.state.currentSession,controller=rt.state.rootApp.screenManager.currentScreen.happyWheels.sessionController;
    const onTitle=!controller&&!(session&&!session.isMenu&&session.m_world)&&menu.optionsBtn.visible!==false;
    if(!menu.characterCreatorBtn){
      const ref=menu.optionsBtn,format=ref.textField.defaultTextFormat,b=new ref.constructor('CHARACTER CREATOR',format.size,format.color);
      b.addEventListener('click',open);menu.characterCreatorBtn=b;menu.addChild(b);
    }
    const b=menu.characterCreatorBtn,list=menu.buttons,gap=menu.buttonSpacing||0;
    const listed=list.includes(b);
    if(!onTitle){
      if(listed){list.splice(list.indexOf(b),1);menu.spaceHeight=Math.max(0,(menu.spaceHeight||0)-gap);try{menu.organizeButtons();}catch{}}
      b.visible=false;return;
    }
    const place=()=>{const mp=list.indexOf(menu.multiplayerBtn),opt=list.indexOf(menu.optionsBtn);return mp>=0?mp+1:(opt<0?list.length:opt);};
    if(!listed){menu.spaceHeight=(menu.spaceHeight||0)+gap;list.splice(place(),0,b);try{menu.organizeButtons();}catch{}}
    else if(list.indexOf(b)!==place()){list.splice(list.indexOf(b),1);list.splice(place(),0,b);try{menu.organizeButtons();}catch{}}
    b.x=menu.optionsBtn.x;b.visible=true;
  }
  window.HWCharacterCreator={open,close,diagnostics:()=>({open:!!panel,base:model?.base,part:key,dirty,previewParts:preview?.hits.length||0})};
  setInterval(()=>{try{install();}catch(e){console.warn('[Character creator menu]',e.message);}},500);
})();
