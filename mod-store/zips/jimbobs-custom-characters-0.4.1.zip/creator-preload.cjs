'use strict';
const {contextBridge,ipcRenderer}=require('electron');
try{contextBridge.exposeInMainWorld('hwCharacterCreator',Object.freeze({
  template:base=>ipcRenderer.invoke('hw-character:template',base),
  save:data=>ipcRenderer.invoke('hw-character:save',data)
}));}catch(error){console.warn('[Character creator]',error.message);}
