'use strict';
const fs = require('node:fs');
const path = require('node:path');

function writeIndex(dir) {
  if (!fs.existsSync(dir) || !fs.statSync(dir).isDirectory()) return;
  const ids = [];
  for (const item of fs.readdirSync(dir, {withFileTypes: true})) {
    if (!item.isDirectory()) continue;
    if (!/^[a-z0-9][a-z0-9-]*$/i.test(item.name)) continue;
    if (fs.existsSync(path.join(dir, item.name, 'character.json'))) ids.push(item.name);
  }
  ids.sort((a, b) => a.localeCompare(b));
  fs.writeFileSync(path.join(dir, 'index.json'), `${JSON.stringify({characters: ids}, null, 2)}\n`);
}

writeIndex(path.join(__dirname, 'web', 'characters'));
writeIndex(path.join(__dirname, '..', '..', 'resources', 'webroot', 'js', 'jimbobs-custom-characters', 'characters'));

const {ipcMain,nativeImage,app,session}=require('electron');
// Current game builds use a sandboxed preload. Register this standalone bridge
// after session creation instead of relying on nested require() in that sandbox.
app.whenReady().then(()=>{
  const preload=path.join(__dirname,'creator-preload.cjs');
  const list=session.defaultSession.getPreloads();
  if(!list.includes(preload))session.defaultSession.setPreloads([...list,preload]);
});
const {createStore}=require('./creator-store.cjs');
const store=createStore(__dirname,path.join(__dirname,'..','..','resources','webroot'));
function trusted(event){
  const url=new URL(event.senderFrame?.url||'about:blank');
  if(event.senderFrame!==event.sender.mainFrame||url.origin!=='https://totaljerkface.com'||!url.pathname.startsWith('/__hw_app__/'))throw Error('Invalid character creator sender.');
}
ipcMain.handle('hw-character:template',(event,base)=>{trusted(event);return store.template(base);});
ipcMain.handle('hw-character:save',(event,data)=>{trusted(event);return store.save(data,image=>{
  const decoded=nativeImage.createFromBuffer(image.bytes),size=decoded.getSize();
  if(decoded.isEmpty()||size.width!==image.width||size.height!==image.height)throw Error('The image could not be decoded.');
});});
