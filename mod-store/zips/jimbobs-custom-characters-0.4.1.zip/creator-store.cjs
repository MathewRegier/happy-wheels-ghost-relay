'use strict';
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const NAMES=['Wheelchair Guy','Segway Guy','Irresponsible Dad','Effective Shopper','Moped Couple','Lawnmower Man','Explorer Guy','Santa','Pogo Stick Man','Irresponsible Mom','Helicopter Man'];
function png(data){
  if(typeof data!=='string'||data.length>24*1024*1024||!/^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(data))throw Error('Invalid PNG image.');
  const b=Buffer.from(data.split(',')[1],'base64');
  if(b.length<33||b.subarray(0,8).toString('hex')!=='89504e470d0a1a0a'||b.toString('ascii',12,16)!=='IHDR')throw Error('Invalid PNG header.');
  const width=b.readUInt32BE(16),height=b.readUInt32BE(20);
  if(!width||!height||width>8192||height>8192||width*height>32*1024*1024)throw Error('Image dimensions are too large.');
  return {bytes:b,width,height};
}
function createStore(modRoot,webroot){
  const characterRoot=path.join(modRoot,'web','characters');
  const servedRoot=path.join(webroot,'js','jimbobs-custom-characters','characters');
  function atlas(base){
    if(!Number.isInteger(base)||base<1||base>11)throw Error('Choose a valid template.');
    const folder=fs.readdirSync(webroot,{withFileTypes:true}).find(e=>e.isDirectory()&&e.name.startsWith('assets-')&&fs.existsSync(path.join(webroot,e.name,'animate',`character${base}`,`character${base}.json`)));
    if(!folder)throw Error('The game character assets could not be found.');
    const dir=path.join(webroot,folder.name,'animate',`character${base}`);
    return {dir,data:JSON.parse(fs.readFileSync(path.join(dir,`character${base}.json`),'utf8'))};
  }
  function template(base){
    const {dir,data}=atlas(base);
    return {base,name:NAMES[base-1],atlas:data,sheet:'data:image/png;base64,'+fs.readFileSync(path.join(dir,`character${base}.png`)).toString('base64')};
  }
  function index(root){
    const ids=fs.readdirSync(root,{withFileTypes:true}).filter(e=>e.isDirectory()&&/^[a-z0-9][a-z0-9-]*$/i.test(e.name)&&fs.existsSync(path.join(root,e.name,'character.json'))).map(e=>e.name).sort();
    const tmp=path.join(root,`.index-${crypto.randomUUID()}.tmp`);
    fs.writeFileSync(tmp,JSON.stringify({characters:ids},null,2));fs.renameSync(tmp,path.join(root,'index.json'));
  }
  function save(input,validateImage){
    if(!input||typeof input.name!=='string'||!input.name.trim()||input.name.trim().length>60)throw Error('Enter a name between 1 and 60 characters.');
    const {data}=atlas(input.base),sheet=png(input.sheet),icon=png(input.icon);
    if(sheet.width!==data.meta.size.w||sheet.height!==data.meta.size.h)throw Error('The sheet must keep the template dimensions.');
    if(icon.width!==128||icon.height!==128)throw Error('The portrait must be 128 × 128.');
    if(validateImage){validateImage(sheet);validateImage(icon);}
    const id=typeof input.id==='string'&&/^[a-z0-9][a-z0-9-]*$/i.test(input.id)?input.id:(input.name.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,40)||'character')+'-'+crypto.randomBytes(6).toString('hex');
    const manifest={name:input.name.trim(),base:input.base,sheet:'sheet.png',icon:'icon.png',creatorVersion:1};
    const roots=[characterRoot,servedRoot].filter((root,index,list)=>list.indexOf(root)===index);
    function writeRoot(root){
      fs.mkdirSync(root,{recursive:true});
      const staging=path.join(root,`.creating-${id}`),dest=path.join(root,id);
      fs.rmSync(staging,{recursive:true,force:true});
      fs.mkdirSync(staging);
      fs.writeFileSync(path.join(staging,'sheet.png'),sheet.bytes);
      fs.writeFileSync(path.join(staging,'icon.png'),icon.bytes);
      fs.writeFileSync(path.join(staging,'character.json'),JSON.stringify(manifest,null,2));
      fs.rmSync(dest,{recursive:true,force:true});
      fs.renameSync(staging,dest);index(root);
    }
    writeRoot(roots[0]);
    let published=true;
    if(roots[1]){try{writeRoot(roots[1]);}catch{published=false;}}
    return {id,...manifest,published,folder:path.join(characterRoot,id)};
  }
  return {template,save};
}
module.exports={createStore,png,NAMES};
