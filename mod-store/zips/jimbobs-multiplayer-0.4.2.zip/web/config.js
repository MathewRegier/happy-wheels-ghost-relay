// Player build settings. Rebuild with tools/setup.py after changing these defaults.
window.HWGhostConfig = Object.freeze({
  development: false,
  version: '0.4.2',
  defaultRelayUrl: 'wss://web-production-79ef3.up.railway.app'
});
