(() => {
  'use strict';
  // Shared Physics v2: one host simulation. Guests never step collision physics.
  window.HWSharedWorld = (lab, send, message) => {
    const fields=['leftPressed','rightPressed','upPressed','downPressed','spacePressed','shiftPressed','ctrlPressed','zPressed'];
    const nestedKeys=['son','daughter','kid','dad','mom','elf1','elf2','elves','rider','passenger','girl','characters','vehicle','bike','segway'];
    const jointNames=['neckJoint','waistJoint','shoulderJoint1','shoulderJoint2','elbowJoint1','elbowJoint2','hipJoint1','hipJoint2','kneeJoint1','kneeJoint2'];
    const breakFn={neckJoint:'neckBreak',waistJoint:'torsoBreak',shoulderJoint1:'shoulderBreak1',shoulderJoint2:'shoulderBreak2',elbowJoint1:'elbowBreak1',elbowJoint2:'elbowBreak2',hipJoint1:'hipBreak1',hipJoint2:'hipBreak2',kneeJoint1:'kneeBreak1',kneeJoint2:'kneeBreak2'};
    const smashFn={head:'headSmash',chest:'chestSmash',pelvis:'pelvisSmash'};
    const DAMAGE_METHODS=new Set([...Object.values(breakFn),...Object.values(smashFn),'backWheelSmash','frontWheelSmash','eject','explode']);
    const FLOW_CALLS=new Set(['createBloodFlow','createPointFlow','createFlow']);
    const CHARACTER_CLASSES=34531,CHARACTER_DATA=1050;
    const actors=new Map(),poses=new Map(),ctors=new Map(),badCtors=new WeakSet();
    const inputs=new Map(),requests=[],restores=[],worldEntries=new Map();
    let context=null,world=null,epoch=null,localKind=0,tick=0,revision=0,inputSeq=0,requestSeq=0,lastSent=0,lastInput=0,lastArrival=0,lastReceived=-1;
    let levelSignature='',levelBodies=[],worldIds=new WeakMap(),nextWorldId=0,ready=false,failed=false,mutatingOwner=null;
    let keys=0,remoteFrame=null,previousFrame=null,applying=false,openingUntil=0,releasedAt=0,seenRevision=-1,lastTextures=[],lastTextureJson='',lastSignatureSent='',snapshotCount=0;
    let damageDepth=0,simulating=0,replayingDamage=0,effectSeq=0,lastEffect=0,loopSeq=0,effects=[];
    const hostLoops=new Map(),mirrorLoops=new Map(),emitters=new Map();
    const doneEffects=new Set();
    const pendingEffects=[];
    const acks=new Map(),lastWorldPose=new Map();
    const staleMs=750,inputTimeout=750,OPEN_MS=10000,PROTECT_MS=3000,OVERLAP_MS=500,EVENT_KEEP=64;
    const now=()=>performance.now();
    const active=()=>context?.room?.mode==='shared'&&!!context.raceStart;
    const guest=()=>active()&&!context.isHost;
    const playing=()=>active()&&context.released&&world&&!failed;
    const badge=document.createElement('div');badge.hidden=true;badge.style.cssText='position:fixed;left:12px;bottom:12px;z-index:9995;background:#172127e8;color:#fff;padding:8px 12px;font:15px Georgia;pointer-events:none';document.body.append(badge);
    function q(n){return Math.round(Number(n)*1000)/1000;}

    function menuOpen(){
      const menu=sessionController()?.characterMenu;
      return !!(menu&&menu.parent&&menu.visible!==false);
    }

    function localIndex(){
      const n=Number(lab.state?.characterIndex);
      const live=Number.isInteger(n)&&n>0?n:1;
      // Hovering the character menu changes characterIndex. Keep advertising the
      // committed type so a preview does not rebuild every remote rider.
      if(menuOpen()&&localKind)return localKind;
      return live;
    }

    function playerIndex(id){
      if(id===context?.selfId)return localIndex();
      const n=Number(context?.room?.players?.find(p=>p.id===id)?.character);
      return Number.isInteger(n)&&n>0?n:null;
    }

    function poseKind(pose){
      const n=Number(pose?.character);
      return Number.isInteger(n)&&n>0?n:null;
    }

    function wantedKind(id,pose){
      return poseKind(pose)||playerIndex(id)||localIndex();
    }

    function sessionController(){
      return lab.state?.rootApp?.screenManager?.currentScreen?.happyWheels?.sessionController||null;
    }

    function playableCtor(fn){
      return typeof fn==='function'&&!!fn.prototype&&typeof fn.prototype.create==='function'&&typeof fn.prototype.reset==='function';
    }

    function rememberCtor(kind,character){
      const ctor=character?.constructor;
      if(!Number.isInteger(kind)||kind<1||!playableCtor(ctor)||badCtors.has(ctor))return;
      ctors.set(kind,ctor);
    }

    function harvestCtors(){
      const session=lab.state?.currentSession;
      if(session?.character&&session.character.main!==false&&!menuOpen())rememberCtor(localIndex(),session.character);
    }

    function gameModule(id){
      try{return lab.require?.(id)||null;}catch{return null;}
    }

    function classKey(kind,session){
      if(lab.state?.hideVehicle)return 'Wf';
      const v111=Number(session?.version)>=1.11;
      return {1:'Qd',2:v111?'HK':'ae',3:'jm',4:v111?'Rf':'_w',5:'eV',6:'V8',7:'AE',8:'sB',9:'yP',10:'Jw',11:'_0'}[kind]||null;
    }

    function nativeClass(kind,session){
      const key=classKey(kind,session);
      const fn=key&&gameModule(CHARACTER_CLASSES)?.[key];
      return playableCtor(fn)&&!badCtors.has(fn)?fn:null;
    }

    function nativeSource(kind){
      const make=gameModule(CHARACTER_DATA)?.iG;
      if(typeof make!=='function')return null;
      const source=make(kind);
      return source?.pixiMovieClip?source:null;
    }

    function withKind(kind,fn){
      const state=lab.state;
      if(!state)return fn();
      const prev=state.characterIndex;
      try{state.characterIndex=kind;return fn();}
      finally{state.characterIndex=prev;}
    }

    function ctorFor(kind,session){
      harvestCtors();
      return nativeClass(kind,session)||ctors.get(kind)||null;
    }

    function riders(character){
      const list=[],seen=new Set();
      function add(obj){
        if(!obj||typeof obj!=='object'||seen.has(obj))return;
        seen.add(obj);list.push(obj);
        for(const key of nestedKeys){
          const value=obj[key];
          if(Array.isArray(value))for(const item of value)add(item);
          else add(value);
        }
      }
      add(character);
      return list;
    }

    function isBody(value){return !!value&&typeof value.GetPosition==='function'&&typeof value.GetAngle==='function';}

    function namedBodies(character){
      const map={};
      riders(character).forEach((rider,index)=>{
        for(const [key,value] of Object.entries(rider)){
          if(!isBody(value))continue;
          if(!/Body$/.test(key)&&!/^(vehicle|bike|body|wheel|frame)$/.test(key))continue;
          map[index+':'+key]=value;
        }
        const vector=Array.isArray(rider.paintVector)?rider.paintVector:[];
        vector.forEach((body,i)=>{
          if(!isBody(body)||Object.values(map).includes(body))return;
          map[index+':pv'+i]=body;
        });
      });
      return map;
    }

    function paintBodies(character){
      const bodies=[],seen=new Set();
      for(const body of Object.values(namedBodies(character))){
        if(!body||seen.has(body))continue;
        seen.add(body);bodies.push(body);
      }
      return bodies;
    }

    function riderBodies(character){
      const list=[],seen=new Set();
      const add=body=>{if(isBody(body)&&!seen.has(body)){seen.add(body);list.push(body);}};
      for(const rider of riders(character)){
        for(const value of Object.values(rider))if(isBody(value))add(value);
        for(const body of rider.paintVector||[])add(body);
        if(Array.isArray(rider._bodies))for(const body of rider._bodies)add(body);
      }
      return list;
    }

    function characterLayer(session,character){
      return character?.characterLayer||session?.character?.characterLayer||session?.level?.characterLayer||null;
    }

    function tagBody(body,id){
      if(!body||!id)return;
      try{body.__hwShared=id;}catch{}
      try{const mc=body.GetUserData?.();if(mc)mc.__hwShared=id;}catch{}
    }

    function tagMovie(node,id){
      if(!node||typeof node!=='object'||node.__hwShared===id)return;
      try{node.__hwShared=id;}catch{}
      for(let i=1;i<8;i++){
        const chunk=node['chunk'+i];
        if(chunk)try{chunk.__hwShared=id;}catch{}
      }
    }

    function worldBodies(session){
      const list=[];
      if(session?.m_world?.GetBodyList)for(let body=session.m_world.GetBodyList();body;body=body.GetNext())list.push(body);
      return list;
    }

    function killBlood(character){
      for(const rider of riders(character||{})){
        for(const [key,value] of Object.entries(rider)){
          if(!value||typeof value!=='object')continue;
          if(!/Blood|intestine|Intestine|spew|Flow/i.test(key)&&!value.stopSpewing)continue;
          try{value.stopSpewing?.();}catch{}
          try{value.remove?.();}catch{}
          try{value.parent?.removeChild(value);}catch{}
          try{rider[key]=null;}catch{}
        }
      }
    }

    function ownedDisplayNodes(character){
      const nodes=new Set();
      const add=node=>{
        if(!node||typeof node!=='object')return;
        if(node.pixiSprite)nodes.add(node.pixiSprite);
        if(node.parent||node.graphics||node.texture)nodes.add(node);
      };
      for(const rider of riders(character||{})){
        for(const [key,value] of Object.entries(rider)){
          if(!/MCs?$|MovieClips?$|BloodFlow$|Rope$|ropes$|Graphics$|gfx$/i.test(key)&&!/rope|girl/i.test(key))continue;
          for(const node of Array.isArray(value)?value:[value])add(node);
        }
        for(const body of rider.paintVector||[])add(body.GetUserData?.());
      }
      for(const body of riderBodies(character))add(body.GetUserData?.());
      return nodes;
    }

    function stripCharacter(character){
      // Collect first: killBlood nulls fields such as intestineMCs.
      const nodes=ownedDisplayNodes(character);
      killBlood(character);
      // Detach wrappers using their native parent API. Do not recursively destroy
      // shared Pixi resources or the session/level reachable from the character.
      for(const node of nodes)try{node.parent?.removeChild(node);}catch{}
    }

    function readPose(body){
      const p=body.GetPosition(),v=body.GetLinearVelocity();
      return [q(p.x),q(p.y),q(body.GetAngle()),q(v.x),q(v.y),q(body.GetAngularVelocity())];
    }

    function vec2(sample,x,y){
      try{const v=new sample.constructor(x,y);if(typeof v.x==='number')return v;}catch{}
      if(sample&&typeof sample.Set==='function'){try{const v=sample.Copy?.()||sample;v.Set(x,y);return v;}catch{}}
      return {x,y};
    }

    function readBreaks(character){
      const flags=[];
      riders(character).forEach((rider,index)=>{
        for(const name of jointNames)if(rider[name]?.broken)flags.push(index+':'+name);
        if(rider.headMC&&rider.headMC.visible===false)flags.push(index+':smash:head');
        if(rider.chestMC&&rider.chestMC.visible===false)flags.push(index+':smash:chest');
        if(rider.pelvisMC&&rider.pelvisMC.visible===false)flags.push(index+':smash:pelvis');
      });
      return flags;
    }

    function applyBreaks(character,flags){
      if(!character||!flags?.length)return;
      const list=riders(character);
      for(const flag of flags){
        const parts=String(flag).split(':');
        const rider=list[Number(parts[0])];
        if(!rider)continue;
        if(parts[1]==='smash'){
          const fn=smashFn[parts[2]];
          if(fn&&typeof rider[fn]==='function'){
            const mc=rider[parts[2]+'MC'];
            if(mc&&mc.visible===false)continue;
            try{rider[fn](0);}catch{}
          }
          continue;
        }
        const name=parts[1],joint=rider[name];
        if(!joint||joint.broken)continue;
        const fn=breakFn[name];
        if(fn&&typeof rider[fn]==='function')try{rider[fn](0);}catch{}
        else try{joint.broken=true;character.session?.m_world?.DestroyJoint(joint);}catch{}
      }
    }

    function paintAll(character){
      for(const rider of riders(character))try{rider.paint();}catch{}
    }

    function report(error){
      const text=String(error?.stack||error);if(lab.errors.length<100)lab.errors.push(text);
      failed=true;badge.hidden=false;badge.textContent='Shared Physics paused: '+String(error?.message||error);message(badge.textContent);
    }
    function patch(obj,key,fn){const original=obj[key];obj[key]=fn(original);restores.push(()=>{obj[key]=original});}
    function inActor(actor,fn){
      const previous=world.character,focus=world.camera?.focus;
      const owner=mutatingOwner;mutatingOwner=actor;
      try{world.character=actor.character;return withKind(actor.kind,fn);}
      finally{world.character=previous;mutatingOwner=owner;if(actor.id!==context.selfId&&world.camera&&focus)world.camera.focus=focus;}
    }
    function listParts(actor){
      if(actor.partMap)return actor.partMap;
      const parts=namedBodies(actor.character),seen=new Set(Object.values(parts));
      // Stable creation order covers bodies not exposed by the character API.
      for(const [i,body] of [...actor.owned].entries())if(!seen.has(body))parts['aux:'+i]=body;
      actor.nextPart=0;actor.partMap=parts;return parts;
    }
    function tagActor(actor){
      for(const body of riderBodies(actor.character))actor.owned.add(body);
      for(const body of actor.owned){body.__hwAuthorityOwner=actor.id;body.__hwAuthorityLife=actor.life;}
    }
    function seeded(seed,fn){
      const original=Math.random;let value=seed>>>0;
      Math.random=()=>{value=(Math.imul(value,1664525)+1013904223)>>>0;return value/4294967296};
      try{return fn()}finally{Math.random=original}
    }
    function wrapMethod(rider,key,fn){
      const mark='__hwWrap_'+key;
      if(rider[mark]||typeof rider[key]!=='function')return;
      const original=rider[key];
      rider[key]=fn(original);
      rider[mark]=true;
      restores.push(()=>{try{rider[key]=original;delete rider[mark];}catch{}});
    }
    function hookOwnership(actor){
      if(!context.isHost)return;
      for(const rider of riders(actor.character))for(const key of ['preActions','checkKeyStates','actions','handleContactBuffer','handleContactAdds']){
        wrapMethod(rider,key,original=>function(...args){const previous=mutatingOwner;mutatingOwner=actor;try{return original.apply(this,args)}finally{mutatingOwner=previous}});
      }
    }
    function hookDamage(actor){
      if(!context.isHost)return;
      riders(actor.character).forEach((rider,index)=>{
        const names=new Set();let proto=rider;
        while(proto){for(const [key,d]of Object.entries(Object.getOwnPropertyDescriptors(proto)))if(typeof d.value==='function'&&DAMAGE_METHODS.has(key))names.add(key);proto=Object.getPrototypeOf(proto)}
        for(const key of names)wrapMethod(rider,key,original=>function(...args){
          if(actor.recording)return original.apply(this,args);
          const event={seq:++actor.nextEvent,rider:index,method:key,args:args.map(damageArg),seed:(Math.random()*4294967296)>>>0};
          actor.recording=true;damageDepth++;
          try{const result=inActor(actor,()=>seeded(event.seed,()=>original.apply(this,args)));actor.events.push(event);compactEvents(actor);return result;}
          finally{actor.recording=false;damageDepth--;}
        });
      });
    }
    function eventFloor(actor){
      const guests=(context.room?.players||[]).filter(p=>p.id!==context.selfId);
      if(!guests.length)return actor.nextEvent;
      let min=Infinity,waiting=false;
      for(const guest of guests){
        const recent=inputs.get(guest.id);
        if(!recent){waiting=true;min=Math.min(min,0);continue;}
        waiting=true;
        const book=acks.get(guest.id)?.get(actor.id);
        // An acknowledgement from a previous life does not cover this life.
        min=Math.min(min,book&&book.life===actor.life?book.seq:0);
      }
      return waiting?min:actor.nextEvent;
    }
    function compactEvents(actor){
      const floor=eventFloor(actor);
      // Keep every unacknowledged event. A respawn starts a new life at sequence 1.
      if(!(floor>0))return;
      actor.events=actor.events.filter(event=>event.seq>floor);
      actor.eventBase=Math.max(actor.eventBase||0,floor);
    }
    function outgoingEvents(actor){
      const base=actor.eventBase||0;
      const events=actor.events.filter(event=>event.seq>base).slice(0,48);
      return {events,eventBase:base,resetEvents:events.length>0&&events[0].seq!==base+1};
    }
    // Smash methods also receive contact impulses and normals (vectors). Other
    // objects cannot be rebuilt on a guest and are replayed as null.
    function damageArg(v){
      if(v==null)return null;
      if(typeof v==='boolean')return v;
      if(typeof v==='number')return Number.isFinite(v)?v:null;
      if(typeof v==='object'&&Number.isFinite(v.x)&&Number.isFinite(v.y)&&!isBody(v))return {v:[q(v.x),q(v.y)]};
      return null;
    }
    function replayArg(v){
      if(v&&typeof v==='object'&&Array.isArray(v.v)){const sample=worldBodies(world)[0]?.GetPosition?.()||{x:0,y:0};return vec2(sample,v.v[0],v.v[1]);}
      return v;
    }
    function applyEvents(actor,events,resetEvents,eventBase){
      if(actor.replayFailed)return 'failed-replay';
      if(resetEvents)actor.appliedEvent=eventBase||0;
      if(!events.length&&eventBase>actor.appliedEvent)return 'missing-history';
      for(const event of events){
        if(event.seq<=actor.appliedEvent)continue;
        if(event.seq!==actor.appliedEvent+1){if(lab.errors.length<100)lab.errors.push('Missing character lifecycle event '+event.seq);return 'missing-history';}
        const rider=riders(actor.character)[event.rider];
        if(!rider||typeof rider[event.method]!=='function'||!DAMAGE_METHODS.has(event.method)){actor.replayFailed=true;return 'failed-replay';}
        let failed=false,error=null;
        try{replayingDamage++;inActor(actor,()=>seeded(event.seed,()=>rider[event.method](...(event.args||[]).map(replayArg))));}
        catch(e){failed=true;error=e;if(lab.errors.length<100)lab.errors.push('Damage replay '+event.method+': '+String(e?.message||e));}
        finally{replayingDamage--;}
        if(failed){actor.replayFailed=true;actor.replayError=String(error?.message||error||'');return 'failed-replay';}
        actor.appliedEvent=event.seq;
      }
      return 'ok';
    }
    function validOrigin(origin){return Array.isArray(origin)&&origin.length===2&&origin.every(n=>Number.isFinite(n)&&Math.abs(n)<1e8);}
    function characterOrigin(character){
      const scale=character.m_physScale||world?.m_physScale||30;
      const origin=[character._startX*scale,character._startY*scale];
      return validOrigin(origin)?origin:null;
    }
    function sameOrigin(a,b){return validOrigin(a)&&validOrigin(b)&&a.every((n,i)=>Math.abs(n-b[i])<1e-7);}
    function takeActor(id,character,kind,life=0){
      const actor={id,character,kind,life,owned:new Set(riderBodies(character)),protectUntil:now()+PROTECT_MS,request:0,events:[],appliedEvent:0,nextEvent:0,finishedAt:0};
      const start=world.getStartPoint?.()||world.getStartPosition?.();
      actor.origin=start&&validOrigin([start.x,start.y])?[start.x,start.y]:characterOrigin(character);
      tagActor(actor);actors.set(id,actor);listParts(actor);hookDamage(actor);hookOwnership(actor);return actor;
    }
    // Guests never run the host's contacts or rider actions, so sounds and
    // particles made there are sent as effects. Damage replays make their own.
    const SOUND_CALLS=['playSoundItem','playSoundInstance','playPointSoundInstance','playAreaSoundInstance'];
    const LOOP_CALLS=['playAreaSoundLoop','playAreaSoundLoopStatic'];
    const LOOP_OPS=['fadeIn','fadeOut','fadeTo','stopSound'];
    const PARTICLE_CALLS=['createBloodFlow','createPointFlow','createFlow','createBloodBurst','createPointBloodBurst','createBloodSpray','createBurst','createPointBurst','createRectBurst','createSpray','createSnowSpray','createSparkBurst','createSparkBurstPoint','createArrowSnap'];
    const EFFECT_MAX=128;
    // Webpack module ids differ between game builds, so verify the export and
    // fall back to one cached search of the module table.
    let soundModuleId=null;
    function soundExport(id){
      try{const inst=lab.require?.(id)?.m?.instance;return inst&&typeof inst.playAreaSoundInstance==='function'?inst:null;}catch{return null;}
    }
    function soundManager(){
      if(soundModuleId===-1)return null;
      if(soundModuleId!=null)return soundExport(soundModuleId);
      for(const id of [87833,94086])if(soundExport(id)){soundModuleId=id;return soundExport(id);}
      const table=lab.require?.m;
      if(!table||typeof table!=='object')return null;
      for(const id of Object.keys(table)){
        let source='';try{source=String(table[id]);}catch{continue;}
        if(source.includes('playAreaSoundInstance=function')&&soundExport(id)){soundModuleId=id;return soundExport(id);}
      }
      soundModuleId=-1;return null;
    }
    function particleController(){return world?.particleController||world?._particleController||null;}
    function recordingEffects(){return !!(context?.isHost&&playing()&&simulating>0&&!applying);}
    function pushEffect(effect){
      effect.seq=++effectSeq;effect.tick=tick;effects.push(effect);
      if(effects.length>EFFECT_MAX*2)effects.splice(0,effects.length-EFFECT_MAX*2);
    }
    function bodyAt(body){
      if(!isBody(body))return null;
      const p=body.GetWorldCenter?.()||body.GetPosition?.();
      if(!p||!Number.isFinite(p.x)||!Number.isFinite(p.y))return null;
      const v=body.GetLinearVelocity?.()||{x:0,y:0};
      return {x:q(p.x),y:q(p.y),a:q(body.GetAngle?.()||0),vx:q(v.x||0),vy:q(v.y||0)};
    }
    function bodyRef(body){
      const owner=body.__hwAuthorityOwner,actor=owner&&actors.get(owner);
      if(actor)for(const [key,part]of Object.entries(listParts(actor)))if(part===body)return {b:[owner,key,String(actor.life)]};
      const id=worldIds.get(body);if(id!=null)return {w:id};
      const p=body.GetWorldCenter?.()||body.GetPosition();return {p:[q(p.x),q(p.y)]};
    }
    function packArg(v){
      if(v==null)return null;
      if(typeof v==='boolean')return v;
      if(typeof v==='number')return Number.isFinite(v)?v:null;
      if(typeof v==='string')return v.length<=64&&/^[\w .:-]*$/.test(v)?v:undefined;
      if(typeof v!=='object')return undefined;
      if(isBody(v))return bodyRef(v);
      if(v===world?.containerSprite||v.pixiSprite||v.addChild||v.children)return {c:1};
      if(typeof v.x==='number'&&typeof v.y==='number')return {v:[q(v.x),q(v.y)]};
      return undefined;
    }
    function packArgs(args){
      const out=[];
      for(const arg of args){const packed=packArg(arg);if(packed===undefined)return null;out.push(packed);}
      return out;
    }
    function standIn(x,y,vx=0,vy=0,angle=0){
      const sample=worldBodies(world)[0]?.GetPosition?.()||{x:0,y:0};
      const at=(lx=0,ly=0)=>{const c=Math.cos(angle),s=Math.sin(angle);return vec2(sample,x+c*lx-s*ly,y+s*lx+c*ly);};
      return {GetWorldCenter:()=>at(),GetPosition:()=>at(),GetInterpolatedPosition:()=>at(),GetInterpolatedWorldCenter:()=>at(),GetLinearVelocity:()=>vec2(sample,vx,vy),GetInterpolatedLinearVelocity:()=>vec2(sample,vx,vy),GetAngle:()=>angle,GetAngularVelocity:()=>0,GetWorldPoint:local=>at(local?.x||0,local?.y||0),GetUserData:()=>null};
    }
    function placedStandIn(effect,index){
      const spot=(effect.at||[]).find(row=>row[0]===index);
      return spot?standIn(spot[1].x,spot[1].y,spot[1].vx,spot[1].vy,spot[1].a||0):null;
    }
    function unpackArg(v){
      if(v==null||typeof v!=='object')return v;
      if(v.c)return world.containerSprite;
      if(v.v){const sample=worldBodies(world)[0]?.GetPosition?.()||{x:0,y:0};return vec2(sample,v.v[0],v.v[1]);}
      if(v.b){const actor=actors.get(v.b[0]);if(v.b[2]!=null&&actor&&String(actor.life)!==String(v.b[2]))return null;const body=actor&&listParts(actor)[v.b[1]];if(body&&new Set(worldBodies(world)).has(body))return body;return null;}
      if(v.w!=null){const body=worldEntries.get(v.w)?.body;if(body)return body;return null;}
      if(v.p)return standIn(v.p[0],v.p[1]);
      return null;
    }
    function hookEffects(){
      const sound=soundManager();
      const particles=particleController();
      const skip=original=>function(...args){if(replayingDamage)return null;return original.apply(this,args);};
      if(!context.isHost){
        // The host sends the effects its damage methods actually created. Replaying
        // the method must not create a second pour or a second bone sound.
        if(sound)for(const name of [...SOUND_CALLS,...LOOP_CALLS])if(typeof sound[name]==='function')patch(sound,name,skip);
        if(particles)for(const name of PARTICLE_CALLS)if(typeof particles[name]==='function')patch(particles,name,skip);
        return;
      }
      if(sound){
        for(const name of SOUND_CALLS)if(typeof sound[name]==='function')patch(sound,name,original=>function(...args){
          const result=original.apply(this,args);
          if(recordingEffects()&&args[0]!=='Victory'){const packed=packArgs(args);if(packed)pushEffect({kind:'sound',method:name,args:packed});}
          return result;
        });
        for(const name of LOOP_CALLS)if(typeof sound[name]==='function')patch(sound,name,original=>function(...args){
          const loop=original.apply(this,args);
          if(loop&&recordingEffects()){
            const packed=packArgs(args);
            if(packed){
              const id=++loopSeq;hostLoops.set(id,{loop,volume:loop.maxVolume});
              pushEffect({kind:'loop',id,method:name,args:packed});
              for(const op of LOOP_OPS)if(typeof loop[op]==='function'){
                const own=loop[op];
                loop[op]=function(...opArgs){
                  if(hostLoops.has(id)&&!(op==='stopSound'&&opArgs[0]===false)){const packedOp=packArgs(opArgs);if(packedOp)pushEffect({kind:'loopOp',id,method:op,args:packedOp});}
                  if(op==='stopSound'&&opArgs[0]!==false)hostLoops.delete(id);
                  return own.apply(this,opArgs);
                };
              }
            }
          }
          return loop;
        });
      }
      if(particles)for(const name of PARTICLE_CALLS)if(typeof particles[name]==='function')patch(particles,name,original=>function(...args){
        const result=original.apply(this,args);
        if(recordingEffects()){
          const packed=packArgs(args);
          if(packed){
            const effect={kind:'particle',method:name,args:packed,at:args.map((arg,i)=>isBody(arg)?[i,bodyAt(arg)]:null).filter(Boolean)};
            if(FLOW_CALLS.has(name)){effect.emitter=++loopSeq;effect.owner=mutatingOwner?.id||'';effect.life=mutatingOwner?.life||0;if(result&&typeof result.stopSpewing==='function'){const own=result.stopSpewing,id=effect.emitter,life=effect.life;result.stopSpewing=function(...op){if(recordingEffects())pushEffect({kind:'emitterStop',emitter:id,life});return own.apply(this,op);};}}
            pushEffect(effect);
          }
        }
        return result;
      });
    }
    function outgoingEffects(){
      for(const [id,entry]of hostLoops){
        if(entry.loop.remove){hostLoops.delete(id);continue;}
        const volume=Number(entry.loop.maxVolume);
        if(Number.isFinite(volume)&&Math.abs(volume-(entry.volume??volume))>0.02){entry.volume=volume;pushEffect({kind:'loopVolume',id,volume:q(volume)});}
        else if(entry.volume==null)entry.volume=volume;
      }
      return effects.splice(0,EFFECT_MAX);
    }
    function playEffects(list){
      const queue=pendingEffects.splice(0).concat(list||[]);
      const waiting=[];
      for(const effect of queue){
        if(!Number.isSafeInteger(effect?.seq)||doneEffects.has(effect.seq))continue;
        const age=Number.isInteger(effect.tick)?tick-effect.tick:0;
        const limit=FLOW_CALLS.has(effect.method)?20:45;
        if((effect.kind==='particle'||effect.kind==='sound'||effect.kind==='emitterStop')&&age>limit){
          if(lab.errors.length<100)lab.errors.push('Dropped '+effect.kind+' '+(effect.method||effect.emitter)+' after '+age+' ticks');
          doneEffects.add(effect.seq);continue;
        }
        let held=false;
        try{held=playEffect(effect)==='hold';}catch(e){if(lab.errors.length<100)lab.errors.push('Effect '+(effect.method||effect.kind)+': '+String(e?.message||e));}
        if(held){waiting.push(effect);continue;}
        doneEffects.add(effect.seq);
      }
      if(waiting.length>48){
        for(const effect of waiting.splice(0,waiting.length-48)){
          if(lab.errors.length<100)lab.errors.push('Dropped backed-up '+(effect.method||effect.kind)+' seq '+effect.seq);
          doneEffects.add(effect.seq);
        }
      }
      pendingEffects.push(...waiting);
    }
    function listenerPoint(){
      const camera=world?.camera,focus=camera?.focus;
      const p=focus?.GetInterpolatedWorldCenter?.()||focus?.GetWorldCenter?.()||focus?.GetInterpolatedPosition?.()||focus?.GetPosition?.();
      if(p&&Number.isFinite(p.x)&&Number.isFinite(p.y))return p;
      const mid=camera?.midScreenPoint;
      if(mid&&Number.isFinite(mid.x)&&Number.isFinite(mid.y))return mid;
      return null;
    }
    function playEffect(effect){
      if(effect.kind==='emitterStop'){
        const entry=emitters.get(effect.emitter);
        if(!entry||entry.life!==effect.life)return;
        try{entry.handle?.stopSpewing?.();}catch{}
        emitters.delete(effect.emitter);return;
      }
      if(effect.kind==='loopVolume'){const loop=mirrorLoops.get(effect.id);if(loop&&Number.isFinite(effect.volume))loop.maxVolume=effect.volume;return;}
      if(effect.kind==='loopOp'){
        const loop=mirrorLoops.get(effect.id);if(!loop||!LOOP_OPS.includes(effect.method))return;
        loop[effect.method](...(effect.args||[]).map(unpackArg));
        if(effect.method==='stopSound')mirrorLoops.delete(effect.id);
        return;
      }
      const raw=effect.args||[],args=raw.map(unpackArg);
      raw.forEach((a,i)=>{if(a&&typeof a==='object'&&(a.b||a.w!=null)&&!args[i]&&!FLOW_CALLS.has(effect.method)){const stand=placedStandIn(effect,i);if(stand)args[i]=stand;}});
      if(raw.some((a,i)=>a&&typeof a==='object'&&(a.b||a.w!=null)&&!args[i]))return 'hold';
      if(effect.kind==='particle'){
        const particles=particleController();
        if(!particles||!PARTICLE_CALLS.includes(effect.method)||typeof particles[effect.method]!=='function')return;
        if(effect.method==='createBloodBurst'&&args.length>6)args[6]=-1;
        if(effect.method==='createPointBloodBurst'&&args.length>5)args[5]=-1;
        for(let i=1;i<args.length;i++)if(Number.isInteger(args[i])&&args[i-1]?.children&&args[i]>args[i-1].children.length)args[i]=args[i-1].children.length;
        const handle=particles[effect.method](...args);
        if(FLOW_CALLS.has(effect.method)&&effect.emitter!=null)emitters.set(effect.emitter,{handle,life:effect.life||0,owner:effect.owner||''});
        return;
      }
      const sound=soundManager();if(!sound)return;
      if(effect.kind==='sound'&&SOUND_CALLS.includes(effect.method)&&typeof sound[effect.method]==='function'){
        // One-shot break sounds are dropped when the listener is still at the
        // level start. Aim it at the camera, which is in the same units as the body.
        const ear=listenerPoint(),body=args.find(isBody);
        if(ear)sound._center=ear;
        else if(body){const p=body.GetWorldCenter?.()||body.GetPosition();sound._center={x:p.x,y:p.y};}
        const played=sound[effect.method](...args);
        if(!played&&body&&ear){
          const p=body.GetWorldCenter?.()||body.GetPosition();
          if(Math.abs(p.x-ear.x)<24&&Math.abs(p.y-ear.y)<16){sound._center={x:p.x,y:p.y};sound[effect.method](...args);}
        }
        return;
      }
      if(effect.kind==='loop'&&LOOP_CALLS.includes(effect.method)&&typeof sound[effect.method]==='function'){
        const loop=sound[effect.method](...args);if(loop)mirrorLoops.set(effect.id,loop);
      }
    }
    function stopSoundsOn(bodies){
      const sound=soundManager(),list=sound?._areaSounds;
      if(!Array.isArray(list))return;
      for(const item of [...list])if(bodies.has(item?._sourceObject))try{item.stopSound();}catch{}
      for(const [id,loop]of mirrorLoops)if(bodies.has(loop?._sourceObject))mirrorLoops.delete(id);
      for(const [id,entry]of hostLoops)if(bodies.has(entry.loop?._sourceObject))hostLoops.delete(id);
    }
    function stopMirrorLoops(){
      for(const loop of mirrorLoops.values())try{loop.stopSound();}catch{}
      mirrorLoops.clear();hostLoops.clear();effects.length=0;pendingEffects.length=0;doneEffects.clear();emitters.clear();
    }
    function destroyActor(id){
      const actor=actors.get(id);if(!actor)return;
      const character=actor.character;
      character.removeKeyListeners?.();
      if(actor.replicaViews)for(const view of actor.replicaViews.values())dropReplica(view);
      // Retain the complete registry through cleanup: native die/reset can erase references.
      const bodies=new Set([...actor.owned,...riderBodies(character)]);
      stopSoundsOn(bodies);
      releaseEmitters(actor);
      stripCharacter(character);
      const live=new Set(worldBodies(world));
      for(const body of bodies)if(live.has(body))world.m_world.DestroyBody(body);
      actors.delete(id);
    }
    function spawnActor(id,kind,life,index,origin=null){
      if(!Number.isInteger(kind)||kind<1||kind>11)throw Error('Character '+kind+' has no verified Shared Physics definition.');
      const Ctor=nativeClass(kind,world),source=nativeSource(kind);
      if(!Ctor||!source)throw Error('This game build does not expose character '+kind+'.');
      // Native rigs bake the constructor origin into fixture centers and clip offsets.
      // Resolve it under the NEW character type, and use the host's exact origin
      // on guests. Reusing the viewer's origin displaces frames from their wheels.
      if(origin!==null&&!validOrigin(origin))throw Error('Invalid character construction origin');
      const at=origin?{x:origin[0],y:origin[1]}:withKind(kind,()=>world.getStartPoint?.()||world.getStartPosition?.()||(()=>{const initial=actors.get(context.selfId)?.origin||characterOrigin(world.character);if(!validOrigin(initial))throw Error("Game build does not expose the level spawn point");return {x:initial[0],y:initial[1]}})());
      const previous=world.character;
      const actor={id,kind,life,character:null,owned:new Set(),protectUntil:now()+PROTECT_MS,request:0,events:[],appliedEvent:0,nextEvent:0,finishedAt:0};
      actor.origin=[at.x,at.y];
      const owner=mutatingOwner;mutatingOwner=actor;
      try{
        withKind(kind,()=>{
          const c=kind===10?new Ctor(at.x,at.y,source,world,-1,'Char4'):new Ctor(at.x,at.y,source,world);
          actor.character=c;c.main=false;c.groupID=-11-(index+1)*10;world.character=c;
          // Native reset() creates bodies again. A fresh rig must call create() ONCE.
          c.create();c.paint();
        });
        actors.set(id,actor);tagActor(actor);listParts(actor);hookDamage(actor);hookOwnership(actor);return actor;
      }catch(e){
        if(actor.character)stripCharacter(actor.character);
        const live=new Set(worldBodies(world));for(const b of actor.owned)if(live.has(b))world.m_world.DestroyBody(b);
        throw e;
      }finally{world.character=previous;mutatingOwner=owner;}
    }
    function adoptLocal(actor){
      world.character=actor.character;localKind=actor.kind;lab.state.characterIndex=actor.kind;
      actor.character.main=true;actor.character.addKeyListeners?.();
      if(world.camera){world.camera.focus=actor.character.cameraFocus;world.camera.secondFocus=actor.character.cameraSecondFocus||null;}
      localKind=actor.kind;world.inputAllowed=true;world.paused=false;
      const controller=sessionController();controller?.closeSessionMenu?.();
    }
    function replaceActor(id,kind,life,origin=null){
      const old=actors.get(id);const request=old?.request||0;
      destroyActor(id);
      const index=Math.max(0,context.room.players.findIndex(p=>p.id===id));
      const actor=spawnActor(id,kind,life,index,origin);actor.request=request;
      if(id===context.selfId)adoptLocal(actor);
      return actor;
    }
    function validSkin(skin){return typeof skin==='string'&&/^[a-z0-9][a-z0-9-]{0,63}$/i.test(skin);}
    function requestSpawn(kind,skin){
      if(!playing())return;
      const request={type:'authorityRequest',epoch,seq:++requestSeq,character:kind||localKind,skin:validSkin(skin)?skin:''};
      if(context.isHost)requests.push({...request,id:context.selfId});else send(request);
      keys=0;message('Respawn requested…');
    }
    function processRequests(){
      for(const request of requests.splice(0)){
        const actor=actors.get(request.id);if(!actor||request.seq<=actor.request)continue;
        actor.request=request.seq;
        const next=replaceActor(request.id,request.character,actor.life+1);
        next.skin=validSkin(request.skin)?request.skin:'';
        inputs.delete(request.id);
      }
    }
    // The game's character screen replaces currentSession with its own preview
    // session, which tears down a live shared race. This picker keeps the level.
    const CHARACTER_NAMES=['Wheelchair Guy','Segway Guy','Irresponsible Dad','Effective Shopper','Moped Couple','Lawnmower Man','Explorer Guy','Santa Claus','Pogostick Man','Irresponsible Mom','Helicopter Man'];
    const iconCache=new Map();
    let picker=null;
    function characterIcon(kind,img){
      if(iconCache.has(kind)){img.src=iconCache.get(kind);return;}
      try{
        const pixi=lab.require?.(99430),texture=pixi?.WpD?.TextureCache?.['char'+kind+'.png'];
        const renderer=lab.state?.rootApp?.renderer,extract=renderer?.extract||renderer?.plugins?.extract;
        if(!texture||!extract?.base64||!pixi.kxk)return;
        const done=url=>{if(typeof url==='string'&&url){iconCache.set(kind,url);img.src=url;}};
        const out=extract.base64(new pixi.kxk(texture));
        if(typeof out?.then==='function')out.then(done,()=>{});else done(out);
      }catch{}
    }
    function closePicker(choice){
      const open=picker;if(!open)return;
      picker=null;
      window.removeEventListener?.('keydown',open.escape,true);
      try{open.panel.remove?.();}catch{}
      if(world)world.inputAllowed=true;
      keys=0;
      if(!choice)return;
      const base=choice.base||choice;
      const skin=choice.custom||'';
      try{window.HWCustomCharacters?.choose?.(skin||null);}catch{}
      const mine=actors.get(context.selfId);if(mine)mine.skin=skin;
      if(Number.isInteger(base)&&base>=1&&base<=11)requestSpawn(base,skin);
    }
    function characterButton(grid,name,current,icon,pick){
      const button=document.createElement('button');
      button.style.cssText='display:flex;flex-direction:column;align-items:center;gap:6px;padding:10px 6px;cursor:pointer;font:14px Georgia,serif;color:#f3ead6;background:'+(current?'#3b4a44':'#1f2c33')+';border:1px solid '+(current?'#fd7f7c':'#465b65');
      const img=document.createElement('img');img.width=50;img.height=50;img.alt='';
      if(typeof icon==='function')icon(img);else if(icon)img.src=icon;
      const label=document.createElement('span');label.textContent=name+(current?' (current)':'');
      button.append(img,label);button.onclick=()=>closePicker(pick);grid.append(button);
    }
    function chooseCharacter(){
      if(picker||!playing())return;
      const controller=sessionController();
      if(controller?.levelDataObject?.forceChar){message('This level uses a fixed character.');return;}
      try{controller?.closeSessionMenu?.();}catch{}
      const panel=document.createElement('div');panel.id='hw-authority-character';
      panel.style.cssText='position:fixed;inset:0;z-index:10001;display:flex;align-items:center;justify-content:center;background:#0b1114b8;font:16px Georgia,serif;color:#f3ead6';
      const box=document.createElement('div');
      box.style.cssText='background:#172127f2;border:1px solid #fd7f7c;padding:20px 24px;box-shadow:0 10px 40px #000a;width:min(760px,92vw)';
      const title=document.createElement('div');title.textContent='Choose your character';title.style.cssText='font-size:24px;margin-bottom:14px;text-align:center';
      const grid=document.createElement('div');grid.style.cssText='display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:8px;max-height:70vh;overflow:auto';
      const open={panel};
      const customs=typeof window.HWCustomCharacters?.list==='function'?window.HWCustomCharacters.list():[];
      const selectedCustom=window.HWCustomCharacters?.selected||null;
      CHARACTER_NAMES.forEach((name,i)=>characterButton(grid,name,!selectedCustom&&i+1===localKind,img=>characterIcon(i+1,img),i+1));
      for(const entry of customs)if(entry&&Number.isInteger(entry.base)&&entry.base>=1&&entry.base<=11&&entry.id)characterButton(grid,entry.name,selectedCustom===entry.id,entry.icon,{base:entry.base,custom:entry.id});
      const hint=document.createElement('div');hint.textContent='Pick a character to respawn as it · Esc to cancel';hint.style.cssText='margin-top:14px;text-align:center;color:#b4c5cd;font-size:13px';
      box.append(title,grid,hint);panel.append(box);
      open.escape=e=>{if(e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();closePicker(0);}};
      picker=open;keys=0;
      if(world)world.inputAllowed=false;
      window.addEventListener('keydown',open.escape,true);
      document.body.append(panel);
      restores.push(()=>closePicker(0));
    }
    function hookController(){
      const controller=sessionController();if(!controller||controller.__hwAuthority===epoch)return;
      const old=controller.__hwAuthority;controller.__hwAuthority=epoch;restores.push(()=>{controller.__hwAuthority=old});
      for(const key of ['restartLevel','restartLevelBind'])if(typeof controller[key]==='function')patch(controller,key,original=>function(...args){if(lab.forceLevelRestart){lab.forceLevelRestart=false;return original.apply(this,args);}if(active())return requestSpawn();return original.apply(this,args)});
      for(const key of ['reopenCharacterMenu','reopenCharacterMenuBind'])if(typeof controller[key]==='function')patch(controller,key,original=>function(...args){if(active())return chooseCharacter();return original.apply(this,args)});
    }
    function actionMask(){
      const character=actors.get(context?.selfId)?.character;
      if(!character)return 0;
      let mask=0;
      fields.forEach((key,i)=>{if(character[key])mask|=1<<i;});
      return mask;
    }
    function inputEvent(e,down){
      if(!active())return;
      if(picker){keys=0;return;}
      if(down&&['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName))return;
    }
    window.addEventListener('keydown',e=>inputEvent(e,true),true);window.addEventListener('keyup',e=>inputEvent(e,false),true);window.addEventListener('blur',()=>{keys=0});
    function shapeSignature(body){
      const a=[];for(let s=body.GetShapeList?.();s;s=s.GetNext())a.push([s.m_type,s.m_vertexCount||0,q(s.m_radius||0)]);
      return a;
    }
    function seedLevel(){
      const owned=new Set([...actors.values()].flatMap(a=>[...a.owned]));
      levelBodies=worldBodies(world).filter(b=>!owned.has(b)).reverse();
      levelSignature=JSON.stringify(levelBodies.map(shapeSignature));worldEntries.clear();worldIds=new WeakMap();nextWorldId=0;
      for(const body of levelBodies){const id=nextWorldId++;worldIds.set(body,id);worldEntries.set(id,{body});}
    }
    // Level triggers can unfix a static body on the host. The guest never runs
    // those triggers, so any level body the host moved follows its pose here.
    const movedLevel=new Set(),movingLevel=new Set(),shownLevel=new Map();
    function levelPoseChanged(body,p,live){
      if(!body||!live.has(body))return false;
      const at=body.GetPosition();
      return Math.abs(at.x-p[1])>1e-3||Math.abs(at.y-p[2])>1e-3||Math.abs(body.GetAngle()-p[3])>1e-3;
    }
    function isFixed(body){
      if(typeof body.IsStatic==='function')return body.IsStatic();
      return body.m_type===1;
    }
    function moveLevelBody(body,pose){
      writePose(body,pose);movingLevel.add(body);
      if(isFixed(body))movedLevel.add(body);
    }
    function hideLevelBody(body){
      if(!body)return;
      movingLevel.delete(body);movedLevel.delete(body);
      const sprite=body.GetUserData?.()||body.m_userData;
      if(sprite)try{sprite.visible=false;}catch{}
    }
    function paintLevel(){
      const level=world.level||world._level;
      if(typeof level?.paint==='function')level.paint();else world.paintLevelItems?.();
      paintMovedLevel();
    }
    // Level.paint only covers bodies the level itself unfixed; paint the rest here.
    function paintMovedLevel(){
      const live=new Set(worldBodies(world)),scale=world.m_physScale||30;
      for(const body of movedLevel){
        if(!live.has(body)){movedLevel.delete(body);continue;}
        const center=body.GetInterpolatedWorldCenter?.()||body.GetWorldCenter?.()||body.GetPosition();
        const angle=(body.GetInterpolatedAngle?.()??body.GetAngle())*180/Math.PI%360;
        const user=body.GetUserData?.()||body.m_userData;
        for(const sprite of [user,user?.pixiSprite]){
          if(!sprite||sprite===body||typeof sprite!=='object'||!('x' in sprite))continue;
          sprite.x=center.x*scale;sprite.y=center.y*scale;
          if('rotation' in sprite)sprite.rotation=angle;
        }
      }
    }
    function validPose(p){return Array.isArray(p)&&p.length===6&&p.every(n=>Number.isFinite(n)&&Math.abs(n)<1e8);}
    function paintFromPose(body,p){
      const scale=world?.m_physScale||30,user=body.GetUserData?.()||body.m_userData;
      for(const sprite of [user,user?.pixiSprite]){
        if(!sprite||sprite===body||typeof sprite!=='object'||!('x' in sprite))continue;
        try{sprite.x=p[0]*scale;sprite.y=p[1]*scale;if('rotation' in sprite)sprite.rotation=p[2]*180/Math.PI;}catch{}
      }
    }
    function poseProblem(body,p,why){
      let frozen=false,shapes=0,proxies=0;
      try{frozen=!!(body.IsFrozen?.()||(typeof body.m_flags==='number'&&(body.m_flags&8)));}catch{}
      try{for(let shape=body.GetShapeList?.();shape;shape=shape.GetNext?.()){shapes++;if(shape.m_proxy||shape.m_proxyId!=null)proxies++;}}catch{}
      if(lab.errors.length<100)lab.errors.push('Pose '+why+' '+(body.__hwPart||'')+' life '+(body.__hwAuthorityLife??'')+' target '+p.join(',')+' frozen '+frozen+' shapes '+shapes+' proxies '+proxies);
    }
    function writePose(body,p){
      if(!validPose(p)){if(lab.errors.length<100)lab.errors.push('Rejected invalid pose');return 'invalid';}
      if(body.__hwPoseStop){paintFromPose(body,p);return 'terminal';}
      if(world.m_world.m_lock)return 'locked';
      const position=vec2(body.GetPosition(),p[0],p[1]);
      let ok=true;
      try{ok=body.SetXForm?body.SetXForm(position,p[2]):(body.SetTransform?.(position,p[2]),true);}catch(e){poseProblem(body,p,String(e?.message||e));body.__hwPoseStop=true;paintFromPose(body,p);return 'frozen';}
      if(ok===false){
        const terminal=Math.abs(p[0])>1e5||Math.abs(p[1])>1e5;
        poseProblem(body,p,terminal?'out-of-bounds':'rejected');
        body.__hwPoseStop=true;paintFromPose(body,p);return terminal?'terminal':'frozen';
      }
      body.SetLinearVelocity(vec2(body.GetLinearVelocity(),p[3],p[4]));body.SetAngularVelocity(p[5]);
      try{body.WakeUp?.();}catch{}
      return 'applied';
    }
    function bodyPose(actor){
      const live=new Set(worldBodies(world)),out={};
      for(const [key,body]of Object.entries(listParts(actor)))if(live.has(body))out[key]=readPose(body);
      return out;
    }
    function releaseEmitters(actor){
      for(const [id,entry]of emitters)if(entry.owner===actor.id){try{entry.handle?.stopSpewing?.();}catch{}emitters.delete(id);}
    }
    function noteLayout(actor,state,result,key){
      const hostKeys=Object.keys(state?.parts||{}).slice(0,16).join(',');
      const guestKeys=Object.keys(listParts(actor)).filter(name=>!/^(new|aux):/.test(name)).slice(0,16).join(',');
      const last=state?.events?.length?state.events[state.events.length-1].seq:state?.eventBase||0;
      const text='Shared layout '+result+' character '+state?.character+' life '+actor.life+' rev '+seenRevision+' applied '+(actor.appliedEvent||0)+' events '+(state?.eventBase||0)+'-'+last+' key '+(key||'')+' host ['+hostKeys+'] guest ['+guestKeys+']'+(actor.replayError?' '+actor.replayError:'');
      if(lab.errors.length<100)lab.errors.push(text);
    }
    function applyPlayer(state){
      let actor=actors.get(state.id);
      if(actor&&state.life<actor.life)return;
      if(state.origin!=null&&!validOrigin(state.origin))throw Error('Invalid character construction origin');
      const origin=state.origin||null;
      if(!actor)actor=spawnActor(state.id,state.character,state.life,context.room.players.findIndex(p=>p.id===state.id),origin);
      else if(actor.life!==state.life||actor.kind!==state.character||(origin&&!sameOrigin(actor.origin,origin))||(Number.isInteger(state.rebuild)&&state.rebuild!==(actor.rebuild||0)))actor=replaceActor(state.id,state.character,state.life,origin);
      if(Number.isInteger(state.rebuild))actor.rebuild=state.rebuild;
      actor.shieldLeft=state.protectedUntil||0;actor.shieldAt=now();
      const lifeResult=applyEvents(actor,state.events||[],!!state.resetEvents,state.eventBase||0);
      if(lifeResult!=='ok'){
        noteLayout(actor,state,lifeResult,'');
        if(!context.isHost&&(actor.repairs||0)<1){
          const repairs=(actor.repairs||0)+1;
          const fresh=replaceActor(state.id,state.character,state.life,origin||actor.origin);
          fresh.repairs=repairs;fresh.rebuild=Number.isInteger(state.rebuild)?state.rebuild:0;fresh.skin=validSkin(state.skin)?state.skin:'';
          const again=applyEvents(fresh,state.events||[],!!state.resetEvents,state.eventBase||0);
          if(again!=='ok'){fresh.blocked=again;noteLayout(fresh,state,again,'');return;}
          actor=fresh;
        }else{actor.blocked=lifeResult;return;}
      }
      tagActor(actor);
      const bodies=listParts(actor),live=new Set(worldBodies(world));
      const missing=Object.keys(state.parts).find(key=>!/^(new|aux):/.test(key)&&(!bodies[key]||!live.has(bodies[key])));
      if(missing){actor.blocked='layout';noteLayout(actor,state,'layout',missing);return;}
      for(const [key,pose]of Object.entries(state.parts)){
        const body=bodies[key];
        if(!body||!live.has(body))continue;
        body.__hwPart=key;
        writePose(body,pose);
      }
      showReplicas(actor,state.replicas);
      // Removed authoritative parts may never remain as hidden colliders or stale sprites.
      for(const [key,body]of Object.entries(bodies))if(!state.parts[key]&&live.has(body)){
        const mc=body.GetUserData?.();mc?.parent?.removeChild(mc);world.m_world.DestroyBody(body);actor.owned.delete(body);
      }
      try{actor.character.dead=state.dead;if(state.finished)actor.character.finished=true;}catch{}
      if(state.finished)actor.finishedAt=state.finishTime||1;
      if(state.id===context.selfId&&state.finished&&!world.replayData?.completed){
        world.replayData=world.replayData||{};world.replayData.completed=true;
        try{world.inputAllowed=false;}catch{}
        try{soundManager()?.playSoundItem?.('Victory');}catch{}
        message('Level complete!');
      }
      actor.request=state.request||0;
      actor.skin=validSkin(state.skin)?state.skin:'';
    }
    function partReplicas(actor){
      const live=new Set(worldBodies(world)),out=[];
      for(const [key,body]of Object.entries(listParts(actor))){
        if(!/^(new|aux):/.test(key)||!live.has(body))continue;
        out.push({key,visual:lab.sharedVisuals?.captureNode?.(body.GetUserData?.())||null,outline:bodyOutline(body)});
        if(out.length>=32)break;
      }
      return out;
    }
    function refreshRopes(actor){
      if(actor.kind!==8)return;
      for(const rider of riders(actor.character)){
        for(const [key,value] of Object.entries(rider)){
          if(typeof value!=='function'||!/rope/i.test(key)||DAMAGE_METHODS.has(key))continue;
          try{value.call(rider);}catch(e){if(lab.errors.length<100)lab.errors.push('Rope '+key+': '+String(e?.message||e));}
        }
      }
    }
    function paintSkins(){
      const apply=window.HWCustomCharacters?.apply;
      if(typeof apply!=='function')return;
      for(const actor of actors.values()){
        const nodes=new Set();
        const add=node=>{
          if(!node||typeof node!=='object')return;
          if(node.pixiSprite)nodes.add(node.pixiSprite);
          // Body art is often the display object itself, with no pixiSprite wrapper.
          if(node.texture||node.children||node.parent)nodes.add(node);
          if(node.inner)add(node.inner);
        };
        for(const node of ownedDisplayNodes(actor.character))add(node);
        for(const body of actor.owned)add(body.GetUserData?.());
        for(const node of nodes)try{apply(node,actor.skin||null);}catch{}
      }
    }
    function dropReplica(view){
      try{lab.sharedVisuals?.remove?.(view);}catch{}
    }
    function showReplicas(actor,replicas){
      if(!actor.replicaViews)actor.replicaViews=new Map();
      const bodies=listParts(actor),live=new Set(worldBodies(world)),seen=new Set();
      for(const replica of replicas||[]){
        if(!replica?.key)continue;
        seen.add(replica.key);
        const real=bodies[replica.key];
        if(real&&live.has(real)){const old=actor.replicaViews.get(replica.key);if(old){dropReplica(old);actor.replicaViews.delete(replica.key);}continue;}
        if(!lab.sharedVisuals?.create||!world.containerSprite?.pixiSprite)continue;
        let view=actor.replicaViews.get(replica.key);
        if(!view){
          view=lab.sharedVisuals.create();actor.replicaViews.set(replica.key,view);world.containerSprite.pixiSprite.addChild(view.group);
          const Graphics=Object.values(lab.require?.(99430)||{}).find(v=>typeof v==='function'&&v.prototype?.drawPolygon&&v.prototype?.beginFill);
          if(Graphics){view.outline=new Graphics();view.group.addChild(view.outline);}
        }
        try{lab.sharedVisuals.draw(view,replica.visual,lastTextures);}catch{}
        if(view.outline){view.outline.clear();if(!replica.visual?.parts?.length){view.outline.beginFill(0x8b8174,1);for(const shape of replica.outline||[]){if(shape.points)view.outline.drawPolygon(shape.points);else if(shape.circle)view.outline.drawCircle(...shape.circle)}view.outline.endFill();}}
      }
      for(const [key,view]of actor.replicaViews)if(!seen.has(key)){dropReplica(view);actor.replicaViews.delete(key);}
    }
    const extraViews=new Map();
    function bodyOutline(body){
      const result=[],scale=world.m_physScale||30;
      for(let shape=body.GetShapeList?.();shape;shape=shape.GetNext()){
        if(shape.m_vertices){const points=[];for(const v of shape.m_vertices.slice(0,shape.m_vertexCount)){const p=body.GetWorldPoint(v);points.push(q(p.x*scale),q(p.y*scale))}result.push({points});}
        else if(Number.isFinite(shape.m_radius)){const p=body.GetWorldPoint(shape.m_localPosition);result.push({circle:[q(p.x*scale),q(p.y*scale),q(shape.m_radius*scale)]});}
      }
      return result;
    }
    function updateExtras(extras,textures,replace){
      const seen=new Set(),pixi=lab.require(99430),Graphics=Object.values(pixi).find(v=>typeof v==='function'&&v.prototype?.drawPolygon&&v.prototype?.beginFill);
      for(const entry of extras){
        seen.add(entry.id);let view=extraViews.get(entry.id);
        if(!view){view=lab.sharedVisuals.create();extraViews.set(entry.id,view);world.containerSprite.pixiSprite.addChild(view.group);if(Graphics){view.outline=new Graphics();view.group.addChild(view.outline)}}
        lab.sharedVisuals.draw(view,entry.visual,textures);
        if(view.outline){view.outline.clear();if(!entry.visual?.parts?.length){view.outline.beginFill(0x8b8174,1);for(const shape of entry.outline||[]){if(shape.points)view.outline.drawPolygon(shape.points);else if(shape.circle)view.outline.drawCircle(...shape.circle)}view.outline.endFill();}}
      }
      if(!replace)return;
      for(const [id,view]of extraViews)if(!seen.has(id)){lab.sharedVisuals.remove(view);extraViews.delete(id);}
    }
    let bumpsEnabled=true;
    function bumpsOff(){return bumpsEnabled===false;}
    function refilterPlayers(){
      const physics=world?.m_world;
      if(!physics||guest())return;
      try{for(const actor of actors.values())for(const body of actor.owned)for(let shape=body.GetShapeList?.();shape;shape=shape.GetNext?.())physics.Refilter?.(shape);}catch{}
    }
    function claimLooseParts(actor){
      if(!actor?.character)return;
      for(const body of riderBodies(actor.character)){
        if(actor.owned.has(body))continue;
        actor.owned.add(body);
        const id=worldIds.get(body);
        if(id!=null&&id>=levelBodies.length){worldEntries.delete(id);lastWorldPose.delete(id);}
        if(actor.partMap&&!Object.values(actor.partMap).includes(body))actor.partMap['new:'+(actor.nextPart++)]=body;
      }
      for(const body of actor.owned){body.__hwAuthorityOwner=actor.id;body.__hwAuthorityLife=actor.life;}
    }
    function ridersOverlap(a,b){
      const A=actorBounds(a),B=actorBounds(b);
      return Number.isFinite(A.minX)&&A.minX<B.maxX&&A.maxX>B.minX&&A.minY<B.maxY&&A.maxY>B.minY;
    }
    function setCollide(on){
      const next=on!==false;
      const enabling=bumpsEnabled===false&&next;
      bumpsEnabled=next;
      if(enabling){
        const list=[...actors.values()];
        for(const actor of list)if(list.some(other=>other!==actor&&ridersOverlap(actor,other)))actor.protectUntil=Math.max(actor.protectUntil||0,now()+PROTECT_MS);
      }
      for(const actor of actors.values())claimLooseParts(actor);
      refilterPlayers();
      if(world)world.__hwCollide=next;
    }
    function shielded(actor){return now()<openingUntil||now()<(actor?.protectUntil||0);}
    function shieldLeft(actor){
      if(!actor)return 0;
      if(!context?.isHost)return Math.max(0,Math.ceil((actor.shieldLeft||0)-(now()-(actor.shieldAt||now()))));
      return Math.max(0,Math.ceil(Math.max(openingUntil,actor.protectUntil||0)-now()));
    }
    function paintShield(){
      const left=playing()?shieldLeft(actors.get(context.selfId)):0;
      const node=document.getElementById('hw-mp-ghost');
      const text=left>0?'Collisions turn on in '+Math.ceil(left/1000):'';
      if(node){node.hidden=!text;if(node.textContent!==text)node.textContent=text;}
      return node?'':text;
    }
    function actorView(actor){
      const live=new Set(worldBodies(world)),scale=world.m_physScale||30;
      let minX=Infinity,minY=Infinity,maxX=-Infinity;
      for(const [key,body]of Object.entries(listParts(actor))){
        if(/^new:/.test(key)||!live.has(body))continue;
        for(const shape of bodyOutline(body)){
          const points=shape.points||(shape.circle?[shape.circle[0]-shape.circle[2],shape.circle[1]-shape.circle[2],shape.circle[0]+shape.circle[2],shape.circle[1]+shape.circle[2]]:[]);
          for(let i=0;i<points.length;i+=2){minX=Math.min(minX,points[i]);maxX=Math.max(maxX,points[i]);minY=Math.min(minY,points[i+1]);}
        }
      }
      if(!Number.isFinite(minX))return null;
      return {x:(minX+maxX)/2,top:minY,worldX:(minX+maxX)/2/scale};
    }
    function players(){
      if(!world||!playing())return [];
      const out=[];
      for(const actor of actors.values()){
        const view=actorView(actor);
        out.push({id:actor.id,life:actor.life,dead:!!actor.character?.dead,finished:!!actor.finishedAt,x:view?.x??null,top:view?.top??null,worldX:view?.worldX??null});
      }
      return out;
    }
    // The native finish block only tests session.character, so other riders use the same test here.
    function atFinish(actor){
      const box=(world.level||world._level)?.endBlock?.aabb;
      if(!box||actor.character.dead)return false;
      const p=actor.character.cameraFocus?.GetWorldCenter?.();
      return !!p&&p.x<box.upperBound.x&&p.x>box.lowerBound.x&&p.y<box.upperBound.y&&p.y>box.lowerBound.y;
    }
    function noteFinish(){
      for(const actor of actors.values()){
        if(actor.finishedAt)continue;
        const done=!!(actor.character.finished||actor.character.completed||(actor.id===context.selfId?world.replayData?.completed:atFinish(actor)));
        if(done){actor.finishedAt=Math.max(1,Math.round(now()-openingUntil+OPEN_MS));try{actor.character.finished=true;}catch{}}
      }
    }
    function poseNear(a,b){
      return !!a&&!!b&&Math.abs(a[0]-b[0])<0.01&&Math.abs(a[1]-b[1])<0.01&&Math.abs(a[2]-b[2])<0.01&&Math.abs(a[3]-b[3])<0.05&&Math.abs(a[4]-b[4])<0.05&&Math.abs(a[5]-b[5])<0.05;
    }
    function snapshot(){
      snapshotCount++;
      const full=snapshotCount%20===1;
      const players=[...actors.values()].map(a=>{
        const packed=outgoingEvents(a);
        return {id:a.id,character:a.kind,life:a.life,origin:a.origin,skin:a.skin||'',rebuild:a.rebuild||0,request:a.request,dead:!!a.character.dead,finished:!!a.finishedAt,finishTime:a.finishedAt||0,protectedUntil:shieldLeft(a),parts:bodyPose(a),replicas:partReplicas(a),breaks:[],events:packed.resetEvents?[]:packed.events,eventBase:packed.eventBase,resetEvents:!!packed.resetEvents};
      });
      const live=new Set(worldBodies(world));
      const entries=[],extras=[],removed=[];
      for(const [id,entry]of worldEntries){
        if(!live.has(entry.body)){removed.push(id);lastWorldPose.delete(id);continue;}
        const pose=readPose(entry.body);
        if(full||!poseNear(lastWorldPose.get(id),pose)){entries.push([id,...pose]);lastWorldPose.set(id,pose);}
        if(id>=levelBodies.length&&(full||entries.some(row=>row[0]===id))){
          const visual=lab.sharedVisuals?.captureNode(entry.body.GetUserData?.());
          extras.push({id,visual,outline:bodyOutline(entry.body)});
        }
      }
      const textures=lab.sharedVisuals?.textures()||[];
      const textureJson=JSON.stringify(textures);
      const sendTextures=snapshotCount===1||textureJson!==lastTextureJson;
      if(sendTextures){lastTextureJson=textureJson;lastTextures=textures.slice();}
      const sendSignature=levelSignature!==lastSignatureSent;
      if(sendSignature)lastSignatureSent=levelSignature;
      return {type:'authorityState',epoch,revision,tick,full,signature:sendSignature?levelSignature:'',players,world:entries,removed,extras,textures:sendTextures?textures:[],effects:outgoingEffects()};
    }
    function receiveState(m){
      if(m.revision<seenRevision||m.revision===seenRevision&&m.tick<=lastReceived)return;
      if(m.signature){if(m.signature!==levelSignature)throw Error('Level physics differ from the host. Reload the same game and level.');}
      else if(!levelSignature)throw Error('Level physics differ from the host. Reload the same game and level.');
      // A rebuilt host world restarts every life at 0. Rebuild riders from it.
      if(seenRevision>=0&&m.revision!==seenRevision)for(const actor of actors.values())actor.life=-1;
      seenRevision=m.revision;lastReceived=m.tick;const arrival=now();previousFrame=remoteFrame;remoteFrame={...m,at:arrival};if(previousFrame)previousFrame.at=previousFrame.at||arrival-50;lastArrival=arrival;ready=true;
      if(m.textures?.length){lastTextureJson=JSON.stringify(m.textures);lastTextures=m.textures.slice();}
      applying=true;
      try{
        for(const player of m.players)applyPlayer(player);
        const ids=new Set(m.players.map(p=>p.id));for(const id of [...actors.keys()])if(!ids.has(id))destroyActor(id);
        const present=new Set(),full=m.full!==false;
        const gone=new Set(full?[]:m.removed||[]);
        for(const id of gone)if(id<levelBodies.length)hideLevelBody(levelBodies[id]);
        const liveNow=new Set(worldBodies(world));
        for(const p of m.world){
          // Level bodies are drawn from the interpolation pass, not snapped here.
          if(p[0]<levelBodies.length)continue;
          const entry=worldEntries.get(p[0]);present.add(p[0]);if(entry?.body)writePose(entry.body,p.slice(1));else if(p[0]<levelBodies.length)throw Error('An initial level body unexpectedly reappeared.');
        }
        const live=new Set(worldBodies(world));
        for(const [id,entry]of worldEntries)if(id>=levelBodies.length&&entry.body&&live.has(entry.body)&&(full?!present.has(id):gone.has(id))){
          const mc=entry.body.GetUserData?.();mc?.parent?.removeChild(mc);world.m_world.DestroyBody(entry.body);worldEntries.delete(id);
        }
        updateExtras(m.extras||[],lastTextures,m.full!==false);
        playEffects(m.effects);
        tick=m.tick;
      }finally{applying=false;}
    }
    function lerpPose(from,to,t){
      const spin=Math.atan2(Math.sin(to[2]-from[2]),Math.cos(to[2]-from[2]));
      return [0,1,3,4,5].reduce((pose,i)=>(pose[i]=from[i]+(to[i]-from[i])*t,pose), [0,0,from[2]+spin*t,0,0,0]);
    }
    function renderSnapshots(){
      if(!guest()||!remoteFrame)return;
      const prev=previousFrame&&previousFrame.revision===remoteFrame.revision?previousFrame:null;
      const span=prev?Math.max(30,Math.min(150,(remoteFrame.at||0)-(prev.at||0))):1;
      const t=prev?Math.max(0,Math.min(1,(now()-(remoteFrame.at||now()))/span)):1;
      const poseFor=(frame,id)=>frame?.players?.find(player=>player.id===id);
      for(const player of remoteFrame.players){
        const actor=actors.get(player.id);if(!actor)continue;
        const old=poseFor(prev,player.id);
        const snap=!old||old.life!==player.life||old.character!==player.character;
        const bodies=listParts(actor),live=new Set(worldBodies(world));
        for(const [key,pose] of Object.entries(player.parts||{})){
          if(!bodies[key]||!live.has(bodies[key]))continue;
          writePose(bodies[key],snap?pose:lerpPose(old.parts?.[key]||pose,pose,t));
        }
      }
      const liveNow=new Set(worldBodies(world)),before=new Map((prev?.world||[]).map(item=>[item[0],item]));
      for(const row of remoteFrame.world||[]){
        if(row[0]<levelBodies.length){
          const body=levelBodies[row[0]];
          if(!body||!liveNow.has(body))continue;
          const target=row.slice(1),from=shownLevel.get(row[0])||readPose(body);
          if(!movingLevel.has(body)&&poseNear(from,target))continue;
          const pose=lerpPose(from,target,t);
          moveLevelBody(body,pose);shownLevel.set(row[0],pose);
          continue;
        }
        const entry=worldEntries.get(row[0]);if(!entry?.body||!liveNow.has(entry.body))continue;
        const old=before.get(row[0]);
        writePose(entry.body,old?lerpPose(old.slice(1),row.slice(1),t):row.slice(1));
      }
    }
    function paintScene(){
      renderSnapshots();
      for(const actor of actors.values())inActor(actor,()=>actor.character.paint());
      world.level?.paint?.();
      world.camera?.step?.(1);
    }
    function actorBounds(actor){
      let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
      for(const body of actor.owned)for(const shape of bodyOutline(body)){
        const points=shape.points||(shape.circle?[shape.circle[0]-shape.circle[2],shape.circle[1]-shape.circle[2],shape.circle[0]+shape.circle[2],shape.circle[1]+shape.circle[2]]:[]);
        for(let i=0;i<points.length;i+=2){minX=Math.min(minX,points[i]);maxX=Math.max(maxX,points[i]);minY=Math.min(minY,points[i+1]);maxY=Math.max(maxY,points[i+1]);}
      }
      return {minX,minY,maxX,maxY};
    }
    function updateProtection(){
      if(now()<openingUntil||now()>openingUntil+3000)return;
      const list=[...actors.values()];
      for(const actor of list){
        if((actor.overlapHolds||0)>=4||now()<actor.protectUntil-50)continue;
        const a=actorBounds(actor);
        const hit=list.some(other=>{if(other===actor)return false;const b=actorBounds(other);return a.minX<b.maxX&&a.maxX>b.minX&&a.minY<b.maxY&&a.maxY>b.minY;});
        if(hit){actor.protectUntil=now()+OVERLAP_MS;actor.overlapHolds=(actor.overlapHolds||0)+1;}
      }
    }
    function installPhysics(){
      const physics=world.m_world;
      patch(physics,'CreateBody',original=>function(...args){
        const body=original.apply(this,args);
        if(mutatingOwner){mutatingOwner.owned.add(body);if(mutatingOwner.partMap)mutatingOwner.partMap['new:'+mutatingOwner.nextPart++]=body;body.__hwAuthorityOwner=mutatingOwner.id;body.__hwAuthorityLife=mutatingOwner.life;}
        else if(playing()&&context.isHost&&!applying){const id=nextWorldId++;worldIds.set(body,id);worldEntries.set(id,{body});}
        return body;
      });
      const previous=physics.m_contactFilter;
      physics.SetContactFilter({ShouldCollide(a,b){
        if(guest())return false;
        const ba=a.m_body||a.GetBody?.(),bb=b.m_body||b.GetBody?.(),ia=ba?.__hwAuthorityOwner,ib=bb?.__hwAuthorityOwner;
        if(ia&&ib&&ia!==ib){if(bumpsOff())return false;const pa=actors.get(ia),pb=actors.get(ib);if(!pa||!pb||shielded(pa)||shielded(pb))return false;}
        return previous?.ShouldCollide?previous.ShouldCollide(a,b):true;
      }});restores.push(()=>{if(physics.m_contactListener)physics.SetContactFilter(previous)});
      patch(physics,'Step',original=>function(...args){
        if(!active())return original.apply(this,args);
        if(guest()||failed)return;
        try{
          for(const actor of actors.values()){
            if(actor.id===context.selfId)continue;
            const input=inputs.get(actor.id),mask=input&&now()-input.at<inputTimeout?input.keys:0;
            fields.forEach((key,i)=>actor.character[key]=!!(mask&(1<<i)));
            inActor(actor,()=>{actor.character.preActions?.();actor.character.checkKeyStates?.();actor.character.actions?.()});
          }
          const result=original.apply(this,args);tick++;
          noteFinish();
          updateProtection();
          for(const actor of actors.values())claimLooseParts(actor);
          for(const actor of actors.values())if(actor.id!==context.selfId)inActor(actor,()=>{actor.character.handleContactBuffer?.();actor.character.handleContactAdds?.()});
          const collideOn=!bumpsOff();
          const changed=[...actors.values()].some(actor=>{const on=shielded(actor);const flip=on!==actor.shieldOn;actor.shieldOn=on;return flip;})||collideOn!==world.__hwCollide;
          world.__hwCollide=collideOn;
          if(changed)refilterPlayers();
          return result;
        }catch(e){report(e);}
      });
      // Guest sessions render snapshots and move their own camera, but never run native gameplay.
      for(const name of ['run30fps','run60fps','runCameraMode'])if(typeof world[name]==='function')patch(world,name,original=>function(...args){
        if(!active())return original.apply(this,args);
        if(failed)return;
        try{
          if(guest()){
            if(!ready)return;
            try{renderSnapshots();}catch(e){report(e);}
            try{this.stepLevelItems?.();}catch(e){report(e);}
            try{this.camera?.step?.(1);}catch(e){report(e);}
            try{if(this._useCulling)this.cullObjects?.();}catch(e){report(e);}
            for(const actor of actors.values())try{inActor(actor,()=>{actor.character.paint();refreshRopes(actor);});}catch(e){report(e);}
            try{paintSkins();}catch(e){report(e);}
            // Particles and positional audio only; neither touches physics.
            try{(this.particleController||this._particleController)?.step?.(name==='run60fps'?0.5:1);}catch(e){if(lab.errors.length<100)lab.errors.push('Particles: '+String(e?.message||e));}
            try{paintLevel();}catch(e){report(e);}
            try{soundManager()?.step?.();}catch{}
            return;
          }
          processRequests();
          simulating++;
          let result;
          try{result=original.apply(this,args);}finally{simulating--;}
          for(const a of actors.values())if(a.id!==context.selfId)inActor(a,()=>a.character.paint());
          return result;
        }catch(e){report(e);}
      });
      const renderer=lab.state?.rootApp?.renderer;
      if(renderer?.on){
        const follow=()=>{
          if(!active()||failed)return;
          if(guest()&&ready){
            try{renderSnapshots();}catch(e){report(e);return;}
            try{world.camera?.step?.(1);}catch(e){report(e);}
            try{if(world._useCulling)world.cullObjects?.();}catch(e){report(e);}
            try{paintLevel();}catch(e){report(e);}
            for(const actor of actors.values())try{inActor(actor,()=>{actor.character.paint();refreshRopes(actor);});}catch(e){report(e);}
          }
          try{paintSkins();}catch(e){report(e);}
        };
        renderer.on('prerender',follow);
        restores.push(()=>{try{renderer.off?.('prerender',follow);}catch{}});
      }
    }
    function installWorld(session){
      world=session;tick=0;revision++;seenRevision=-1;ready=context.isHost;failed=false;lastReceived=-1;remoteFrame=null;previousFrame=null;openingUntil=(releasedAt||now())+OPEN_MS;snapshotCount=0;lastSignatureSent='';lastWorldPose.clear();
      takeActor(context.selfId,world.character,localIndex());localKind=localIndex();
      lastEffect=0;doneEffects.clear();pendingEffects.length=0;seedLevel();installPhysics();hookController();hookEffects();
      if(context.isHost)for(const [i,p]of context.room.players.entries())if(p.id!==context.selfId)spawnActor(p.id,p.character||1,0,i);
      lab.sharedActors=actors;lab.paintSharedSkins=paintSkins;
    }
    function reset(){
      // Restore hooks before retiring a world. Never run native destruction on a disposed world.
      while(restores.length){try{restores.pop()()}catch{}}
      const current=lab.state?.currentSession;
      for(const [id,a]of actors){
        if(id===context?.selfId)continue;
        if(world===current&&world?.m_world?.m_contactListener)destroyActor(id);else stripCharacter(a.character);
      }
      stopMirrorLoops();damageDepth=0;simulating=0;movedLevel.clear();movingLevel.clear();shownLevel.clear();acks.clear();
      actors.clear();inputs.clear();requests.length=0;poses.clear();worldEntries.clear();for(const v of extraViews.values())lab.sharedVisuals?.remove(v);extraViews.clear();world=null;ready=false;keys=0;failed=false;remoteFrame=null;previousFrame=null;
    }
    function stop(){reset();epoch=null;revision=0;tick=0;lastReceived=-1;releasedAt=0;seenRevision=-1;effectSeq=0;lastEffect=0;loopSeq=0;paintShield();badge.hidden=true;document.getElementById('hw-authority-character')?.remove();}
    function receive(m){
      if(!active()||m.epoch!==epoch||!world||failed)return;
      try{
        if(m.type==='authorityInput'&&context.isHost){
          const old=inputs.get(m.id);if(!old||m.seq>old.seq)inputs.set(m.id,{...m,at:now()});
          if(m.applied&&typeof m.applied==='object'){let book=acks.get(m.id);if(!book){book=new Map();acks.set(m.id,book);}for(const [id,value] of Object.entries(m.applied)){const ack=Number.isSafeInteger(value)?null:value;if(ack&&Number.isSafeInteger(ack.life)&&Number.isSafeInteger(ack.seq)&&ack.seq>=0)book.set(id,{life:ack.life,seq:ack.seq});}}
        }
        else if(m.type==='authorityRequest'&&context.isHost)requests.push(m);
        else if(m.type==='authorityState'&&guest())receiveState(m);
      }catch(e){report(e);}
    }
    function update(next){
      context=next;
      if(!active()){if(epoch!==null)stop();return false;}
      if(!context.room.capabilities?.includes('shared-authority-v3')){badge.hidden=false;badge.textContent='Shared Physics requires the updated relay (authority v3).';return true;}
      if(epoch!==context.raceStart){stop();epoch=context.raceStart;inputSeq=0;requestSeq=0;lastSent=0;lastInput=0;}
      try{
        if(!world&&context.session&&!context.session.isMenu&&context.session.character&&!menuOpen())installWorld(context.session);
        if(world&&context.session!==world){reset();throw Error('The level restarted outside the shared session. Start a new race to resynchronize.');}
        if(!world)return true;
        hookController();
        if(playing()){
          if(typeof context.collide==='boolean')bumpsEnabled=context.collide;
          if(!releasedAt){releasedAt=now();openingUntil=releasedAt+OPEN_MS;}
          if(context.isHost){
            const ids=new Set(context.room.players.map(p=>p.id));for(const id of [...actors.keys()])if(!ids.has(id))destroyActor(id);
            if(now()-lastSent>=50){lastSent=now();send(snapshot());}
          }else if(now()-lastInput>=33){
            const applied={};for(const actor of actors.values())applied[actor.id]={life:actor.life,seq:actor.appliedEvent||0};
            const recover=[];for(const actor of actors.values())if(actor.blocked)recover.push({id:actor.id,life:actor.life});
            lastInput=now();send({type:'authorityInput',epoch,seq:++inputSeq,keys:actionMask(),applied,recover});
          }
        }
        const shield=paintShield();
        if(!failed){badge.hidden=false;badge.textContent=(!context.released?'Shared Physics · waiting for start':guest()&&(!ready||now()-lastArrival>staleMs)?'Waiting for host — controls and world updates delayed':'Shared Physics · '+actors.size+' players · '+(context.isHost?'host simulation':'connected'))+(shield?' · '+shield:'');}
      }catch(e){report(e);}
      return true;
    }
    return {update,receive,stop,reset,requestSpawn,chooseCharacter,players,setCollide,diagnostics:()=>({authority:2,epoch,revision,tick,host:context?.isHost,actors:actors.size,failed,ready,lastReceived,poseAge:Math.round(now()-lastArrival),bodies:worldBodies(world||{}).length,kinds:Object.fromEntries([...actors].map(([id,a])=>[id,a.kind])),owned:Object.fromEntries([...actors].map(([id,a])=>[id,a.owned.size])),finished:Object.fromEntries([...actors].map(([id,a])=>[id,a.finishedAt||0]))})};
  };
})();
