'use strict';
const fs=require('node:fs/promises'),path=require('node:path'),{createHash,randomBytes}=require('node:crypto');
const core=require('../web/core.js');
const digest=bytes=>createHash('sha256').update(bytes).digest('hex');
function normalizeBase(value){const u=new URL(String(value||''));if(u.username||u.password||u.search||u.hash||(u.protocol!=='https:'&&!(u.protocol==='http:'&&['127.0.0.1','localhost','[::1]'].includes(u.hostname))))throw Error('Use an HTTPS map server, or HTTP localhost for testing.');if(!['','/'].includes(u.pathname))throw Error('Enter the map server origin without a path.');return u.origin;}
function createMapsClient({directory,safeStorage,fetchImpl=fetch}={}){
  let settings={base:'',secret:''},token='',initializing=null;const pending=new Map();
  const disk=path.join(directory,'jimbob-maps'),settingsPath=path.join(directory,'jimbob-maps-settings.json');
  function init(){return initializing||(initializing=(async()=>{try{const data=JSON.parse(await fs.readFile(settingsPath,'utf8'));settings.base=data.base?normalizeBase(data.base):'';settings.secret=typeof data.secret==='string'?data.secret:'';if(settings.secret&&safeStorage?.isEncryptionAvailable())token=safeStorage.decryptString(Buffer.from(settings.secret,'base64'));}catch{}})());}
  async function configure(value={}){
    await init();if(value.base!=null)settings.base=value.base?normalizeBase(value.base):'';
    if(value.token!=null){if(typeof value.token!=='string'||value.token.length>512)throw Error('Invalid publishing key.');token=value.token;settings.secret=token&&safeStorage?.isEncryptionAvailable()?safeStorage.encryptString(token).toString('base64'):'';}
    await fs.mkdir(directory,{recursive:true});await fs.writeFile(settingsPath,JSON.stringify(settings),'utf8');
    return {base:settings.base,hasKey:!!token,keySaved:!!settings.secret};
  }
  async function base(relay){await init();if(settings.base)return settings.base;if(!relay)throw Error('Choose your Jimbob Maps server in Multiplayer settings.');const u=new URL(relay);if(!['ws:','wss:'].includes(u.protocol))throw Error('Invalid multiplayer server.');u.protocol=u.protocol==='wss:'?'https:':'http:';u.pathname='/';u.search='';u.hash='';return normalizeBase(u.href);}
  async function request(route,{relay,method='GET',body,auth=false,max=2*1024*1024}={}){
    const origin=await base(relay),url=origin+route;
    if(auth&&!token)throw Error('Enter your publishing key in Builder.');
    const headers={accept:'application/json'};if(body)headers['content-type']='application/json';if(auth)headers.authorization='Bearer '+token;
    let response;
    try{response=await fetchImpl(url,{method,headers,body:body?JSON.stringify(body):undefined,redirect:'error',signal:AbortSignal.timeout(method==='POST'?90000:20000)});}catch{throw Error('Could not reach Jimbob Maps. Check the server address and try again.');}
    if(Number(response.headers.get('content-length'))>max)throw Error('Map server response exceeds its size limit.');
    const chunks=[];let size=0;
    for await(const chunk of response.body){size+=chunk.length;if(size>max)throw Error('Map server response exceeds its size limit.');chunks.push(Buffer.from(chunk));}
    const bytes=Buffer.concat(chunks);
    if(!response.ok){let message;try{message=JSON.parse(bytes).error;}catch{}throw Error(typeof message==='string'?message.slice(0,300):'Jimbob Maps request failed ('+response.status+').');}
    return bytes;
  }
  async function jsonRequest(route,options={}){
    const bytes=await request(route,options);
    try{return JSON.parse(bytes.toString('utf8'));}catch{
      const origin=await base(options.relay);
      throw Error('The server at '+origin+' did not return the Jimbob Maps API. An older relay or the wrong port may be selected. Start maps-service/server.cjs and set its HTTP address in Builder publishing connection.');
    }
  }
  function descriptor(value){if(!core.validMeta(value?.meta)||value.meta.source!=='jimbob'||!Number.isSafeInteger(value.size)||value.size<1||value.size>16*1024*1024)throw Error('The map server returned an invalid revision.');if(value.requiredFeatures?.some(v=>!['hosted-maps-v1'].includes(v)))throw Error('Update Multiplayer: this map requires newer features.');return value;}
  async function list(options={}){
    const query=new URLSearchParams({page:String(Math.max(1,Number(options.page)||1)),query:String(options.query||'').slice(0,120),sort:options.sort==='oldest'?'oldest':'newest'});
    const data=await jsonRequest('/api/maps'+(options.mine?'/mine':'')+'?'+query,{relay:options.relay,auth:!!options.mine});
    if(!Array.isArray(data.items)||data.items.length>24)throw Error('Invalid map catalogue.');data.items=data.items.map(descriptor);return data;
  }
  async function inspect(code,revision,relay){const id=String(code||'').replace(/^JM-/i,'').toLowerCase();if(!/^[a-f0-9]{16}$/.test(id)||revision!=null&&(!Number.isSafeInteger(Number(revision))||Number(revision)<1))throw Error('Enter a JM map code.');return descriptor(await jsonRequest('/api/maps/'+id+(revision!=null?'/revisions/'+Number(revision):''),{relay}));}
  async function trim(){try{const files=await fs.readdir(disk),rows=await Promise.all(files.filter(f=>/^[a-f0-9]{64}\.xml$/.test(f)).map(async name=>({name,...await fs.stat(path.join(disk,name))})));let total=rows.reduce((n,r)=>n+r.size,0);for(const row of rows.sort((a,b)=>a.mtimeMs-b.mtimeMs)){if(total<=256*1024*1024)break;await fs.unlink(path.join(disk,row.name));total-=row.size;}}catch{}}
  async function download(meta,relay){
    if(!core.validMeta(meta)||meta.source!=='jimbob')throw Error('Invalid hosted map.');
    const namespace=digest(await base(relay)),key=namespace+':'+meta.mapId+':'+meta.revision+':'+meta.hash;
    if(pending.has(key))return pending.get(key);
    if(pending.size>=4)throw Error('Wait for the current map downloads.');
    const task=(async()=>{
      const dest=path.join(disk,meta.hash+'.xml');
      // Resolve on every launch so a cache cannot silently substitute another revision or unknown rules.
      const info=await inspect(meta.mapId,meta.revision,relay);if(!core.compatible(info.meta,meta))throw Error('The hosted map differs from the room revision.');
      let bytes;try{bytes=await fs.readFile(dest);if(bytes.length!==info.size||digest(bytes)!==meta.hash)bytes=null;}catch{}
      if(!bytes){bytes=await request('/api/maps/'+meta.mapId+'/revisions/'+meta.revision+'/xml',{relay,max:16*1024*1024});if(bytes.length!==info.size||digest(bytes)!==meta.hash)throw Error('Map download verification failed. Retry the map.');await fs.mkdir(disk,{recursive:true});const temp=dest+'.'+randomBytes(6).toString('hex')+'.tmp';await fs.writeFile(temp,bytes);await fs.rename(temp,dest);await trim();}
      return {...info,xml:new TextDecoder('utf-8',{fatal:true}).decode(bytes)};
    })().finally(()=>pending.delete(key));pending.set(key,task);return task;
  }
  async function preview(meta,relay){if(!core.validMeta(meta)||meta.source!=='jimbob')throw Error('Invalid map preview');const data=await request('/api/maps/'+meta.mapId+'/revisions/'+meta.revision+'/preview',{relay,max:2*1024*1024});if(data.subarray(0,8).toString('hex')!=='89504e470d0a1a0a')throw Error('Invalid preview image.');return 'data:image/png;base64,'+data.toString('base64');}
  async function publish(input){if(typeof input?.xml!=='string'||Buffer.byteLength(input.xml)>16*1024*1024)throw Error('Map XML exceeds 16 MB.');return descriptor(await jsonRequest('/api/maps',{relay:input.relay,method:'POST',body:{xml:input.xml,title:input.title,description:input.description,visibility:input.visibility,mapId:input.mapId,baseRevision:input.baseRevision,uploadId:input.uploadId,preview:input.preview},auth:true}));}
  return {configure,base,list,inspect,download,preview,publish};
}
module.exports={createMapsClient,normalizeBase};
