(() => {
  'use strict';
  const registry=new Map();let generation=0,pendingTracker=null;
  const api=window.HWJimbobMaps={errors:[],active:null};
  function bridge(){if(!window.hwJimbobMaps)throw Error('Restart Happy Wheels through Steam to load Jimbob Maps.');return window.hwJimbobMaps;}
  function relay(){return window.HWGhost?.lobby?.().server||window.HWGhostConfig?.defaultRelayUrl;}
  function parse(xml){if(typeof xml!=='string'||xml.length>16*1024*1024||/<!DOCTYPE|<!ENTITY/i.test(xml))throw Error('Unsupported hosted XML.');const doc=new DOMParser().parseFromString(xml,'text/xml');if(doc.getElementsByTagName('parsererror').length||doc.documentElement?.tagName!=='levelXML'||!doc.querySelector('levelXML > info'))throw Error('Invalid hosted map XML.');return doc;}
  function install(hw,lab){
    const Loader=lab.require?.(0x183ff)?.Pu;if(!Loader?.prototype?.loadXML||!Loader.prototype.buildLevelSourceObject)throw Error('The game XML loader is unavailable.');
    if(!Loader.prototype.__jmpHosted){
      const originalData=Loader.prototype.loadData,originalBuild=Loader.prototype.buildLevelSourceObject;
      Loader.prototype.loadData=function(){const entry=registry.get(String(this.levelId));if(!entry)return originalData.apply(this,arguments);const previous=window.xml;window.xml=entry.xml;try{return this.loadXML();}finally{if(previous===undefined)delete window.xml;else window.xml=previous;}};
      Loader.prototype.buildLevelSourceObject=function(){
        const source=originalBuild.apply(this,arguments),entry=registry.get(String(this.levelId));if(!entry)return source;
        const doc=parse(entry.xml);
        for(const [folder,[section,item]] of Object.entries({shapes:['shapes','sh'],special:['specials','sp'],groups:['groups','g'],joints:['joints','j'],triggers:['triggers','t']})){
          const expected=doc.querySelectorAll('levelXML > '+section+' > '+item).length,node=source?.getChildByName?.(folder),actual=Number(node?.numChildren??node?.children?.length??0);
          if(actual!==expected)throw Error('Hosted map failed to build '+folder+' ('+actual+'/'+expected+'). Return to the lobby and retry.');
        }
        const compiled=window.HWJimbobLevels.rememberCourse(entry.meta,entry.xml);source.__jmpCourseBoxes=compiled.boxes.map(({text,x,y})=>({text,x,y}));return source;
      };
      Loader.prototype.__jmpHosted=true;
    }
    if(!hw.__jmpHostedNavigation){const original=hw.loadLevelByID;hw.loadLevelByID=function(){api.cancel();return original.apply(this,arguments);};hw.__jmpHostedNavigation=true;}
  }
  api.metaFor=level=>registry.get(String(level))?.meta||null;
  api.configure=options=>bridge().configure(options);
  api.list=options=>bridge().list({...options,relay:relay()});
  api.inspect=async code=>bridge().inspect({code,relay:relay()});
  api.preview=meta=>bridge().preview({meta,relay:relay()});
  api.publish=input=>bridge().publish({...input,relay:relay()});
  api.capture=rect=>bridge().capture(rect);
  api.choosePreview=()=>bridge().choosePreview();
  api.cancel=()=>{++generation;api.active=null;if(pendingTracker)pendingTracker.loading=false;pendingTracker=null;};
  api.load=async(meta,{guard=()=>true}={})=>{
    if(!window.HWGhostCore.validMeta(meta)||meta.source!=='jimbob')throw Error('Invalid hosted revision.');
    const lab=window.HWGhost,hw=lab?.state?.rootApp?.screenManager?.currentScreen?.happyWheels;
    if(!hw||!lab.require)throw Error('Wait for Happy Wheels to load.');install(hw,lab);
    const ticket=++generation,tracker={level:meta.level,hash:null,loading:true};pendingTracker=tracker;lab.download=tracker;lab.levelHash=null;
    try{
      const entry=await bridge().download({meta,relay:relay()});if(ticket!==generation||!guard())return;
      if(!window.HWGhostCore.compatible(meta,entry.meta))throw Error('Map revision mismatch.');const doc=parse(entry.xml);window.HWJimbobLevels.rememberCourse(entry.meta,entry.xml);
      registry.set(meta.level,entry);api.active=entry;
      // Never evict a registry entry while it can be used by a native restart. Keep a bounded set of other revisions.
      if(registry.size>16)for(const key of registry.keys())if(key!==meta.level){registry.delete(key);break;}
      lab.download={level:meta.level,hash:meta.hash,loading:false};lab.levelHash=meta.hash;lab.pendingHash=Promise.resolve(meta.hash);
      if(hw.sessionController)hw.closeSessionController();hw.closeMainMenu?.();
      const info=doc.querySelector('levelXML > info');
      hw.openSessionController({id:Number(meta.level),name:meta.title||entry.name,author_id:0,author_name:meta.author||'Jimbob',character:Number(info.getAttribute('c'))||1,forceChar:false,_forceChar:info.getAttribute('f')==='t',plays:0,rating:0},null);
    }catch(e){if(ticket!==generation||!guard())return;lab.download={level:meta.level,loading:false,hash:null};api.errors.push(String(e.message));throw e;}finally{tracker.loading=false;if(pendingTracker===tracker)pendingTracker=null;}
  };
})();
