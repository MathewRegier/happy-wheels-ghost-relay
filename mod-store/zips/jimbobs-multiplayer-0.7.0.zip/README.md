# Jimbob's Multiplayer · 0.7.0

Adds Jimbob Maps browsing, previews, JM codes and verified map downloads to the existing Ghost and Shared Physics modes. The Multiplayer Maps tab uses Jimbob Maps hosting; the separate legacy JHWMP catalog tab has been removed. Players do not need Builder. The room pins the same immutable XML revision for all players and keeps existing character selection, spawning, survival, restart voting and fixed camera rules.

Your server must run the Jimbob Maps service. Set its WSS address in Multiplayer settings. The Maps origin is derived from that address unless you explicitly set a different Maps address. B2 credentials and the publishing key are not required by players.

Install this local delivery with its included installer, which refreshes the native Maps bridge as well as the mod. A plain mod-folder copy cannot refresh a bridge already baked into the game archive. Do not run an older launcher install afterward if it would replace this mod with an older catalogue version.

Creators install Builder 0.3.0 as well and use Publish to Jimbob Maps. Ordinary Happy Wheels XML uses the game's assets; additional custom characters still require their own character mod.
