# Jimbob's Multiplayer · 0.7.7

Ghost racing, host-run Shared Physics, public rooms, Steam invites and chat. The Multiplayer Maps tab loads Jimbob Maps: browse, preview, or open a JM code, and everyone in the room gets the same verified revision.

Players do not need Builder. This update also plays published tycoon and Studio maps, and lets one person start a solo room. Survival maps still need at least two players. Solo rooms stay off the public browser.

Install with the Happy Wheels Mod Launcher, or unzip and copy the `jimbobs-multiplayer` folder into the game's `mods` folder. Fully quit every Happy Wheels window, then launch through Steam. Everyone in a room should use 0.7.7. This build puts the Multiplayer button back on the Happy Wheels 1.99.3 title screen. Install the updated launcher, press Install, then update this mod.

See README.txt for install steps and the full update notes.
