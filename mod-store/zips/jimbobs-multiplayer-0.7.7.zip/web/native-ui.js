(function(root){
  'use strict';
  if(root.HWNativeUI)return;
  function alive(node){const sprite=node?.pixiSprite||node;return !!sprite&&!node.destroyed&&!node._destroyed&&!sprite.destroyed&&!sprite._destroyed;}
  function visible(node){
    if(!alive(node))return false;
    for(const first of [node,node.pixiSprite]){
      const seen=new Set();
      for(let n=first;n&&!seen.has(n);n=n.parent){seen.add(n);if(n.visible===false||n.renderable===false||n.alpha===0)return false;}
    }
    return true;
  }
  function attached(node){return alive(node)&&!!(node.parent||node.pixiSprite?.parent);}
  function setButton(button,on){
    for(const node of [button,button?.pixiSprite,button?.textField,button?.textField?.pixiSprite]){
      if(!alive(node))continue;
      try{node.visible=on;node.renderable=on;node.alpha=on?1:0;}catch{}
    }
    if(button)try{button.interactive=on;button.eventMode=on?'static':'none';}catch{}
  }
  function watchMenu(menu){
    if(!menu||menu.__hwTitleHooks)return;
    menu.__hwTitleHooks=true;
    // Hide immediately, including calls made by native bound event handlers.
    for(const key of ['hideButtons','openBasicMenu','openLevelBrowser','openFeaturedMenu','openReplayBrowser','openLoadLevelMenu','openOptionsMenu','maskTransition']){
      const original=menu[key];if(typeof original!=='function')continue;
      menu[key]=function(...args){setButton(this.multiplayerBtn,false);setButton(this.characterCreatorBtn,false);return original.apply(this,args);};
    }
  }
  function titleVisible(hw,session){
    const menu=hw?.mainMenu;watchMenu(menu);
    if(!menu?.optionsBtn||!attached(menu)||!visible(menu)||!visible(menu.optionsBtn)||hw.sessionController||hw.editor)return false;
    if(session&&!session.isMenu&&(session.m_world||session.containerSprite))return false;
    for(const owner of [hw,menu])for(const [key,node]of Object.entries(owner)){
      if(node===menu||!node||typeof node!=='object')continue;
      if(/browser|featured|selector|basicMenu|loadMenu|optionsMenu|searchMenu|levelMenu|levelExplorer|replayMenu|promptSprite/i.test(key)&&attached(node)&&visible(node))return false;
    }
    return true;
  }
  function discardVictory(controller){
    const node=controller?.victoryMC;if(!node)return false;
    // Native openSessionMenu(false) replaces this pointer without removing the
    // previous movie clip. Stop its ticker and detach before another can exist.
    try{node.stop?.();}catch{}
    try{node.visible=false;if(node.pixiSprite)node.pixiSprite.visible=false;}catch{}
    try{node.parent?.removeChild?.(node);}catch{}
    try{if(node.pixiSprite?.parent)node.pixiSprite.parent.removeChild(node.pixiSprite);}catch{}
    if(controller.victoryMC===node)controller.victoryMC=null;
    return true;
  }
  function worldReady(session,controller,hw,repair=false){
    if(!session||session.isMenu||session.isEditorTest||!session.m_world||!session.character||controller?.session!==session||!alive(session)||!alive(session.containerSprite)||!alive(hw))return false;
    const container=session.containerSprite;
    if(repair){
      // Only restore the native scene roots. Never reveal authored hidden objects,
      // damaged character variants, trigger artwork or offscreen culled sprites.
      if(!session.parent&&!session.pixiSprite?.parent)hw.addChildAt?.(session,0);
      if(!container.parent&&!container.pixiSprite?.parent)session.addChild?.(container);
      for(const node of [hw,session,container])for(const n of [node,node.pixiSprite])if(alive(n)){n.visible=true;n.renderable=true;n.alpha=1;}
    }
    return attached(hw)&&(session.parent===hw||session.pixiSprite?.parent===hw.pixiSprite)&&(container.parent===session||container.pixiSprite?.parent===session.pixiSprite)&&visible(hw)&&visible(session)&&visible(container);
  }
  function gameOf(screen){
    const direct=screen?.$$rp;
    if(direct&&(direct.mainMenu||direct.sessionController||direct.editor||direct.characterMenu))return direct;
    return null;
  }
  function repair(screen){
    const manager=screen?.screenManager||window.HWMod?.state?.rootApp?.screenManager;
    const current=screen||manager?.$$uB;
    if(current&&!current.__jmpGame){
      try{
        Object.defineProperty(current,'happyWheels',{configurable:true,get(){return gameOf(current);}});
      }catch{}
      current.__jmpGame=true;
    }
    return current?.__jmpGame?gameOf(current):null;
  }
  const api={alive,visible,attached,setButton,watchMenu,titleVisible,discardVictory,worldReady,repair,gameOf};
  setInterval(()=>{try{repair();}catch{}},200);
  root.HWNativeUI=api;if(typeof module==='object'&&module.exports)module.exports=api;
})(typeof window==='object'?window:globalThis);
