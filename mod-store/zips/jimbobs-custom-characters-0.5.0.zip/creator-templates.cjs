'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const cached=new Map();
function discover(webroot,base){
  if(!Number.isInteger(base)||base<1||base>11)throw Error('Choose a valid template.');
  const assets=fs.readdirSync(webroot,{withFileTypes:true}).filter(e=>e.isDirectory()&&e.name.startsWith('assets-'));
  for(const asset of assets){
    const dir=path.join(webroot,asset.name,'animate',`character${base}`);if(!fs.existsSync(dir))continue;
    const pages=[];
    function walk(folder){for(const e of fs.readdirSync(folder,{withFileTypes:true})){const file=path.join(folder,e.name);if(e.isDirectory())walk(file);else if(e.name.endsWith('.json')&&!e.name.includes('@')){const data=JSON.parse(fs.readFileSync(file,'utf8'));if(data.frames&&data.meta?.size)pages.push({file,data,image:path.join(folder,path.basename(data.meta.image||e.name.replace(/\.json$/,'.png'))),id:path.relative(dir,file).replace(/\\/g,'/')});}}}
    walk(dir);pages.sort((a,b)=>a.id.localeCompare(b.id));if(pages.length)return {dir,pages,asset:asset.name};
  }
  throw Error('This character template is unavailable in the installed game.');
}
function family(name){
  const s=name.replace(/([a-z])([A-Z])/g,'$1_$2').toLowerCase();
  if(/wheel|seat|chair|frame|fork|handle|stem|rod|propeller|tire|spoke|cart|sled|sleigh|moped|engine|tank|spring|rope|chain|pedal|mower|basket/.test(s))return 'vehicle';
  if(/blood|wound|organ|brain|guts|intestin/.test(s))return 'detail';
  if(/upper_?arm/.test(s))return 'upper arm';if(/lower_?arm|forearm|hand/.test(s))return 'lower arm';
  if(/upper_?leg|thigh/.test(s))return 'upper leg';if(/lower_?leg|shin/.test(s))return 'lower leg';
  if(/foot|feet|shoe/.test(s))return 'foot';if(/pelvis|hip/.test(s))return 'pelvis';
  if(/chest|torso|body/.test(s))return 'torso';if(/helmet|hair|hat/.test(s))return 'head accessory';if(/head|face|neck/.test(s))return 'head';
  return 'unmapped';
}
function semantics(webroot,keys,base){
  const result={};const file=path.join(webroot,'js','dependencies.js');if(!fs.existsSync(file))return result;
  const stat=fs.statSync(file),cacheKey=file+':'+stat.mtimeMs;let blocks=cached.get(cacheKey);
  if(!blocks){
    const src=fs.readFileSync(file,'utf8'),rx=/\b([a-zA-Z_$][\w$]*)\.(\w+)=[a-zA-Z_$][\w$]*\.[\w$]+\.extend\(function\(/g;
    const matches=[...src.matchAll(rx)];blocks=matches.map((m,i)=>({name:m[2],start:m.index,text:src.slice(m.index,matches[i+1]?.index??src.length)}));cached.clear();cached.set(cacheKey,blocks);
  }
  const keySet=new Set(keys),relevant=blocks.filter(b=>[...b.text.matchAll(/["']([^"']+\.png)["']/g)].some(m=>keySet.has(m[1])));
  if(!relevant.length)return result;
  const source=fs.readFileSync(file,'utf8'),lo=relevant[0].start;
  const endMatch=new RegExp('const \\w+=\\{stage:\\w+\\.character'+base+'[,}]').exec(source.slice(lo));
  if(!endMatch)return result;
  const end=lo+endMatch.index,scope=blocks.filter(b=>b.start>=lo&&b.start<end).map(b=>({...b,text:b.text.slice(0,end-b.start)}));
  const byName=new Map(scope.map(b=>[b.name,b])),roles=new Map();
  const passenger=/^(kid|girl|girl_source|son|daughter|elf_?\d+|passenger\d*)$/i;
  function children(block){const out=[];for(const m of block.text.matchAll(/(\w+)=(?:\()?new\s+[\w$]+\.(\w+)[^;]*;this\[\1\.name=["']([^"']+)["']\]=\1/g))out.push({name:m[2],label:m[3]});return out;}
  function visit(name,owner,part,seen=new Set()){
    const marker=name+':'+owner+':'+part;if(seen.has(marker))return;seen.add(marker);
    const block=byName.get(name);if(!block)return;
    const ownFamily=family(name),f=ownFamily!=='unmapped'?ownFamily:part;
    const existing=roles.get(name)||[];existing.push({owner,family:f});roles.set(name,existing);
    const labelled=new Map(children(block).map(c=>[c.name,c.label]));
    for(const m of block.text.matchAll(/new\s+[\w$]+\.(\w+)/g)){
      const child=m[1],label=labelled.get(child)||child;if(/shape_?guide/i.test(label))continue;
      const childOwner=passenger.test(label)||passenger.test(child)?'passenger':owner;
      const childFamily=family(label);visit(child,childFamily==='vehicle'?'vehicle':childOwner,childFamily==='unmapped'?f:childFamily,seen);
    }
  }
  const stage=byName.get('character'+base);if(stage)for(const c of children(stage)){if(/shape_?guide/i.test(c.label))continue;visit(c.name,passenger.test(c.label)||passenger.test(c.name)?'passenger':family(c.label)==='vehicle'?'vehicle':'rider',family(c.label));}
  for(const b of scope){const f=family(b.name),candidates=roles.get(b.name)||[],owners=[...new Set(candidates.map(r=>r.owner))];
    const owner=f==='vehicle'?'vehicle':owners.length===1?owners[0]:owners.length>1?'shared':'unknown';
    const families=[...new Set(candidates.map(r=>r.family).filter(x=>x!=='unmapped'))],part=f!=='unmapped'?f:families.length===1?families[0]:'unmapped';
    for(const m of b.text.matchAll(/["']([^"']+\.png)["']/g)){if(!keySet.has(m[1]))continue;
      const incoming={owner,family:part,symbol:b.name,verified:owner!=='unknown'&&owner!=='shared'&&part!=='unmapped',state:/broken|sever|crush|smashed|wound|dead|injur|chunk|cut|rip|snap|burn|split|blood/i.test(b.name)?'alternate':'normal'};
      const old=result[m[1]];if(!old)result[m[1]]=incoming;else if(old.owner!==incoming.owner&&incoming.owner!=='unknown'){old.owner='shared';old.verified=false;}else if(!old.verified&&incoming.verified)result[m[1]]=incoming;
    }
  }
  return result;
}
function atlas(webroot,base){
  const found=discover(webroot,base),counts=new Map();for(const p of found.pages)for(const k of Object.keys(p.data.frames))counts.set(k,(counts.get(k)||0)+1);
  const roles=semantics(webroot,[...counts.keys()],base),frames={},pages=[];let y=0,width=0;
  for(const p of found.pages){const h=p.data.meta.size.h,w=p.data.meta.size.w,rect={x:0,y,w,h};width=Math.max(width,w);
    for(const [original,item] of Object.entries(p.data.frames)){const key=counts.get(original)>1?p.id+'::'+original:original;frames[key]={...item,frame:{...item.frame,y:item.frame.y+y},pageId:p.id,sourceKey:original,semantic:roles[original]||{owner:'unknown',family:'unmapped',verified:false,state:'unknown'}};}
    pages.push({id:p.id,source:path.relative(path.join(webroot,found.asset),p.file).replace(/\\/g,'/'),image:p.image,rect});y+=h;
  }
  const data={frames,meta:{size:{w:width,h:y},image:'sheet.png'},pages:pages.map(({image,...p})=>p),creatorLayout:2};
  const fingerprint=crypto.createHash('sha256').update(JSON.stringify(data)).digest('hex');return {dir:found.dir,data,pages,fingerprint};
}
module.exports={atlas,discover,semantics,family};
