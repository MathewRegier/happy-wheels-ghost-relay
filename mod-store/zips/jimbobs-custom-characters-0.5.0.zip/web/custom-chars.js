(() => {
  'use strict';
  const ROOT='./js/jimbobs-custom-characters/';
  const api=window.HWCustomCharacters={version:'0.5.0',errors:[],selected:null,preview:null,slots:0,painted:0};
  let requireGame,state,pixi,app,roster=[],committed=null;
  const assets=new Map(),skinned=new WeakMap();
  const report=e=>{const text=String(e?.message||e);if(!api.errors.includes(text))api.errors.push(text);console.error('[Custom characters]',text);};
  const safePath=s=>typeof s==='string'&&!s.includes('..')&&!s.includes('\\')&&!/^[a-z]+:|^\//i.test(s);
  const getMenu=()=>state?.rootApp?.screenManager?.currentScreen?.happyWheels?.sessionController?.characterMenu;
  function connectRuntime(){
    requireGame=window.HWMod?.require||window.HWGhost?.require||requireGame;
    if(!requireGame&&!window.HWMod)for(const key of Object.keys(window)){
      const chunks=window[key];
      if(/^Tmu[A-Za-z0-9]+$/.test(key)&&Array.isArray(chunks)&&chunks.push!==Array.prototype.push){chunks.push([['jimbob-custom-characters'],{},r=>{requireGame=r;}]);break;}
    }
    if(!requireGame)return false;
    if(window.HWMod?.state?.rootApp)state=window.HWMod.state;
    else for(const id of [35057,29552])try{const candidate=requireGame(id)?.w;if(candidate?.rootApp){state=candidate;break;}}catch{}
    if(!state?.rootApp?.renderer)return false;
    pixi=window.HWMod?.pixi?.()?.raw||requireGame(99430);app=state.rootApp;return !!pixi?.gPd;
  }
  async function loadAsset(entry){
    const cacheKey=entry.id+':'+(entry.revision||'legacy');if(assets.has(cacheKey))return assets.get(cacheKey);
    const task=(async()=>{
      if(entry.profileFile&&window.HWNativeCharacter){const response=await fetch(ROOT+entry.profileFile);if(!response.ok)throw Error('Could not load native profile');entry.profile=HWNativeCharacter.validate(await response.json());}
      const urls=[...Object.values(pixi.WpD.TextureCache).map(t=>t?.baseTexture?.resource?.url),...performance.getEntriesByType('resource').map(r=>r.name)];
      const assetRoot=urls.find(u=>u&&/\/assets-[^/]+\//.test(u))?.match(/^(.*\/assets-[^/]+\/)/)?.[1];
      if(!assetRoot)throw Error('Game assets are not ready yet.');
      const response=await fetch(entry.atlas?ROOT+entry.atlas:assetRoot+'animate/character'+entry.base+'/character'+entry.base+'.json');
      if(!response.ok)throw Error('Could not load the base character atlas.');
      const atlas=await response.json(),base=pixi.gPd.from(ROOT+entry.sheet).baseTexture;
      if(!base.valid)await new Promise((resolve,reject)=>{base.once('loaded',resolve);base.once('error',reject);});
      const sx=base.width/atlas.meta.size.w,sy=base.height/atlas.meta.size.h;
      if(Math.abs(sx-sy)>.005)throw Error(entry.name+': sheet aspect ratio must match the base atlas.');
      for(const item of Object.values(atlas.frames)){const f=item.frame;item.frame={x:f.x*sx,y:f.y*sy,w:f.w*sx,h:f.h*sy};}
      return {base,atlas,variants:new WeakMap(),textures:new Set(),lastUsed:Date.now(),lookup:new Map(Object.entries(atlas.frames).map(([k,f])=>[f.sourceKey||k,f.frame]))};
    })();
    assets.set(cacheKey,task);try{const value=await task;assets.set(cacheKey,value);trimAssets();return value;}catch(e){assets.delete(cacheKey);throw e;}
  }
  function replacement(texture,entry,asset){
    if(asset.variants.has(texture))return asset.variants.get(texture);
    if(!(texture.baseTexture?.resource?.url||'').includes('/animate/character'+entry.base+'/'))return texture;
    const frame=(texture.textureCacheIds||[]).map(k=>asset.lookup.get(k)).find(Boolean);
    if(!frame)return texture;
    const result=new pixi.gPd(asset.base,new pixi.M_G(frame.x,frame.y,frame.w,frame.h),texture.orig.clone(),texture.trim?.clone(),texture.rotate);
    const url='js/jimbobs-custom-characters/'+entry.sheet;
    result.__hwGhost={url,frame:[frame.x,frame.y,frame.w,frame.h],orig:[texture.orig.x,texture.orig.y,texture.orig.width,texture.orig.height],trim:texture.trim?[texture.trim.x,texture.trim.y,texture.trim.width,texture.trim.height]:null,rotate:texture.rotate||0};
    const nativeURL=(texture.baseTexture?.resource?.url||'').split('/__hw_app__/')[1];if(nativeURL&&/^assets-[a-z0-9]+\/animate\//.test(nativeURL))result.__hwGhost.fallback={url:nativeURL,frame:[texture.frame.x,texture.frame.y,texture.frame.width,texture.frame.height],orig:[texture.orig.x,texture.orig.y,texture.orig.width,texture.orig.height],trim:texture.trim?[texture.trim.x,texture.trim.y,texture.trim.width,texture.trim.height]:null,rotate:texture.rotate||0};
    asset.base.__hwUrl=url;
    asset.variants.set(texture,result);asset.textures.add(result);skinned.set(result,texture);return result;
  }
  function paint(node,entry,asset){
    if(!node)return;
    if(node.texture){const current=node.texture,original=skinned.get(current)||current,next=entry&&asset?replacement(original,entry,asset):original;if(next!==current){node.texture=next;api.painted++;}}
    for(const child of node.children||[])paint(child,entry,asset);
  }
  function renderSkin(){
    const menu=getMenu();
    if(menu?.parent&&menu.selectedIcon?.__customCharacter){committed=menu.selectedIcon.__customCharacter;api.selected=committed.id;}
    const entry=menu?.parent?menu.selectedIcon?.__customCharacter:committed;
    const session=menu?.parent?menu.session:state.currentSession,asset=entry&&assets.get(entry.id+':'+(entry.revision||'legacy'));
    if(window.HWNativeCharacter)HWNativeCharacter.hook(session?.character,()=>{const current=getMenu(),chosen=current?.parent?current.selectedIcon?.__customCharacter:committed;return chosen?.profile&&chosen.base===state.characterIndex?chosen:null;});
    api.preview=menu?.parent?entry?.id||null:null;
    // Shared Physics paints each rider from that rider's skin. One scene-wide pass would dress every copy of the base character the same.
    if(window.HWGhost?.sharedActors?.size){try{window.HWGhost.paintSharedSkins?.();}catch(e){report(e);}return;}
    if(session&&(!entry||asset?.base)){if(asset)asset.lastUsed=Date.now();const character=session.character||session._character,owned=new Set(),seen=new Set();function collect(o,depth=0){if(!o||typeof o!=='object'||seen.has(o)||depth>5)return;seen.add(o);if(o.pixiSprite){owned.add(o.pixiSprite);return;}if(Array.isArray(o)){for(const n of o)collect(n,depth+1);return;}for(const [key,value] of Object.entries(o))if(/MCs?$/.test(key)||['kid','son','daughter','dad','mom','girl','elf1','elf2','elves','composites','rider','passenger','characters'].includes(key))collect(value,depth+1);}collect(character);for(const node of owned)paint(node,entry,asset);}
  }
  async function addSlot(menu,empty,entry){
    const generation=menu.__skinGeneration,token=menu.__skinPageToken||0,asset=await loadAsset(entry);if(!menu.parent||menu.__skinGeneration!==generation||(menu.__skinPageToken||0)!==token)return;
    const icon=new menu.icons[0].constructor(entry.base);
    icon.__customCharacter=entry;icon.__replacedEmpty=empty||null;icon.x=empty?.x??-1000;icon.y=empty?.y??-1000;
    icon.loaderBW.visible=false;icon.loaderColor.visible=false;
    let texture;
    if(entry.iconFrame){const f=asset.atlas.frames[entry.iconFrame]?.frame;if(!f)throw Error('Unknown portrait atlas frame: '+entry.iconFrame);texture=new pixi.gPd(asset.base,new pixi.M_G(f.x,f.y,f.w,f.h));}
    else texture=pixi.gPd.from(ROOT+entry.icon);
    const portrait=new pixi.kxk(texture);portrait.name=entry.name;portrait.eventMode='none';
    function sizePortrait(){const scale=40/Math.max(texture.width,texture.height);portrait.scale.set(scale);portrait.x=25-texture.width*scale/2;portrait.y=25-texture.height*scale/2;}
    sizePortrait();if(!texture.baseTexture.valid)texture.baseTexture.once('loaded',sizePortrait);
    icon.pixiSprite.addChild(portrait);
    icon.addEventListener('mouseOver',event=>{menu.iconMouseOverHandler(event);renderSkin();});
    icon.addEventListener('mouseDown',event=>{committed=entry;api.selected=entry.id;menu.iconMouseDownHandler(event);});
    if(empty){menu.icons[menu.icons.indexOf(empty)]=icon;menu.iconHolder.removeChild(empty);}else menu.icons.push(icon);menu.iconHolder.addChild(icon);if(!empty)icon.visible=false;menu.__skinIcons?.set(entry.id,icon);
    const descriptor=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(icon),'selected');
    if(descriptor?.set)Object.defineProperty(icon,'selected',{get(){return descriptor.get?.call(this);},set(value){descriptor.set.call(this,value);this.loaderBW.visible=false;this.loaderColor.visible=false;portrait.alpha=value?1:.72;}});
    api.slots++;return icon;
  }
  let pager;
  function pageCount(total,slots){const per=Math.max(1,slots|0);return Math.max(1,Math.ceil(Math.max(0,total)/per));}
  function arrowGraphic(direction){
    const left=direction==='left';
    const face=left?'146,30 84,30 84,12 10,56 84,100 84,82 146,82':'14,30 76,30 76,12 150,56 76,100 76,82 14,82';
    const shadow=face.split(' ').map(pair=>{const [x,y]=pair.split(',').map(Number);return (x+8)+','+(y+9);}).join(' ');
    const shade=left?'#2a6cbc':'#d4545c';
    return `<svg viewBox="-4 -4 176 128" aria-hidden="true"><polygon class="shadow" points="${shadow}" fill="${shade}" stroke="${shade}" stroke-width="8" stroke-linejoin="round"></polygon><polygon class="face" points="${face}" fill="${left?'#4aa6ff':'#ff8f8a'}" stroke="#fff" stroke-width="8" stroke-linejoin="round"></polygon></svg>`;
  }
  function ensurePager(){
    if(pager)return pager;
    document.getElementById('hw-skin-drawer')?.remove();
    if(!document.getElementById('hw-character-pages-style')){const style=document.createElement('style');style.id='hw-character-pages-style';style.textContent=`
      #hw-character-pages{position:fixed;z-index:2600;display:flex;align-items:center;gap:clamp(14px,2vw,28px);pointer-events:auto;user-select:none;filter:drop-shadow(0 2px 0 rgba(20,28,40,.18))}
      #hw-character-pages[hidden]{display:none!important}
      #hw-character-pages button{appearance:none;border:0;background:none;padding:0;margin:0;cursor:pointer;width:clamp(78px,8vw,118px);line-height:0}
      #hw-character-pages button:focus-visible{outline:3px solid #ffe27a;outline-offset:4px;border-radius:8px}
      #hw-character-pages svg{width:100%;height:auto;overflow:visible;display:block}
      #hw-character-pages .face{transform-box:fill-box;transform-origin:center;transition:transform .08s ease,filter .08s ease}
      #hw-character-pages button:hover .face{transform:translateY(-4px);filter:brightness(1.12)}
      #hw-character-pages button:active .face{transform:translate(7px,8px);filter:brightness(.94)}
      #hw-character-pages .count{margin:0;display:flex;align-items:center;gap:.28em;font:900 clamp(40px,4.8vw,68px)/1 "Arial Rounded MT Bold","Segoe UI Black","Arial Black",sans-serif;letter-spacing:.02em}
      #hw-character-pages .count span{paint-order:stroke fill;-webkit-text-stroke:7px #fff;text-shadow:4px 5px 0 rgba(36,48,64,.28)}
      #hw-character-pages .count .now{color:#ef3c50}
      #hw-character-pages .count .rest{color:#fff;-webkit-text-stroke-color:#8ea2b6}
    `;document.head.append(style);}
    pager=document.createElement('nav');pager.id='hw-character-pages';pager.hidden=true;pager.setAttribute('aria-label','Character pages');
    const previous=document.createElement('button'),next=document.createElement('button'),count=document.createElement('p');
    previous.type=next.type='button';previous.setAttribute('aria-label','Previous characters');next.setAttribute('aria-label','Next characters');
    previous.innerHTML=arrowGraphic('left');next.innerHTML=arrowGraphic('right');
    count.className='count';count.innerHTML='<span class="now" data-page>1</span><span class="rest">/</span><span class="rest" data-pages>1</span>';
    previous.onclick=()=>turnPage(-1);next.onclick=()=>turnPage(1);
    pager.addEventListener('pointerdown',event=>event.stopPropagation());
    pager.append(previous,count,next);document.body.append(pager);return pager;
  }
  function stageSize(){
    const renderer=app?.renderer,resolution=renderer?.resolution||1,screen=app?.screen||renderer?.screen;
    return {width:screen?.width||(renderer?.width||1)/resolution,height:screen?.height||(renderer?.height||1)/resolution};
  }
  function stageToCss(x,y){
    const view=app?.renderer?.view;if(!view?.getBoundingClientRect)return null;
    const rect=view.getBoundingClientRect(),stage=stageSize();
    return {x:x*rect.width/Math.max(1,stage.width)+rect.left,y:y*rect.height/Math.max(1,stage.height)+rect.top,rect};
  }
  function holderPoint(holder,x,y){
    const node=holder?.pixiSprite||holder;node?.updateTransform?.();
    if(node?.toGlobal){const point=node.toGlobal({x,y});if(Number.isFinite(point?.x)&&Number.isFinite(point?.y))return point;}
    const wt=node?.worldTransform;if(!wt)return {x,y};
    return {x:wt.a*x+wt.c*y+wt.tx,y:wt.b*x+wt.d*y+wt.ty};
  }
  function movePager(menu){
    if(!pager||pager.hidden)return;
    const icons=(menu.icons||[]).filter(icon=>icon&&icon.visible!==false&&icon.x>-400&&icon.y>-400);
    const view=app?.renderer?.view;
    if(!icons.length||!view?.getBoundingClientRect){pager.style.left='72%';pager.style.top='auto';pager.style.bottom='7%';pager.style.transform='translateX(-50%)';return;}
    const xs=[...new Set(icons.map(icon=>icon.x))].sort((a,b)=>a-b),ys=[...new Set(icons.map(icon=>icon.y))].sort((a,b)=>a-b);
    const gapX=xs.length>1?xs[1]-xs[0]:64,gapY=ys.length>1?ys[1]-ys[0]:64;
    const localX=(Math.min(...xs)+Math.max(...xs)+gapX)/2,localY=Math.max(...ys)+gapY;
    let global=holderPoint(menu.iconHolder,localX,localY);
    let css=stageToCss(global.x,global.y);
    if(css&&css.x<css.rect.left+css.rect.width*0.5){global={x:localX,y:localY};css=stageToCss(global.x,global.y);}
    if(!css||css.x<css.rect.left+css.rect.width*0.5){pager.style.left='72%';pager.style.top='auto';pager.style.bottom='7%';pager.style.transform='translateX(-50%)';return;}
    pager.style.left=css.x+'px';pager.style.top=(css.y+10)+'px';pager.style.bottom='auto';pager.style.transform='translateX(-50%)';
  }
  function syncPager(menu){
    const bar=ensurePager();
    if(!menu?.parent){bar.hidden=true;return;}
    bar.hidden=false;
    const per=menu.__skinSlots?.length||0,pages=per?pageCount(roster.length,per):1,page=Math.min(pages,menu.__skinPage||1);
    bar.querySelector('[data-page]').textContent=String(page);bar.querySelector('[data-pages]').textContent=String(pages);
    movePager(menu);
  }
  function restoreSkins(menu){
    for(const icon of [...menu.icons]){
      if(!icon.__customCharacter)continue;
      const empty=icon.__replacedEmpty,index=menu.icons.indexOf(icon);
      try{menu.iconHolder.removeChild(icon);}catch{}
      icon.visible=false;
      if(empty&&index>=0){menu.icons[index]=empty;if(empty.parent!==menu.iconHolder)menu.iconHolder.addChild(empty);}
      else if(index>=0)menu.icons.splice(index,1);
    }
  }
  function placeSkin(menu,empty,icon){
    const index=menu.icons.indexOf(empty);
    if(index>=0){try{menu.iconHolder.removeChild(empty);}catch{}menu.icons[index]=icon;}
    else if(!menu.icons.includes(icon))menu.icons.push(icon);
    icon.__replacedEmpty=empty;icon.x=empty?.x??icon.x;icon.y=empty?.y??icon.y;icon.visible=true;
    if(icon.parent!==menu.iconHolder)menu.iconHolder.addChild(icon);
  }
  async function showSkinPage(menu,page){
    const slots=menu.__skinSlots||[],pages=slots.length?pageCount(roster.length,slots.length):1;
    page=Math.min(pages,Math.max(1,page||1));menu.__skinPage=page;const token=++menu.__skinPageToken;
    restoreSkins(menu);syncPager(menu);
    const slice=slots.length?roster.slice((page-1)*slots.length,page*slots.length):[];
    for(let i=0;i<slice.length;i++){
      if((menu.__skinPageToken||0)!==token||!menu.parent)return;
      const entry=slice[i],empty=slots[i],existing=menu.__skinIcons?.get(entry.id);
      if(existing)placeSkin(menu,empty,existing);else await addSlot(menu,empty,entry);
    }
    if((menu.__skinPageToken||0)===token)syncPager(menu);
  }
  function turnPage(delta){
    const menu=getMenu();if(!menu?.parent)return;
    const per=menu.__skinSlots?.length||0;if(!per)return;
    const pages=pageCount(roster.length,per),next=Math.min(pages,Math.max(1,(menu.__skinPage||1)+delta));
    if(next!==menu.__skinPage)showSkinPage(menu,next).catch(report);
  }
  function installMenu(menu){
    syncPager(menu);if(!menu?.parent||menu.__customInstalled)return;
    menu.__customInstalled=true;menu.__skinIcons=new Map();menu.__skinGeneration=(menu.__skinGeneration||0)+1;if(!menu.__skinPageToken)menu.__skinPageToken=0;api.slots=0;
    const empty=menu.icons.filter(icon=>!icon.loaderColor&&!icon.loaderBW&&!icon.__customCharacter&&icon.visible!==false);
    let slots=empty;
    if(empty.length>20){const min=Math.min(...empty.map(icon=>icon.x));slots=empty.filter(icon=>icon.x<min+520);if(!slots.length)slots=empty.slice(0,20);}
    menu.__skinSlots=slots;
    for(const icon of menu.icons.filter(icon=>icon.loaderColor&&!icon.__customCharacter)){
      if(icon.__skinDownWrapped)continue;icon.__skinDownWrapped=true;const nativeDown=menu.iconMouseDownHandler;icon.removeEventListener('mouseDown',nativeDown);icon.addEventListener('mouseDown',event=>{committed=null;api.selected=null;nativeDown(event);});
    }
    showSkinPage(menu,menu.__skinPage||1).catch(report);
  }
  function reconcile(menu){
    if(!menu?.parent)return;
    const chosen=menu.selectedIcon?.__customCharacter,updated=chosen&&roster.find(e=>e.id===chosen.id);
    if(chosen){const native=menu.icons.find(i=>!i.__customCharacter&&i.loaderColor&&i._index===chosen.base)||menu.icons.find(i=>!i.__customCharacter&&i.loaderColor);if(native)menu.iconMouseOverHandler({target:native,currentTarget:native});}
    for(const icon of [...menu.icons])if(icon.__customCharacter){const empty=icon.__replacedEmpty,index=menu.icons.indexOf(icon);try{menu.iconHolder.removeChild(icon);}catch{}if(empty){menu.icons[index]=empty;menu.iconHolder.addChild(empty);}else menu.icons.splice(index,1);}
    menu.__customInstalled=false;menu.__skinIcons=new Map();menu.__skinLoads=new Map();installMenu(menu);if(updated){const generation=menu.__skinGeneration;loadAsset(updated).then(()=>{if(menu.parent&&menu.__skinGeneration===generation){const icon=menu.__skinIcons.get(updated.id);if(icon)menu.iconMouseOverHandler({target:icon,currentTarget:icon});}}).catch(report);}
  }
  function trimAssets(){
    const loaded=[...assets.entries()].filter(([,a])=>a?.base);let bytes=loaded.reduce((n,[,a])=>n+a.base.width*a.base.height*4,0);
    if(loaded.length<=4&&bytes<=96*1024*1024)return;
    const used=new Set();function visit(n){if(n?.texture?.baseTexture)used.add(n.texture.baseTexture);for(const c of n?.children||[])visit(c);}visit(app?.stage);visit(state?.currentSession?.pixiSprite);
    for(const [k,a] of loaded.sort((a,b)=>a[1].lastUsed-b[1].lastUsed)){if(assets.size<=4&&bytes<=96*1024*1024)break;if(used.has(a.base)||k.startsWith(committed?.id+':'))continue;assets.delete(k);bytes-=a.base.width*a.base.height*4;for(const t of a.textures)t.destroy(false);a.base.destroy();}
  }
  function folderPath(file){
    const value=String(file||'').replace(/^\.\//,'');
    return safePath(value)?value:'';
  }
  function fromFolder(folder,data){
    if(!data||!/^[a-z0-9][a-z0-9-]*$/i.test(folder))return null;
    const sheet=folderPath(data.sheet||'sheet.png');
    const icon=folderPath(data.icon||'icon.png');
    const base=Number(data.base);
    if(data.enabled===false||!sheet||!icon||!Number.isInteger(base)||base<1||base>11)return null;
    const entry={id:folder,name:String(data.name||folder),base,revision:String(data.revision||''),sheet:'characters/'+folder+'/'+sheet,icon:'characters/'+folder+'/'+icon};if(data.atlas&&safePath(data.atlas))entry.atlas='characters/'+folder+'/'+data.atlas;
    if(data.profileFile&&safePath(data.profileFile))entry.profileFile='characters/'+folder+'/'+data.profileFile;
    return entry;
  }
  async function loadRoster(){
    const index=await fetch(ROOT+'characters/index.json').then(r=>{if(!r.ok)throw Error('Could not load characters/index.json');return r.json();});
    const folders=index.characters||index;
    const entries=[];
    for(const folder of folders){
      try{
        const data=await fetch(ROOT+'characters/'+folder+'/character.json').then(r=>{if(!r.ok)throw Error('Missing character.json in '+folder);return r.json();});
        const entry=fromFolder(folder,data);
        if(entry)entries.push(entry);
        else if(data.enabled!==false)report('Skipped '+folder+': character.json needs name, base 1-11, sheet, and icon.');
      }catch(error){report(error);}
    }
    return entries;
  }
  const missing=new Set();function missingSkin(id){if(missing.has(id))return;missing.add(id);api.missingSkins=[...missing];const notice=document.createElement('div');notice.textContent='A player’s custom skin is not installed here. Their original character is shown. Install their skin from Character Creator → Community skins, or import their .jskin file.';notice.style.cssText='position:fixed;bottom:35px;left:20px;z-index:5000;max-width:380px;padding:12px;background:#192428;color:#eee7d7;font:14px Trebuchet MS;border:1px solid #ff9083;border-radius:6px';document.body.append(notice);setTimeout(()=>notice.remove(),7000);}
  api.resolveTexture=desc=>{const m=desc?.url?.match(/^js\/jimbobs-custom-characters\/characters\/([a-z0-9-]+)\/(sheet[^/]*\.png)$/);if(!m)return desc;const entry=roster.find(r=>r.id===m[1]);if(entry&&entry.sheet==='characters/'+m[1]+'/'+m[2])return desc;missingSkin(m[1]);return desc.fallback||desc;};
  api.list=()=>roster.map(entry=>({id:entry.id,name:entry.name,base:entry.base,icon:ROOT+entry.icon}));
  api.reloadRoster=async()=>{roster=await loadRoster();if(committed)committed=roster.find(r=>r.id===committed.id)||null;api.selected=committed?.id||null;reconcile(getMenu());return api.list();};
  api.creatorRuntime=()=>connectRuntime()?{require:requireGame,state,pixi,app}:null;
  api.addCreated=async data=>{
    if(data.enabled===false){if(committed?.id===data.id){committed=null;api.selected=null;}roster=roster.filter(e=>e.id!==data.id);reconcile(getMenu());return {id:data.id,available:false,disabled:true};}
    const entry=fromFolder(data.id,data);if(!entry)throw Error('Invalid saved character.');
    roster=roster.filter(e=>e.id!==entry.id);roster.push(entry);await loadAsset(entry);if(committed?.id===entry.id)committed=entry;reconcile(getMenu());return {id:entry.id,available:true};
  };
  api.choose=id=>{
    const entry=id?roster.find(item=>item.id===id)||null:null;
    committed=entry;api.selected=entry?.id||null;
    if(entry)loadAsset(entry).catch(report);
    return api.selected;
  };
  api.apply=(node,id)=>{
    if(!node)return;
    const entry=id?roster.find(item=>item.id===id)||null:null;
    if(!entry){paint(node,null,null);if(id)missingSkin(id);return;}
    const asset=assets.get(entry.id+':'+(entry.revision||'legacy'));
    if(!asset?.base){loadAsset(entry).catch(report);return;}
    paint(node,entry,asset);
  };
  loadRoster().then(list=>{
    roster=list;
    const boot=setInterval(()=>{try{if(!connectRuntime())return;clearInterval(boot);const render=app.renderer.render;app.renderer.render=function(...args){try{installMenu(getMenu());renderSkin();}catch(e){report(e);}return render.apply(this,args);};api.diagnostics=()=>{const menu=getMenu(),per=menu?.__skinSlots?.length||0;return {selected:api.selected,preview:api.preview,slots:api.slots,painted:api.painted,errors:api.errors,base:state.characterIndex,page:menu?.__skinPage||1,pages:per?pageCount(roster.length,per):1};};}catch(e){report(e);}},100);
  }).catch(report);
})();
