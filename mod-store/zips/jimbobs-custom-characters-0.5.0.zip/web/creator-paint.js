/* Independent pixel editor: edits never change the native atlas layout. */
(() => {
  'use strict';
  function flood(data,width,height,x,y,color,tolerance=0,lockAlpha=true){
    x=Math.floor(x);y=Math.floor(y);if(x<0||y<0||x>=width||y>=height)return;
    const start=(y*width+x)*4,target=Array.from(data.slice(start,start+4));
    if(lockAlpha&&target[3]===0)return;
    const seen=new Uint8Array(width*height),queue=new Int32Array(width*height);let head=0,tail=0;
    queue[tail++]=y*width+x;seen[y*width+x]=1;
    const srcA=color[3];
    while(head<tail){const n=queue[head++],i=n*4;
      if(Math.max(...target.map((v,k)=>Math.abs(v-data[i+k])))>tolerance)continue;
      if(lockAlpha){
        const keep=data[i+3];
        for(let k=0;k<3;k++)data[i+k]=Math.round(data[i+k]*(1-srcA)+color[k]*srcA);
        data[i+3]=keep;
      }else{
        const dstA=data[i+3]/255,outA=srcA+dstA*(1-srcA);
        for(let k=0;k<3;k++)data[i+k]=outA?Math.round((color[k]*srcA+data[i+k]*dstA*(1-srcA))/outA):0;
        data[i+3]=Math.round(outA*255);
      }
      const px=n%width;for(const next of [px>0?n-1:-1,px<width-1?n+1:-1,n-width,n+width])if(next>=0&&next<width*height&&!seen[next]){seen[next]=1;queue[tail++]=next;}
    }
  }
  function region(sheet,item){
    const f=item.frame,c=document.createElement('canvas');c.width=item.rotated?f.h:f.w;c.height=item.rotated?f.w:f.h;
    const ctx=c.getContext('2d');if(item.rotated){ctx.translate(0,c.height);ctx.rotate(-Math.PI/2);}
    ctx.drawImage(sheet,f.x,f.y,f.w,f.h,0,0,f.w,f.h);return c;
  }
  function commit(sheet,item,part){
    const f=item.frame,ctx=sheet.getContext('2d');ctx.save();ctx.clearRect(f.x,f.y,f.w,f.h);ctx.translate(f.x,f.y);
    if(item.rotated){ctx.translate(f.w,0);ctx.rotate(Math.PI/2);}ctx.drawImage(part,0,0);ctx.restore();
  }
  function compactImage(image){
    if(!image.width||!image.height||image.data.length<65536)return image;
    const pixels=new Uint32Array(image.data.buffer,image.data.byteOffset,image.data.length/4);let runs=0,last=-1;
    for(const pixel of pixels){if(pixel!==last){runs++;last=pixel;}}
    if(runs*8>=image.data.byteLength)return image;
    const packed=new Uint32Array(runs*2);let index=0,count=0;last=-1;
    for(const pixel of pixels){if(pixel===last){count++;continue;}if(count){packed[index++]=count;packed[index++]=last;}last=pixel;count=1;}
    if(count){packed[index++]=count;packed[index++]=last;}return {width:image.width,height:image.height,packed};
  }
  function restoreImage(image){if(!image.packed)return image;const pixels=new Uint32Array(image.width*image.height);let at=0;for(let i=0;i<image.packed.length;i+=2){pixels.fill(image.packed[i+1],at,at+image.packed[i]);at+=image.packed[i];}const data=new Uint8ClampedArray(pixels.buffer);return typeof ImageData!=='undefined'?new ImageData(data,image.width,image.height):{data,width:image.width,height:image.height};}
  class History{
    constructor(limit=48*1024*1024){this.limit=limit;this.undoStack=[];this.redoStack=[];this.bytes=0;this.currentState=0;this.nextState=1;}
    entry(keyOrTx,before,after){
      if(typeof keyOrTx==='string')return {key:keyOrTx,before,after,changes:[{key:keyOrTx,before,after}]};
      const changes=keyOrTx.changes||[];
      const first=changes[0];
      return {...keyOrTx,key:keyOrTx.key||first?.key,before:keyOrTx.before||first?.before,after:keyOrTx.after||first?.after,changes};
    }
    size(entry){return entry.changes.reduce((n,change)=>n+(change.before.packed?.byteLength||change.before.data.length)+(change.after.packed?.byteLength||change.after.data.length)+(change.beforeMask?.byteLength||0)+(change.afterMask?.byteLength||0),0);}
    drop(list){while(list.length){const entry=list.pop();this.bytes-=this.size(entry);}}
    push(keyOrTx,before,after){
      const entry=this.entry(keyOrTx,before,after);
      if(!entry.changes.length||entry.changes.every(change=>change.before.data.every((v,i)=>v===change.after.data[i])))return false;
      for(const change of entry.changes){change.before=compactImage(change.before);change.after=compactImage(change.after);}entry.before=entry.changes[0].before;entry.after=entry.changes[0].after;
      this.drop(this.redoStack);
      entry.beforeState=this.currentState;entry.afterState=this.nextState++;this.currentState=entry.afterState;this.undoStack.push(entry);this.bytes+=this.size(entry);
      while(this.bytes>this.limit&&this.undoStack.length>1){const old=this.undoStack.shift();this.bytes-=this.size(old);}
      return true;
    }
    undo(){const entry=this.undoStack.pop();if(entry){this.redoStack.push(entry);this.currentState=entry.beforeState;}return entry;}
    redo(){const entry=this.redoStack.pop();if(entry){this.undoStack.push(entry);this.currentState=entry.afterState;}return entry;}
  }
  function partPoint(instance,lx,ly){
    const det=instance.a*instance.d-instance.b*instance.c;
    if(!det||!instance.partW||!instance.partH)return null;
    const x=lx-instance.tx,y=ly-instance.ty;
    const sx=(instance.d*x-instance.c*y)/det,sy=(-instance.b*x+instance.a*y)/det;
    if(sx<instance.dx||sy<instance.dy||sx>=instance.dx+instance.dw||sy>=instance.dy+instance.dh)return null;
    const u=(sx-instance.dx)/instance.dw,v=(sy-instance.dy)/instance.dh;
    const px=Math.floor(u*instance.partW),py=Math.floor(v*instance.partH);
    if(px<0||py<0||px>=instance.partW||py>=instance.partH)return null;
    return {key:instance.key,x:px,y:py,u,v};
  }
  function partPixelToCharacter(instance,px,py){
    const u=(px+0.5)/instance.partW,v=(py+0.5)/instance.partH;
    const sx=instance.dx+u*instance.dw,sy=instance.dy+v*instance.dh;
    return {x:instance.a*sx+instance.c*sy+instance.tx,y:instance.b*sx+instance.d*sy+instance.ty};
  }
  function brushCover(dist,radius){
    const edge=0.75;
    if(dist<=radius-edge)return 1;
    if(dist>=radius)return 0;
    return (radius-dist)/edge;
  }
  function segmentDistance(px,py,x0,y0,x1,y1){
    const dx=x1-x0,dy=y1-y0,len=dx*dx+dy*dy;
    let t=len?((px-x0)*dx+(py-y0)*dy)/len:0;
    t=Math.max(0,Math.min(1,t));
    return Math.hypot(px-(x0+t*dx),py-(y0+t*dy));
  }
  function frontPart(instances,lx,ly,opaque){
    for(let i=instances.length-1;i>=0;i--){
      const hit=partPoint(instances[i],lx,ly);
      if(!hit)continue;
      if(opaque&&!opaque(hit))continue;
      if(!hit.key)return {blocked:true};
      return hit;
    }
    return null;
  }
  function stampMax(mask,width,height,x0,y0,x1,y1,radius){
    const r=Math.max(0.5,radius),step=Math.max(1,r/3);
    const dist=Math.hypot(x1-x0,y1-y0),count=Math.max(1,Math.ceil(dist/step));
    for(let i=0;i<=count;i++){
      const cx=x0+(x1-x0)*i/count,cy=y0+(y1-y0)*i/count;
      const xStart=Math.max(0,Math.floor(cx-r)),xEnd=Math.min(width-1,Math.ceil(cx+r));
      const yStart=Math.max(0,Math.floor(cy-r)),yEnd=Math.min(height-1,Math.ceil(cy+r));
      for(let y=yStart;y<=yEnd;y++)for(let x=xStart;x<=xEnd;x++){
        const fall=1-Math.hypot(x+0.5-cx,y+0.5-cy)/r;
        if(fall<=0)continue;
        const index=y*width+x;
        if(fall>mask[index])mask[index]=fall;
      }
    }
  }
  function composite(original,mask,color,opacity,erase){
    const out=new Uint8ClampedArray(original);
    for(let i=0,p=0;p<mask.length;p++,i+=4){
      const cover=mask[p]*opacity;
      if(cover<=0)continue;
      if(erase){out[i+3]=Math.round(original[i+3]*(1-cover));continue;}
      for(let k=0;k<3;k++)out[i+k]=Math.round(original[i+k]*(1-cover)+color[k]*cover);
    }
    return out;
  }
  function strokeBounds(inst,from,to,radius){
    const det=inst.a*inst.d-inst.b*inst.c;if(!det||!inst.dw||!inst.dh)return null;
    const points=[];for(const p of [from,to])for(const ox of [-radius,radius])for(const oy of [-radius,radius]){const x=p.x+ox-inst.tx,y=p.y+oy-inst.ty;points.push({x:((inst.d*x-inst.c*y)/det-inst.dx)*inst.partW/inst.dw,y:((-inst.b*x+inst.a*y)/det-inst.dy)*inst.partH/inst.dh});}
    const x0=Math.max(0,Math.floor(Math.min(...points.map(p=>p.x)))-1),y0=Math.max(0,Math.floor(Math.min(...points.map(p=>p.y)))-1),x1=Math.min(inst.partW-1,Math.ceil(Math.max(...points.map(p=>p.x)))+1),y1=Math.min(inst.partH-1,Math.ceil(Math.max(...points.map(p=>p.y)))+1);return x1<x0||y1<y0?null:{x0,y0,x1,y1};
  }
  function recolour(source,current,width,height,from,to,tolerance=35,paintMask,preserveDamage=false){
    from=Array.from(from).slice(0,3); // Canvas samples include alpha; hue uses RGB only.
    const out=new Uint8ClampedArray(current),sourceLum=Math.max(1,.2126*from[0]+.7152*from[1]+.0722*from[2]);
    const chroma=Math.max(...from)-Math.min(...from);function hsv(rgb){const max=Math.max(...rgb),min=Math.min(...rgb),diff=max-min;let hue=0;if(diff){if(max===rgb[0])hue=60*((rgb[1]-rgb[2])/diff%6);else if(max===rgb[1])hue=60*((rgb[2]-rgb[0])/diff+2);else hue=60*((rgb[0]-rgb[1])/diff+4);}return {h:(hue+360)%360,s:max?diff/max:0};}const sample=hsv(from);
    for(let p=0,i=0;p<width*height;p++,i+=4){if(!source[i+3]||paintMask?.[p])continue;const rgb=[source[i],source[i+1],source[i+2]],lum=.2126*rgb[0]+.7152*rgb[1]+.0722*rgb[2];
      if(preserveDamage&&rgb[0]>90&&rgb[0]>rgb[1]*1.5&&rgb[0]>rgb[2]*1.5)continue;
      if(lum<20)continue; // Keep dark outlines.
      const colour=hsv(rgb),hueDistance=Math.min(Math.abs(colour.h-sample.h),360-Math.abs(colour.h-sample.h));
      if(chroma<25?Math.max(...rgb)-Math.min(...rgb)>35||lum/sourceLum<.2:hueDistance>Math.min(38,12+tolerance*.85)||colour.s<Math.max(.1,sample.s-.4)||Math.abs(colour.s-sample.s)>.5||lum/sourceLum<.2||lum/sourceLum>2.2)continue;
      const shade=Math.max(.22,Math.min(1.6,lum/sourceLum));for(let k=0;k<3;k++)out[i+k]=Math.round(source[i+k]*(1-(to[3]??1))+Math.min(255,to[k]*shade)*(to[3]??1));out[i+3]=current[i+3];
    }
    return out;
  }
  function affine(from,to){
    const [p,q,r]=from,[u,v,w]=to,det=(q.x-p.x)*(r.y-p.y)-(r.x-p.x)*(q.y-p.y);if(!Number.isFinite(det)||Math.abs(det)<.01)throw Error('Place three different, non-collinear landmarks.');
    const a=((v.x-u.x)*(r.y-p.y)-(w.x-u.x)*(q.y-p.y))/det,c=((w.x-u.x)*(q.x-p.x)-(v.x-u.x)*(r.x-p.x))/det;
    const b=((v.y-u.y)*(r.y-p.y)-(w.y-u.y)*(q.y-p.y))/det,d=((w.y-u.y)*(q.x-p.x)-(v.y-u.y)*(r.x-p.x))/det;
    return {a,b,c,d,tx:u.x-a*p.x-c*p.y,ty:u.y-b*p.x-d*p.y};
  }
  function transfer(before,after,target,from,to,preserveDamage=true){
    const m=affine(to,from),out=new Uint8ClampedArray(target.data);
    for(let y=0;y<target.height;y++)for(let x=0;x<target.width;x++){const i=(y*target.width+x)*4;if(!out[i+3])continue;
      if(preserveDamage&&out[i]>90&&out[i]>out[i+1]*1.5&&out[i]>out[i+2]*1.5)continue;
      const sx=Math.floor(m.a*(x+.5)+m.c*(y+.5)+m.tx),sy=Math.floor(m.b*(x+.5)+m.d*(y+.5)+m.ty);if(sx<0||sy<0||sx>=after.width||sy>=after.height)continue;const j=(sy*after.width+sx)*4;
      if(!after.data[j+3]||[0,1,2,3].every(k=>before.data[j+k]===after.data[j+k]))continue;
      for(let k=0;k<3;k++)out[i+k]=after.data[j+k];
    }return out;
  }
  const api={compactImage,restoreImage,affine,transfer,strokeBounds,recolour,flood,region,commit,History,partPoint,partPixelToCharacter,frontPart,brushCover,segmentDistance,stampMax,composite};
  if(typeof module!=='undefined')module.exports=api;else window.HWCreatorPaint=api;
})();
