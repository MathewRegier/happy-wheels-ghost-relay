(() => {
  'use strict';
  const names=['Wheelchair Guy','Segway Guy','Irresponsible Dad','Effective Shopper','Moped Couple','Lawnmower Man','Explorer Guy','Santa','Pogo Stick Man','Irresponsible Mom','Helicopter Man'];
  const P=window.HWCreatorPaint;
  let panel,model,part,key,history,dirty=false,busy=false,tool='brush',zoom=1,stroke=null,preview=null,loadToken=0,returnFocus;
  const $=id=>panel.querySelector('[data-id="'+id+'"]');
  const canvas=(w,h)=>Object.assign(document.createElement('canvas'),{width:w,height:h});
  const image=url=>new Promise((resolve,reject)=>{const i=new Image();i.onload=()=>resolve(i);i.onerror=()=>reject(Error('The template image could not be loaded.'));i.src=url;});
  const button=(label,fn,cls='')=>{const b=document.createElement('button');b.type='button';b.textContent=label;b.className=cls;b.onclick=fn;return b;};
  function status(text){$('status').textContent=text;}
  function error(e){status(e?.message||String(e));console.error('[Character creator]',e);}
  function css(){
    if(document.getElementById('hw-creator-style'))return;
    const style=document.createElement('style');style.id='hw-creator-style';style.textContent=`
    #hw-character-creator{position:fixed;inset:0;z-index:30000;background:radial-gradient(ellipse at 95% 0%,#45606c 0%,#283c47 35%,#1b2a32 75%);color:#f5eedb;font:16px/1.45 Georgia,serif;display:flex;flex-direction:column;isolation:isolate;--ink:#0d171c;--paper:#f5eedb;--coral:#ff8582;--gold:#f2cb64;--sky:#acd7e8;--line:#536b75;--accent:#ff8582;--muted:#b9d0d9}
    #hw-character-creator *{box-sizing:border-box}#hw-character-creator [hidden]{display:none!important}
    #hw-character-creator button,#hw-character-creator input,#hw-character-creator select{font:inherit;color:inherit}
    #hw-character-creator button{border:1px solid var(--line);background:#223035;border-radius:5px;padding:9px 12px;cursor:pointer}
    #hw-character-creator button:hover{background:#34474c;border-color:#aabdc1}#hw-character-creator button:focus-visible,#hw-character-creator input:focus-visible{outline:3px solid #ffd277;outline-offset:2px}
    #hw-character-creator button:disabled{opacity:.4;cursor:default}#hw-character-creator button.active{border-color:var(--accent);background:#533a37;color:#ffe3d9}
    #hw-character-creator .primary{background:var(--accent);border-color:var(--accent);color:#231b19;font-weight:bold}#hw-character-creator .primary:hover{background:#ffb1a6}
    #hw-character-creator header{display:flex;align-items:flex-end;gap:22px;padding:clamp(16px,3vw,36px) clamp(16px,3vw,40px) 0;background:transparent;border:0}
    #hw-character-creator h1{font:900 clamp(36px,5vw,64px)/1.05 Georgia,serif;color:#fd8081;text-shadow:2px 3px 0 var(--ink);margin:0}#hw-character-creator h2{font:700 clamp(26px,3vw,40px)/1.15 Georgia,serif;color:var(--paper);margin:0 0 8px}
    #hw-character-creator .eyebrow{margin:0 0 6px;font:12px Georgia,serif;letter-spacing:3px;text-transform:uppercase;color:#b4c5cd}
    #hw-character-creator .steps{flex:1;color:var(--gold);font:700 14px Georgia,serif;letter-spacing:.08em;text-transform:uppercase;padding-bottom:10px}#hw-character-creator .step{color:var(--gold)}
    #hw-character-creator .panel{background:#11191cf2}
    #hw-character-creator .library,#hw-character-creator .choose{display:grid;grid-template-columns:minmax(0,1.25fr) minmax(300px,.8fr);grid-template-rows:auto minmax(0,1fr);gap:18px;flex:1;min-height:0;padding:18px clamp(16px,3vw,40px) 8px}
    #hw-character-creator .intro{grid-column:1;grid-row:1}
    #hw-character-creator .home-actions{display:flex;flex-wrap:wrap;gap:10px;margin-top:16px}
    #hw-character-creator .stage{grid-column:2;grid-row:1 / span 2;display:flex;flex-direction:column;min-width:0;min-height:280px;background:#101b21;border:2px solid var(--ink);border-radius:14px;box-shadow:0 6px 0 var(--ink);overflow:hidden}
    #hw-character-creator .char-grid,#hw-character-creator .templates{grid-column:1;grid-row:2;min-height:0;overflow:auto;align-content:start;margin:0}
    #hw-character-creator .char-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:14px}
    #hw-character-creator .char-card{display:flex;flex-direction:column;gap:8px;padding:12px;border:2px solid var(--ink);border-radius:12px;background:#17272f;box-shadow:0 4px 0 var(--ink)}
    #hw-character-creator .char-card img{width:100%;height:148px;object-fit:contain;background:radial-gradient(ellipse,#466272,#17282f);border-radius:8px}
    #hw-character-creator .char-card strong{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font:700 22px Georgia,serif}
    #hw-character-creator .char-card.disabled-card{opacity:.55}#hw-character-creator .char-card.active{border-color:var(--gold)}
    #hw-character-creator .card-actions{display:flex;flex-wrap:wrap;gap:6px}#hw-character-creator .card-actions button{flex:1 1 72px;padding:8px 6px;font-size:14px}
    #hw-character-creator .preview-col{display:flex;flex-direction:column;min-width:0;min-height:0}
    #hw-character-creator .preview-chrome{background:#101b21;padding:16px 18px}
    #hw-character-creator .preview-hole{flex:1;min-height:240px}
    #hw-character-creator .templates{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px}
    #hw-character-creator .templates button{text-align:left;display:flex;align-items:center;gap:12px;min-height:76px}#hw-character-creator .templates span{color:var(--gold);font:700 22px Georgia,serif}
    #hw-character-creator .home-actions button,#hw-character-creator .intro>button,#hw-character-creator .stage button,#hw-character-creator header>button,#hw-character-creator .templates button{border:2px solid var(--ink);border-radius:8px;background:#334d59;box-shadow:0 3px 0 var(--ink);color:var(--paper);font:700 16px Georgia,serif}
    #hw-character-creator .home-actions button:hover,#hw-character-creator .intro>button:hover,#hw-character-creator .stage button:hover,#hw-character-creator header>button:hover,#hw-character-creator .templates button:hover{background:#3d5c6a}
    #hw-character-creator .home-actions .primary,#hw-character-creator .stage .primary{background:var(--coral);color:#231b19;border-color:var(--ink)}#hw-character-creator .home-actions .primary:hover,#hw-character-creator .stage .primary:hover{background:#ffb1a6}
    #hw-character-creator p{color:var(--muted);line-height:1.55;margin:8px 0}#hw-character-creator .editor{display:grid;grid-template-columns:205px minmax(250px,1fr) minmax(200px,280px) 230px;flex:1;min-height:0}
    #hw-character-creator aside{padding:16px;overflow:auto;border-right:1px solid var(--line);background:#192428}#hw-character-creator .right{border-right:0;border-left:1px solid var(--line)}
    #hw-character-creator .label{display:block;color:#f4d8ac;font-size:11px;letter-spacing:1.5px;text-transform:uppercase;margin:15px 0 8px}
    #hw-character-creator .tools{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px}#hw-character-creator .tools button{padding:10px 5px}
    #hw-character-creator input[type=range]{width:100%;accent-color:var(--accent)}#hw-character-creator input[type=color]{width:100%;height:38px;border:0;background:none;padding:0;cursor:pointer}
    #hw-character-creator input[type=text],#hw-character-creator input[type=search]{width:100%;background:#111b1e;border:1px solid var(--line);border-radius:4px;padding:10px}
    #hw-character-creator .swatches{display:flex;gap:5px;flex-wrap:wrap;margin-top:8px}#hw-character-creator .swatches button{width:23px;height:23px;min-width:0;padding:0;border-radius:50%}
    #hw-character-creator .work{min-width:0;min-height:0;display:flex;flex-direction:column}.workbar{padding:10px 12px;display:flex;gap:8px;align-items:center;border-bottom:1px solid var(--line);flex-wrap:wrap}.workbar strong{flex:1}
    #hw-character-creator .viewport{flex:1;overflow:auto;min-height:0;display:grid;place-items:start center;padding:24px;background:#131e22}
    #hw-character-creator .viewport canvas{touch-action:none;image-rendering:pixelated;box-shadow:0 8px 40px #0008;background-color:#344147;background-image:linear-gradient(45deg,#425057 25%,transparent 25%),linear-gradient(-45deg,#425057 25%,transparent 25%),linear-gradient(45deg,transparent 75%,#425057 75%),linear-gradient(-45deg,transparent 75%,#425057 75%);background-size:16px 16px;background-position:0 0,0 8px,8px -8px,-8px 0;cursor:crosshair}
    #hw-character-creator .previewbox{background:radial-gradient(ellipse,#4b595d,#253237);border:1px solid var(--line);border-radius:6px;overflow:hidden}#hw-character-creator .previewbox canvas{width:100%;display:block;cursor:crosshair}
    #hw-character-creator .parts{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px;margin-top:10px}.parts button{padding:5px!important;min-width:0}.parts canvas{width:100%;height:55px;object-fit:contain;image-rendering:auto}.parts small{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:10px}
    #hw-character-creator footer{display:flex;gap:18px;align-items:center;min-height:48px;padding:10px 24px;border-top:1px solid var(--line);background:#192428}#hw-character-creator footer span{flex:1;color:var(--muted)}
    #hw-character-creator .check{display:flex;gap:8px;align-items:center;font-size:12px;line-height:1.4;margin:12px 0}#hw-character-creator .saving{display:flex;gap:10px;align-items:center}#hw-character-creator .saving input{width:210px}
    #hw-character-creator .confirm{position:absolute;inset:0;background:#000b;display:grid;place-items:center;z-index:3}.confirm>div{background:#223035;padding:28px;border:1px solid var(--line);border-radius:8px;max-width:460px}.confirm button{margin:12px 8px 0 0}
    @media(max-width:1000px){#hw-character-creator .editor{grid-template-columns:155px minmax(180px,1fr) minmax(160px,220px)}#hw-character-creator .right{position:absolute;right:10px;top:100px;width:230px;max-height:70vh;z-index:5}#hw-character-creator header{gap:10px;padding:10px}#hw-character-creator .steps{display:none}#hw-character-creator aside{padding:10px}#hw-character-creator .saving input{width:150px}}
    @media(max-width:900px){#hw-character-creator .library,#hw-character-creator .choose{grid-template-columns:1fr;grid-template-rows:auto minmax(220px,34vh) minmax(0,1fr)}#hw-character-creator .intro,#hw-character-creator .stage,#hw-character-creator .char-grid,#hw-character-creator .templates{grid-column:1}#hw-character-creator .stage{grid-row:2}#hw-character-creator .char-grid,#hw-character-creator .templates{grid-row:3}#hw-character-creator .editor{grid-template-columns:1fr}#hw-character-creator .preview-col{min-height:220px}}
    `;document.head.append(style);
  }
  function confirmDiscard(action){
    if(!dirty)return action();
    const cover=document.createElement('div');cover.className='confirm';cover.setAttribute('role','alertdialog');cover.setAttribute('aria-label','Discard unsaved changes?');
    const box=document.createElement('div'),h=document.createElement('h2'),p=document.createElement('p');h.textContent='Keep your changes?';p.textContent='Your character has unsaved edits. Save it first, or discard these edits to continue.';
    box.append(h,p,button('Keep editing',()=>cover.remove()),button('Discard edits',async()=>{clearTimeout(draftTimer);const id=model?.draftId;await draftQueue;if(id)await window.hwCharacterCreator.clearDraft?.(id);cover.remove();dirty=false;action();}));cover.append(box);panel.append(cover);box.querySelector('button').focus();
  }
  function close(){if(busy)return;if(stroke)pointerUp();confirmDiscard(()=>{++loadToken;stopPreviewWatch();disposePreview();panel.remove();panel=null;clearTimeout(draftTimer);returnFocus?.focus?.();});}
  function open(){
    if(panel&&!panel.isConnected){stopPreviewWatch();disposePreview();panel=null;}
    if(panel)return;css();returnFocus=document.activeElement;panel=document.createElement('section');panel.id='hw-character-creator';panel.setAttribute('role','dialog');panel.setAttribute('aria-modal','true');panel.setAttribute('aria-label','Custom characters');
    panel.innerHTML=`<header><div class="brand"><p class="eyebrow">Jimbob's workshop</p><h1>Custom characters</h1></div><div class="steps"><span class="step" data-id="step">Your characters</span></div><div class="saving" data-id="saving" hidden><input data-id="name" type="text" maxlength="60" aria-label="Character name" placeholder="Name your character"><button class="primary" data-id="save">Save character</button></div><button data-id="close" aria-label="Close custom characters">Close</button></header>
    <div class="library" data-id="library"><div class="intro"><h2>Your characters</h2><p>Pick a rider to edit, or start from someone already in Happy Wheels. Their movement stays. The artwork becomes yours.</p><div class="home-actions"><button class="primary" data-id="create-character">Create a character</button><button data-id="open-skins">Community skins</button><button data-id="import-skin">Import a skin file</button></div></div><div class="stage"><div class="preview-hole" data-preview-hole data-id="roster-hole"></div><div class="preview-chrome"><h2 data-id="roster-name">Select a character</h2><p data-id="roster-hint">Hover a character to see them here. Press = for the skin server.</p></div></div><div class="char-grid" data-id="roster"></div></div>
    <div class="choose" data-id="choose" hidden><div class="intro"><button data-id="templates-back">← Your characters</button><h2>Choose a starting rider</h2><p>Pick the body and movement you want. Painting never changes the physics.</p></div><div class="stage"><div class="preview-hole" data-preview-hole data-id="template-hole"></div><div class="preview-chrome"><h2 data-id="template-name">Choose your starting character</h2><p data-id="template-hint">Original movement. Your own colours.</p><button class="primary" data-id="edit" disabled>Use this character</button></div></div><div class="templates" data-id="templates"></div></div>
    <div class="editor" data-id="editor" hidden><aside class="panel"><button data-id="back">← Back</button><span class="label">Paint tools</span><div class="tools" data-id="tools"></div><label class="label" for="hw-creator-color">Colour</label><input id="hw-creator-color" data-id="color" type="color" value="#ed7d6d"><div class="swatches" data-id="swatches"></div><label class="label">Brush size <output data-id="size-out">8 px</output></label><input data-id="size" aria-label="Brush size" type="range" min="1" max="80" value="8"><label class="label">Opacity <output data-id="opacity-out">100%</output></label><input data-id="opacity" aria-label="Opacity" type="range" min="1" max="100" value="100"><label class="label">Fill tolerance <output data-id="tolerance-out">20</output></label><input data-id="tolerance" aria-label="Fill tolerance" type="range" min="0" max="150" value="20"><label class="check"><input data-id="alpha" type="checkbox" checked>Keep paint inside existing artwork</label><div class="tools"><button data-id="undo">Undo</button><button data-id="redo">Redo</button></div><p>Ctrl+Z / Ctrl+Y<br>B brush · E eraser<br>F fill · I eyedropper</p></aside>
    <main class="work panel"><div class="workbar"><strong data-id="part-title">Choose a body part</strong><button data-id="full">Show full body</button><button data-id="atlas">Sprite map</button><button data-id="import-sheet">Import sprite map</button><input data-id="import-file" type="file" accept=".png,.webp,image/png,image/webp" hidden aria-label="Import a sprite map"><button data-id="zoom-out" aria-label="Zoom out">−</button><span data-id="zoom">100%</span><button data-id="zoom-in" aria-label="Zoom in">+</button><button data-id="fit">Fit</button></div><div class="viewport" data-id="viewport"><canvas data-id="paint" width="600" height="600"></canvas></div></main>
    <div class="preview-col"><div class="preview-chrome"><span class="label">Character preview</span></div><div class="preview-hole" data-preview-hole data-id="live-hole"></div><div class="preview-chrome"><p>Same session the character selector uses. Click a part to edit it.</p></div></div>
    <aside class="right panel"><label class="label">Body parts & damage frames</label><input data-id="search" type="search" aria-label="Find texture part" placeholder="Find a part…"><div class="parts" data-id="parts"></div></aside></div>
    <footer><span data-id="status" role="status" aria-live="polite">Choose a character, or create a new one.</span><small>Native body parts · original physics</small></footer>`;
    document.body.append(panel);$('close').onclick=close;dirty=false;model=null;history=new P.History();
    names.forEach((name,i)=>{const b=button('',()=>showTemplate(i+1,true));b.innerHTML='<span>'+String(i+1).padStart(2,'0')+'</span>';b.append(document.createTextNode(name));b.dataset.base=i+1;b.addEventListener('pointerenter',()=>showTemplate(i+1,false));b.addEventListener('focus',()=>showTemplate(i+1,false));$('templates').append(b);});
    window.hwCharacterCreator?.availability?.().then(list=>{if(!panel)return;for(const entry of list){const tile=[...$('templates').children].find(b=>Number(b.dataset.base)===entry.base);if(tile&&!entry.available){tile.disabled=true;tile.title=entry.error;}}}).catch(error);
    $('edit').onclick=edit;$('create-character').onclick=()=>confirmDiscard(showTemplates);$('open-skins').onclick=()=>window.HWSkinLibrary?.open({onChanged:renderLibrary});$('import-skin').onclick=importSkinFile;$('templates-back').onclick=()=>confirmDiscard(showLibrary);$('back').onclick=()=>confirmDiscard(()=>{const saved=!!model?.characterId;disposePreview();model=null;key=null;part=null;enterEditor=false;if(saved)showLibrary();else{showScreen('choose');status('Choose a rider to begin.');}});
    const toolLabel={recolour:'Recolour',brush:'Brush',eraser:'Eraser',select:'Select part',fill:'Fill',eyedropper:'Eyedropper'};
    for(const t of Object.keys(toolLabel)){const b=button(toolLabel[t],()=>setTool(t));b.dataset.tool=t;$('tools').append(b);}setTool('brush');
    ['#ed7d6d','#f3ca69','#80bfa0','#729fc5','#b292c7','#f1dfca','#573c32','#263036','#ffffff','#111111'].forEach(color=>{const b=button('',()=>{$('color').value=color;});b.style.background=color;b.setAttribute('aria-label',color);$('swatches').append(b);});
    for(const name of ['size','opacity','tolerance'])$(name).oninput=()=>$(name+'-out').textContent=$(name).value+(name==='size'?' px':name==='opacity'?'%':'');
    $('undo').onclick=()=>undo(false);$('redo').onclick=()=>undo(true);$('search').oninput=filterParts;
    $('full').onclick=()=>showView('body');$('atlas').onclick=()=>showView('atlas');$('import-sheet').onclick=()=>$('import-file').click();$('import-file').onchange=importSheet;$('fit').onclick=fit;$('zoom-in').onclick=()=>scale(zoom*1.25);$('zoom-out').onclick=()=>scale(zoom/1.25);
    $('save').onclick=save;$('name').oninput=()=>{markDirty();};
    const c=$('paint');c.onpointerdown=pointerDown;c.onpointermove=pointerMove;c.onpointerup=pointerUp;c.onpointercancel=pointerUp;c.onlostpointercapture=pointerUp;
    $('live-hole').onpointerdown=e=>{if(!$('editor').hidden)pickPreview(e);};
    panel.addEventListener('keydown',keydown);panel.addEventListener('keyup',e=>e.stopPropagation());panel.addEventListener('pointerdown',e=>e.stopPropagation());
    $('close').focus();
    showScreen('library');
    startPreviewWatch();
    renderLibrary();
    if(window.hwCharacterCreator?.version!==2)status('Restart the game after installing this update to enable the creator’s save connection.');
  }
  const templateCache=new Map();function trimTemplates(){let bytes=[...templateCache.values()].reduce((n,c)=>n+c.sheet.width*c.sheet.height*4,0);for(const [id,c] of templateCache){if(templateCache.size<=3&&bytes<=64*1024*1024)break;if(id===model?.base)continue;templateCache.delete(id);bytes-=c.sheet.width*c.sheet.height*4;}}
  let selectedBase=0,docRev=0,renderQueued=false,previewFrame=0,previewLayoutFrame=0,previewWatch=null,libraryId=null;
  let savedDepth=0,unsavedName=false,savedState=0,draftTimer=0,documentCounter=0;
  function noteHistory(){docRev++;queueDraft();dirty=unsavedName||history.currentState!==savedState;}
  function markDirty(){unsavedName=true;docRev++;dirty=true;queueDraft();}
  function showScreen(name){
    $('library').hidden=name!=='library';$('choose').hidden=name!=='choose';$('editor').hidden=name!=='editor';$('saving').hidden=name!=='editor';
    $('step').textContent=name==='library'?'Your characters':name==='choose'?'Choose a rider':'Paint';
    panel.dataset.screen=name;if(preview)preview.layoutSignature='';schedulePreviewLayout();
  }
  function showLibrary(){disposePreview();model=null;key=null;part=null;libraryId=null;showScreen('library');renderLibrary();status('Choose a character, or create a new one.');}
  function showTemplates(){disposePreview();model=null;libraryId=null;showScreen('choose');status('Choose a template to begin.');}
  async function renderLibrary(){
    if(!panel)return;
    const box=$('roster');box.replaceChildren();
    if(!window.hwCharacterCreator?.list){status('Restart the game to manage saved characters.');return;}
    let entries=[];
    try{entries=await window.hwCharacterCreator.list();}catch(e){error(e);return;}
    if(!panel)return;const drafts=await window.hwCharacterCreator.drafts?.()||[];for(const draft of drafts){box.append(button('Continue draft: '+(draft.name||names[draft.base-1]),()=>confirmDiscard(()=>resumeDraft(draft.docId)),'char-card'));}
    for(const entry of entries){
      const card=document.createElement('article');
      card.className='char-card'+(entry.enabled?'':' disabled-card')+(entry.id===libraryId?' active':'');
      card.dataset.id=entry.id;
      const img=document.createElement('img');img.alt='';if(entry.icon)img.src=entry.icon;
      const name=document.createElement('strong');name.textContent=entry.name;
      const actions=document.createElement('div');actions.className='card-actions';
      actions.append(button('Edit',()=>confirmDiscard(()=>editSaved(entry.id))),button(entry.enabled?'Disable':'Enable',()=>setCharacterEnabled(entry.id,!entry.enabled)),button('Delete',()=>deleteCharacter(entry)),button('Publish',()=>window.HWSkinLibrary?.open({localId:entry.id,onChanged:renderLibrary})));
      card.append(img,name,actions);
      card.addEventListener('pointerenter',()=>previewSaved(entry.id));
      box.append(card);
    }
    if(!entries.length)$('roster-hint').textContent='No saved characters yet. Create one to see it here.';
  }
  function markLibraryCard(id){for(const card of $('roster').querySelectorAll('.char-card'))card.classList.toggle('active',card.dataset.id===id);}
  async function mountSaved(id,token){
    const data=await window.hwCharacterCreator.load(id);
    if(!panel||token!==loadToken)return;
    const img=await image(data.sheet);if(!panel||token!==loadToken)return;
    const sheet=canvas(img.width,img.height);sheet.getContext('2d').drawImage(img,0,0);
    disposePreview();
    model={...data,sheet,frames:Object.entries(data.atlas.frames),view:'body',labels:new Map(),parts:new Map(),characterId:id,docId:++documentCounter};
    for(const [k] of model.frames)model.labels.set(k,pretty(k));if(data.project?.originalSheet){const reference=await image(data.project.originalSheet);if(!panel||token!==loadToken)return;model.originalSheet=canvas(reference.width,reference.height);model.originalSheet.getContext('2d').drawImage(reference,0,0);}
    buildPreview({dress:true});
    if(!panel||token!==loadToken){disposePreview();return;}
    libraryId=id;$('roster-name').textContent=data.name;
    $('roster-hint').textContent=data.enabled?'Showing in the character menu.':'Disabled. It stays out of the character menu until you enable it.';
    status(data.name);
  }
  function previewSaved(id){
    if(busy||(libraryId===id&&preview))return;
    const token=++loadToken;libraryId=id;markLibraryCard(id);status('Loading preview…');
    mountSaved(id,token).catch(e=>{if(panel&&token===loadToken)error(e);});
  }
  async function editSaved(id){
    if(busy)return;
    if(!(preview&&model?.characterId===id)){
      const token=++loadToken;
      try{await mountSaved(id,token);}catch(e){error(e);return;}
      if(!panel||model?.characterId!==id)return;
    }
    revealEditor();
  }
  async function setCharacterEnabled(id,enabled){
    if(busy)return;busy=true;
    try{
      const result=await window.hwCharacterCreator.setEnabled(id,enabled);
      await window.HWCustomCharacters?.reloadRoster?.();
      libraryId=null;await renderLibrary();busy=false;previewSaved(id);
      status(result.published===false?(enabled?'Enabled, but the game copy could not be updated.':'Disabled, but the game copy could not be updated.'):(enabled?'Enabled. It will appear in the character menu.':'Disabled. It is hidden from the character menu.'));
    }catch(e){error(e);}finally{busy=false;}
  }
  function deleteCharacter(entry){
    if(busy)return;
    const cover=document.createElement('div');cover.className='confirm';cover.setAttribute('role','alertdialog');cover.setAttribute('aria-label','Delete character?');
    const box=document.createElement('div'),h=document.createElement('h2'),p=document.createElement('p');
    h.textContent='Delete this character?';p.textContent='“'+entry.name+'” will be removed from your characters folder and from the character menu.';
    const cancel=button('Keep',()=>cover.remove());
    const ok=button('Delete',async()=>{cover.remove();busy=true;try{const result=await window.hwCharacterCreator.remove(entry.id);await window.HWCustomCharacters?.reloadRoster?.();if(libraryId===entry.id){libraryId=null;disposePreview();$('roster-name').textContent='Select a character';}await renderLibrary();status(result.published===false?'Deleted here, but the game copy could not be removed.':'Deleted “'+entry.name+'”.');}catch(e){error(e);}finally{busy=false;}});
    ok.className='primary';box.append(h,p,cancel,ok);cover.append(box);panel.append(cover);cancel.focus();
  }
  function showTemplate(base,select){
    if(busy)return;
    if(select&&dirty&&base!==model?.base){confirmDiscard(()=>showTemplate(base,true));return;}
    const token=++loadToken;
    if(select){selectedBase=base;for(const b of $('templates').children)b.classList.toggle('active',Number(b.dataset.base)===base);$('edit').disabled=true;}
    if(!select&&preview?.templateBase===base){$('template-name').textContent=names[base-1];status('Looking at '+names[base-1]+'. Click it to select that character.');return;}
    status('Loading '+names[base-1]+'…');
    loadTemplate(base,token,select);
  }
  async function loadTemplate(base,token,select){
    try{
      if(!window.hwCharacterCreator)throw Error('Restart the game to load the character creator connection.');
      let cached=templateCache.get(base);
      if(!cached){
        const data=await window.hwCharacterCreator.template(base),img=data.sheet?await image(data.sheet):null;if(!panel||token!==loadToken)return;
        const sheet=canvas(data.atlas.meta.size.w,data.atlas.meta.size.h);if(img)sheet.getContext('2d').drawImage(img,0,0);else for(const page of data.pages){const pageImage=await image(page.sheet);if(!panel||token!==loadToken)return;sheet.getContext('2d').drawImage(pageImage,page.rect.x,page.rect.y);}
        cached={data,sheet,snapshot:null,bounds:null};templateCache.set(base,cached);trimTemplates();
      }
      if(!panel||token!==loadToken)return;
      const sheet=copyCanvas(cached.sheet);
      disposePreview();
      model={...cached.data,sheet,frames:Object.entries(cached.data.atlas.frames),view:'body',labels:new Map(),parts:new Map(),docId:++documentCounter};
      for(const [k] of model.frames)model.labels.set(k,pretty(k));
      try{buildPreview({dress:false});}catch(e){disposePreview();error(e);return;}
      if(!panel||token!==loadToken){disposePreview();return;}
      if(preview)preview.templateBase=base;
      $('template-name').textContent=cached.data.name;$('template-hint').textContent='Clone this character’s artwork, movement, and body parts.';
      if(select&&selectedBase===base){$('edit').disabled=false;status('Ready. Choose “Use this character” to start painting.');if(enterEditor){enterEditor=false;revealEditor();}}
      else status('Looking at '+cached.data.name+'. Click it to select that character.');
    }catch(e){if(panel&&token===loadToken)error(e);}
  }
  function copyCanvas(source){const copy=canvas(source.width,source.height);copy.getContext('2d').drawImage(source,0,0);return copy;}
  let enterEditor=false;
  function revealEditor(){
    showScreen('editor');$('name').value=model.characterId?model.name:'My '+model.name;$('back').textContent=model.characterId?'← Your characters':'← Templates';history=new P.History();dirty=false;unsavedName=false;savedDepth=0;savedState=history.currentState;docRev++;model.draftId=model.draftId||'draft-'+Date.now().toString(36)+'-'+documentCounter;model.originalSheet=model.originalSheet||copyCanvas(model.sheet);model.iconCrop=model.project?.iconCrop||null;model.iconOwner=model.project?.iconOwner||'rider';model.iconMode=model.project?.iconMode||(model.characterId&&model.icon?'manual':'auto');model.manualIcon=model.project?.manualIcon||model.icon||null;model.roleOverrides=model.project?.roleOverrides||{};model.materials=model.project?.materials||{};model.links=model.project?.links||[];
    if(preview){dressPreview();holdPreviewStill();}installWorkshopControls();$('compare-original').textContent='Compare original';
    makeParts();showView('body');$('import-sheet').title='PNG or WebP laid out like this character’s sprite map, '+model.sheet.width+'×'+model.sheet.height+' pixels.';status('Draw on the character, or import a sprite map you already painted.');
  }
  function edit(){if(!selectedBase||busy)return;if(preview&&model?.base===selectedBase){revealEditor();return;}enterEditor=true;showTemplate(selectedBase,true);}
  function setTool(t){
    tool=t;if(!panel)return;
    for(const b of $('tools').children){b.classList.toggle('active',b.dataset.tool===t);b.setAttribute('aria-pressed',b.dataset.tool===t?'true':'false');}
    if(t==='select')status('Select part: click a visible piece to edit that texture alone.');
    else if(t==='fill')status('Fill stays inside the texture you click.');
    else if(model?.view==='portrait')status(model.portraitFraming?'Drag the frame, then use it. Brush, eraser, fill, and the eyedropper edit the icon after that.':'Painting the menu icon with the '+t+'.');
    else if(model?.view==='body')status('Draw across the character. Each visible part keeps its own texture.');
    else if(key)status('Painting '+label(key)+' with the '+t+'.');
  }
  function pretty(key){
    const base=String(key).split('/').pop().replace(/\.[a-z0-9]+$/i,'').replace(/[_-]+/g,' ').replace(/([a-z])([A-Z])/g,'$1 $2').replace(/\s+/g,' ').trim();
    return base.replace(/\b[a-z]/g,ch=>ch.toUpperCase())||'Texture';
  }
  function label(k){return model.labels.get(k)||pretty(k);}
  function makeParts(){
    $('parts').replaceChildren();model.partButtons=new Map();for(const [k,item] of model.frames){const b=button('',()=>select(k));b.dataset.key=k;b.title=k;model.partButtons.set(k,b);
      const c=canvas(100,75),p=P.region(model.sheet,item),ctx=c.getContext('2d'),s=Math.min(90/p.width,65/p.height);ctx.drawImage(p,(100-p.width*s)/2,(75-p.height*s)/2,p.width*s,p.height*s);
      const text=document.createElement('small');const r=role(k);text.textContent=r.verified?r.family+' · '+r.state:label(k)+' · needs mapping';b.title=r.owner+' · '+r.family+' · '+r.state+'\n'+k;b.append(c,text);$('parts').append(b);
    }filterParts();
  }
  function filterParts(){const search=$('search').value.toLowerCase(),owner=$('owner-filter')?.value||'any',state=$('state-filter')?.value||'all';for(const b of $('parts').children){const r=role(b.dataset.key);b.hidden=!(label(b.dataset.key)+' '+b.dataset.key+' '+r.owner+' '+r.family+' '+r.state).toLowerCase().includes(search)||(owner!=='any'&&(owner==='unknown'?r.verified:r.owner!==owner))||(state!=='all'&&(state==='unknown'?r.verified:r.state!==state));}}
  function select(k){if(stroke)pointerUp();key=k;part=ensurePart(k);model.view='part';model.portraitFraming=false;$('alpha').disabled=false;$('part-title').textContent=label(k);for(const b of $('parts').children)b.classList.toggle('active',b.dataset.key===k);renderWork();fit();syncPortraitChrome();const shared=preview?.pose?.items?.filter(item=>item.key===k).length||0;status(shared>1?'Painting '+label(k)+'. This texture is shared by multiple parts.':'Painting '+label(k)+'. Other texture pieces are protected.');}
  function syncPortraitChrome(){const on=model?.view==='portrait',box=$('portrait-options'),btn=$('portrait'),framing=!!(on&&model?.portraitFraming);if(box)box.hidden=!on;if(btn)btn.classList.toggle('active',!!on);const use=$('use-frame'),range=$('portrait-zoom');if(use)use.hidden=!framing;if(range)range.hidden=!framing;}
  function showView(view){if(stroke)pointerUp();if(view!=='portrait')model.portraitFraming=false;model.view=view;const lock=$('alpha');if(lock)lock.disabled=view==='body';if(view==='body')$('part-title').textContent=tool==='select'?'Click a visible part':'Draw on the character';else if(view==='atlas')$('part-title').textContent='Sprite map · click a texture';else if(view==='portrait')$('part-title').textContent=model.portraitFraming?'Drag the icon frame':'Menu icon';else if(key)$('part-title').textContent=label(key);if(view==='portrait')for(const b of $('parts').children)b.classList.remove('active');renderWork();fit();syncPortraitChrome();}
  function scale(value){zoom=Math.max(.1,Math.min(16,value));const c=$('paint');c.style.width=c.width*zoom+'px';c.style.height=c.height*zoom+'px';$('zoom').textContent=Math.round(zoom*100)+'%';}
  function fit(){const box=$('viewport'),c=$('paint'),cap=model.view==='part'?6:model.view==='portrait'&&!model.portraitFraming?12:1;scale(Math.min((box.clientWidth-48)/Math.max(c.width,1),(box.clientHeight-48)/Math.max(c.height,1),cap));}
  function renderPortrait(c){
    if(model.portraitFraming&&preview?.snapshot){const snap=preview.snapshot,side=Math.max(snap.width,snap.height,1),g=c.getContext('2d'),ox=(side-snap.width)/2,oy=(side-snap.height)/2;c.width=side;c.height=side;g.clearRect(0,0,side,side);g.drawImage(snap,ox,oy);const density=preview.snapshotScale||1,crop=model.portraitCrop||{x:0,y:0,size:Math.max(preview.bounds?.width||1,preview.bounds?.height||1)},x=ox+crop.x*density,y=oy+crop.y*density,s=crop.size*density;g.save();g.fillStyle='rgba(17,25,28,.55)';g.beginPath();g.rect(0,0,side,side);g.rect(x,y,s,s);g.fill('evenodd');g.strokeStyle='#ff9083';g.lineWidth=Math.max(2,side/180);g.strokeRect(x,y,s,s);g.restore();c.__frame={ox,oy,density};}
    else if(model.portrait){c.width=model.portrait.width;c.height=model.portrait.height;c.getContext('2d').drawImage(model.portrait,0,0);c.__frame=null;}
  }
  function renderWork(){
    if(!model)return;const c=$('paint');
    if(model.view==='body'){c.width=700;c.height=760;blitPreview(c);}
    else if(model.view==='portrait')renderPortrait(c);
    else{const source=model.view==='atlas'?model.sheet:part;c.width=source.width;c.height=source.height;c.getContext('2d').drawImage(source,0,0);}
    scale(zoom);
  }
  function point(e,c=$('paint')){const r=c.getBoundingClientRect();return {x:(e.clientX-r.left)*c.width/r.width,y:(e.clientY-r.top)*c.height/r.height};}
  function rgba(){const h=$('color').value;return [parseInt(h.slice(1,3),16),parseInt(h.slice(3,5),16),parseInt(h.slice(5,7),16),Number($('opacity').value)/100];}
  function ensurePart(k){
    if(!model.parts)model.parts=new Map();
    let piece=model.parts.get(k);
    if(!piece){piece=P.region(model.sheet,model.atlas.frames[k]);model.parts.set(k,piece);}
    return piece;
  }
  function commitPart(k){const piece=model.parts?.get(k);if(!piece)return;P.commit(model.sheet,model.atlas.frames[k],piece);if(key===k)part=piece;thumb(k);}
  function thumb(k){const b=model.partButtons?.get(k),piece=model.parts?.get(k);if(!b||!piece)return;const c=b.querySelector('canvas'),ctx=c.getContext('2d'),s=Math.min(90/piece.width,65/piece.height);ctx.clearRect(0,0,100,75);ctx.drawImage(piece,(100-piece.width*s)/2,(75-piece.height*s)/2,piece.width*s,piece.height*s);}
  function publishSheet(){preview?.base?.update?.();if(preview)preview.samples=null;schedulePreview();}
  function characterPoint(e,c=$('paint')){
    const at=point(e,c),m=c.__creatorMap;if(!m)return null;if(m.flipped)at.x=c.width-at.x;
    return {x:m.bounds.x+(at.x-m.x)/m.scale,y:m.bounds.y+(at.y-m.y)/m.scale};
  }
  function partAlpha(k,x,y,source){
    const data=source||ensurePart(k).getContext('2d').getImageData(0,0,ensurePart(k).width,ensurePart(k).height).data;
    const piece=ensurePart(k),px=Math.round(x),py=Math.round(y);
    if(px<0||py<0||px>=piece.width||py>=piece.height)return 0;
    return data[(py*piece.width+px)*4+3];
  }
  function visibleHit(lx,ly,alphas){
    const instances=preview?.pose?.items||[];
    return P.frontPart(instances,lx,ly,hit=>{
      if(!hit.key)return true;
      const data=alphas?.get(hit.key);
      return partAlpha(hit.key,hit.x,hit.y,data)>16;
    });
  }
  function applyMasks(masks,originals,color,opacity,erase){
    for(const [k,mask] of masks){
      const piece=ensurePart(k),before=originals.get(k);
      const after=P.composite(before.data,mask,color,opacity,erase);
      piece.getContext('2d').putImageData(new ImageData(after,piece.width,piece.height),0,0);
      commitPart(k);
    }
  }
  function pickPreview(e,c){
    const at=c?characterPoint(e,c):previewPoint(e);
    if(!at)return;
    const hit=visibleHit(at.x,at.y);
    if(hit?.key&&!hit.blocked)select(hit.key);else status('Click directly on a body part, or choose its tile on the right.');
  }
  function bodyPointerDown(e){
    const at=characterPoint(e);if(!at)return;
    if(tool==='select'){const hit=visibleHit(at.x,at.y);if(hit?.key&&!hit.blocked)select(hit.key);else status('Click a visible part.');return;}
    if(tool==='eyedropper'){sampleCharacter(at);return;}
    if(tool==='fill'){fillCharacter(at);return;}if(tool==='recolour'){recolourCharacter(at);return;}
    const alphas=new Map();
    for(const item of preview.pose?.items||[]){
      if(!item.key||alphas.has(item.key))continue;
      const piece=ensurePart(item.key);
      alphas.set(item.key,piece.getContext('2d').getImageData(0,0,piece.width,piece.height).data);
    }
    stroke={kind:'body',docId:model.docId,tool,color:rgba(),opacity:Number($('opacity').value)/100,size:Number($('size').value),last:at,alphas,masks:new Map(),originals:new Map()};
    $('paint').setPointerCapture(e.pointerId);
    extendBody(at);
  }
  function extendBody(at,defer=false){
    const from=stroke.last,radius=Math.max(0.5,stroke.size/2),instances=preview.pose?.items||[];
    for(const inst of instances){
      if(!inst.key)continue;
      const piece=ensurePart(inst.key);
      const bounds=P.strokeBounds(inst,from,at,radius);if(!bounds)continue;const {x0,y0,x1,y1}=bounds;
      if(!stroke.masks.has(inst.key)){
        stroke.masks.set(inst.key,new Float32Array(piece.width*piece.height));
        stroke.originals.set(inst.key,piece.getContext('2d').getImageData(0,0,piece.width,piece.height));
      }
      const mask=stroke.masks.get(inst.key);
      for(let py=y0;py<=y1;py++)for(let px=x0;px<=x1;px++){
        const char=P.partPixelToCharacter(inst,px,py);
        const cover=P.brushCover(P.segmentDistance(char.x,char.y,from.x,from.y,at.x,at.y),radius);
        if(cover<=0)continue;
        const owner=visibleHit(char.x,char.y,stroke.alphas);
        if(!owner||owner.blocked||owner.key!==inst.key)continue;
        const index=py*piece.width+px;
        if(cover>mask[index])mask[index]=cover;
      }
    }
    stroke.last=at;if(!defer){applyMasks(stroke.masks,stroke.originals,stroke.color,stroke.opacity,stroke.tool==='eraser');publishSheet();}
  }
  function finishBodyStroke(){
    const changes=[];
    for(const [k,before] of stroke.originals){
      const piece=ensurePart(k),after=piece.getContext('2d').getImageData(0,0,piece.width,piece.height);
      if(before.data.some((v,i)=>v!==after.data[i]))changes.push({key:k,before,after});
    }
    if(changes.length&&history.push({docId:stroke.docId,type:stroke.tool,changes}))noteHistory();
    const count=changes.length;
    stroke=null;updateHistory();publishSheet();
    if(count)status(count>1?'Updated '+count+' textures. One undo puts them all back.':'Updated 1 texture.');
  }
  function sampleCharacter(at){
    const hit=visibleHit(at.x,at.y);if(!hit?.key||hit.blocked){status('Eyedropper only samples the character.');return;}
    const piece=ensurePart(hit.key),px=Math.max(0,Math.min(piece.width-1,Math.round(hit.x))),py=Math.max(0,Math.min(piece.height-1,Math.round(hit.y)));
    const data=piece.getContext('2d').getImageData(px,py,1,1).data;
    $('color').value='#'+[...data.slice(0,3)].map(v=>v.toString(16).padStart(2,'0')).join('');
    status('Colour picked from the character.');
  }
  function fillCharacter(at){
    const hit=visibleHit(at.x,at.y);if(!hit?.key||hit.blocked){status('Fill stays inside a texture. Click the character.');return;}
    const piece=ensurePart(hit.key),ctx=piece.getContext('2d'),before=ctx.getImageData(0,0,piece.width,piece.height);
    const data=new Uint8ClampedArray(before.data);
    P.flood(data,piece.width,piece.height,hit.x,hit.y,rgba(),Number($('tolerance').value),$('alpha').checked);
    ctx.putImageData(new ImageData(data,piece.width,piece.height),0,0);commitPart(hit.key);
    const after=ctx.getImageData(0,0,piece.width,piece.height);
    if(history.push({docId:model.docId,type:'fill',changes:[{key:hit.key,before,after}]}))noteHistory();
    publishSheet();updateHistory();status('Fill stays inside this texture.');
  }
  function pointerDown(e){
    if(model?.compareOriginal){status('Showing original artwork. Choose Show edited before painting.');return;}
    if(!model||busy||e.button!==0)return;e.preventDefault();
    if(model.view==='body'){bodyPointerDown(e);return;}
    const at=point(e);if(model.view==='atlas'){const found=model.frames.find(([,v])=>at.x>=v.frame.x&&at.x<v.frame.x+v.frame.w&&at.y>=v.frame.y&&at.y<v.frame.y+v.frame.h);if(found)select(found[0]);return;}
    if(model.view==='portrait'&&model.portraitFraming){model.portraitDrag={x:at.x,y:at.y,crop:{x:model.portraitCrop.x,y:model.portraitCrop.y,size:model.portraitCrop.size}};$('paint').setPointerCapture(e.pointerId);return;}
    if(model.view==='portrait'&&(tool==='select'||tool==='recolour')){status('Select and recolour edit the character. The icon uses brush, eraser, fill, and the eyedropper.');return;}
    const piece=model.view==='portrait'?model.portrait:part;if(!piece)return;
    if(tool==='recolour'){recolourPart(at);return;}if(tool==='select'){status('Select part works on the full character. Press B to paint this texture.');return;}
    const ctx=piece.getContext('2d'),before=ctx.getImageData(0,0,piece.width,piece.height);
    if(tool==='eyedropper'){const x=Math.min(piece.width-1,Math.max(0,Math.floor(at.x))),y=Math.min(piece.height-1,Math.max(0,Math.floor(at.y))),i=(y*piece.width+x)*4;$('color').value='#'+[...before.data.slice(i,i+3)].map(v=>v.toString(16).padStart(2,'0')).join('');status('Colour picked. Press B to paint.');return;}
    if(tool==='fill'){const data=ctx.getImageData(0,0,piece.width,piece.height);P.flood(data.data,piece.width,piece.height,at.x,at.y,rgba(),Number($('tolerance').value),$('alpha').checked);ctx.putImageData(data,0,0);record(before,model.view==='portrait');return;}
    stroke={before,layer:canvas(piece.width,piece.height),last:at,tool,color:$('color').value,size:Number($('size').value),opacity:Number($('opacity').value)/100,lock:$('alpha').checked,portrait:model.view==='portrait'};$('paint').setPointerCapture(e.pointerId);dab(at,at);
  }
  function dab(a,b,defer=false){
    const s=stroke,ctx=s.layer.getContext('2d');ctx.strokeStyle=s.color;ctx.fillStyle=s.color;ctx.lineWidth=s.size;ctx.lineCap='round';ctx.lineJoin='round';ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke();ctx.beginPath();ctx.arc(b.x,b.y,s.size/2,0,Math.PI*2);ctx.fill();
    if(!defer)applyPartStroke();
  }
  function applyPartStroke(){const s=stroke;if(!s)return;const piece=s.portrait?model.portrait:part,target=piece.getContext('2d');target.putImageData(s.before,0,0);target.save();target.globalAlpha=s.opacity;target.globalCompositeOperation=s.tool==='eraser'?'destination-out':s.lock?'source-atop':'source-over';target.drawImage(s.layer,0,0);target.restore();if(s.portrait)showPortraitSurface();else{commitPart(key);showPartSurface();publishSheet();}}
  function showPortraitSurface(){if(model?.view!=='portrait'||model.portraitFraming||!model.portrait)return;const c=$('paint');if(c.width!==model.portrait.width||c.height!==model.portrait.height){c.width=model.portrait.width;c.height=model.portrait.height;scale(zoom);}c.getContext('2d').clearRect(0,0,c.width,c.height);c.getContext('2d').drawImage(model.portrait,0,0);}
  function showPartSurface(){
    if(model?.view!=='part'||!part)return;
    const c=$('paint');
    if(c.width!==part.width||c.height!==part.height){c.width=part.width;c.height=part.height;scale(zoom);}
    c.getContext('2d').clearRect(0,0,c.width,c.height);c.getContext('2d').drawImage(part,0,0);
  }
  let paintRAF=0,moveQueue=[];
  function flushMoves(){if(paintRAF)cancelAnimationFrame(paintRAF);paintRAF=0;const events=moveQueue;moveQueue=[];if(!stroke)return;for(const e of events){if(stroke.kind==='body'){const at=characterPoint(e);if(at)extendBody(at,true);}else{const at=point(e);dab(stroke.last,at,true);stroke.last=at;}}if(!events.length)return;if(stroke.kind==='body'){applyMasks(stroke.masks,stroke.originals,stroke.color,stroke.opacity,stroke.tool==='eraser');publishSheet();}else applyPartStroke();}
  function pointerMove(e){if(model?.portraitDrag){const at=point(e),start=model.portraitDrag,map=$('paint').__frame;if(!map)return;model.portraitCrop={x:start.crop.x-(at.x-start.x)/map.density,y:start.crop.y-(at.y-start.y)/map.density,size:start.crop.size};renderWork();return;}if(!stroke)return;moveQueue.push(...(e.getCoalescedEvents?.()?.length?e.getCoalescedEvents():[e]));if(!paintRAF)paintRAF=requestAnimationFrame(flushMoves);}
  function pointerUp(){if(model?.portraitDrag){model.portraitDrag=null;return;}flushMoves();if(!stroke)return;if(stroke.kind==='body'){finishBodyStroke();return;}const before=stroke.before,portrait=stroke.portrait;stroke=null;record(before,portrait);}
  function iconSnapshot(){const crop=model.iconCrop;return {mode:model.iconMode||'auto',manual:model.manualIcon||null,crop:crop?{x:crop.x,y:crop.y,size:crop.size}:null,owner:model.iconOwner||'rider'};}
  function record(before,portrait){if(portrait){const after=model.portrait.getContext('2d').getImageData(0,0,model.portrait.width,model.portrait.height),beforeIcon=iconSnapshot();model.iconMode='manual';model.iconCrop=null;model.manualIcon=model.portrait.toDataURL('image/png');if(history.push({docId:model.docId,type:'portrait',beforeIcon,afterIcon:iconSnapshot(),changes:[{key:'__portrait',before,after}]}))noteHistory();else{model.iconMode=beforeIcon.mode;model.manualIcon=beforeIcon.manual;model.iconCrop=beforeIcon.crop;}showPortraitSurface();updateHistory();if(dirty)status('Icon updated. Save your character to use it in the menu.');return;}const after=part.getContext('2d').getImageData(0,0,part.width,part.height);commitPart(key);if(history.push({docId:model.docId,type:tool,changes:[{key,before,after}]}))noteHistory();showPartSurface();publishSheet();updateHistory();}
  function updateHistory(){$('undo').disabled=!history.undoStack.length;$('redo').disabled=!history.redoStack.length;}
  function importSheet(e){
    const file=e.target.files&&e.target.files[0];
    e.target.value='';
    if(!file||!model||busy)return;if(file.size>32*1024*1024){status('Choose an image smaller than 32 MB.');return;}
    if(stroke)pointerUp();
    const url=URL.createObjectURL(file);
    const target=model,token=loadToken;image(url).then(img=>{URL.revokeObjectURL(url);if(panel&&model===target&&token===loadToken&&img.width*img.height<=32*1024*1024&&img.width<=8192&&img.height<=8192)applyImportedSheet(img);}).catch(err=>{URL.revokeObjectURL(url);if(panel&&model===target)error(err);});
  }
  function applyImportedSheet(img){
    const sheet=model.sheet,w=sheet.width,h=sheet.height;
    const sx=img.width/w,sy=img.height/h;
    const exact=img.width===w&&img.height===h;
    const multiple=sx===sy&&sx>=1&&Math.abs(sx-Math.round(sx))<0.001;
    if(!exact&&!multiple){status('That sprite map is '+img.width+'×'+img.height+'. This character needs '+w+'×'+h+', or a whole-number multiple of that size.');return;}
    const ctx=sheet.getContext('2d'),before=ctx.getImageData(0,0,w,h),beforeReference=model.originalSheet,beforeMasks=model.paintMasks,beforeMaterials=model.materials;
    ctx.clearRect(0,0,w,h);
    ctx.drawImage(img,0,0,w,h);
    const after=ctx.getImageData(0,0,w,h);
    model.parts=new Map();model.originalSheet=copyCanvas(model.sheet);model.paintMasks=new Map();model.materials={};
    if(history.push({docId:model.docId,type:'import',beforeReference,afterReference:model.originalSheet,beforeMasks,afterMasks:model.paintMasks,beforeMaterials,afterMaterials:model.materials,changes:[{key:'__sheet',before,after}]}))noteHistory();
    makeParts();
    if(key&&model.atlas.frames[key]){part=ensurePart(key);for(const b of $('parts').children)b.classList.toggle('active',b.dataset.key===key);}
    if(model.view==='part'&&part)showPartSurface();else renderWork();
    publishSheet();updateHistory();
    status(exact?'Imported sprite map. Every part is using that artwork.':'Fitted a '+img.width+'×'+img.height+' sprite map onto the '+w+'×'+h+' layout.');
  }
  function undo(redo){
    if(busy)return;
    if(stroke)pointerUp();
    const entry=redo?history.redo():history.undo();
    if(!entry||(entry.docId&&entry.docId!==model.docId))return;
    if(entry.type==='links'){model.links=redo?entry.afterLinks:entry.beforeLinks;noteHistory();updateHistory();return;}if(entry.type==='mapping'){model.roleOverrides=redo?entry.afterRoles:entry.beforeRoles;makeParts();noteHistory();updateHistory();return;}if(entry.beforeMaterials)model.materials=redo?entry.afterMaterials:entry.beforeMaterials;
    if(entry.type==='icon'||entry.type==='portrait'){const icon=redo?entry.afterIcon:entry.beforeIcon;Object.assign(model,{iconMode:icon.mode,manualIcon:icon.manual,iconCrop:icon.crop,iconOwner:icon.owner});if(entry.type==='portrait'){const pixels=P.restoreImage(redo?entry.after:entry.before);if(!model.portrait)model.portrait=canvas(pixels.width,pixels.height);model.portrait.getContext('2d').putImageData(pixels,0,0);model.portraitReady=true;model.portraitFraming=false;if($('portrait-owner'))$('portrait-owner').value=icon.owner||'rider';}noteHistory();if(model.view==='portrait')showView('portrait');updateHistory();return;}if(entry.type==='import'){
      const change=entry.changes[0],pixels=P.restoreImage(redo?change.after:change.before);
      model.sheet.getContext('2d').putImageData(pixels,0,0);model.originalSheet=redo?entry.afterReference:entry.beforeReference;model.paintMasks=redo?entry.afterMasks:entry.beforeMasks;
      model.parts=new Map();
      if(key&&model.atlas.frames[key])part=ensurePart(key);
      makeParts();
      if(key){for(const b of $('parts').children)b.classList.toggle('active',b.dataset.key===key);}
      if(model.view==='part'&&part)showPartSurface();else renderWork();
      noteHistory();publishSheet();updateHistory();return;
    }
    const changes=entry.changes||[{key:entry.key,before:entry.before,after:entry.after}];
    for(const change of changes){if(change.beforeMask)model.paintMasks.set(change.key,new Uint8Array(redo?change.afterMask:change.beforeMask));const piece=ensurePart(change.key);piece.getContext('2d').putImageData(P.restoreImage(redo?change.after:change.before),0,0);commitPart(change.key);}
    noteHistory();
    if(model.view==='part'&&key){part=ensurePart(key);showPartSurface();}
    publishSheet();updateHistory();
  }
  function refresh(){P.commit(model.sheet,model.atlas.frames[key],part);preview?.base?.update?.();schedulePreview();const b=[...$('parts').children].find(b=>b.dataset.key===key);if(b){const c=b.querySelector('canvas'),ctx=c.getContext('2d'),s=Math.min(90/part.width,65/part.height);ctx.clearRect(0,0,100,75);ctx.drawImage(part,(100-part.width*s)/2,(75-part.height*s)/2,part.width*s,part.height*s);}}
  function keydown(e){
    e.stopPropagation();
    if(e.key==='Tab'){const scope=panel.querySelector('.portrait-editor,.confirm')||panel;const nodes=[...scope.querySelectorAll('button,input,select')].filter(n=>!n.disabled&&n.getClientRects().length),first=nodes[0],last=nodes.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus();}return;}
    if(e.key==='Escape'){e.preventDefault();const modal=panel.querySelector('.portrait-editor,.confirm,.shade');if(modal){modal.remove();return;}close();return;}
    if(e.key==='='&&!['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName)){e.preventDefault();window.HWSkinLibrary?.settings?.();return;}
    if(['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName))return;
    if(busy||panel.querySelector('.portrait-editor,.confirm'))return;
    const k=e.key.toLowerCase();if((e.ctrlKey||e.metaKey)&&['z','y','s'].includes(k)){e.preventDefault();if(k==='s')save();else undo(k==='y'||e.shiftKey);return;}
    if(model&&(model.view==='part'||model.view==='body'||model.view==='portrait')){const t={b:'brush',e:'eraser',f:'fill',i:'eyedropper',s:'select',r:'recolour'}[k];if(t){e.preventDefault();setTool(t);}}
  }
  // Character selector preview, from the menu's characterLoaded:
  // source = iG(characterIndex); session = new Preview(source); session.visible = false;
  // menu.addChild(session); session.scaleX = session.scaleY = 2; session.create(); session.visible = true.
  const PREVIEW_SESSION=58640,SETTLE_STEPS=24;
  function pixiRoot(session){return session?.pixiSprite||session?._pixiSprite||null;}
  function disposePreview(){
    const current=preview;preview=null;if(!current)return;
    const state=current.rt?.state;
    if(state&&current.session&&state.currentSession===current.session)state.currentSession=current.savedSession??null;
    try{current.session?.die?.();}catch{}
    try{current.session?.destroy?.();}catch{}
    try{if(current.holder?.parent)current.holder.parent.removeChild(current.holder);}catch{}
    try{if(current.backdrop?.parent)current.backdrop.parent.removeChild(current.backdrop);}catch{}
    try{current.backdrop?.texture?.destroy?.(true);current.backdrop?.destroy?.();current.clip?.parent?.removeChild(current.clip);current.clip?.texture?.destroy?.(true);current.clip?.destroy?.();}catch{}
    for(const t of current.textures?.values?.()||[])try{t.destroy(false);}catch{}
    try{current.base?.destroy?.();}catch{}
    clearPreviewWindow();
  }
  function clearPreviewWindow(){
    if(!panel||!panel.dataset.previewWindow)return;
    panel.style.clipPath='';
    panel.style.webkitClipPath='';
    panel.style.maskImage='';
    panel.style.webkitMaskImage='';
    panel.style.maskMode='';
    panel.style.webkitMaskMode='';
    delete panel.dataset.previewWindow;
  }
  function previewClipPath(){
    let path=document.getElementById('hw-preview-clip-path');
    if(path)return path;
    const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');
    svg.id='hw-preview-clip-svg';svg.setAttribute('aria-hidden','true');svg.style.cssText='position:absolute;width:0;height:0';
    const clip=document.createElementNS('http://www.w3.org/2000/svg','clipPath');
    clip.id='hw-preview-clip';clip.setAttribute('clipPathUnits','objectBoundingBox');
    path=document.createElementNS('http://www.w3.org/2000/svg','path');
    path.id='hw-preview-clip-path';path.setAttribute('fill-rule','evenodd');path.setAttribute('clip-rule','evenodd');
    clip.append(path);svg.append(clip);document.body.append(svg);return path;
  }
  function syncPreviewWindow(){
    if(!panel)return;
    const hole=preview?activeHole():null;
    if(!hole){clearPreviewWindow();return;}
    const panelBox=panel.getBoundingClientRect(),box=hole.getBoundingClientRect();
    const x=Math.round(box.left-panelBox.left),y=Math.round(box.top-panelBox.top),w=Math.round(box.width),h=Math.round(box.height),pw=Math.round(panelBox.width),ph=Math.round(panelBox.height);
    if(w<8||h<8||pw<8||ph<8){clearPreviewWindow();return;}
    const signature=[x,y,w,h,pw,ph].join(',');
    if(panel.dataset.previewWindow===signature)return;
    panel.dataset.previewWindow=signature;
    const nx=x/pw,ny=y/ph,nw=w/pw,nh=h/ph;
    previewClipPath().setAttribute('d',`M0 0H1V1H0Z M${nx} ${ny}H${nx+nw}V${ny+nh}H${nx}Z`);
    panel.style.maskImage='';panel.style.webkitMaskImage='';
    panel.style.clipPath='url(#hw-preview-clip)';panel.style.webkitClipPath='url(#hw-preview-clip)';
  }
  function freezeSimulation(session){
    const step=typeof session.run30fps==='function'?session.run30fps.bind(session):typeof session.run==='function'?session.run.bind(session):null;
    if(step)for(let i=0;i<SETTLE_STEPS;i++){try{step();}catch{break;}}
    try{session._character?.paint?.();}catch{}
    const run=session.run;
    if(typeof run==='function'&&session.listeners&&typeof session.removeEventListener==='function'){
      for(const type of Object.keys(session.listeners)){
        const list=session.listeners[type];
        if(Array.isArray(list)&&list.some(item=>item?.listener===run))session.removeEventListener(type,run);
      }
    }
    try{session.removeEventListener?.('enterFrame',run);}catch{}
  }
  function atlasKey(texture){
    const ids=texture?.textureCacheIds||(texture?.textureCacheId?[texture.textureCacheId]:null);
    const named=ids?.find(k=>model.atlas.frames[k])||Object.keys(model.atlas.frames).find(k=>ids?.includes(model.atlas.frames[k].sourceKey));
    if(named)return named;
    const f=texture?.frame;if(!f)return null;
    let best=null,score=1e9;
    for(const [k,item] of Object.entries(model.atlas.frames)){
      const a=item.frame,dw=Math.min(Math.abs(a.w-f.width)+Math.abs(a.h-f.height),Math.abs(a.w-f.height)+Math.abs(a.h-f.width));
      const page=model.atlas.pages?.find(p=>p.id===item.pageId),url=texture.baseTexture?.resource?.url||'';if(page&&model.atlas.pages.length>1&&!url.includes(page.source.replace(/\.json$/i,'.png')))continue;const dp=Math.abs(a.x-f.x)+Math.abs(a.y-(page?.rect.y||0)-f.y);
      if(dw<3&&dp<score){score=dp;best=k;}
    }
    return score<6?best:null;
  }
  function dressPreview(){
    const {session,rt,base,textures,hits}=preview,seen=new Set(),names=new Map();
    hits.length=0;
    const character=session._character;
    if(character)for(const [name,value] of Object.entries(character)){
      if(value?.pixiSprite)names.set(value.pixiSprite,name);
      if(Array.isArray(value))for(const item of value)if(item?.pixiSprite)names.set(item.pixiSprite,name);
    }
    function visit(sprite){
      if(!sprite||seen.has(sprite))return;seen.add(sprite);
      const name=names.get(sprite)||sprite._flashSprite?.name||sprite.name||'';
      if(/shapeGuide|shapeRef/i.test(String(name))){sprite.visible=false;return;}
      if(sprite.texture&&sprite.visible!==false){
        const owned=[...textures.values()].includes(sprite.texture);
        const k=owned?[...textures.entries()].find(([,t])=>t===sprite.texture)?.[0]:atlasKey(sprite.texture);
        if(k&&!owned&&sprite.texture.orig?.clone){
          let t=textures.get(k);
          if(!t){const f=model.atlas.frames[k].frame,o=sprite.texture;t=new rt.pixi.gPd(base,new rt.pixi.M_G(f.x,f.y,f.w,f.h),o.orig.clone(),o.trim?.clone?.()||o.trim,o.rotate||0);textures.set(k,t);}
          sprite.texture=t;
          if(name)model.labels.set(k,pretty(String(name).replace(/MCs?$/,'').replace(/([a-z])([A-Z])/g,'$1 $2')));
        }
        if(k)hits.push({node:sprite,key:k});
      }
      for(const child of sprite.children||[])visit(child);
    }
    visit(pixiRoot(session));
  }
  function buildPreview(options={}){
    const rt=window.HWCustomCharacters.creatorRuntime();if(!rt?.app?.stage)throw Error('The game is still loading. Try again in a moment.');
    const Preview=rt.require(PREVIEW_SESSION)?.v,source=rt.require(1050)?.iG?.(model.base);
    if(typeof Preview!=='function'||!source?.pixiMovieClip)throw Error('This game build does not expose the character preview.');
    const state=rt.state,savedIndex=state.characterIndex,savedSession=state.currentSession;
    state.characterIndex=model.base;
    let session,holder;
    try{
      session=new Preview(source);
      const sprite=pixiRoot(session);
      if(!sprite?.emit)throw Error('This game build does not expose the character preview.');
      state.currentSession=session;
      holder=new rt.pixi.mcf();
      try{holder.eventMode='none';}catch{}
      rt.app.stage.addChild(holder);
      session.visible=false;
      holder.addChild(sprite);
      session.scaleX=session.scaleY=2;
      session.create();
      session.visible=true;
    }catch(e){
      try{holder?.parent?.removeChild(holder);}catch{}
      try{session?.die?.();}catch{}
      throw e;
    }finally{
      state.characterIndex=savedIndex;
      state.currentSession=savedSession??null;
    }
    const texture=rt.pixi.gPd.from(model.sheet);
    preview={rt,session,holder,savedSession,base:texture.baseTexture,textures:new Map(),hits:[],bounds:null,snapshot:null,fitted:false,held:false,templateBase:null,backdrop:null};
    if(options.dress!==false)dressPreview();
    holdPreviewStill();
    schedulePreviewLayout();
  }
  function holdPreviewStill(){
    if(!preview?.session||preview.held)return;
    freezeSimulation(preview.session);
    preview.held=true;
    try{captureSnapshot();}catch(e){error(e);}
  }
  function activeHole(){
    if(!panel)return null;
    const screen=panel.dataset.screen||'library';
    const hole=$(screen==='choose'?'template-hole':screen==='editor'?'live-hole':'roster-hole');
    if(!hole||hole.closest('[hidden]')||hole.offsetWidth<8||hole.offsetHeight<8)return null;
    return hole;
  }
  function stageView(){
    const rt=preview?.rt,renderer=rt?.app?.renderer,view=rt?.app?.view||renderer?.view;
    if(!view?.getBoundingClientRect||!renderer)return null;
    const resolution=renderer.resolution||1,screen=rt.app.screen||renderer.screen;
    return {view,screen:{width:screen?.width||renderer.width/resolution,height:screen?.height||renderer.height/resolution}};
  }
  function clientRectToStage(node){
    const info=stageView();if(!info)return null;
    const canvasRect=info.view.getBoundingClientRect(),rect=node.getBoundingClientRect();
    const sx=info.screen.width/Math.max(1,canvasRect.width),sy=info.screen.height/Math.max(1,canvasRect.height);
    return {x:(rect.left-canvasRect.left)*sx,y:(rect.top-canvasRect.top)*sy,w:rect.width*sx,h:rect.height*sy};
  }
  function focusBounds(root){
    let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity,count=0;
    function walk(node){
      if(!node||node.visible===false)return;
      const tex=node.texture,b=tex&&node.getBounds?.();
      if(b&&b.width>1&&b.height>1&&b.width<2200&&b.height<2200&&tex.width>1&&tex.width<2200&&tex.height>1&&tex.height<2200){
        if(b.x<minX)minX=b.x;if(b.y<minY)minY=b.y;if(b.x+b.width>maxX)maxX=b.x+b.width;if(b.y+b.height>maxY)maxY=b.y+b.height;count++;
      }
      for(const child of node.children||[])walk(child);
    }
    walk(root);
    return count?{x:minX,y:minY,width:maxX-minX,height:maxY-minY}:null;
  }
  function ensureBackdrop(){
    if(preview.backdrop)return;
    const sample=canvas(4,4),g=sample.getContext('2d'),grd=g.createRadialGradient(2,2.6,.2,2,2,2.8);
    grd.addColorStop(0,'#45545a');grd.addColorStop(1,'#263237');g.fillStyle=grd;g.fillRect(0,0,4,4);
    const sprite=new preview.rt.pixi.kxk(preview.rt.pixi.gPd.from(sample));
    try{sprite.eventMode='none';}catch{}
    preview.backdrop=sprite;
  }
  function placePreview(){
    if(!preview?.session||!panel)return;
    const hole=activeHole();preview.holder.visible=!!hole;if(preview.backdrop)preview.backdrop.visible=!!hole;if(preview.clip)preview.clip.visible=!!hole;if(!hole){syncPreviewWindow();return;}
    const root=pixiRoot(preview.session);if(!root)return;
    ensureBackdrop();if(!preview.clip){const white=canvas(2,2);white.getContext('2d').fillStyle='#fff';white.getContext('2d').fillRect(0,0,2,2);preview.clip=new preview.rt.pixi.kxk(preview.rt.pixi.gPd.from(white));preview.clip.eventMode='none';preview.rt.app.stage.addChild(preview.clip);preview.holder.mask=preview.clip;}
    const holeStage=clientRectToStage(hole);if(!holeStage||holeStage.w<8||holeStage.h<8)return;
    root.updateTransform?.();
    const bounds=focusBounds(root);
    if(bounds&&!preview.fitted){
      const fit=Math.min(holeStage.w/bounds.width,holeStage.h/bounds.height)*0.86;
      const current=Number(preview.session.scaleX)||2;
      preview.session.scaleX=preview.session.scaleY=Math.max(.05,Math.min(8,current*fit));
      preview.fitted=true;
      root.updateTransform?.();
    }
    const placed=focusBounds(root);
    if(placed){
      preview.holder.x+=(holeStage.x+holeStage.w/2)-(placed.x+placed.width/2);
      preview.holder.y+=(holeStage.y+holeStage.h/2)-(placed.y+placed.height/2);
    }
    Object.assign(preview.clip,{x:holeStage.x,y:holeStage.y,width:holeStage.w,height:holeStage.h});
    preview.backdrop.x=holeStage.x;preview.backdrop.y=holeStage.y;preview.backdrop.width=holeStage.w;preview.backdrop.height=holeStage.h;
    preview.rt.app.stage.addChild(preview.backdrop);preview.rt.app.stage.addChild(preview.holder);
    syncPreviewWindow();
  }
  function stopPreviewWatch(){
    cancelAnimationFrame(previewFrame);cancelAnimationFrame(previewLayoutFrame);previewFrame=0;previewLayoutFrame=0;
    previewWatch?.disconnect();previewWatch=null;window.removeEventListener('resize',schedulePreviewLayout);
  }
  function schedulePreviewLayout(){if(!panel||previewLayoutFrame)return;previewLayoutFrame=requestAnimationFrame(()=>{previewLayoutFrame=0;layoutPreview();});}
  function layoutPreview(){
    if(!panel?.isConnected){stopPreviewWatch();disposePreview();panel=null;return;}
    try{
      if(!preview){clearPreviewWindow();return;}
      const hole=activeHole(),rect=hole?.getBoundingClientRect()||null,view=stageView()?.view,canvasRect=view?.getBoundingClientRect?.()||null;
      const signature=[rect?Math.round(rect.x):-1,rect?Math.round(rect.y):-1,rect?Math.round(rect.width):0,rect?Math.round(rect.height):0,canvasRect?Math.round(canvasRect.width):0,canvasRect?Math.round(canvasRect.height):0].join(',');
      if(signature===preview.layoutSignature)return;
      const width=rect?Math.round(rect.width):0,height=rect?Math.round(rect.height):0;
      if(width!==preview.layoutWidth||height!==preview.layoutHeight)preview.fitted=false;
      preview.layoutSignature=signature;preview.layoutWidth=width;preview.layoutHeight=height;
      placePreview();syncPreviewWindow();
    }catch(e){/* keep the last good frame */}
  }
  function startPreviewWatch(){
    stopPreviewWatch();if(!panel)return;
    window.addEventListener('resize',schedulePreviewLayout);
    if(typeof ResizeObserver==='function'){
      previewWatch=new ResizeObserver(schedulePreviewLayout);
      previewWatch.observe(panel);
      for(const hole of panel.querySelectorAll('[data-preview-hole]'))previewWatch.observe(hole);
      const view=window.HWCustomCharacters?.creatorRuntime?.()?.app?.view||window.HWCustomCharacters?.creatorRuntime?.()?.app?.renderer?.view;
      if(view)previewWatch.observe(view);
    }else previewFrame=requestAnimationFrame(function poll(){if(!panel?.isConnected){previewFrame=0;return;}previewFrame=requestAnimationFrame(poll);layoutPreview();});
    schedulePreviewLayout();
  }
  function previewPoint(e){
    const root=pixiRoot(preview?.session),info=stageView();
    if(!root?.worldTransform?.clone||!info)return null;
    root.updateTransform?.();
    const canvasRect=info.view.getBoundingClientRect();
    const x=(e.clientX-canvasRect.left)*info.screen.width/Math.max(1,canvasRect.width),y=(e.clientY-canvasRect.top)*info.screen.height/Math.max(1,canvasRect.height);
    const inv=root.worldTransform.clone();inv.invert();
    return {x:inv.a*x+inv.c*y+inv.tx,y:inv.b*x+inv.d*y+inv.ty};
  }
  function partBounds(root){
    const inv=root.worldTransform.clone();inv.invert();
    let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity,count=0;
    function walk(node){
      if(!node||node.visible===false)return;
      const tex=node.texture,b=tex&&node.getBounds?.();
      if(b&&b.width>1&&b.height>1&&b.width<2200&&b.height<2200&&tex.width<2200&&tex.height<2200){
        for(const [x,y] of [[b.x,b.y],[b.x+b.width,b.y],[b.x,b.y+b.height],[b.x+b.width,b.y+b.height]]){
          const lx=inv.a*x+inv.c*y+inv.tx,ly=inv.b*x+inv.d*y+inv.ty;
          if(lx<minX)minX=lx;if(ly<minY)minY=ly;if(lx>maxX)maxX=lx;if(ly>maxY)maxY=ly;
        }
        count++;
      }
      for(const child of node.children||[])walk(child);
    }
    walk(root);
    if(!count)return null;
    const pad=18;
    return {x:minX-pad,y:minY-pad,width:Math.max(1,maxX-minX+pad*2),height:Math.max(1,maxY-minY+pad*2)};
  }
  function textureSource(tex){return tex?.baseTexture?.resource?.source||tex?.baseTexture?.source||null;}
  function drawFrame(ctx,source,tex,dx,dy,dw,dh){
    const frame=tex.frame,rot=tex.rotate||0;
    if(!frame||!source)return;
    if(rot===2){ctx.translate(dx+dh,dy);ctx.rotate(Math.PI/2);ctx.drawImage(source,frame.x,frame.y,frame.width,frame.height,0,0,dh,dw);}
    else if(rot===6){ctx.translate(dx,dy+dw);ctx.rotate(-Math.PI/2);ctx.drawImage(source,frame.x,frame.y,frame.width,frame.height,0,0,dh,dw);}
    else if(rot===4||rot===8){ctx.translate(dx+dw,dy+dh);ctx.rotate(Math.PI);ctx.drawImage(source,frame.x,frame.y,frame.width,frame.height,0,0,dw,dh);}
    else ctx.drawImage(source,frame.x,frame.y,frame.width,frame.height,dx,dy,dw,dh);
  }
  function captureSnapshot(){
    const root=pixiRoot(preview.session);
    root.updateTransform();
    const inv=root.worldTransform.clone();inv.invert();
    const sprites=[];
    function walk(node){
      if(!node||node.visible===false||node.renderable===false||node.worldAlpha===0)return;
      const tex=node.texture,source=textureSource(tex);
      if(source&&tex.frame&&tex.width>1&&tex.height>1&&tex.width<2200&&tex.height<2200)sprites.push(node);
      for(const child of node.children||[])walk(child);
    }
    walk(root);
    if(!sprites.length)throw Error('The character preview has no visible parts.');
    let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
    const placed=sprites.map(sprite=>{
      const tex=sprite.texture,anchorX=sprite.anchor?.x||0,anchorY=sprite.anchor?.y||0;
      const origW=tex.orig?.width||tex.width,origH=tex.orig?.height||tex.height,trim=tex.trim;
      const dx=-anchorX*origW+(trim?trim.x:0),dy=-anchorY*origH+(trim?trim.y:0);
      const dw=trim?trim.width:origW,dh=trim?trim.height:origH;
      const local=inv.clone();local.append(sprite.worldTransform);
      for(const [x,y] of [[dx,dy],[dx+dw,dy],[dx,dy+dh],[dx+dw,dy+dh]]){
        const lx=local.a*x+local.c*y+local.tx,ly=local.b*x+local.d*y+local.ty;
        if(lx<minX)minX=lx;if(ly<minY)minY=ly;if(lx>maxX)maxX=lx;if(ly>maxY)maxY=ly;
      }
      const owned=[...preview.textures.values()].includes(tex);
      const frameKey=owned?[...preview.textures.entries()].find(([,t])=>t===tex)?.[0]:atlasKey(tex);
      return {sprite,local,dx,dy,dw,dh,key:frameKey};
    });
    const pad=18,width=Math.max(1,Math.ceil(maxX-minX+pad*2)),height=Math.max(1,Math.ceil(maxY-minY+pad*2));
    if(!preview.pose){
      preview.pose={minX,minY,width,height,pad,items:placed.map(item=>{
        const frame=model.atlas.frames[item.key];
        const partW=frame?(frame.rotated?frame.frame.h:frame.frame.w):item.dw;
        const partH=frame?(frame.rotated?frame.frame.w:frame.frame.h):item.dh;
        return {key:item.key,a:item.local.a,b:item.local.b,c:item.local.c,d:item.local.d,tx:item.local.tx,ty:item.local.ty,dx:item.dx,dy:item.dy,dw:item.dw,dh:item.dh,partW,partH,sprite:item.sprite};
      })};
      preview.quads=preview.pose.items.filter(item=>item.key);
      preview.bounds={x:minX-pad,y:minY-pad,width,height};
      preview.full=preview.bounds;
    }
    const pose=preview.pose;
    const resolution=Math.max(1,Math.min(4,1536/Math.max(pose.width,pose.height))),sw=Math.ceil(pose.width*resolution),sh=Math.ceil(pose.height*resolution);preview.snapshotScale=resolution;
    const snap=preview.snapshot?.width===sw&&preview.snapshot?.height===sh?preview.snapshot:canvas(sw,sh);
    const ctx=snap.getContext('2d');
    ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,sw,sh);ctx.scale(resolution,resolution);
    ctx.translate(pose.pad-pose.minX,pose.pad-pose.minY);
    for(const item of pose.items){
      ctx.save();
      ctx.transform(item.a,item.b,item.c,item.d,item.tx,item.ty);
      ctx.globalAlpha=item.sprite.worldAlpha??1;
      try{drawFrame(ctx,textureSource(item.sprite.texture),item.sprite.texture,item.dx,item.dy,item.dw,item.dh);}catch{}
      ctx.restore();
    }
    preview.snapshot=snap;
  }
  function lockFraming(){captureSnapshot();}
  function schedulePreview(){
    if(!preview||renderQueued)return;
    renderQueued=true;
    const doc=model?.docId;
    requestAnimationFrame(()=>{
      renderQueued=false;
      if(!preview?.session||model?.docId!==doc)return;
      try{captureSnapshot();paintVisiblePreviews();}catch(e){error(e);}
    });
  }
  function paintVisiblePreviews(){
    if(!preview?.snapshot||$('editor').hidden||model?.view!=='body')return;
    blitPreview($('paint'));
  }
  function blitSnapshot(image,bounds,target){
    const ctx=target.getContext('2d');
    const scale=Math.min((target.width-44)/Math.max(1,bounds.width),(target.height-44)/Math.max(1,bounds.height));
    const x=(target.width-bounds.width*scale)/2,y=(target.height-bounds.height*scale)/2;
    ctx.clearRect(0,0,target.width,target.height);
    const flipped=!!model?.viewFlip;if(flipped){ctx.save();ctx.translate(target.width,0);ctx.scale(-1,1);}
    ctx.drawImage(image,x,y,bounds.width*scale,bounds.height*scale);if(flipped)ctx.restore();
    target.__creatorMap={x,y,scale,bounds,flipped};
  }
  function originalSnapshot(){
    if(preview.originalReference===model.originalSheet&&preview.originalSnapshot)return preview.originalSnapshot;
    const out=canvas(preview.snapshot.width,preview.snapshot.height),g=out.getContext('2d'),pose=preview.pose;g.scale(preview.snapshotScale||1,preview.snapshotScale||1);g.translate(pose.pad-pose.minX,pose.pad-pose.minY);
    for(const item of pose.items){g.save();g.transform(item.a,item.b,item.c,item.d,item.tx,item.ty);g.globalAlpha=item.sprite.worldAlpha??1;const tex=item.sprite.texture;try{drawFrame(g,preview.textures.get(item.key)===tex?model.originalSheet:textureSource(tex),tex,item.dx,item.dy,item.dw,item.dh);}catch{}g.restore();}
    preview.originalReference=model.originalSheet;preview.originalSnapshot=out;return out;
  }
  function blitPreview(target){if(preview?.snapshot&&target)blitSnapshot(model.compareOriginal?originalSnapshot():preview.snapshot,preview.bounds,target);}
  function textureSample(texture){
    const source=texture.baseTexture?.resource?.source||texture.baseTexture?.source;
    if(!source)return null;
    if(preview.samples?.has(texture.baseTexture))return preview.samples.get(texture.baseTexture);
    const sample=canvas(source.width||texture.baseTexture.width,source.height||texture.baseTexture.height);
    try{sample.getContext('2d').drawImage(source,0,0);}catch{return null;}
    preview.samples=preview.samples||new Map();
    preview.samples.set(texture.baseTexture,sample);
    return sample;
  }
  function spriteOpaque(sprite,wx,wy){
    if(sprite.visible===false||sprite.worldAlpha===0)return false;
    const inv=sprite.worldTransform?.clone?.();if(!inv?.invert)return false;inv.invert();
    const lx=inv.a*wx+inv.c*wy+inv.tx,ly=inv.b*wx+inv.d*wy+inv.ty;
    const tex=sprite.texture;if(!tex)return false;
    const anchorX=sprite.anchor?.x||0,anchorY=sprite.anchor?.y||0;
    const origW=tex.orig?.width||tex.width,origH=tex.orig?.height||tex.height;
    const px=lx+anchorX*origW,py=ly+anchorY*origH;
    if(px<0||py<0||px>=origW||py>=origH)return false;
    const trim=tex.trim;
    let u,v;
    if(trim){
      if(px<trim.x||py<trim.y||px>=trim.x+trim.width||py>=trim.y+trim.height)return false;
      u=(px-trim.x)/Math.max(1,trim.width);v=(py-trim.y)/Math.max(1,trim.height);
    }else{u=px/origW;v=py/origH;}
    const frame=tex.frame;if(!frame)return true;
    const rot=tex.rotate||0;
    let ax,ay;
    if(rot===2){ax=frame.x+v*frame.width;ay=frame.y+(1-u)*frame.height;}
    else if(rot===6){ax=frame.x+(1-v)*frame.width;ay=frame.y+u*frame.height;}
    else if(rot===4||rot===8){ax=frame.x+(1-u)*frame.width;ay=frame.y+(1-v)*frame.height;}
    else{ax=frame.x+u*frame.width;ay=frame.y+v*frame.height;}
    const sample=textureSample(tex);if(!sample)return true;
    const image=sample.getContext('2d').getImageData(Math.max(0,Math.min(sample.width-1,Math.floor(ax))),Math.max(0,Math.min(sample.height-1,Math.floor(ay))),1,1).data;
    return image[3]>16;
  }
  function lockEditing(locked){
    if(!panel)return;
    for(const id of ['name','undo','redo','back','save','close','full','atlas','import-sheet']){const node=$(id);if(node)node.disabled=locked;}
    for(const node of panel.querySelectorAll('.templates button, .tools button, .swatches button, .workshop-controls button, .workshop-controls select, .portrait-editor button, .portrait-editor input, .portrait-editor select'))node.disabled=locked;
    $('paint').style.pointerEvents=locked?'none':'';
  }
  async function save(){
    if(!model||busy)return;if(stroke)pointerUp();const name=$('name').value.trim();if(!name){$('name').focus();status('Give your character a name first.');return;}
    const rev=docRev,sheet=model.sheet.toDataURL('image/png'),base=model.base;
    busy=true;lockEditing(true);status('Saving your character…');
    try{
      captureSnapshot();
      const icon=await makePortrait();
      const result=await window.hwCharacterCreator.save({name,base,sheet,icon:icon.toDataURL('image/png'),id:model.characterId||undefined,project:projectData()});
      const placed=await window.HWCustomCharacters.addCreated(result);
      model.characterId=result.id;
      if(docRev===rev){savedDepth=history.undoStack.length;savedState=history.currentState;unsavedName=false;dirty=false;model.name=name;clearTimeout(draftTimer);await draftQueue;await window.hwCharacterCreator.clearDraft?.(model.draftId);}
      if(result.published===false)status('Saved, but it could not be published into the game yet. Save again to retry.');
      else if(placed?.available===false&&!placed?.disabled)status('Saved, but no character slot is available.');
      else if(docRev!==rev)status('Saved an earlier state. You still have unsaved changes.');
      else if(result.enabled===false)status('Saved “'+name+'”. It stays hidden until you enable it.');
      else status('Saved “'+name+'”. It is now available in character selection.');
      
      $('step').textContent='03 / Ready to play';
    }catch(e){error(e);}finally{busy=false;if(panel)lockEditing(false);}
  }

  function maskEncode(value){let text='';for(let i=0;i<value.length;i+=16384)text+=String.fromCharCode(...value.subarray(i,i+16384));return btoa(text);}
  function maskDecode(value){return typeof value==='string'?Uint8Array.from(atob(value),c=>c.charCodeAt(0)):new Uint8Array(value);}
  function projectData(){return {version:2,originalSheet:model.originalSheet?.toDataURL('image/png'),iconMode:model.iconMode||'auto',manualIcon:model.iconMode==='manual'?model.manualIcon||null:null,iconCrop:model.iconCrop||null,iconOwner:model.iconOwner||'rider',roleOverrides:model.roleOverrides||{},materials:model.materials||{},links:model.links||[],palette:[...$('swatches').children].map(b=>b.getAttribute('aria-label')),paintMasks:Object.fromEntries([...(model.paintMasks||new Map())].map(([k,v])=>[k,maskEncode(v)]))};}
  let draftQueue=Promise.resolve();
  function queueDraft(){clearTimeout(draftTimer);draftTimer=setTimeout(()=>{if(!panel||!model||!dirty||$('editor').hidden||busy)return;const doc=model,data={docId:doc.draftId,name:$('name').value,base:doc.base,characterId:doc.characterId||null,sheet:doc.sheet.toDataURL('image/png'),project:projectData()};draftQueue=draftQueue.then(()=>window.hwCharacterCreator.draft(data)).catch(e=>{if(panel&&model===doc)status('Draft could not be saved: '+e.message);});},1200);}
  function importSkinFile(){
    if(busy)return;const input=document.createElement('input');input.type='file';input.accept='.jskin,application/json';
    input.onchange=async()=>{const file=input.files?.[0];if(!file)return;if(file.size>64*1024*1024){status('This skin export is too large.');return;}busy=true;try{const saved=await window.hwCharacterCreator.importSkin(JSON.parse(await file.text()));await window.HWCustomCharacters.addCreated(saved);if(panel){await renderLibrary();status('Imported '+saved.name+'. Find it in Your characters.');}}catch(e){error(e);}finally{busy=false;}};input.click();
  }
  async function resumeDraft(id){if(busy)return;busy=true;const token=++loadToken;try{const data=await window.hwCharacterCreator.loadDraft(id),template=await window.hwCharacterCreator.template(data.base),img=await image(data.sheet);if(!panel||token!==loadToken)return;disposePreview();const sheet=canvas(img.width,img.height);sheet.getContext('2d').drawImage(img,0,0);model={...data,name:data.name||'My character',atlas:template.atlas,sheet,frames:Object.entries(template.atlas.frames),parts:new Map(),labels:new Map(),docId:++documentCounter,draftId:id};for(const [k] of model.frames)model.labels.set(k,pretty(k));if(data.project?.originalSheet){const original=await image(data.project.originalSheet);model.originalSheet=canvas(original.width,original.height);model.originalSheet.getContext('2d').drawImage(original,0,0);}buildPreview({dress:true});revealEditor();markDirty();status('Draft restored. Save when you are ready to play.');}catch(e){error(e);}finally{busy=false;}}
  function role(k){return model.roleOverrides?.[k]||model.atlas.frames[k]?.semantic||{owner:'unknown',family:'unmapped',verified:false,state:'unknown'};}
  function workshopStyle(){if(document.getElementById('hw-workshop-style'))return;const st=document.createElement('style');st.id='hw-workshop-style';st.textContent=`#hw-character-creator .workshop-controls{display:flex;align-items:center;gap:14px;flex-wrap:wrap;padding:12px 16px;background:#17242b;border-bottom:2px solid #0d171c}#hw-character-creator .tool-group{display:flex;align-items:center;gap:8px;flex-wrap:wrap;padding:6px;background:#243844;border:2px solid #0d171c;border-radius:10px;box-shadow:0 3px 0 #0d171c}#hw-character-creator .action-group{margin-left:auto}#hw-character-creator .icon-options{background:#2c261c;border-color:#f2cb64}#hw-character-creator .group-label{padding:0 8px;color:#f2cb64;font:700 11px Georgia,serif;letter-spacing:.14em;text-transform:uppercase}#hw-character-creator .tool-group button,#hw-character-creator .advanced summary{border:2px solid #0d171c;border-radius:8px;background:#334d59;box-shadow:0 2px 0 #0d171c;color:#f5eedb;font:700 15px Georgia,serif}#hw-character-creator .tool-group button:hover{background:#3d5c6a}#hw-character-creator .tool-group button.active{background:#ff8582;color:#231b19}#hw-character-creator .icon-options input[type=range]{width:150px}#hw-character-creator .advanced{position:relative}#hw-character-creator .advanced summary{cursor:pointer;border:1px solid #52636a;padding:9px;border-radius:5px}#hw-character-creator .advanced-tools{position:absolute;top:100%;left:0;z-index:8;min-width:190px;display:grid;gap:6px;background:#192428;border:1px solid #ff9083;border-radius:6px;padding:10px;box-shadow:0 10px 30px #0008}#hw-character-creator .right select{width:100%;max-width:none;margin-bottom:6px}#hw-character-creator[data-screen=editor]{background:#11191c}#hw-character-creator .parts{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}#hw-character-creator .parts canvas{width:100%;height:auto;aspect-ratio:1;object-fit:contain}#hw-character-creator .parts small{white-space:normal;line-height:1.25;font-size:12px}#hw-character-creator aside select{width:100%;min-width:0;max-width:100%}#hw-character-creator .tools button{min-width:0;min-height:42px;font-size:15px;overflow-wrap:normal}#hw-character-creator .swatches button{width:30px;height:30px}#hw-character-creator select{background:#192428;color:#eee7d7;border:1px solid #52636a;border-radius:5px;padding:7px;max-width:160px}#hw-character-creator .portrait-editor{position:absolute;inset:0;background:#10191bf2;z-index:10;display:flex;align-items:center;justify-content:center;padding:20px}#hw-character-creator .portrait-card{width:min(820px,95vw);max-height:95vh;overflow:auto;background:#192428;border:2px solid #ff9083;border-radius:12px;padding:24px}#hw-character-creator .portrait-layout{display:grid;grid-template-columns:1fr 160px;gap:20px}#hw-character-creator .portrait-edit{width:100%;max-width:420px;aspect-ratio:1;touch-action:none;background:repeating-conic-gradient(#344147 0% 25%,#425057 0% 50%) 0/20px 20px;cursor:crosshair}#hw-character-creator .portrait-small{width:40px;height:40px;image-rendering:auto;background:#26373b}#hw-character-creator .review-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px}#hw-character-creator .review-grid canvas{width:100%;height:130px;object-fit:contain}#hw-character-creator .workshop-controls small{color:#b0bfc0}#hw-character-creator .portrait-options{display:flex;align-items:center;gap:8px;flex-wrap:wrap}#hw-character-creator .portrait-options input[type=range]{width:120px}#hw-character-creator .brush-ring{position:fixed;pointer-events:none;z-index:30010;border:1px solid #fff;border-radius:50%;outline:1px solid #26373b}#hw-character-creator .steps{font-size:12px}#hw-character-creator .preview-col[data-editor-live]{display:none}#hw-character-creator .editor{grid-template-columns:minmax(280px,320px) minmax(420px,1fr) minmax(340px,420px)}#hw-character-creator .editor>.preview-col{display:none}#hw-character-creator .right{position:static;max-height:none}@media(max-width:1200px){#hw-character-creator .editor{grid-template-columns:250px minmax(280px,1fr)}#hw-character-creator .right{position:absolute;top:150px;right:12px;max-height:65vh;width:320px;z-index:5;background:#192428;border:2px solid #ff9083}#hw-character-creator .right[hidden]{display:none!important}}@media(max-width:680px){#hw-character-creator .editor{grid-template-columns:150px minmax(150px,1fr)}#hw-character-creator h1{font-size:18px}#hw-character-creator .portrait-layout{grid-template-columns:1fr}}`;document.head.append(st);}
  function picker(values,label,change){const select=document.createElement('select');select.setAttribute('aria-label',label);for(const [v,text] of values){const o=document.createElement('option');o.value=v;o.textContent=text;select.append(o);}select.onchange=change;return select;}
  function installWorkshopControls(){
    workshopStyle();if(!$('workshop')){const bar=document.createElement('div');bar.className='workshop-controls';bar.dataset.id='workshop';
      const owner=picker([['any','All owners'],['rider','Rider'],['passenger','Passenger'],['vehicle','Vehicle'],['unknown','Needs mapping']],'Show owner',filterParts);owner.dataset.id='owner-filter';
      const state=picker([['all','All states'],['normal','Normal'],['alternate','Damage / alternate'],['unknown','Needs review']],'Show state',filterParts);state.dataset.id='state-filter';
      const material=picker([['auto','Clicked material'],['skin','Skin'],['shirt','Shirt'],['trousers','Trousers'],['shoes','Shoes'],['hair','Hair / head'],['vehicle','Vehicle']],'Recolour material',()=>setTool('recolour'));material.dataset.id='material';
      const parts=button('Parts',()=>{$('parts').parentElement.hidden=!$('parts').parentElement.hidden});parts.title='Body parts and alternate frames';
      const portrait=button('Icon',()=>showPortrait().catch(error));portrait.dataset.id='portrait';const review=button('Review states',reviewStates);
      const portraitOptions=document.createElement('div');portraitOptions.className='portrait-options tool-group icon-options';portraitOptions.dataset.id='portrait-options';portraitOptions.hidden=true;
      const iconLabel=document.createElement('span');iconLabel.className='group-label';iconLabel.textContent='Icon';portraitOptions.append(iconLabel);
      const useFrame=button('Use this frame',()=>applyFrame().catch(error));useFrame.dataset.id='use-frame';useFrame.hidden=true;
      const portraitOwner=picker([['rider','Rider'],['passenger','Passenger']],'Icon character');portraitOwner.dataset.id='portrait-owner';portraitOwner.onchange=()=>{model.iconOwner=portraitOwner.value;if(model.portraitFraming)beginFrame().catch(error);else if(model.iconMode!=='manual')applyHeadshot().catch(error);else status('Headshot and frame will use this character. Your drawing stays until you choose one.');};
      const portraitZoom=document.createElement('input');portraitZoom.type='range';portraitZoom.min='20';portraitZoom.max='200';portraitZoom.value='100';portraitZoom.dataset.id='portrait-zoom';portraitZoom.hidden=true;portraitZoom.setAttribute('aria-label','Icon zoom');portraitZoom.oninput=setPortraitZoom;
      const portraitFile=document.createElement('input');portraitFile.type='file';portraitFile.accept='image/png,image/webp';portraitFile.hidden=true;portraitFile.onchange=()=>{const f=portraitFile.files?.[0];portraitFile.value='';importPortrait(f).catch(error);};
      portraitOptions.append(button('Headshot',()=>applyHeadshot().catch(error)),button('Frame character',()=>beginFrame().catch(error)),useFrame,portraitOwner,portraitZoom,button('Import icon',()=>portraitFile.click()),portraitFile);
      const duplicate=button('Save as copy',()=>{model.characterId=null;markDirty();status('This will save as a new character.');});
      const test=button('Test character',testCharacter);
      const side=$('parts').parentElement;side.insertBefore(owner,$('search'));side.insertBefore(state,$('search'));const materialLabel=document.createElement('label');materialLabel.className='label';materialLabel.textContent='Recolour scope';$('tools').after(materialLabel,material);const advanced=document.createElement('details'),summary=document.createElement('summary'),advancedTools=document.createElement('div');advanced.className='advanced';summary.textContent='More tools';advancedTools.className='advanced-tools';advanced.append(summary,advancedTools);advancedTools.append(duplicate);const viewGroup=document.createElement('div');viewGroup.className='tool-group';viewGroup.append(parts,portrait);const actionGroup=document.createElement('div');actionGroup.className='tool-group action-group';actionGroup.append(review,test,advanced);bar.append(viewGroup,portraitOptions,actionGroup);$('viewport').parentElement.insertBefore(bar,$('viewport'));if(window.innerWidth<1000)$('parts').parentElement.hidden=true;
      const exportButton=button('Export skin',exportCurrent),importButton=button('Import skin',importSkinFile);advancedTools.append(exportButton,importButton,button('Open skin folder',()=>{if(!model.characterId){status('Save this character first.');return;}window.hwCharacterCreator.openFolder(model.characterId).catch(error);}),button('Flip view',()=>{if(stroke)pointerUp();model.viewFlip=!model.viewFlip;showView('body');status('Preview direction changed. The character’s gameplay physics are unchanged.');}));const compare=button('Compare original',()=>{if(stroke)pointerUp();model.compareOriginal=!model.compareOriginal;compare.textContent=model.compareOriginal?'Show edited':'Compare original';showView('body');status(model.compareOriginal?'Showing original artwork. Choose Show edited to continue painting.':'Showing your edited artwork.');});compare.dataset.id='compare-original';advancedTools.append(compare);
      const map=button('Map selected part',mapPart),links=button('Link artwork',linkArtwork),reset=button('Reset part',()=>{if(!key){status('Select a texture first.');return;}if(stroke)pointerUp();const piece=ensurePart(key),g=piece.getContext('2d'),before=g.getImageData(0,0,piece.width,piece.height),after=P.region(model.originalSheet,model.atlas.frames[key]).getContext('2d').getImageData(0,0,piece.width,piece.height),beforeMask=new Uint8Array(model.paintMasks.get(key)||piece.width*piece.height),afterMask=new Uint8Array(piece.width*piece.height);g.putImageData(after,0,0);model.paintMasks.set(key,afterMask);commitPart(key);if(history.push({docId:model.docId,type:'reset',changes:[{key,before,after,beforeMask,afterMask}]}))noteHistory();showPartSurface();publishSheet();updateHistory();});advancedTools.append(map,links,reset);
      const c=$('paint'),viewport=$('viewport');let panning=null,space=false;
      panel.addEventListener('keydown',e=>{if(e.code==='Space'&&!['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName)){space=true;e.preventDefault();}});panel.addEventListener('keyup',e=>{if(e.code==='Space')space=false;});
      c.addEventListener('pointerdown',e=>{if(space||e.button===1){e.preventDefault();e.stopImmediatePropagation();panning={x:e.clientX,y:e.clientY,left:viewport.scrollLeft,top:viewport.scrollTop};c.setPointerCapture(e.pointerId);}},true);
      c.addEventListener('pointermove',e=>{if(panning){viewport.scrollLeft=panning.left-(e.clientX-panning.x);viewport.scrollTop=panning.top-(e.clientY-panning.y);e.stopImmediatePropagation();}},true);c.addEventListener('pointerup',e=>{if(panning){panning=null;e.stopImmediatePropagation();}},true);
      viewport.addEventListener('wheel',e=>{if(!e.ctrlKey&&!e.metaKey)return;e.preventDefault();const rect=c.getBoundingClientRect(),x=e.clientX-rect.left,y=e.clientY-rect.top,old=zoom;scale(zoom*(e.deltaY<0?1.12:1/1.12));viewport.scrollLeft+=x*(zoom/old-1);viewport.scrollTop+=y*(zoom/old-1);},{passive:false});
      const ring=document.createElement('div');ring.className='brush-ring';ring.hidden=true;panel.append(ring);c.addEventListener('pointermove',e=>{if(!['brush','eraser'].includes(tool)){ring.hidden=true;return;}const size=Number($('size').value)*zoom;ring.style.width=ring.style.height=size+'px';ring.style.left=e.clientX-size/2+'px';ring.style.top=e.clientY-size/2+'px';ring.hidden=false;});c.addEventListener('pointerleave',()=>ring.hidden=true);
    }
    const originalPush=history.push.bind(history);model.paintMasks=new Map(Object.entries(model.project?.paintMasks||{}).map(([k,v])=>[k,maskDecode(v)]));
    history.push=function(tx,before,after){if(typeof tx==='object'&&['brush','eraser','fill'].includes(tx.type)){const originals=[...tx.changes];for(const link of model.links||[]){const changed=originals.find(c=>c.key===link.source);if(!changed||originals.some(c=>c.key===link.target))continue;const piece=ensurePart(link.target),g=piece.getContext('2d'),before=g.getImageData(0,0,piece.width,piece.height),after=new ImageData(P.transfer(changed.before,changed.after,before,link.from,link.to,link.preserveDamage),piece.width,piece.height);if(before.data.every((v,i)=>v===after.data[i]))continue;g.putImageData(after,0,0);commitPart(link.target);tx.changes.push({key:link.target,before,after});}for(const change of tx.changes){const mask=model.paintMasks.get(change.key)||new Uint8Array(change.before.width*change.before.height);change.beforeMask=new Uint8Array(mask);for(let p=0,i=0;i<change.after.data.length;p++,i+=4)if([0,1,2,3].some(k=>change.before.data[i+k]!==change.after.data[i+k]))mask[p]=1;change.afterMask=new Uint8Array(mask);model.paintMasks.set(change.key,mask);}}return originalPush(tx,before,after);};
    if(model.project?.palette?.length){$('swatches').replaceChildren();for(const colour of model.project.palette.slice(0,24)){if(!/^#[0-9a-f]{6}$/i.test(colour))continue;const b=button('',()=>{$('color').value=colour;});b.style.background=colour;b.setAttribute('aria-label',colour);$('swatches').append(b);}}
    if(!$('keep-colour')){const b=button('Keep colour',()=>{const colour=$('color').value;if([...$('swatches').children].some(b=>b.getAttribute('aria-label')===colour))return;if($('swatches').children.length>=24){status('Your palette holds 24 colours.');return;}const swatch=button('',()=>{$('color').value=colour;});swatch.style.background=colour;swatch.setAttribute('aria-label',colour);$('swatches').append(swatch);markDirty();});b.dataset.id='keep-colour';$('swatches').after(b);}
    updateHistory();
  }
  function testCharacter(){
    if(busy||!model?.characterId||dirty){status('Save your character before testing.');return;}
    if(window.HWGhost?.lobby?.().room){status('Leave the multiplayer room before opening the private character test.');return;}
    try{
      const rt=window.HWCustomCharacters.creatorRuntime(),h=rt?.state.rootApp.screenManager.currentScreen?.happyWheels,Loader=rt?.require(0x183ff)?.Pu;
      if(!h||!Loader?.prototype?.loadXML)throw Error('The native test loader is unavailable in this game build.');
      const id=model.characterId,base=model.base,testId=899999991;
      const xml='<levelXML><info v="2.01" rv="1.99.2" x="400" y="5000" c="'+base+'" f="t" h="f" bg="0" bgc="16777215"/><shapes><sh t="0" p0="1400" p1="5250" p2="3600" p3="50" p4="0" p5="t" p6="f" p7="1" p8="4032711" p9="-1" p10="100" p11="1"/><sh t="0" p0="1400" p1="5190" p2="300" p3="30" p4="-12" p5="t" p6="f" p7="1" p8="4032711" p9="-1" p10="100" p11="1"/></shapes><specials/><groups/><joints/><triggers/></levelXML>';
      if(!Loader.prototype.__creatorTest){const original=Loader.prototype.loadData;Loader.prototype.loadData=function(){if(Number(this.levelId)!==testId||!Loader.prototype.__creatorTestXML)return original.apply(this,arguments);const previous=window.xml;window.xml=Loader.prototype.__creatorTestXML;try{return this.loadXML();}finally{if(previous===undefined)delete window.xml;else window.xml=previous;}};Loader.prototype.__creatorTest=true;}
      Loader.prototype.__creatorTestXML=xml;window.HWCustomCharacters.choose(id);close();h.closeMainMenu?.();h.openSessionController({id:testId,name:'Character skin test',author_id:0,author_name:'Private creator',character:base,forceChar:true,plays:0,rating:0},null);
      document.getElementById('hw-creator-test-return')?.remove();const back=button('Back to character creator',()=>{try{h.closeSessionController?.();h.openMainMenu?.();}finally{back.remove();open();editSaved(id);}});back.id='hw-creator-test-return';back.style.cssText='position:fixed;left:20px;bottom:24px;z-index:25000;background:#ff9083;color:#231b19;border:0;border-radius:6px;padding:12px;font:bold 14px Trebuchet MS;cursor:pointer';document.body.append(back);
    }catch(e){if(panel)error(e);else console.error('[Character creator test]',e);}
  }
  function statusAfterClose(text){console.info('[Character creator]',text);}
  function linkArtwork(){
    if(!key){status('Select the normal texture you want to draw on first.');return;}if(stroke)pointerUp();
    if(!role(key).verified){status('Identify this part before linking artwork.');return;}const sourceKey=key,cover=document.createElement('section');cover.className='portrait-editor';const card=document.createElement('div');card.className='portrait-card';const h=document.createElement('h2');h.textContent='Link drawing to an alternate texture';const p=document.createElement('p');p.textContent='Choose a matching variant. Click the same three landmarks on both pictures, in the same order. Future brush strokes on the left will also update the right. Missing regions and existing transparency stay protected.';
    const candidates=model.frames.filter(([k])=>k!==sourceKey&&role(k).owner===role(sourceKey).owner&&role(k).family===role(sourceKey).family),target=picker(candidates.map(([k])=>[k,role(k).state+' · '+label(k)]),'Target variant');
    if(!candidates.length){status('No matching variants are mapped. Identify them with Map selected part first.');return;}
    const left=canvas(320,320),right=canvas(320,320),from=[],to=[];let rectangles=[];
    function draw(){rectangles=[];for(const [i,c,k,points]of [[0,left,sourceKey,from],[1,right,target.value,to]]){const piece=ensurePart(k),g=c.getContext('2d'),scale=Math.min(290/piece.width,290/piece.height),x=(320-piece.width*scale)/2,y=(320-piece.height*scale)/2;g.clearRect(0,0,320,320);g.drawImage(piece,x,y,piece.width*scale,piece.height*scale);rectangles[i]={x,y,scale};for(let n=0;n<points.length;n++){g.fillStyle='#ff9083';g.beginPath();g.arc(x+points[n].x*scale,y+points[n].y*scale,6,0,Math.PI*2);g.fill();g.fillStyle='#fff';g.font='bold 16px sans-serif';g.fillText(n+1,x+points[n].x*scale+8,y+points[n].y*scale);}}}
    for(const [i,c,points]of [[0,left,from],[1,right,to]]){c.style.cssText='width:100%;max-width:320px;background:#344147;cursor:crosshair';c.onpointerdown=e=>{if(points.length===3)return;const r=c.getBoundingClientRect(),a=rectangles[i],piece=ensurePart(i?target.value:sourceKey),x=((e.clientX-r.left)*320/r.width-a.x)/a.scale,y=((e.clientY-r.top)*320/r.height-a.y)/a.scale;if(x<0||y<0||x>=piece.width||y>=piece.height)return;points.push({x,y});draw();};}
    target.onchange=()=>{to.length=0;draw();};const row=document.createElement('div');row.style.cssText='display:grid;grid-template-columns:1fr 1fr;gap:20px';row.append(left,right);
    const hint=document.createElement('p');hint.textContent='Tip: use the joint, an outside corner, and an inside corner. Avoid three points on a straight line. Red injury detail is protected.';
    const controls=document.createElement('div');controls.append(button('Reset landmarks',()=>{from.length=to.length=0;draw();}),button('Save link',()=>{if(from.length!==3||to.length!==3){hint.textContent='Place three landmarks on each picture.';return;}try{P.affine(from,to);P.affine(to,from);}catch(e){hint.textContent=e.message;return;}const beforeLinks=model.links;model.links=[...beforeLinks.filter(l=>!(l.source===sourceKey&&l.target===target.value)),{source:sourceKey,target:target.value,from:[...from],to:[...to],preserveDamage:true}];history.push({docId:model.docId,type:'links',beforeLinks,afterLinks:model.links,changes:[{key:'__settings',before:{data:[0]},after:{data:[1]}}]});noteHistory();updateHistory();cover.remove();status('Link saved. Future drawing on this texture updates the linked variant in one undo step.');}),button('Remove links from this part',()=>{const beforeLinks=model.links;model.links=beforeLinks.filter(l=>l.source!==sourceKey);history.push({docId:model.docId,type:'links',beforeLinks,afterLinks:model.links,changes:[{key:'__settings',before:{data:[0]},after:{data:[1]}}]});noteHistory();updateHistory();cover.remove();}),button('Cancel',()=>cover.remove()));card.append(h,p,target,row,hint,controls);cover.append(card);panel.append(cover);draw();
  }
  function mapPart(){if(!key){status('Select a texture first.');return;}const old=role(key),cover=document.createElement('div');cover.className='confirm';const box=document.createElement('div'),h=document.createElement('h2');h.textContent='Identify this texture';const owner=picker([['rider','Rider'],['passenger','Passenger'],['vehicle','Vehicle'],['unknown','Unknown']],'Part owner'),family=picker(['head','head accessory','torso','upper arm','lower arm','pelvis','upper leg','lower leg','foot','vehicle','detail','unmapped'].map(x=>[x,x]),'Part family');owner.value=old.owner;family.value=old.family;box.append(h,owner,family,button('Apply',()=>{const beforeRoles={...model.roleOverrides};model.roleOverrides={...beforeRoles,[key]:{...old,owner:owner.value,family:family.value,verified:owner.value!=='unknown'&&family.value!=='unmapped'}};history.push({docId:model.docId,type:'mapping',beforeRoles,afterRoles:model.roleOverrides,changes:[{key:'__settings',before:{data:[0]},after:{data:[1]}}]});noteHistory();updateHistory();makeParts();cover.remove();}),button('Cancel',()=>cover.remove()));cover.append(box);panel.append(cover);}
  function recolourCharacter(at){const hit=visibleHit(at.x,at.y);if(!hit?.key||hit.blocked){status('Click a material on the character to recolour all its linked variants.');return;}applyRecolour(hit.key,hit.x,hit.y);}
  function recolourPart(at){if(key)applyRecolour(key,Math.floor(at.x),Math.floor(at.y));}
  function applyRecolour(k,x,y){
    const selected=role(k);if(!selected.verified){status('Map this texture before linking its colours. You can still paint it with Brush.');return;}
    const reference=P.region(model.originalSheet,model.atlas.frames[k]),ctx=reference.getContext('2d');x=Math.min(reference.width-1,Math.max(0,x));y=Math.min(reference.height-1,Math.max(0,y));const sampled=[...ctx.getImageData(x,y,1,1).data];if(!sampled[3])return;
    const beforeMaterials={...model.materials},material=$('material').value,groups={skin:['head','head accessory','torso','upper arm','lower arm','pelvis','upper leg','lower leg'],shirt:['torso','upper arm'],trousers:['pelvis','upper leg'],shoes:['foot','lower leg'],hair:['head','head accessory'],vehicle:['vehicle']};const allowed=groups[material]||[selected.family],color=rgba(),changes=[];
    for(const [frameKey,item] of model.frames){const r=role(frameKey);if(r.owner!==selected.owner||!r.verified||!allowed.includes(r.family)||r.family==='detail')continue;const piece=ensurePart(frameKey),g=piece.getContext('2d'),before=g.getImageData(0,0,piece.width,piece.height),baseline=P.region(model.originalSheet,item).getContext('2d').getImageData(0,0,piece.width,piece.height);const next=P.recolour(baseline.data,before.data,piece.width,piece.height,sampled,color,Math.max(20,Number($('tolerance').value)),model.paintMasks.get(frameKey),r.state==='alternate');const after=new ImageData(next,piece.width,piece.height);if(before.data.every((v,i)=>v===after.data[i]))continue;g.putImageData(after,0,0);commitPart(frameKey);changes.push({key:frameKey,before,after});}
    model.materials={...beforeMaterials,[selected.owner+':'+material]:{from:sampled.slice(0,3),to:color.slice(0,3)}};if(history.push({docId:model.docId,type:'recolour',beforeMaterials,afterMaterials:model.materials,changes}))noteHistory();publishSheet();updateHistory();if(model.view==='part')showPartSurface();status('Recoloured '+changes.length+' linked textures. Shading, outlines, and your brush marks are preserved. Red damage detail is protected in identified damage frames. Review every alternate frame before saving.');
  }
  async function makePortrait(recipe={}){
    const mode=recipe.mode||model.iconMode,cropRecipe=recipe.crop===undefined?model.iconCrop:recipe.crop,ownerRecipe=recipe.owner||model.iconOwner||'rider';const out=canvas(128,128),g=out.getContext('2d');if(mode==='manual'&&model.manualIcon){const img=await image(model.manualIcon);g.drawImage(img,0,0,128,128);return out;}
    captureSnapshot();const snap=preview.snapshot,b=preview.bounds;let crop=cropRecipe;
    if(!crop){const head=preview.pose.items.filter(i=>{const r=role(i.key);return r.owner===ownerRecipe&&['head','head accessory'].includes(r.family);});if(head.length){let x0=Infinity,y0=Infinity,x1=-Infinity,y1=-Infinity;for(const inst of head)for(const [x,y] of [[0,0],[inst.partW,0],[0,inst.partH],[inst.partW,inst.partH]]){const p=P.partPixelToCharacter(inst,x,y);x0=Math.min(x0,p.x);y0=Math.min(y0,p.y);x1=Math.max(x1,p.x);y1=Math.max(y1,p.y);}const size=Math.max(x1-x0,y1-y0)*1.35;crop={x:(x0+x1)/2-b.x-size/2,y:(y0+y1)/2-b.y-size/2,size};}else{const size=Math.max(b.width,b.height);crop={x:(b.width-size)/2,y:(b.height-size)/2,size};}}
    const density=preview.snapshotScale||1;g.drawImage(snap,crop.x*density,crop.y*density,crop.size*density,crop.size*density,4,4,120,120);return out;
  }
  async function ensurePortrait(){if(!model.portrait)model.portrait=canvas(128,128);if(model.portraitReady)return;const icon=await makePortrait();model.portrait.getContext('2d').clearRect(0,0,128,128);model.portrait.getContext('2d').drawImage(icon,0,0,128,128);model.portraitReady=true;}
  async function showPortrait(){if(!model||busy)return;if(stroke)pointerUp();await ensurePortrait();model.portraitFraming=false;if($('portrait-owner'))$('portrait-owner').value=model.iconOwner||'rider';showView('portrait');status('This is the menu icon. Paint with the same tools, or start from a headshot or a framed character.');}
  function commitPortrait(beforePixels,beforeIcon){const after=model.portrait.getContext('2d').getImageData(0,0,128,128);if(history.push({docId:model.docId,type:'portrait',beforeIcon,afterIcon:iconSnapshot(),changes:[{key:'__portrait',before:beforePixels,after}]}))noteHistory();else Object.assign(model,{iconMode:beforeIcon.mode,manualIcon:beforeIcon.manual,iconCrop:beforeIcon.crop,iconOwner:beforeIcon.owner});updateHistory();}
  async function applyHeadshot(){if(!model||busy)return;if(stroke)pointerUp();await ensurePortrait();const beforeIcon=iconSnapshot(),before=model.portrait.getContext('2d').getImageData(0,0,128,128),icon=await makePortrait({mode:'auto',crop:null,owner:model.iconOwner||'rider'}),g=model.portrait.getContext('2d');g.clearRect(0,0,128,128);g.drawImage(icon,0,0);model.portraitFraming=false;model.iconMode='auto';model.manualIcon=null;model.iconCrop=null;commitPortrait(before,beforeIcon);showView('portrait');status('Automatic headshot is on the icon. Paint over it with the normal tools if you want to change it.');}
  async function beginFrame(){if(!model||busy)return;if(stroke)pointerUp();await ensurePortrait();captureSnapshot();const b=preview.bounds,size=Math.max(b.width,b.height)*100/Number($('portrait-zoom')?.value||100);model.portraitCrop=model.iconCrop?.size?{x:model.iconCrop.x,y:model.iconCrop.y,size:model.iconCrop.size}:{x:(b.width-size)/2,y:(b.height-size)/2,size};model.portraitFraming=true;showView('portrait');status('Drag the frame. The zoom slider changes how much of the character it includes.');}
  function setPortraitZoom(){if(!model?.portraitFraming||!preview?.bounds)return;const b=preview.bounds,size=Math.max(b.width,b.height)*100/Number($('portrait-zoom').value||100),crop=model.portraitCrop||{x:0,y:0,size},cx=crop.x+crop.size/2,cy=crop.y+crop.size/2;model.portraitCrop={x:cx-size/2,y:cy-size/2,size};renderWork();}
  async function applyFrame(){if(!model?.portraitFraming)return;if(stroke)pointerUp();const beforeIcon=iconSnapshot(),before=model.portrait.getContext('2d').getImageData(0,0,128,128),icon=await makePortrait({mode:'crop',crop:model.portraitCrop,owner:model.iconOwner||'rider'}),g=model.portrait.getContext('2d');g.clearRect(0,0,128,128);g.drawImage(icon,0,0);model.portraitFraming=false;model.iconMode='manual';model.iconCrop={x:model.portraitCrop.x,y:model.portraitCrop.y,size:model.portraitCrop.size};model.manualIcon=model.portrait.toDataURL('image/png');commitPortrait(before,beforeIcon);showView('portrait');status('Frame applied. Paint the icon with the same tools as the character.');}
  async function importPortrait(file){if(!model||!file||file.size>16*1024*1024){if(file)status('Choose an image smaller than 16 MB.');return;}await ensurePortrait();const url=URL.createObjectURL(file);try{const im=await image(url),beforeIcon=iconSnapshot(),before=model.portrait.getContext('2d').getImageData(0,0,128,128),g=model.portrait.getContext('2d'),fit=128/Math.max(im.width,im.height);g.clearRect(0,0,128,128);g.drawImage(im,(128-im.width*fit)/2,(128-im.height*fit)/2,im.width*fit,im.height*fit);model.portraitFraming=false;model.iconMode='manual';model.iconCrop=null;model.manualIcon=model.portrait.toDataURL('image/png');commitPortrait(before,beforeIcon);showView('portrait');status('Imported icon. Paint it with the same tools as the character.');}finally{URL.revokeObjectURL(url);}}
  function reviewStates(){if(!model)return;const cover=document.createElement('section');cover.className='portrait-editor';const card=document.createElement('div');card.className='portrait-card';const h=document.createElement('h2');h.textContent='Review every texture state';const p=document.createElement('p');p.textContent='Check rider, passenger, vehicle, and damaged artwork. Unmapped textures need your review; saving never changes the physics.';const grid=document.createElement('div');grid.className='review-grid';for(const [k,item] of model.frames){const r=role(k),b=button('',()=>{cover.remove();select(k);});const c=canvas(160,130),piece=ensurePart(k),scale=Math.min(150/piece.width,120/piece.height);c.getContext('2d').drawImage(piece,(160-piece.width*scale)/2,(130-piece.height*scale)/2,piece.width*scale,piece.height*scale);const label=document.createElement('small');label.textContent=r.owner+' · '+r.family+' · '+r.state+(r.verified?'':' · NEEDS REVIEW');b.append(c,label);grid.append(b);}card.append(h,p,button('Return to painting',()=>cover.remove()),grid);cover.append(card);panel.append(cover);}
  async function exportCurrent(){if(!model.characterId||dirty){status('Save your character before exporting.');return;}try{const data=await window.hwCharacterCreator.exportSkin(model.characterId),blob=new Blob([JSON.stringify(data)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=model.characterId+'.jskin';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);status('Exported your skin with its icon and editable project.');}catch(e){error(e);}}

  function buttonAlive(button){if(!button||button.destroyed||button._destroyed)return false;const node=button.pixiSprite||button;return !!(node&&!node.destroyed&&!node._destroyed);}
  function showMenuButton(button,on){for(const node of [button,button?.pixiSprite,button?.textField,button?.textField?.pixiSprite]){if(!node)continue;try{node.visible=on;}catch{}try{node.renderable=on;}catch{}try{node.alpha=on?1:0;}catch{}}try{button.interactive=on;}catch{}try{button.eventMode=on?'static':'none';}catch{}}
  function labelMenuButton(button){try{if(button.textField)button.textField.text='CUSTOM CHARACTERS';}catch{}try{if(typeof button.text==='string')button.text='CUSTOM CHARACTERS';}catch{}}
  function install(){
    const rt=window.HWCustomCharacters?.creatorRuntime?.(),menu=rt?.state.rootApp.screenManager.currentScreen?.happyWheels?.mainMenu;
    if(!menu?.optionsBtn||!Array.isArray(menu.buttons))return;
    const session=rt.state.currentSession,controller=rt.state.rootApp.screenManager.currentScreen.happyWheels.sessionController;
    const onTitle=!controller&&!(session&&!session.isMenu&&(session.m_world||session.containerSprite))&&menu.optionsBtn.visible!==false;
    let b=menu.characterCreatorBtn;
    const belongs=b&&(b.parent===menu||b.pixiSprite?.parent===menu.pixiSprite||b.pixiSprite?.parent===menu);
    if(b&&(!buttonAlive(b)||!belongs)){try{b.removeEventListener?.('click',open);}catch{}const index=menu.buttons.indexOf(b);if(index>=0){menu.buttons.splice(index,1);menu.spaceHeight=Math.max(0,(menu.spaceHeight||0)-(menu.buttonSpacing||0));}menu.characterCreatorBtn=null;b=null;}
    if(panel?.isConnected){if(b)labelMenuButton(b);return;}
    if(!b){if(!onTitle)return;const ref=menu.optionsBtn,format=ref.textField?.defaultTextFormat||{};b=new ref.constructor('CUSTOM CHARACTERS',format.size,format.color);b.addEventListener('click',open);try{b.interactive=true;b.eventMode='static';}catch{}menu.characterCreatorBtn=b;menu.addChild(b);const at=menu.buttons.indexOf(menu.multiplayerBtn);menu.buttons.splice(at<0?menu.buttons.indexOf(ref):at+1,0,b);menu.spaceHeight=(menu.spaceHeight||0)+(menu.buttonSpacing||0);try{menu.organizeButtons();}catch{}}
    labelMenuButton(b);
    const list=menu.buttons,index=list.indexOf(b),gap=menu.buttonSpacing||0;
    if(onTitle){if(index<0){const mp=list.indexOf(menu.multiplayerBtn),at=mp>=0?mp+1:list.indexOf(menu.optionsBtn);list.splice(at<0?list.length:at,0,b);menu.spaceHeight=(menu.spaceHeight||0)+gap;try{menu.organizeButtons();}catch{}}showMenuButton(b,true);b.x=menu.optionsBtn.x;}
    else if(index>=0){list.splice(index,1);menu.spaceHeight=Math.max(0,(menu.spaceHeight||0)-gap);try{menu.organizeButtons();}catch{}showMenuButton(b,false);}
  }
  window.HWCharacterCreator={open,close,diagnostics:()=>({open:!!panel,base:model?.base,part:key,dirty,previewParts:preview?.hits.length||0,version:'0.5.0',sheet:model?{width:model.sheet.width,height:model.sheet.height}:null,historyBytes:history?.bytes||0,links:model?.links?.length||0})};
  setInterval(()=>{try{install();}catch(e){console.warn('[Character creator menu]',e.message);}},500);
})();
