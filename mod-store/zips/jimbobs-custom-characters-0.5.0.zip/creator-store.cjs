"use strict";
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const templates=require('./creator-templates.cjs');
const NAMES=['Wheelchair Guy','Segway Guy','Irresponsible Dad','Effective Shopper','Moped Couple','Lawnmower Man','Explorer Guy','Santa','Pogo Stick Man','Irresponsible Mom','Helicopter Man'];
const VERSION=2;
function png(data){
 if(typeof data!=='string'||data.length>48*1024*1024||!/^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(data))throw Error('Invalid PNG image.');
 const b=Buffer.from(data.split(',')[1],'base64');if(b.length<33||b.subarray(0,8).toString('hex')!=='89504e470d0a1a0a'||b.toString('ascii',12,16)!=='IHDR')throw Error('Invalid PNG header.');
 const width=b.readUInt32BE(16),height=b.readUInt32BE(20);if(!width||!height||width>8192||height>8192||width*height>32*1024*1024)throw Error('Image dimensions are too large.');return {bytes:b,width,height};
}
function validateProject(project,atlas,validateImage){
 if(!project)return;if(typeof project!=='object'||Array.isArray(project)||JSON.stringify(project).length>48*1024*1024)throw Error('Invalid or oversized editor project.');
 for(const [key,value]of Object.entries(project.paintMasks||{})){const item=atlas.frames[key];if(!item)throw Error('Project mask uses an unknown texture.');const count=item.frame.w*item.frame.h,length=typeof value==='string'?Buffer.from(value,'base64').length:Array.isArray(value)?value.length:-1;if(length!==count)throw Error('Project mask dimensions do not match the texture.');}
 for(const link of project.links||[]){const source=atlas.frames[link.source],target=atlas.frames[link.target];if(!source||!target)throw Error('Linked texture is unavailable.');for(const [points,item]of [[link.from,source],[link.to,target]]){const w=item.rotated?item.frame.h:item.frame.w,h=item.rotated?item.frame.w:item.frame.h;if(!Array.isArray(points)||points.length!==3||points.some(p=>!Number.isFinite(p.x)||!Number.isFinite(p.y)||p.x<0||p.y<0||p.x>w||p.y>h))throw Error('Invalid texture landmarks.');require('./web/creator-paint.js').affine(points,points);}}
 if((project.links||[]).length>1024)throw Error('Too many texture links.');
 for(const key of ['originalSheet','manualIcon'])if(project[key]){const image=png(project[key]),expected=key==='manualIcon'?{w:128,h:128}:atlas.meta.size;if(image.width!==expected.w||image.height!==expected.h)throw Error('Project image dimensions do not match.');validateImage?.(image);}
}
function createStore(modRoot,webroot,options={}){
 const packagedRoot=path.join(modRoot,'web','characters'),characterRoot=options.libraryRoot||packagedRoot,servedRoot=path.join(webroot,'js','jimbobs-custom-characters','characters');
 const draftRoot=options.projectRoot||path.join(modRoot,'creator-projects');
 function safeId(id){if(typeof id!=='string'||id.length>64||!/^[a-z0-9][a-z0-9-]*$/i.test(id))throw Error('Unknown character.');return id;}
 function safeFile(file){if(typeof file!=='string'||!file||file.includes('..')||file.includes('\\')||path.isAbsolute(file)||/^[a-z]+:/i.test(file))throw Error('Invalid character asset path.');return file;}
 function readJson(f){return JSON.parse(fs.readFileSync(f,'utf8'));}
 function idsIn(root){if(!fs.existsSync(root))return [];return fs.readdirSync(root,{withFileTypes:true}).filter(e=>e.isDirectory()&&/^[a-z0-9][a-z0-9-]*$/i.test(e.name)&&fs.existsSync(path.join(root,e.name,'character.json'))).map(e=>e.name).sort();}
 function roots(){return [...new Set([characterRoot,packagedRoot,servedRoot])];}
 function replaceDirectory(root,id,write){
  fs.mkdirSync(root,{recursive:true});const nonce=crypto.randomUUID(),stage=path.join(root,`.creating-${id}-${nonce}`),dest=path.join(root,id),prior=path.join(root,`.previous-${id}`),journal=path.join(root,`.transaction-${id}.json`);
  if(fs.existsSync(journal))recover(root);
  fs.mkdirSync(stage);let moved=false,promoted=false;
  try{
   if(fs.existsSync(dest))fs.cpSync(dest,stage,{recursive:true});write(stage);
   fs.writeFileSync(journal,JSON.stringify({id,stage:path.basename(stage),previous:path.basename(prior)}));
   if(fs.existsSync(prior))fs.rmSync(prior,{recursive:true,force:true});
   if(fs.existsSync(dest)){fs.renameSync(dest,prior);moved=true;}
   fs.renameSync(stage,dest);promoted=true;index(root);fs.unlinkSync(journal);
   // Keep one recoverable version. It is outside the visible character index.
  }catch(error){
   if(promoted&&!moved&&fs.existsSync(dest))fs.rmSync(dest,{recursive:true,force:true});
   if(moved&&fs.existsSync(prior)){if(fs.existsSync(dest))fs.rmSync(dest,{recursive:true,force:true});fs.renameSync(prior,dest);}
   if(fs.existsSync(stage))fs.rmSync(stage,{recursive:true,force:true});if(fs.existsSync(journal))fs.unlinkSync(journal);throw error;
  }
 }
 function recover(root){if(!fs.existsSync(root))return;for(const e of fs.readdirSync(root)){if(!/^\.transaction-[a-z0-9-]+\.json$/i.test(e))continue;const file=path.join(root,e);try{const j=readJson(file),id=safeId(j.id);if(!/^\.creating-[a-z0-9-]+$/i.test(j.stage)||j.previous!=='.previous-'+id)throw Error('Invalid recovery journal');const dest=path.join(root,id),prior=path.join(root,j.previous),stage=path.join(root,j.stage);if(fs.existsSync(prior)){if(fs.existsSync(dest))fs.rmSync(dest,{recursive:true,force:true});fs.renameSync(prior,dest);}else if(!fs.existsSync(dest)&&fs.existsSync(stage))fs.renameSync(stage,dest);if(fs.existsSync(stage))fs.rmSync(stage,{recursive:true,force:true});fs.unlinkSync(file);}catch(e){console.warn('[Creator recovery]',e.message);}}}
 function index(root){if(!fs.existsSync(root))return;const ids=idsIn(root).filter(id=>{try{return readJson(path.join(root,id,'character.json')).enabled!==false;}catch{return false;}});const tmp=path.join(root,'.index-'+crypto.randomUUID()+'.tmp');fs.writeFileSync(tmp,JSON.stringify({characters:ids},null,2));fs.renameSync(tmp,path.join(root,'index.json'));}
 function migrate(){
  roots().forEach(recover);fs.mkdirSync(characterRoot,{recursive:true});
  if(characterRoot!==packagedRoot){for(const source of [packagedRoot,servedRoot])for(const id of idsIn(source)){const dest=path.join(characterRoot,id);if(!fs.existsSync(dest))fs.cpSync(path.join(source,id),dest,{recursive:true});}
   for(const id of idsIn(characterRoot)){const dest=path.join(packagedRoot,id);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.cpSync(path.join(characterRoot,id),dest,{recursive:true});}index(packagedRoot);}
  index(characterRoot);
 }
 function template(base){const a=templates.atlas(webroot,base);return {base,name:NAMES[base-1],atlas:a.data,fingerprint:a.fingerprint,pages:a.pages.map(p=>({...a.data.pages.find(x=>x.id===p.id),sheet:'data:image/png;base64,'+fs.readFileSync(p.image).toString('base64')})),sheet:a.pages.length===1?'data:image/png;base64,'+fs.readFileSync(a.pages[0].image).toString('base64'):null};}
 function availability(){return NAMES.map((name,i)=>{try{const a=templates.discover(webroot,i+1);return {base:i+1,name,available:true,pages:a.pages.length};}catch(e){return {base:i+1,name,available:false,error:e.message};}});}
 function readMeta(id){id=safeId(id);const data=readJson(path.join(characterRoot,id,'character.json')),base=Number(data.base);if(!Number.isInteger(base)||base<1||base>11)throw Error('Invalid character base.');return {id,name:String(data.name||id),base,enabled:data.enabled!==false,data};}
 function list(){return idsIn(characterRoot).map(id=>{try{const m=readMeta(id),f=path.join(characterRoot,id,safeFile(m.data.icon||'icon.png'));return {...m,data:undefined,revision:m.data.revision||'',community:m.data.community||null,icon:fs.existsSync(f)?'data:image/png;base64,'+fs.readFileSync(f).toString('base64'):''};}catch{return null;}}).filter(Boolean);}
 function load(id){const m=readMeta(id),dir=path.join(characterRoot,id),atlas=m.data.atlas?readJson(path.join(dir,safeFile(m.data.atlas))):templates.atlas(webroot,m.base).data;const icon=path.join(dir,safeFile(m.data.icon||'icon.png'));const project=path.join(dir,'project.json');return {id:m.id,name:m.name,base:m.base,enabled:m.enabled,atlas,revision:m.data.revision||'',community:m.data.community||null,sheet:'data:image/png;base64,'+fs.readFileSync(path.join(dir,safeFile(m.data.sheet||'sheet.png'))).toString('base64'),icon:fs.existsSync(icon)?'data:image/png;base64,'+fs.readFileSync(icon).toString('base64'):'',project:fs.existsSync(project)?readJson(project):null};}
 function publish(id){let published=true;for(const root of roots().filter(r=>r!==characterRoot)){try{replaceDirectory(root,id,stage=>fs.cpSync(path.join(characterRoot,id),stage,{recursive:true}));}catch{published=false;}}return published;}
 function save(input,validateImage){
  if(!input||typeof input.name!=='string'||!input.name.trim()||input.name.trim().length>60)throw Error('Enter a name between 1 and 60 characters.');
  const a=templates.atlas(webroot,input.base),sheet=png(input.sheet),icon=png(input.icon);if(sheet.width!==a.data.meta.size.w||sheet.height!==a.data.meta.size.h)throw Error('The sheet must keep the template dimensions.');if(icon.width!==128||icon.height!==128)throw Error('The portrait must be 128 × 128.');validateImage?.(sheet);validateImage?.(icon);
  const id=input.id?safeId(input.id):(input.name.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,40)||'character')+'-'+crypto.randomBytes(6).toString('hex');
  const old=path.join(characterRoot,id,'character.json'),prior=fs.existsSync(old)?readJson(old):{};
  if(prior.base&&Number(prior.base)!==input.base)throw Error('Changing a saved character base requires Save as copy.');
  const revision=crypto.createHash('sha256').update(sheet.bytes).update(icon.bytes).digest('hex');
  const manifest={...prior,name:input.name.trim(),base:input.base,sheet:'sheet-'+revision.slice(0,16)+'.png',icon:'icon-'+revision.slice(0,16)+'.png',atlas:'atlas.json',creatorVersion:VERSION,revision,templateFingerprint:a.fingerprint};
  if(input.community)manifest.community=input.community;
  const project=input.project||null;validateProject(project,a.data,validateImage);
  replaceDirectory(characterRoot,id,stage=>{for(const f of fs.readdirSync(stage))if(/^(sheet|icon)-[a-f0-9]{16}\.png$/.test(f)&&f!==manifest.sheet&&f!==manifest.icon)fs.unlinkSync(path.join(stage,f));fs.writeFileSync(path.join(stage,'sheet.png'),sheet.bytes);fs.writeFileSync(path.join(stage,'icon.png'),icon.bytes);fs.writeFileSync(path.join(stage,manifest.sheet),sheet.bytes);fs.writeFileSync(path.join(stage,manifest.icon),icon.bytes);fs.writeFileSync(path.join(stage,'atlas.json'),JSON.stringify(a.data));fs.writeFileSync(path.join(stage,'character.json'),JSON.stringify(manifest,null,2));if(project)fs.writeFileSync(path.join(stage,'project.json'),JSON.stringify(project));else if(input.community&&fs.existsSync(path.join(stage,'project.json')))fs.unlinkSync(path.join(stage,'project.json'));});
  return {id,...manifest,published:publish(id),folder:path.join(characterRoot,id)};
 }
 function setEnabled(id,enabled){const m=readMeta(id),next={...m.data};if(enabled)delete next.enabled;else next.enabled=false;replaceDirectory(characterRoot,m.id,stage=>fs.writeFileSync(path.join(stage,'character.json'),JSON.stringify(next,null,2)));return {id:m.id,enabled:!!enabled,published:publish(m.id)};}
 function remove(id){id=safeId(id);readMeta(id);fs.mkdirSync(path.join(characterRoot,'.trash'),{recursive:true});fs.renameSync(path.join(characterRoot,id),path.join(characterRoot,'.trash',id+'-'+Date.now()));index(characterRoot);let published=true;for(const root of roots().filter(r=>r!==characterRoot)){try{fs.rmSync(path.join(root,id),{recursive:true,force:true});index(root);}catch{published=false;}}return {id,published};}
 function draft(data){if(!data||!Number.isInteger(data.base)||typeof data.sheet!=='string')throw Error('Invalid draft.');const img=png(data.sheet),a=templates.atlas(webroot,data.base);if(img.width!==a.data.meta.size.w||img.height!==a.data.meta.size.h)throw Error('Draft dimensions do not match its template.');validateProject(data.project,a.data);if(JSON.stringify(data).length>64*1024*1024)throw Error('Draft is too large.');const id=safeId(data.docId||'working');fs.mkdirSync(draftRoot,{recursive:true});const dest=path.join(draftRoot,id+'.json'),tmp=dest+'.tmp';fs.writeFileSync(tmp,JSON.stringify({...data,savedAt:Date.now(),version:VERSION}));fs.renameSync(tmp,dest);return {id,savedAt:Date.now(),pixels:img.width*img.height};}
 function drafts(){if(!fs.existsSync(draftRoot))return [];return fs.readdirSync(draftRoot).filter(n=>/^[a-z0-9-]+\.json$/i.test(n)).map(n=>{try{const d=readJson(path.join(draftRoot,n));return {docId:d.docId,name:d.name,base:d.base,savedAt:d.savedAt};}catch{return null;}}).filter(Boolean).sort((a,b)=>b.savedAt-a.savedAt);}
 function loadDraft(id){return readJson(path.join(draftRoot,safeId(id)+'.json'));}
 function clearDraft(id){fs.rmSync(path.join(draftRoot,safeId(id)+'.json'),{force:true});}
 function exportSkin(id){const m=readMeta(id),dir=path.join(characterRoot,m.id),files={};for(const file of [m.data.sheet||'sheet.png',m.data.icon||'icon.png',m.data.atlas,m.data.profileFile,'project.json'].filter(Boolean)){const f=path.join(dir,safeFile(file));if(fs.existsSync(f))files[file]=fs.readFileSync(f).toString('base64');}return {format:'jimbob-skin',version:2,id:m.id,manifest:m.data,files};}
 function importSkin(pack,validateImage){if(!pack||pack.format!=='jimbob-skin'||pack.version!==2||!pack.manifest||!pack.files)throw Error('Choose a Jimbob skin export.');const m=pack.manifest;if(m.templateFingerprint&&templates.atlas(webroot,Number(m.base)).fingerprint!==m.templateFingerprint)throw Error('This skin uses a different game template version.');const sheet='data:image/png;base64,'+pack.files[safeFile(m.sheet||'sheet.png')],icon='data:image/png;base64,'+pack.files[safeFile(m.icon||'icon.png')];if(m.profileFile)throw Error('Physics-profile packages must be installed manually. This importer accepts cosmetic skins.');const originalId=pack.id?safeId(pack.id):null;return save({id:originalId&&!fs.existsSync(path.join(characterRoot,originalId))?originalId:undefined,name:m.name,base:Number(m.base),sheet,icon,project:pack.files['project.json']?JSON.parse(Buffer.from(pack.files['project.json'],'base64').toString()):null},validateImage);}

 function installCommunity(pack,info,server,options={},validateImage){
  if(!info||!/^[a-f0-9]{16}$/.test(info.id)||!Number.isSafeInteger(info.revision)||info.revision<1||!/^[a-f0-9]{64}$/.test(info.hash)||!/^[a-f0-9]{64}$/.test(info.artRevision))throw Error('Invalid community skin revision.');
  if(!pack||pack.format!=='jimbob-skin'||pack.version!==2||pack.manifest?.base!==info.base||pack.manifest?.name!==info.name||pack.manifest.sheet!=='sheet.png'||pack.manifest.icon!=='icon.png'||Object.keys(pack.files||{}).sort().join(',')!=='icon.png,sheet.png')throw Error('The community skin package is invalid.');
  if(info.templateFingerprint&&templates.atlas(webroot,info.base).fingerprint!==info.templateFingerprint)throw Error('This skin uses a different game template version. Update the game and Custom Characters mod before installing.');
  const id='community-'+info.id,existing=list().find(c=>c.id===id);
  if(existing){if(existing.community?.server!==server||existing.community.id!==info.id)throw Error('A different skin already uses this ID. Keep it or rename your local copy before installing.');
   if((existing.revision!==existing.community.artRevision||(existing.community.name&&existing.name!==existing.community.name))&&!options.replaceEdited)throw Error('This skin has local edits. Save it as a copy before updating, or confirm replacement.');
   if(options.expectedRevision!==existing.revision||(options.expectedName!=null&&options.expectedName!==existing.name))throw Error('Your local skin changed during the download. Refresh and try again.');
  }
  const sheet='data:image/png;base64,'+pack.files['sheet.png'],icon='data:image/png;base64,'+pack.files['icon.png'];
  if(crypto.createHash('sha256').update(png(sheet).bytes).update(png(icon).bytes).digest('hex')!==info.artRevision)throw Error('Skin artwork verification failed.');
  return save({id,name:info.name,base:info.base,sheet,icon,community:{server,id:info.id,name:info.name,revision:info.revision,hash:info.hash,artRevision:info.artRevision}},validateImage);
 }
 function sharingData(id){const m=readMeta(id),dir=path.join(characterRoot,m.id);return {base:m.base,name:m.name,templateFingerprint:m.data.templateFingerprint,profileFile:m.data.profileFile,sheet:'data:image/png;base64,'+fs.readFileSync(path.join(dir,safeFile(m.data.sheet||'sheet.png'))).toString('base64'),icon:'data:image/png;base64,'+fs.readFileSync(path.join(dir,safeFile(m.data.icon||'icon.png'))).toString('base64')};}
 return {version:VERSION,sharingData,template,availability,save,list,load,setEnabled,remove,migrate,recover,draft,drafts,loadDraft,clearDraft,exportSkin,importSkin,installCommunity,characterRoot};
}
module.exports={createStore,png,NAMES,VERSION};
