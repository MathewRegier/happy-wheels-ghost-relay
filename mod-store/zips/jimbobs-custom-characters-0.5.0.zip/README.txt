Jimbob's Custom Characters 0.5.0
Created by Jimbob · Discord jimbob1111

Fully quit Happy Wheels and launch it through Steam after installing.
Open Custom Characters on the title screen, beneath Multiplayer (or above
Options when Multiplayer is not installed).

Quick skin workflow
1. Create a new character and pick any of the eleven native templates.
2. Choose Recolour and a scope such as Shirt. Click the original material
   on the rider or passenger to change related, identified textures.
3. Use Brush to draw across the assembled character. One stroke can update
   several individual textures; one Undo restores the entire stroke.
4. Use Parts or Select part for detailed editing of one texture.
5. Use Icon to make a headshot, frame a crop, or import/draw a menu icon.
6. Review states to check every texture, then Save character.
7. Test character opens a private offline practice level. Back to character
   creator returns to editing. Leave a multiplayer room before testing.

More tools includes Save as copy, .jskin export/import, Open skin folder,
Flip view, Compare original, Map selected part, Link artwork, and Reset part.
Flip view changes the editing view only. It does not change gameplay physics.
On smaller windows, Parts opens the texture sidebar. Hold Space or use the
middle mouse button to pan. Ctrl+wheel zooms. B/E/F/I select paint tools;
Ctrl+Z / Ctrl+Y undo/redo and Ctrl+S saves.

Related artwork
Recolour uses the untouched source artwork, preserving its shading and
transparency. Hand-painted pixels are protected from later recolouring.
Ownership and part families are derived from the native character definitions.
Unknown/shared textures are marked Needs mapping and must be reviewed rather
than assigned to the wrong person automatically. Use Map selected part when
needed. Red detail is protected in identified damage frames; red clothes and
unidentified damage need visual review and may require individual painting.

A new drawing/logo cannot be reliably transferred to a differently shaped
fragment by colour replacement. Link artwork lets you identify three matching
landmarks on a normal texture and an alternate texture. Future strokes update
that linked target in the same Undo transaction, preserving target alpha and
red injury detail. Links are authored, not guessed by arbitrary resizing.

Saving and recovery
The authoritative library is in Happy Wheels application data:
  %APPDATA%\HappyWheels\JimbobCharacters\skins
Drafts are stored alongside it under drafts. Unsaved edits are autosaved after
a short pause and appear as Continue draft in Your characters after a restart.
Keep editing / Discard edits protects navigation. Deliberately discarded drafts
are removed. A saved skin keeps one previous version for recovery; deleted
skins are moved into a hidden .trash folder. The mod/game folders contain
runtime copies. Existing skins are migrated on launch and retained during
mod replacement by the updated local installer.

Sharing
Export .jskin and have your friend import it in Your characters. Import into a
library without that ID retains its identity for multiplayer lookup; importing
again into the same library creates a copy. Everyone needs the matching skin
installed to see it. Missing custom skins have a native-character fallback.
The creator produces cosmetic skins; physics-profile imports are not enabled.

When you have more custom characters than empty menu slots, arrows under the
character grid change pages. One page still shows 1 / 1. Saving updates names,
art, and icons without a full game restart. Disabled skins remain editable in
the library and stay outside the playable roster.

Community skins
Open Community skins in the creator library. Publish a saved character, or
browse and install other players' skins. Updates ask before replacing local
edits. The original uploader can update or remove their public listing.
Press = for the server address. The public library uses the same Railway
address as Jimbob Maps. Press Use default if a local test address is saved.
Publishing identity is encrypted in your HappyWheels user-data folder. Keep
that folder backed up to retain ownership access when changing computers.
Display names are not verified Steam identities. Players need Custom Characters
for skins; neither Builder nor Multiplayer is required for the skin library.
