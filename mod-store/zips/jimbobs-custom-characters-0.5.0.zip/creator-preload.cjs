'use strict';
const {contextBridge,ipcRenderer}=require('electron');
try{contextBridge.exposeInMainWorld('hwCharacterCreator',Object.freeze({
  version:2,
  community:Object.freeze(Object.fromEntries(['configure','list','preview','publish','install','remove'].map(name=>[name,arg=>ipcRenderer.invoke('hw-character:community-'+name,arg)]))),
  availability:()=>ipcRenderer.invoke('hw-character:availability'),
  draft:data=>ipcRenderer.invoke('hw-character:draft',data),
  drafts:()=>ipcRenderer.invoke('hw-character:drafts'),
  loadDraft:id=>ipcRenderer.invoke('hw-character:load-draft',id),
  clearDraft:id=>ipcRenderer.invoke('hw-character:clear-draft',id),
  exportSkin:id=>ipcRenderer.invoke('hw-character:export',id),
  importSkin:data=>ipcRenderer.invoke('hw-character:import',data),
  openFolder:id=>ipcRenderer.invoke('hw-character:folder',id),
  template:base=>ipcRenderer.invoke('hw-character:template',base),
  save:data=>ipcRenderer.invoke('hw-character:save',data),
  list:()=>ipcRenderer.invoke('hw-character:list'),
  load:id=>ipcRenderer.invoke('hw-character:load',id),
  setEnabled:(id,enabled)=>ipcRenderer.invoke('hw-character:enabled',id,enabled),
  remove:id=>ipcRenderer.invoke('hw-character:remove',id)
}));}catch(error){console.warn('[Character creator]',error.message);}
