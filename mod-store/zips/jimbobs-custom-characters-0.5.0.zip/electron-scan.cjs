'use strict';
const fs = require('node:fs');
const path = require('node:path');

function writeIndex(dir) {
  if (!fs.existsSync(dir) || !fs.statSync(dir).isDirectory()) return;
  const ids = [];
  for (const item of fs.readdirSync(dir, {withFileTypes: true})) {
    if (!item.isDirectory()) continue;
    if (!/^[a-z0-9][a-z0-9-]*$/i.test(item.name)) continue;
    const manifest = path.join(dir, item.name, 'character.json');
    if (!fs.existsSync(manifest)) continue;
    try { if (JSON.parse(fs.readFileSync(manifest, 'utf8')).enabled === false) continue; } catch { continue; }
    ids.push(item.name);
  }
  ids.sort((a, b) => a.localeCompare(b));
  fs.writeFileSync(path.join(dir, 'index.json'), `${JSON.stringify({characters: ids}, null, 2)}\n`);
}

writeIndex(path.join(__dirname, 'web', 'characters'));
writeIndex(path.join(__dirname, '..', '..', 'resources', 'webroot', 'js', 'jimbobs-custom-characters', 'characters'));

const {ipcMain,nativeImage,app,session,shell,safeStorage}=require('electron');
// Current game builds use a sandboxed preload. Register this standalone bridge
// after session creation instead of relying on nested require() in that sandbox.
app.whenReady().then(()=>{
  const preload=path.join(__dirname,'creator-preload.cjs');
  const list=session.defaultSession.getPreloads();
  if(!list.includes(preload))session.defaultSession.setPreloads([...list,preload]);
});
const {createStore}=require('./creator-store.cjs');
const store=createStore(__dirname,path.join(__dirname,'..','..','resources','webroot'),{libraryRoot:path.join(app.getPath('userData'),'JimbobCharacters','skins'),projectRoot:path.join(app.getPath('userData'),'JimbobCharacters','drafts')});
store.migrate();
function trusted(event){
  const url=new URL(event.senderFrame?.url||'about:blank');
  if(event.senderFrame!==event.sender.mainFrame||url.origin!=='https://totaljerkface.com'||!url.pathname.startsWith('/__hw_app__/'))throw Error('Invalid character creator sender.');
}
ipcMain.handle('hw-character:template',(event,base)=>{trusted(event);return store.template(base);});
ipcMain.handle('hw-character:list',event=>{trusted(event);return store.list();});
ipcMain.handle('hw-character:load',(event,id)=>{trusted(event);return store.load(id);});
ipcMain.handle('hw-character:enabled',(event,id,enabled)=>{trusted(event);return store.setEnabled(id,!!enabled);});
ipcMain.handle('hw-character:remove',(event,id)=>{trusted(event);return store.remove(id);});
ipcMain.handle('hw-character:save',(event,data)=>{trusted(event);return store.save(data,image=>{
  const decoded=nativeImage.createFromBuffer(image.bytes),size=decoded.getSize();
  if(decoded.isEmpty()||size.width!==image.width||size.height!==image.height)throw Error('The image could not be decoded.');
});});

function validateImage(image){const decoded=nativeImage.createFromBuffer(image.bytes),size=decoded.getSize();if(decoded.isEmpty()||size.width!==image.width||size.height!==image.height)throw Error('The image could not be decoded.');}
for(const [channel,fn] of Object.entries({'availability':()=>store.availability(),'draft':data=>store.draft(data),'drafts':()=>store.drafts(),'load-draft':id=>store.loadDraft(id),'clear-draft':id=>store.clearDraft(id),'export':id=>store.exportSkin(id),'import':data=>store.importSkin(data,validateImage),'folder':async id=>{if(!store.list().some(c=>c.id===id))throw Error('Unknown character.');const error=await shell.openPath(path.join(store.characterRoot,id));if(error)throw Error(error);return true;}}))ipcMain.handle('hw-character:'+channel,(event,arg)=>{trusted(event);return fn(arg);});

const community=require('./community-client.cjs').createCommunityClient({directory:app.getPath('userData'),safeStorage,store,validateImage});
for(const name of ['configure','list','preview','publish','install','remove'])ipcMain.handle('hw-character:community-'+name,(event,arg)=>{trusted(event);return community[name](arg);});
