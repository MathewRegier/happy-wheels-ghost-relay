// Native ragdoll reflection. Solver, contacts, snapshots and paint stay physical;
// character controls and construction see the original character coordinates.
// Direct vehicle fields use that same view only while a left-facing rider is in control.
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else{const api=root.HWJimbobFacing||factory();root.HWJimbobFacing=api;root.HWBuilderFacing=api;}})(typeof window==='object'?window:globalThis,()=>{
  'use strict';
  let current=null;
  const worlds=new WeakMap(),bodies=new WeakSet(),shapes=new WeakSet(),joints=new WeakSet(),scales=new WeakMap(),angleBox=new WeakMap();
  const copy=o=>Object.assign(Object.create(Object.getPrototypeOf(o)),o);
  function vector(v,x,y){if(!v)return v;const result=copy(v);result.x=x;result.y=y;return result;}
  const local=v=>vector(v,-v.x,v.y);
  const point=(v,a)=>vector(v,2*a.mirrorX-v.x,v.y);
  function physical(fn){const old=current;current=null;try{return fn();}finally{current=old;}}
  function run(actor,fn){const old=current;current=actor?.facing==='left'?actor:null;try{return fn();}finally{current=old;}}
  // Screen-relative Left/Right is applied once, in the shared checkKeyStates
  // dispatch. This scope only changes the physics coordinates.
  const controls=run;
  // A live view, not a copy: vehicle code mutates these fields in place.
  // Outside control, callers still receive the solver's own objects.
  function axis(raw,key,flip){
    return {enumerable:true,configurable:true,
      get(){return flip&&current?-raw[key]:raw[key];},
      set(v){raw[key]=flip&&current?-v:v;}};
  }
  function vecView(raw,flipX){
    const view=Object.create(Object.getPrototypeOf(raw));
    Object.defineProperty(view,'x',axis(raw,'x',flipX));
    Object.defineProperty(view,'y',axis(raw,'y',false));
    return view;
  }
  function matView(raw){
    const view=Object.create(Object.getPrototypeOf(raw));
    const col1=vecView(raw.col1,false),col2=vecView(raw.col2,false);
    Object.defineProperty(col1,'y',axis(raw.col1,'y',true));
    Object.defineProperty(col2,'x',axis(raw.col2,'x',true));
    const adopt=(col,value)=>{col.x=value.x;col.y=value.y;};
    Object.defineProperty(view,'col1',{enumerable:true,configurable:true,get(){return col1;},set(v){adopt(col1,v);}});
    Object.defineProperty(view,'col2',{enumerable:true,configurable:true,get(){return col2;},set(v){adopt(col2,v);}});
    return view;
  }
  function pointView(raw){
    const view=Object.create(Object.getPrototypeOf(raw));
    Object.defineProperty(view,'x',{enumerable:true,configurable:true,get(){return current?2*current.mirrorX-raw.x:raw.x;},set(v){raw.x=current?2*current.mirrorX-v:v;}});
    Object.defineProperty(view,'y',axis(raw,'y',false));
    return view;
  }
  function xfView(raw){
    const view=Object.create(Object.getPrototypeOf(raw));
    const position=pointView(raw.position),R=matView(raw.R);
    Object.defineProperty(view,'position',{enumerable:true,configurable:true,get(){return position;},set(v){position.x=v.x;position.y=v.y;}});
    Object.defineProperty(view,'R',{enumerable:true,configurable:true,get(){return R;},set(v){R.col1=v.col1;R.col2=v.col2;}});
    return view;
  }
  function virtualNumber(obj,key,flip){
    if(!obj||!(key in obj)||Object.getOwnPropertyDescriptor(obj,key)?.get)return;
    let value=obj[key];
    Object.defineProperty(obj,key,{enumerable:true,configurable:true,
      get(){return flip&&current?-value:value;},
      set(v){value=flip&&current?-v:v;}});
  }
  function virtualVector(obj,key,flipX){
    if(!obj?.[key]||Object.getOwnPropertyDescriptor(obj,key)?.get)return;
    const raw=obj[key],view=vecView(raw,flipX);
    Object.defineProperty(obj,key,{enumerable:true,configurable:true,
      get(){return current?view:raw;},
      set(v){raw.x=flipX&&current?-v.x:v.x;raw.y=v.y;}});
  }
  function virtualTransform(obj){
    if(!obj?.m_xf||Object.getOwnPropertyDescriptor(obj,'m_xf')?.get)return;
    const raw=obj.m_xf,view=xfView(raw);
    Object.defineProperty(obj,'m_xf',{enumerable:true,configurable:true,
      get(){return current?view:raw;},
      set(v){if(!current){raw.position.x=v.position.x;raw.position.y=v.position.y;raw.R.col1.x=v.R.col1.x;raw.R.col1.y=v.R.col1.y;raw.R.col2.x=v.R.col2.x;raw.R.col2.y=v.R.col2.y;return;}view.position=v.position;view.R=v.R;}});
  }
  function virtualizeBody(b){virtualTransform(b);virtualVector(b,'m_linearVelocity',true);virtualNumber(b,'m_angularVelocity',true);}
  function virtualizeJoint(j){
    if(!j||angleBox.has(j)||!('m_lowerAngle' in j))return;
    const raw={lower:j.m_lowerAngle,upper:j.m_upperAngle};
    angleBox.set(j,raw);
    Object.defineProperty(j,'m_lowerAngle',{enumerable:true,configurable:true,get(){return current?-raw.upper:raw.lower;},set(v){if(current)raw.upper=-v;else raw.lower=v;}});
    Object.defineProperty(j,'m_upperAngle',{enumerable:true,configurable:true,get(){return current?-raw.lower:raw.upper;},set(v){if(current)raw.lower=-v;else raw.upper=v;}});
    virtualNumber(j,'m_motorSpeed',true);
  }
  function shape(def){
    const d=copy(def);
    if(d.vertices&&d.vertexCount){d.vertices=d.vertices.slice();for(let i=0;i<d.vertexCount;i++)d.vertices[i]=local(def.vertices[d.vertexCount-1-i]);}
    for(const k of ['localPosition','localCenter'])if(d[k])d[k]=local(d[k]);
    return d;
  }
  function shapeMethods(s){
    if(!s||shapes.has(s))return s;shapes.add(s);
    // Reversing winding also reorders vertices. Native hands use vertex 2 as
    // their grip endpoint; restore that semantic order in the control view.
    for(const key of ['GetVertices','GetCoreVertices','GetNormals']){
      const original=s[key];if(typeof original!=='function')continue;
      s[key]=function(...args){const a=current,v=physical(()=>original.apply(this,args));if(!a||!v)return v;
        const n=this.m_vertexCount||v.length,result=v.slice();
        for(let i=0;i<n;i++)result[i]=local(v[key==='GetNormals'?(n-2-i+n)%n:n-1-i]);
        return result;
      };
    }
    return s;
  }
  function body(b){
    if(!b)return b;
    for(let s=b.GetShapeList?.();s;s=s.GetNext?.())shapeMethods(s);
    if(bodies.has(b))return b;bodies.add(b);virtualizeBody(b);
    const wrap=(key,args,result)=>{const original=b[key];if(typeof original!=='function')return;
      b[key]=function(...values){const a=current;if(!a)return original.apply(this,values);
        const out=physical(()=>original.apply(this,args?args(values,a):values));return result?result(out,a):out;};};
    for(const key of ['GetPosition','GetWorldCenter','GetInterpolatedPosition','GetInterpolatedWorldCenter'])wrap(key,null,point);
    for(const key of ['GetLinearVelocity','GetInterpolatedLinearVelocity'])wrap(key,null,local);
    for(const key of ['GetAngle','GetAngularVelocity','GetInterpolatedAngle'])wrap(key,null,v=>-v);
    wrap('GetInterpolatedWorldPoint',v=>[local(v[0])],point);
    wrap('GetInterpolatedXForm',null,(xf,a)=>{
      if(!a||!xf?.position)return xf;
      const out=copy(xf);out.position=point(xf.position,a);
      if(xf.R){const R=copy(xf.R);if(R.col1){R.col1=copy(R.col1);R.col1.y=-xf.R.col1.y;}if(R.col2){R.col2=copy(R.col2);R.col2.x=-xf.R.col2.x;}out.R=R;}
      return out;
    });
    wrap('GetLocalCenter',null,local);
    for(const key of ['SetXForm','SetTransform'])wrap(key,(v,a)=>[point(v[0],a),-v[1]]);
    wrap('SetLinearVelocity',v=>[local(v[0])]);wrap('SetAngularVelocity',v=>[-v[0]]);wrap('ApplyTorque',v=>[-v[0],...v.slice(1)]);
    for(const key of ['ApplyForce','ApplyImpulse'])wrap(key,(v,a)=>[local(v[0]),point(v[1],a),...v.slice(2)]);
    wrap('GetWorldPoint',v=>[local(v[0])],point);
    wrap('GetLinearVelocityFromWorldPoint',(v,a)=>[point(v[0],a)],local);
    wrap('GetLocalPoint',(v,a)=>[point(v[0],a)],local);
    for(const key of ['GetWorldVector','GetLocalVector','GetLinearVelocityFromLocalPoint'])wrap(key,v=>[local(v[0])],local);
    const create=b.CreateShape;
    if(typeof create==='function')b.CreateShape=function(def){const a=current;return shapeMethods(physical(()=>create.call(this,a?shape(def):def)));};
    // Mass and transform sync read the raw fields. They must not see the control view.
    for(const key of ['SetMassFromShapes','SetMass','ResetMassData','SynchronizeTransform','SynchronizeXForm']){const original=b[key];if(typeof original!=='function')continue;b[key]=function(...args){return physical(()=>original.apply(this,args));};}
    return b;
  }
  function joint(def,a){
    const d=copy(def);
    for(const key of ['localAnchor1','localAnchor2','localAnchorA','localAnchorB','localAxis1','localAxisA'])if(d[key])d[key]=local(d[key]);
    if(d.anchorPoint)d.anchorPoint=point(d.anchorPoint,a);
    if(d.axis)d.axis=local(d.axis);
    if('referenceAngle' in d)d.referenceAngle=-d.referenceAngle;
    if('lowerAngle' in d){d.lowerAngle=-def.upperAngle;d.upperAngle=-def.lowerAngle;if('motorSpeed' in d)d.motorSpeed=-d.motorSpeed;}
    return d;
  }
  function jointMethods(j,angular=typeof j?.GetJointAngle==='function'){
    if(!j||joints.has(j))return j;joints.add(j);virtualizeJoint(j);
    const wrap=(key,args,result)=>{const original=j[key];if(typeof original!=='function')return;
      j[key]=function(...values){const a=current;if(!a)return original.apply(this,values);const out=physical(()=>original.apply(this,args?args(values,a):values));return result?result(out,a):out;};};
    for(const key of ['GetAnchor1','GetAnchor2','GetAnchorA','GetAnchorB'])wrap(key,null,point);
    if(angular){
      for(const key of ['GetJointAngle','GetJointSpeed','GetMotorSpeed','GetMotorTorque','GetReactionTorque'])wrap(key,null,v=>-v);
      wrap('SetMotorSpeed',v=>[-v[0]]);wrap('SetLimits',v=>[-v[1],-v[0]]);
      wrap('GetLowerLimit',null,()=>{const raw=angleBox.get(j);return raw?-raw.upper:-j.m_upperAngle;});
      wrap('GetUpperLimit',null,()=>{const raw=angleBox.get(j);return raw?-raw.lower:-j.m_lowerAngle;});
    }
    return j;
  }
  function limits(j,a=current){const raw=angleBox.get(j);return a?.facing==='left'&&raw?{lower:-raw.upper,upper:-raw.lower}:{lower:j.m_lowerAngle,upper:j.m_upperAngle};}
  function bindCharacter(actor,list=[actor.character]){
    const undo=[];
    if(actor.facing==='left')for(const c of list){
      if(typeof c?.setJoint!=='function')continue;
      const own=Object.prototype.hasOwnProperty.call(c,'setJoint'),original=c.setJoint;
      c.setJoint=function(j,offset,gain,maxSpeed=10){return run(actor,()=>{
        // Native pose offsets are relative to lower limit in character space.
        j.IsMotorEnabled()||j.EnableMotor(true);
        const error=j.GetJointAngle()-(limits(j,actor).lower+offset);
        j.SetMotorSpeed(Math.min(gain*Math.pow(Math.abs(error),2),maxSpeed)*(error<0?1:-1));
      });};
      undo.push(()=>{if(own)c.setJoint=original;else delete c.setJoint;});
    }
    return ()=>{while(undo.length)undo.pop()();};
  }
  function uninstall(world){const r=worlds.get(world);if(!r)return;for(const [key,v]of r)if(world[key]===v.wrapper)world[key]=v.original;worlds.delete(world);}
  function install(world){
    if(!world)return;
    let r=worlds.get(world);if(!r){r=new Map();worlds.set(world,r);}
    // Reinstall replaced methods rather than trusting a permanent marker.
    const hook=(key,make)=>{if(r.get(key)?.wrapper===world[key])return;const original=world[key];if(typeof original!=='function')return;const wrapper=make(original);world[key]=wrapper;r.set(key,{original,wrapper});};
    physical(()=>{
      for(let b=world.GetBodyList?.();b;b=b.GetNext())body(b);
      for(let j=world.GetJointList?.();j;j=j.GetNext())jointMethods(j);
    });
    hook('CreateBody',create=>function(def){const a=current;
      if(!a)return body(physical(()=>create.apply(this,arguments)));
      const d=copy(def);d.position=point(def.position,a);d.angle=-(def.angle||0);if(d.linearVelocity)d.linearVelocity=local(d.linearVelocity);if('angularVelocity' in d)d.angularVelocity=-d.angularVelocity;
      return body(physical(()=>create.call(this,d)));
    });
    hook('CreateJoint',create=>function(def){const a=current;return jointMethods(physical(()=>create.call(this,a?joint(def,a):def)),'lowerAngle' in def);});
    for(const key of ['Query','QueryAABB'])hook(key,original=>function(...args){const a=current;if(!a)return physical(()=>original.apply(this,args));
      const i=args.findIndex(v=>v?.lowerBound&&v?.upperBound);
      if(i>=0){const v=args[i],bounds=copy(v);bounds.lowerBound=point(v.upperBound,a);bounds.lowerBound.y=v.lowerBound.y;bounds.upperBound=point(v.lowerBound,a);bounds.upperBound.y=v.upperBound.y;args[i]=bounds;}
      return physical(()=>original.apply(this,args));
    });
    return ()=>uninstall(world);
  }
  function reflect(character,facing='left'){
    const seen=new Set(),nodes=new Set(),factor=facing==='left'?-1:1;
    function node(n){if(!n||nodes.has(n)||typeof n.scaleX!=='number')return;nodes.add(n);let s=scales.get(n);
      if(!s){s={base:n.scaleX,applied:n.scaleX};scales.set(n,s);}else if(n.scaleX!==s.applied)s.base=n.scaleX;
      n.scaleX=s.base*factor;s.applied=n.scaleX;
    }
    function scan(c){if(!c||seen.has(c))return;seen.add(c);
      for(const [key,value]of Object.entries(c))if(/MCs?$|MovieClips?$/.test(key))for(const n of Array.isArray(value)?value:[value])node(n);
      for(const b of c.paintVector||[])node(b.GetUserData?.());
      for(const key of ['kid','girl','son','daughter','elf1','elf2'])scan(c[key]);
    }
    scan(character);
  }
  function paint(character,facing='left'){physical(()=>character.paint());reflect(character,facing);}
  return {run,controls,physical,install,uninstall,limits,bindCharacter,reflect,paint};
});
