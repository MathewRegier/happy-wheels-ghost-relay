(() => {
  'use strict';
  const boot=setInterval(()=>{
    const lab=window.HWGhost;
    if(!lab?.state?.rootApp?.renderer||!window.HWGhostCore||!window.HWJimbobCourse||lab.installed)return;
    clearInterval(boot);lab.installed=true;initialize(lab);
  },100);
  function initialize(lab){
    const core=window.HWGhostCore,courseApi=window.HWJimbobCourse,p=lab.require(99430);
    const Container=p.mcf,Sprite=p.kxk,Texture=p.gPd,Matrix=p.uqu,Rectangle=p.M_G;
    const app=lab.state.rootApp;
    let session=null,meta=null,recording=null,saved=null,playback=null,network=null;
    let ids=new WeakMap(),nextId=0,textureIds=new WeakMap(),textures=[],lastCapture=-1,lastIteration=-1;
    let sessionStart=0,lastFrame=null,room=null,ready=false,raceStart=null,released=false,clockOffset=0,finishSent=false,networkAt=0,lastSentAt=0,socketEpoch=0,relayUrl='',relaySeats=8,steamRoom='';
    let deaths=0,sawDead=false,bestProgress=0,liveProgress=0,trackBounds=null,spectateId=null,finishedRace=false,wantMenu=false,chromeSnapshot=null,hiddenChrome=[],readyCheck=false,lastShareKey='',lastShareAt=0,travelLock=null,travelAt=0,hostReadyAt=0,askSuppressAt=0,lastHostReady=false,lastChecking=false,pendingDecline=false,pendingStatus=false,pendingCollide=false,pendingChat=false,pendingPick=false,pendingProfile=false,playerCollide=true,lastPhase='',lastPresenceKey='',lastMapKey='',lastCharacter=0,confirmedCharacter=0,confirmedSkin='',confirmedLaunch=0,launchId=0,preparedLaunch=0,prepHold=0,prepSentFor=0,prepSentAt=0,armedLaunch=0,committedLoad=0,pendingSelect=null,loadErrorFor=0,playGen=0,armedGen=0,seenLobbyRev=0,retiredLaunch=0,lobbyTimer=0,characterHold=null,resultsRows=null,lingerUntil=0,launchRoster=[],characterTrace=[],lastAckKey='',entryError='',entryWait='',entryMilestone='',lastWaitKey='',entryTimer=0;
    let steam={ok:false,name:'',avatar:'',error:''},profileSent=false;
    const deadGens=new Set();
    const retiredSessions=new WeakSet();
    const avatars=new Map(),chatLog=[],courseRuns=new Map();
    let course=courseApi?courseApi.empty():null,coursePlaced=false,courseSession=null;
    const peers=new Map(),textureLoad=new Map(),localSprites=new Map(),levelHashes=new Map();
    let pendingAction=null,recordedBytes=0,selfId=null,travelTarget=null,ui=null;
    const hwGhostNet=(function(){
      const a=window.hwGhostNet,b=window.hwGhostSteam;
      if(!b)return a;
      if(!a)return b;
      const out={};
      for(const src of [a,b])for(const key of ['listRooms','connect','send','disconnect','openPeer','onEvent','steamStatus','steamPublish','steamInvite','steamTake','onSteam'])if(typeof src[key]==='function')out[key]=src[key].bind(src);
      return out;
    })();
    const layer=new Container();layer.name="Jimbob's Multiplayer visuals";layer.interactiveChildren=false;app.stage.addChild(layer);
    const localGroup=new Container();layer.addChild(localGroup);
    if(!document.getElementById('hw-mp-tag-style')){
      const style=document.createElement('style');style.id='hw-mp-tag-style';
      style.textContent='#hw-mp-tags{position:fixed;inset:0;overflow:hidden;pointer-events:none;z-index:9997}.hw-mp-tag{position:absolute;transform:translate(-50%,-100%);font:700 15px/1.15 Georgia,serif;color:#f7efe0;background:#12191699;padding:1px 6px;border-radius:2px;text-shadow:0 1px 0 #000,1px 0 0 #000,-1px 0 0 #000,0 -1px 0 #000;white-space:nowrap;letter-spacing:.2px;pointer-events:none}';
      document.head.appendChild(style);
    }
    const tags=document.createElement('div');tags.id='hw-mp-tags';document.body.appendChild(tags);
    const selfTag=document.createElement('div');selfTag.className='hw-mp-tag';selfTag.hidden=true;tags.appendChild(selfTag);
    const inputBlocks=new Set(),chatTimes=[];
    const pressFlags=['leftPressed','rightPressed','upPressed','downPressed','spacePressed','shiftPressed','ctrlPressed','zPressed'];
    const courseHud=document.createElement('div');courseHud.id='jmp-course-hud';courseHud.hidden=true;
    courseHud.style.cssText='pointer-events:none;position:fixed;left:50%;top:18px;transform:translateX(-50%);z-index:9996;background:#172127e8;color:#f5e8d2;padding:6px 12px;font:16px Georgia,serif';
    document.body.appendChild(courseHud);
    const courseMarks=document.createElement('div');courseMarks.id='jmp-course-marks';courseMarks.style.cssText='position:fixed;inset:0;pointer-events:none;z-index:9995';document.body.appendChild(courseMarks);
    function courseRun(id){
      const key=id||'self';
      let run=courseRuns.get(key);
      if(!run){run=courseApi.freshRun();courseRuns.set(key,run);}
      return run;
    }
    function seatIndex(id){
      const roster=launchRoster.length?launchRoster:(room?.players||[]);
      const i=roster.findIndex(p=>p.id===id);
      return i>=0?i:0;
    }
    function scanCourse(s){
      courseSession=s;
      if(!courseApi||!s||s.isMenu||s.isEditorTest){course=courseApi?courseApi.empty():null;return;}
      const nativeBoxes=courseApi.collect(s);
      const draft=window.HWBuilder?.active;
      const level=String(s.__jmpLevelId||lab.state.levelIndex||'');
      const definitionMeta=String(room?.meta?.level||'')===level?room.meta:String(lab.meta?.level||'')===level?lab.meta:null;
      const canonical=window.HWJimbobLevels?.courseFor?.(definitionMeta);
      const key=level+':'+(definitionMeta?.hash||'');
      // Private tests have the exact XML already in memory in BOTH windows.
      // Do not depend on native display containers retaining metadata after create().
      if(draft&&String(draft.id)===level&&window.HWBuilderCore){
        const doc=window.HWBuilderCore.parse(draft.xml,DOMParser);
        const boxes=window.HWBuilderCore.marks(doc).map(({text,x,y})=>({text,x,y,
          node:nativeBoxes.find(box=>box.text===text.split(/\r?\n/)[0].trim()&&Math.abs(box.x-x)<.01&&Math.abs(box.y-y)<.01)?.node}));
        course=courseApi.compile(boxes);
        lab.courseSource='draft-xml';
      }else if(canonical){
        course=canonical;lab.courseSource='published-xml';
      }else{
        // A second scan happens at countdown and after respawns. Native source
        // objects may have been consumed or moved since the first build.
        if(s.__jmpCourseDefinition?.key!==key||(!s.__jmpCourseDefinition.boxes.length&&nativeBoxes.length)){
          s.__jmpCourseDefinition={key,boxes:nativeBoxes.map(box=>({text:box.text,x:box.x,y:box.y}))};
        }
        course=courseApi.compile(s.__jmpCourseDefinition.boxes.map(box=>({...box})));
        lab.courseSource='native-level';
      }

      courseApi.hideMarks({boxes:nativeBoxes});
      courseApi.hideMarks(course);
      window.HWJimbobCamera?.install(s.camera,s,course.camera);
      // Survival has no native finish line. This runtime rule belongs to
      // Multiplayer; published-map players do not have Builder's timer.
      if(course.goal||(room&&course.play==='survival')){
        try{
          const box=(s.level||s._level)?.endBlock?.aabb;
          if(box){box.lowerBound.x=1e8;box.lowerBound.y=1e8;box.upperBound.x=1e8;box.upperBound.y=1e8;}
        }catch{}
      }
      if(course.bump!=null&&room?.mode==='shared'&&room.hostId===selfId&&playerCollide!==course.bump){
        try{lab.setCollide(course.bump);}catch{}
      }
    }
    function characterPixels(s,character){
      const c=character||s?.character;
      const scale=c?.m_physScale||s?.m_physScale||30;
      const p=c?.cameraFocus?.GetPosition?.()||c?.cameraFocus?.GetWorldCenter?.()||c?.body?.GetPosition?.();
      if(p&&Number.isFinite(p.x))return {x:p.x*scale,y:p.y*scale};
      if(Number.isFinite(c?.x)&&Number.isFinite(c?.y))return {x:c.x,y:c.y};
      return null;
    }
    function placeOnCourse(s,id,at){
      if(room?.mode==='shared')return; // Authority constructs native rigs at the course origin.
      const mark=at||courseApi.slotFor(course,seatIndex(id||selfId));
      if(!s?.character||!mark)return;
      courseApi.shiftCharacter(s.character,s,mark.x,mark.y);
    }
    function resetCourse(){courseRuns.clear();coursePlaced=false;}
    function tickCourse(s){
      if(!courseApi||!courseApi.tagged(course)||!released||!s)return;
      if(room?.mode==='shared'){
        for(const p of shared.players?.()||[]){
          if(p.x==null||p.top==null)continue;
          courseApi.advance(course,courseRun(p.id),p.x,p.top);
        }
      }else{
        const at=characterPixels(s);
        if(at)courseApi.advance(course,courseRun(selfId),at.x,at.y);
      }
      const mine=courseRun(selfId);
      if(mine.done)finishedRace=true;
      if(course.clockMs&&poseTime()>=course.clockMs){mine.done=true;finishedRace=true;}
    }
    function paintCourse(s){
      if(!courseApi||!courseApi.tagged(course)||!s||s.isMenu){courseHud.hidden=true;courseMarks.replaceChildren();return;}
      const mine=courseRun(selfId);
      const bits=[];
      if(course.flags.length)bits.push('Flag '+(Math.min(course.flags.length,mine.next+1))+'/'+course.flags.length);
      if(course.loops)bits.push('Loop '+(Math.min(course.loops,mine.loop+1))+'/'+course.loops);
      if(mine.done)bits.push('Goal');
      courseHud.hidden=!bits.length||!raceStart;courseHud.textContent=bits.join(' · ');
      const spr=s.containerSprite?.pixiSprite,view=app.renderer.view||app.view,rect=view?.getBoundingClientRect?.();
      if(!spr||!rect||raceStart){courseMarks.replaceChildren();return;}
      const sw=app.renderer.screen?.width||app.renderer.width||rect.width;
      const sh=app.renderer.screen?.height||app.renderer.height||rect.height;
      const marks=[...course.starts.map((m,i)=>({...m,label:'S'+(m.n||i+1),color:'#a4d8ef'})),...course.flags.map((m,i)=>({...m,label:'F'+(m.n||i+1),color:'#7cb8ff'})),...(course.goal?[{...course.goal,label:'G',color:'#fd8081'}]:[])];
      courseMarks.replaceChildren(...marks.map(mark=>{
        const at=spr.worldTransform.apply({x:mark.x,y:mark.y});
        const el=document.createElement('div');
        el.textContent=mark.label;
        el.style.cssText='position:absolute;transform:translate(-50%,-50%);font:700 13px Georgia,serif;color:'+mark.color+';text-shadow:0 0 4px #000';
        el.style.left=Math.round(rect.left+at.x*(rect.width/sw))+'px';
        el.style.top=Math.round(rect.top+at.y*(rect.height/sh))+'px';
        return el;
      }));
    }
    function playerName(id){return String(room?.players?.find(p=>p.id===id)?.name||'Racer').slice(0,24);}
    function ensureTag(peer,id){
      if(!peer.tag){peer.tag=document.createElement('div');peer.tag.className='hw-mp-tag';peer.tag.hidden=true;tags.appendChild(peer.tag);}
      const name=playerName(id);if(peer.tag.textContent!==name)peer.tag.textContent=name;
    }
    function screenOf(matrix, point){
      const view=app.renderer.view||app.view,rect=view?.getBoundingClientRect?.();
      if(!matrix||!rect||!point||!Number.isFinite(point.x)||!Number.isFinite(point.y))return null;
      const sw=app.renderer.screen?.width||app.renderer.width||rect.width;
      const sh=app.renderer.screen?.height||app.renderer.height||rect.height;
      const at=matrix.apply(point);
      return {x:rect.left+at.x*(rect.width/sw),y:rect.top+at.y*(rect.height/sh)};
    }
    function pinTag(tag, screen){
      if(!tag)return;
      if(!screen){tag.hidden=true;return;}
      tag.hidden=false;
      tag.style.left=Math.round(screen.x)+'px';
      tag.style.top=Math.round(screen.y-18)+'px';
    }
    function frameAnchor(frame){
      if(frame?.head&&Number.isFinite(frame.head.x)&&Number.isFinite(frame.head.y))return frame.head;
      let best=null;
      for(const part of frame?.parts||[]){
        if(!best||part[7]<best.y)best={x:part[6],y:part[7]};
      }
      return best;
    }
    function placeTag(peer, frame){
      if(!peer.tag||!peer.group.visible||!layer.visible){if(peer.tag)peer.tag.hidden=true;return;}
      const matrix=session?.containerSprite?.pixiSprite?.worldTransform;
      pinTag(peer.tag, screenOf(matrix, frameAnchor(frame)));
    }
    function dropTag(peer){peer.tag?.remove();peer.tag=null;}
    const sharedTags=new Map(),sharedScores=new Map();
    function hideTags(){selfTag.hidden=true;for(const peer of peers.values())if(peer.tag)peer.tag.hidden=true;for(const tag of sharedTags.values())tag.hidden=true;}
    function sharedScore(id){let score=sharedScores.get(id);if(!score){score={deaths:0,best:0,progress:0,dead:false,finished:false};sharedScores.set(id,score);}return score;}
    function noteSharedScore(score,p){
      const life=Number.isInteger(p.life)?p.life:null;
      if(life!=null){
        if(!Number.isInteger(score.life))score.life=life;
        else if(life>score.life){score.deaths+=life-score.life;score.life=life;}
        else if(life<score.life)score.life=life;
      }else if(p.dead&&!score.dead)score.deaths++;
      score.dead=!!p.dead;
    }
    function trackShared(s){
      const list=shared.players?.()||[];
      if(!trackBounds)trackBounds=measureBounds(s);
      const view=app.renderer.view||app.view,rect=view?.getBoundingClientRect?.();
      const sw=app.renderer.screen?.width||app.renderer.width||rect?.width||1;
      const sh=app.renderer.screen?.height||app.renderer.height||rect?.height||1;
      const matrix=s?.containerSprite?.pixiSprite?.worldTransform;
      const seen=new Set();
      for(const p of list){
        const score=sharedScore(p.id);
        noteSharedScore(score,p);
        if(p.finished)score.finished=true;
        if(p.worldX!=null&&trackBounds)score.progress=score.finished?1:Math.max(0,Math.min(0.99,(p.worldX-trackBounds.minX)/(trackBounds.maxX-trackBounds.minX)));
        if(score.finished)score.progress=1;
        score.best=Math.max(score.best,score.progress);
        if(p.id===selfId){deaths=score.deaths;liveProgress=score.progress;bestProgress=score.best;continue;}
        let tag=sharedTags.get(p.id);
        if(!tag){tag=document.createElement('div');tag.className='hw-mp-tag';tag.hidden=true;tags.appendChild(tag);sharedTags.set(p.id,tag);}
        const name=playerName(p.id);if(tag.textContent!==name)tag.textContent=name;
        seen.add(p.id);
        if(p.headX==null||p.headY==null||!matrix||!rect){tag.hidden=true;continue;}
        const at=matrix.apply({x:p.headX,y:p.headY});
        tag.hidden=false;
        tag.style.left=Math.round(rect.left+at.x*(rect.width/sw))+'px';
        tag.style.top=Math.round(rect.top+at.y*(rect.height/sh)-18)+'px';
      }
      for(const [id,tag]of sharedTags)if(!seen.has(id))tag.hidden=true;
    }
    function clearShared(){sharedScores.clear();for(const tag of sharedTags.values())tag.remove();sharedTags.clear();}
    lab.stats={captured:0,parts:0,ghostParts:0,unsupported:0};
    lab.textures=()=>textures;
    const message=text=>{lab.status=text;status.textContent=text;ui?.refresh();};
    const shared=window.HWSharedWorld(lab,send,message);lab.sharedWorld=shared;
    const networkMetrics=new window.HWSharedNet.Metrics(),packetEncoder=new TextEncoder();
    lab.networkDiagnostics=()=>({transport:networkMetrics.summary(),shared:shared.networkDiagnostics()});
    function sharedContext(){return {room,selfId,isHost:room?.hostId===selfId,raceStart,released,session,collide:playerCollide,launchRoster};}
    const rect=r=>r?[r.x,r.y,r.width,r.height]:null;
    const quant=x=>Math.round(x*1000)/1000;
    function rawTextureUrl(texture){
      const r=texture?.baseTexture?.resource;
      return texture?.__hwGhost?.url||texture?.baseTexture?.__hwUrl||r?.url||r?.src||r?.source?.src||'';
    }
    function textureId(texture){
      if(textureIds.has(texture))return textureIds.get(texture);
      try{
        const tagged=texture?.__hwGhost;
        const desc=tagged&&core.validTexture(tagged)?{...tagged}:{
          url:core.publicTexturePath(rawTextureUrl(texture)),
          frame:rect(texture.frame),orig:rect(texture.orig),trim:rect(texture.trim),rotate:texture.rotate||0
        };
      if(!core.validTexture(desc))return null;
      const id=textures.length;textures.push(desc);textureIds.set(texture,id);return id;
      }catch{return null;}
    }
    function roots(character){
      const wrappers=new Set(),seen=new Set();
      function visit(obj,depth=0){
        if(!obj||typeof obj!=='object'||seen.has(obj)||depth>5)return;seen.add(obj);
        if(obj.pixiSprite){if(obj.parent)wrappers.add(obj);return;}
        if(Array.isArray(obj)){for(const v of obj)visit(v,depth+1);return;}
        for(const [k,v] of Object.entries(obj)){
          if(/MCs?$/.test(k)||['son','daughter','dad','mom','elf1','elf2','elves','composites','rider','passenger','characters'].includes(k))visit(v,depth+1);
          if(k==='paintVector'&&Array.isArray(v))for(const body of v)visit(body?.GetUserData?.(),depth+1);
        }
      }
      visit(character);
      return [...wrappers].filter(w=>{for(let a=w.parent;a;a=a.parent)if(wrappers.has(a))return false;return true;})
        .sort((a,b)=>(a.parent?.children?.indexOf(a)||0)-(b.parent?.children?.indexOf(b)||0));
    }
    function poseTime(){
      if(raceStart&&released)return Math.max(0,(Date.now()+clockOffset)-raceStart);
      const iter=Number(session?.iteration),step=Number(session?.m_timeStep||session?.timeStep);
      if(Number.isFinite(iter)&&Number.isFinite(step)&&step>0){
        const t=(iter-sessionStart)*step*1000;
        if(Number.isFinite(t))return Math.max(0,t);
      }
      if(raceStart)return Math.max(0,(Date.now()+clockOffset)-raceStart);
      return 0;
    }
    function bodyX(obj){
      try{
        const p=obj?.GetPosition?.()||obj?.GetWorldCenter?.();
        if(p&&Number.isFinite(p.x))return p.x;
      }catch{}
      return null;
    }
    function measureBounds(s){
      const xs=[];
      try{
        for(let b=s?.m_world?.GetBodyList?.();b;b=b.GetNext()){
          const x=bodyX(b);if(x!=null&&Math.abs(x)<1e6)xs.push(x);
        }
      }catch{}
      if(xs.length<2)return trackBounds;
      xs.sort((a,b)=>a-b);
      const lo=xs[Math.floor((xs.length-1)*0.02)];
      const hi=xs[Math.ceil((xs.length-1)*0.98)];
      return hi>lo?{minX:lo,maxX:hi}:trackBounds;
    }
    function happyWheels(){return app.screenManager.currentScreen?.happyWheels;}
    function sessionController(){return happyWheels()?.sessionController;}
    function hookNonPausingMenu(){
      const controller=sessionController();
      if(!controller)return;
      if(controller.openSessionMenu&&!controller.__hwNonPausingMenu){
        controller.__hwNonPausingMenu=true;
        const open=controller.openSessionMenu;
        controller.openSessionMenu=function(shouldPause=true,...args){
          if(room&&raceStart)shouldPause=false;
          return open.call(this,shouldPause,...args);
        };
      }
      // Native menu buttons and rebound restart keys use these methods too.
      if(controller.__hwAuthority===undefined){
        const hooks=controller.__hwRestartVote instanceof Map?controller.__hwRestartVote:(controller.__hwRestartVote=new Map());
        for(const key of ['restartLevel','restartLevelBind']){
          const original=controller[key];if(typeof original!=='function')continue;
          if(original===hooks.get(key)?.wrapper)continue;
          const wrapper=function(...args){
            if(!lab.forceLevelRestart&&requestRestartVote())return;
            return original.apply(this,args);
          };
          controller[key]=wrapper;hooks.set(key,{original,wrapper});
        }
      }
    }
    function inPostFinish(){return !!(network&&released&&(finishedRace||finishSent||courseRun(selfId).done||(!course?.goal&&session?.replayData?.completed)));}
    function noteChrome(){
      const hw=happyWheels();
      chromeSnapshot=hw?.children?new Set(hw.children):null;
      hiddenChrome=[];
    }
    function restoreChrome(){
      for(const node of hiddenChrome)try{node.visible=true;}catch{}
      hiddenChrome=[];
    }
    function hideNode(node){
      if(!node||node.visible===false)return;
      try{node.visible=false;hiddenChrome.push(node);}catch{}
    }
    function hideFinishChrome(s){
      if(wantMenu){restoreChrome();return;}
      if(!inPostFinish()&&!(network&&released&&s?.replayData?.completed))return;
      finishedRace=true;
      thawWorld(s);
      const hw=happyWheels();
      const hide=(node,depth=0)=>{
        if(!node||depth>5)return;
        const name=String(node.name||node.constructor?.name||'');
        if(/complete|result|finish|endlevel|levelend|winpanel|postgame/i.test(name)&&node!==s?.containerSprite&&node!==s?.containerSprite?.pixiSprite)hideNode(node);
        for(const child of node.children||[])hide(child,depth+1);
      };
      hide(hw);hide(app.stage);
      try{s.containerSprite.visible=true;}catch{}
      try{s.containerSprite.pixiSprite.visible=true;}catch{}
    }
    function revealNode(node,depth=0,seen){
      if(!node||typeof node!=='object'||depth>14||seen.has(node))return;
      seen.add(node);
      try{
        if(node.visible===false)node.visible=true;
        if(node.renderable===false)node.renderable=true;
      }catch{}
      if(node.pixiSprite)revealNode(node.pixiSprite,depth+1,seen);
      for(const child of node.children||[])revealNode(child,depth+1,seen);
    }
    function revealWorld(s){
      const seen=new Set();
      revealNode(s?.containerSprite,0,seen);
      revealNode(s?.containerSprite?.pixiSprite,0,seen);
      try{
        for(let b=s?.m_world?.GetBodyList?.();b;b=b.GetNext()){
          try{revealNode(b.GetUserData?.(),0,seen);}catch{}
        }
      }catch{}
      for(const key of ['specials','items','shapes','levelObjects','gameObjects','triggers','groups','paintVector']){
        const list=s?.[key];
        if(Array.isArray(list))for(const item of list)revealNode(item,0,seen);
      }
    }
    function steerCamera(s,focus){
      if(!s||!focus)return;
      const character=s.character;
      const bodies=new Set([character,character?.body,character?.centralBody,character?.pelvis,character?.chest,character?.m_body].filter(Boolean));
      const keys=['cameraFocus','cameraTarget','followTarget','camTarget','lookAt'];
      for(const obj of [s,character,sessionController()]){
        if(!obj)continue;
        for(const key of keys){
          const val=obj[key];
          if(!val||typeof val!=='object'||bodies.has(val))continue;
          if(typeof val.SetPosition==='function')continue;
          try{if(typeof val.x==='number'){val.x=focus.x;val.y=focus.y;}}catch{}
          try{val.position?.set?.(focus.x,focus.y);}catch{}
        }
        try{if(typeof obj.cameraX==='number'){obj.cameraX=focus.x;obj.cameraY=focus.y;}}catch{}
      }
    }
    function livePeerIds(){
      const now=performance.now();
      return [...peers.keys()].filter(id=>{const peer=peers.get(id);return peer?.lastArrival&&now-peer.lastArrival<8000;});
    }
    function spectateIds(){
      const ids=livePeerIds();
      if(selfId&&!ids.includes(selfId))ids.unshift(selfId);
      return ids;
    }
    function watchingOther(){return !!(spectateId&&selfId&&spectateId!==selfId&&peers.get(spectateId));}
    function cycleSpectate(next){
      const ids=spectateIds();
      if(!ids.length){spectateId=selfId||null;return;}
      const current=spectateId||selfId;
      const i=ids.indexOf(current);
      spectateId=i<0?ids[0]:ids[(i+(next?1:-1)+ids.length)%ids.length];
    }
    function spectatePlayer(id){if(id&&(id===selfId||peers.has(id)))spectateId=id;}
    function resetWatch(){spectateId=null;finishedRace=false;wantMenu=false;restoreChrome();}
    function resumeGameAudio(){
      try{
        const muted=!!lab.state?.sharedObject?.data?.muted;
        const Howler=window.Howler;
        if(Howler&&!muted){
          if(typeof Howler.mute==='function')Howler.mute(false);
          Howler.ctx?.resume?.();
          Howler._ctx?.resume?.();
        }
      }catch{}
      for(const obj of [lab.state,happyWheels(),session,sessionController()]){
        if(!obj)continue;
        for(const key of ['sound','sounds','soundManager','audio','audioManager']){
          const snd=obj[key];
          if(!snd)continue;
          try{snd.systemUnMute?.();}catch{}
          try{snd.unMute?.();}catch{}
          try{snd.unmute?.();}catch{}
          try{if(typeof snd.resume==='function')snd.resume();}catch{}
        }
      }
    }
    function onLocalRestart(){
      resetWatch();
      resumeGameAudio();
    }
    function manualRestart(){
      if(room&&survivalCourse()){requestRestartVote();return true;}
      if(course?.play==='survival'||course?.retry==='off')return true;
      onLocalRestart();
      const controller=sessionController();
      if(!controller?.restartLevel)return false;
      const mark=course?.retry==='start'?courseApi.slotFor(course,seatIndex(selfId)):(courseRun(selfId).last||courseApi.slotFor(course,seatIndex(selfId)));
      try{controller.restartLevel();resumeGameAudio();}catch{return false;}
      const ticket=playGen;
      setTimeout(()=>{
        if(ticket!==playGen)return;
        scanCourse(lab.state.currentSession||session);
        if(mark)placeOnCourse(lab.state.currentSession||session,selfId,mark);
      },80);
      return true;
    }
    function allowGameMenu(){
      wantMenu=true;
      restoreChrome();
      const view=app.view||app.canvas||document.querySelector('canvas');
      try{view?.focus?.();}catch{}
      return true;
    }
    function manualMenu(){return allowGameMenu();}
    function peerFocus(peer){
      if(!peer)return null;
      const frame=core.liveSample(peer.frames,performance.now(),peer.lastArrival)||peer.frames.at(-1);
      if(!frame?.parts?.length)return null;
      let x=0,y=0,n=0;
      for(const part of frame.parts){x+=part[6];y+=part[7];n++;}
      return n?{x:x/n,y:y/n}:null;
    }
    function alignWorldLayer(s){
      const spr=s?.containerSprite?.pixiSprite;if(!spr)return;
      layer.transform.setFromMatrix(spr.worldTransform.clone().prepend(app.stage.worldTransform.clone().invert()));
    }
    function paintPeers(){
      const now=performance.now();
      for(const [id,peer] of peers){
        const fresh=peer.lastArrival&&now-peer.lastArrival<8000;
        peer.group.visible=fresh;
        if(!fresh){if(peer.tag)peer.tag.hidden=true;continue;}
        const shown=core.liveSample(peer.frames,now,peer.lastArrival);
        draw(peer.group,peer.sprites,shown,peer.textures);
        ensureTag(peer,id);placeTag(peer,shown);
      }
    }
    function applySpectate(s,early){
      if(wantMenu||!inPostFinish()||!s?.containerSprite?.pixiSprite)return;
      if(!spectateId)spectateId=selfId;
      if(!watchingOther())return;
      const focus=peerFocus(peers.get(spectateId));if(!focus)return;
      steerCamera(s,focus);
      revealWorld(s);
      if(early)return;
      paintPeers();
      alignWorldLayer(s);
      const spr=s.containerSprite.pixiSprite;
      try{spr.updateTransform();}catch{}
      const m=spr.worldTransform;
      const sx=m.a*focus.x+m.c*focus.y+m.tx;
      const sy=m.b*focus.x+m.d*focus.y+m.ty;
      const view=app.renderer.screen||{width:app.renderer.width,height:app.renderer.height};
      spr.position.set(spr.x+(view.width/2)-sx,spr.y+(view.height/2)-sy);
      try{spr.updateTransform();}catch{}
      revealWorld(s);
      alignWorldLayer(s);
    }
    function characterX(s){
      const c=s?.character;if(!c)return null;
      for(const obj of [c,c.body,c.centralBody,c.cameraFocus,c.pelvis,c.chest,c.hip,c.torso,c.m_body]){
        const x=bodyX(obj);if(x!=null)return x;
      }
      const seen=new Set();
      function walk(obj,depth){
        if(!obj||typeof obj!=='object'||seen.has(obj)||depth>4)return null;
        seen.add(obj);
        const x=bodyX(obj);if(x!=null)return x;
        for(const key of ['body','centralBody','cameraFocus','pelvis','chest','hip','torso','m_body']){
          const found=walk(obj[key],depth+1);if(found!=null)return found;
        }
        return null;
      }
      return walk(c,0);
    }
    function localProgress(s){
      if(courseApi&&courseApi.tagged(course)&&(course.flags.length||course.goal)){
        const mine=courseRun(selfId);
        return mine.done?1:courseApi.progress(course,mine);
      }
      if(s?.replayData?.completed)return 1;
      if(!trackBounds)trackBounds=measureBounds(s);
      const x=characterX(s);
      if(x==null||!trackBounds)return liveProgress;
      return Math.max(0,Math.min(0.99,(x-trackBounds.minX)/(trackBounds.maxX-trackBounds.minX)));
    }
    function markDead(){
      if(sawDead)return;
      sawDead=true;
      deaths++;
    }
    function decorate(frame,s){
      if(!frame)return null;
      liveProgress=localProgress(s);
      if(liveProgress>bestProgress)bestProgress=liveProgress;
      if(s?.character?.dead||frame.dead)markDead();
      frame.progress=bestProgress;
      frame.current=liveProgress;
      frame.deaths=deaths;
      frame.best=bestProgress;
      return frame;
    }
    function tintOf(n){
      const v=n?.tint;
      if(typeof v==='number'&&Number.isFinite(v))return v&0xffffff;
      if(v&&typeof v.toNumber==='function'){const n=Number(v.toNumber());if(Number.isFinite(n))return n&0xffffff;}
      return 0xffffff;
    }
    function displayLevelPoint(node, inv){
      const sprite=node?.pixiSprite||node;
      const wt=sprite?.worldTransform;
      if(!node||node.visible===false||sprite?.visible===false||sprite?.destroyed||!(sprite?.parent||node.parent)||!wt||typeof wt.clone!=='function')return null;
      const m=wt.clone().prepend(inv);
      let cx=0,cy=0;
      const bounds=sprite.getLocalBounds?.();
      if(bounds&&(bounds.width||bounds.height)){cx=bounds.x+bounds.width/2;cy=bounds.y+bounds.height/2;}
      const x=m.a*cx+m.c*cy+m.tx,y=m.b*cx+m.d*cy+m.ty;
      return Number.isFinite(x)&&Number.isFinite(y)?{x,y}:null;
    }
    function bodyLevelPoint(body, scale){
      if(!body||typeof body.GetPosition!=='function')return null;
      try{if(body.m_world&&session?.m_world&&body.m_world!==session.m_world)return null;}catch{return null;}
      const p=body.GetInterpolatedWorldCenter?.()||body.GetWorldCenter?.()||body.GetPosition?.();
      if(!p||!Number.isFinite(p.x)||!Number.isFinite(p.y))return null;
      return {x:p.x*scale,y:p.y*scale};
    }
    function characterHead(character, inv){
      if(!character||typeof core.anchorTargets!=='function')return null;
      const head=core.anchorTargets(character,'head');
      const torso=core.anchorTargets(character,'torso');
      let cache=character.__jmpHead;
      const current=cache?.rank==='torso'?torso:head;
      if(!cache||cache.display!==current.display||cache.body!==current.body){
        cache=(head.display||head.body)?{...head}:{...torso};
        character.__jmpHead=cache;
      }
      const scale=character.m_physScale||session?.m_physScale||30;
      const point=displayLevelPoint(cache.display, inv)||bodyLevelPoint(cache.body, scale);
      if(point)return point;
      if(cache.rank==='torso')return null;
      cache={...torso};
      character.__jmpHead=cache;
      return displayLevelPoint(cache.display, inv)||bodyLevelPoint(cache.body, scale);
    }
    function placeSelfTag(){selfTag.hidden=true;}
    function neutralizeInput(){
      const s=lab.state?.currentSession||session;
      for(const obj of [s?.character,s,sessionController(),lab.state]){
        if(!obj)continue;
        for(const flag of pressFlags){try{if(flag in obj)obj[flag]=false;}catch{}}
        for(const name of ['keys','keyStates','keyState','pressedKeys','_keys']){
          const bag=obj[name];
          if(Array.isArray(bag))bag.fill(false);
          else if(bag&&typeof bag==='object')for(const key of Object.keys(bag))bag[key]=false;
        }
      }
      try{shared.neutralizeInput?.();}catch{}
    }
    function holdCharacterKeys(character){
      if(!character||character.__jmpChatKeys||typeof character.checkKeyStates!=='function')return;
      const original=character.checkKeyStates;
      character.checkKeyStates=function(...args){
        if(inputBlocks.has('chat')){for(const key of pressFlags)this[key]=false;return;}
        return original.apply(this,args);
      };
      character.__jmpChatKeys=true;
    }
    lab.inputBlocked=reason=>inputBlocks.has(reason);
    lab.setInputBlock=(reason,on)=>{
      if(reason!=='chat')return;
      if(on)inputBlocks.add('chat');else inputBlocks.delete('chat');
      neutralizeInput();
      if(on)try{shared.dropHeldInput?.();}catch{}
    };
    function capture(character=session?.character,decorateFrame=true){
      if(!character||!session?.containerSprite)return null;
      const inv=session.containerSprite.pixiSprite.worldTransform.clone().invert(),parts=[],seen=new Set();let unsupported=0;
      function visit(n){
        if(!n||seen.has(n)||!n.visible||n.isMask||n.worldAlpha<=0)return;seen.add(n);
        if(n.texture&&n.renderable){
          const tid=textureId(n.texture);
          if(tid!==null){
            if(!ids.has(n))ids.set(n,nextId++);
            const m=n.worldTransform.clone().prepend(inv);
            const part=[ids.get(n),tid,...[m.a,m.b,m.c,m.d,m.tx,m.ty].map(quant),quant(Math.max(0,Math.min(1,Number(n.worldAlpha)||0))),tintOf(n),Number(n.anchor?.x)||0,Number(n.anchor?.y)||0];
            if(part.every(x=>Number.isFinite(x)))parts.push(part);else unsupported++;
          }else unsupported++;
        }else if(n.geometry&&n.renderable)unsupported++;
        for(const child of n.children||[])visit(child);
      }
      for(const w of roots(character))visit(w.pixiSprite);
      lab.stats.parts=parts.length;lab.stats.unsupported=unsupported;
      const frame={t:poseTime(),parts,dead:!!session.character.dead,finished:courseApi&&course.goal?!!courseRun(selfId).done:!!session.replayData?.completed};
      const head=characterHead(character, inv);
      if(head)frame.head={x:quant(head.x),y:quant(head.y)};
      return decorateFrame?decorate(core.validFrame(frame)?frame:null,session):(core.validFrame(frame)?frame:null);
    }
    function resolveTexture(desc){
      const key=JSON.stringify(desc);if(textureLoad.has(key))return textureLoad.get(key);
      const cached=Object.values(p.WpD.TextureCache).find(t=>{
        const url=t?.baseTexture?.__hwUrl||t?.baseTexture?.resource?.url||t?.baseTexture?.resource?.src||'';
        return (url.endsWith('/'+desc.url)||url.endsWith(desc.url))&&JSON.stringify(rect(t.frame))===JSON.stringify(desc.frame)&&t.rotate===desc.rotate;
      });
      if(cached){textureLoad.set(key,cached);return cached;}
      textureLoad.set(key,null);
      const base=Texture.from('./'+desc.url).baseTexture;
      const make=()=>{try{textureLoad.set(key,new Texture(base,new Rectangle(...desc.frame),new Rectangle(...desc.orig),desc.trim?new Rectangle(...desc.trim):null,desc.rotate));}catch(e){lab.errors.push(String(e));}};
      if(base.valid)make();else{base.once('loaded',make);base.once('error',()=>lab.errors.push('Ghost texture failed: '+desc.url));}
      return textureLoad.get(key);
    }
    function draw(group,sprites,frame,manifest,opacity=.42){
      for(const sprite of sprites.values())sprite.visible=false;
      if(!frame)return;
      for(const a of frame.parts){
        const desc=manifest[a[1]];if(!desc)continue;const texture=resolveTexture(desc);if(!texture)continue;
        let sprite=sprites.get(a[0]);if(!sprite){sprite=new Sprite(texture);sprites.set(a[0],sprite);group.addChild(sprite);}
        sprite.texture=texture;sprite.visible=true;sprite.alpha=a[8]*opacity;sprite.tint=a[9];sprite.anchor.set(a[10],a[11]);
        sprite.transform.setFromMatrix(new Matrix(...a.slice(2,8)));group.setChildIndex(sprite,group.children.length-1);
      }
      for(const [id,sprite]of sprites)if(!sprite.visible){releaseDisplay(sprite);sprites.delete(id);}
    }
    function releaseDisplay(node){
      if(!node||node.destroyed||node.__hwReleased)return;
      node.__hwReleased=true;
      try{node.parent?.removeChild(node);}catch{}
      try{node.destroy?.({children:true,texture:false,baseTexture:false});}catch{}
    }
    lab.sharedVisuals={
      captureNode:node=>capture({partMC:node},false),
      textures:()=>textures,
      textureRevision:()=>textures.length, // This registry is append-only for a session.
      create:()=>({group:new Container(),sprites:new Map()}),
      draw:(view,frame,manifest)=>draw(view.group,view.sprites,frame,manifest,1),
      remove:view=>{if(!view||view.discarded)return;view.discarded=true;view.sprites?.clear?.();releaseDisplay(view.group);}
    };
    function clear(group,sprites){for(const sprite of sprites.values())releaseDisplay(sprite);sprites.clear();}
    function freezeWorld(s){
      if(!s||s.isMenu)return;
      try{if(typeof s.pause==='function'&&!s.paused)s.pause();}catch{}
      if(s.paused===false)try{s.paused=true;}catch{}
    }
    function thawWorld(s){
      if(!s)return;
      try{
        if(typeof s.unpause==='function')s.unpause();
        else if(typeof s.resume==='function')s.resume();
        else s.paused=false;
      }catch{try{s.paused=false;}catch{}}
      resumeGameAudio();
    }
    function remainingMs(){return raceStart==null?null:raceStart-(Date.now()+clockOffset);}
    function holdForCountdown(s){
      if(!raceStart||released||!s||s.isMenu)return;
      const remaining=remainingMs();
      if(remaining>50){
        freezeWorld(s);
        if(!coursePlaced){placeOnCourse(s,selfId,courseApi.slotFor(course,seatIndex(selfId)));coursePlaced=true;}
        const n=String(Math.max(1,Math.ceil(remaining/1000)));
        const text='Race countdown: '+n;
        if(lab.status!==text)message(text);
        return;
      }
      released=true;ready=false;prepHold=0;thawWorld(s);
      sessionStart=s.iteration;lastFrame=capture()||lastFrame;publishFrame(true);
      resetWatch();noteChrome();
      message('GO! Race on.');
    }
    function fingerprint(s){
      const geometry=[];
      for(let b=s.m_world.GetBodyList();b;b=b.GetNext()){
        const shapes=[];for(let sh=b.GetShapeList();sh;sh=sh.GetNext())shapes.push({type:sh.m_type,radius:sh.m_radius,vertices:sh.m_vertices?.map(v=>[v.x,v.y]),filter:sh.m_filter});
        geometry.push({position:[b.GetPosition().x,b.GetPosition().y],angle:b.GetAngle(),shapes});
      }
      return crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(geometry))).then(b=>Array.from(new Uint8Array(b),x=>x.toString(16).padStart(2,'0')).join(''));
    }
    function playingLevelId(){
      if(!session||session.isMenu||session.isEditorTest)return '';
      const index=String(lab.state.levelIndex||'');
      return /^[1-9][0-9]{0,8}$/.test(index)?index:'';
    }
    function sessionPlayable(s){
      return !!(s&&!retiredSessions.has(s)&&!s.isMenu&&!s.isEditorTest&&s.m_world&&s.containerSprite&&s.character);
    }
    function levelPlayable(){
      return sessionPlayable(session);
    }
    function characterSelected(){
      return !!(session&&!session.isMenu&&!session.isEditorTest&&session.character&&session.m_world&&session.containerSprite&&!characterMenuOpen()&&!lab.download?.loading);
    }
    function nativeChoice(){
      if(characterMenuOpen()||!session?.character)return null;
      const n=Number(lab.state.characterIndex);
      if(!Number.isInteger(n)||n<1||n>32)return null;
      const skin=session.character.__customCharacterId||window.HWCustomCharacters?.selected||'';
      return {id:n,skin:typeof skin==='string'?skin:''};
    }
    function sessionReadyForLaunch(){
      if(!room?.launchId||launchId!==room.launchId||!room.meta)return false;
      if(lab.download?.loading||characterMenuOpen())return false;
      if(!session?.character||!session.m_world||!session.containerSprite||session.isMenu||session.isEditorTest)return false;
      if(playingLevelId()!==String(room.meta.level))return false;
      if(!meta||String(meta.level)!==String(room.meta.level))return false;
      const choice=nativeChoice();
      const expected=room.rules?.rider||confirmedCharacter;
      return !!(choice&&expected&&choice.id===expected);
    }
    function characterMenuShowing(){
      const menu=sessionController()?.characterMenu;
      if(!menu||menu.visible===false)return false;
      return !!(menu.parent||menu.pixiSprite?.parent);
    }
    function characterMenuOpen(){
      if(lab.state.currentSession?.isMenu&&!characterMenuShowing())return false;
      return characterMenuShowing();
    }
    function pauseMenuOpen(){
      const menu=sessionController()?.sessionMenu;
      return !!(menu&&(menu.visible===true||(menu.parent&&menu.visible!==false)));
    }
    function selectingCharacter(){
      if(!room?.launched&&!travelTarget)return false;
      if(characterSelected())return false;
      if(characterMenuOpen())return true;
      if(!room?.meta&&!travelTarget&&!lab.download?.level)return false;
      if(lab.download?.loading)return false;
      return !!(room?.launched||travelTarget);
    }
    function localLevelIds(){
      const ids=[];
      const play=playingLevelId();
      if(play)ids.push(play);
      if(meta?.level)ids.push(String(meta.level));
      if(lab.download?.level)ids.push(String(lab.download.level));
      if(travelTarget?.level)ids.push(String(travelTarget.level));
      return ids;
    }
    function onRoomLevel(){
      if(!session||session.isMenu||session.isEditorTest||!session.m_world||!session.character||characterMenuOpen()||lab.download?.loading)return false;
      if(!room?.meta?.level)return false;
      return playingLevelId()===String(room.meta.level);
    }
    function loadingHostLevel(){
      const level=room?.meta?.level;
      if(!level)return false;
      if(travelTarget&&String(travelTarget.level)===String(level))return true;
      if(travelLock===level&&Date.now()-travelAt<8000)return true;
      if(lab.download?.loading&&String(lab.download.level)===String(level))return true;
      return false;
    }
    function settleGuestLoad(){
      if(!room||room.hostId===selfId||!onRoomLevel())return false;
      adoptHostLevel();
      travelTarget=null;
      travelLock=null;
      publishPresence();
      return true;
    }
    function noteHostReady(next){
      const hostReady=!!next?.players?.find(p=>p.id===next.hostId)?.ready;
      const checking=!!next?.checking;
      if((checking&&!lastChecking)||(hostReady&&!lastHostReady))hostReadyAt=Date.now();
      if(!checking&&!hostReady)hostReadyAt=0;
      lastChecking=checking;
      lastHostReady=hostReady;
    }
    function hostChecking(next){
      const current=next||room;
      return !!(current&&current.checking);
    }
    function shouldAskReady(){
      if(!room||room.hostId===selfId||ready||raceStart)return false;
      if(hostChecking())return true;
      if(!onRoomLevel())return false;
      return hostReadyAt>0&&hostReadyAt>=askSuppressAt;
    }
    function shareHostLevel(){
      if(sameHeldLevel())return false;
      if(!network||!room||room.hostId!==selfId)return false;
      if(!session||session.isMenu||session.isEditorTest||characterMenuOpen())return false;
      let next=null;
      if(meta&&session&&!session.isMenu&&!session.isEditorTest&&playingLevelId()===meta.level)next=meta;
      else if(lab.download?.hash&&lab.download.level&&!lab.download.loading)next={protocol:core.VERSION,game:'1.99',level:lab.download.level,hash:lab.download.hash,character:lab.state.characterIndex,fingerprint:'download-sha256'};
      if(!next?.hash||!/^[a-f0-9]{64}$/.test(next.hash))return false;
      if(raceStart&&room.meta&&room.meta.level===next.level)return false;
      if(room.meta&&room.meta.level===next.level)return false;
      const moved=!room.meta||room.meta.level!==next.level;
      const key=(moved?'summon:':'level:')+next.level+':'+next.hash,now=performance.now();
      if(key===lastShareKey&&now-lastShareAt<2000)return false;
      lastShareKey=key;lastShareAt=now;
      if(moved){ready=false;readyCheck=false;ui?.hideReadyAsk?.();}
      scanCourse(session);
      send({type:moved?'summon':'level',meta:next,rules:{play:course?.play,waitSec:course?.waitSec,rider:course?.rider,seats:course?.seats,lingerMs:course?.lingerMs}});
      if(moved)message('Bringing everyone to level '+next.level+'…');
      return true;
    }
    function samePublishedLevel(){
      if(!room?.meta?.level)return false;
      const id=String(room.meta.level);
      return String(lab.state.levelIndex)===id||(meta&&String(meta.level)===id)||lab.download?.level===id;
    }
    function localCharacterEdit(){
      return !!(room?.meta&&samePublishedLevel()&&characterMenuOpen());
    }
    function rememberCharacterSwitch(){
      if(!room||room.mode==='shared'||characterHold)return;
      characterHold={raceStart,released,ready,meta,at:Date.now()};
    }
    function characterSwitching(){
      if(!characterHold)return false;
      if(!room||room.mode==='shared'||Date.now()-characterHold.at>15000){characterHold=null;return false;}
      return true;
    }
    function sameHeldLevel(){
      if(!characterSwitching())return false;
      const index=String(lab.state.levelIndex||'');
      const level=String(characterHold.meta?.level||room?.meta?.level||'');
      return !index||!level||index===level;
    }
    function hookCharacterMenu(){
      if(room?.mode==='shared')return;
      const controller=sessionController();
      if(!controller)return;
      for(const key of ['reopenCharacterMenu','reopenCharacterMenuBind']){
        const fn=controller[key];
        if(typeof fn!=='function'||fn.__hwGhostCharacter)continue;
        const wrapped=function(...args){rememberCharacterSwitch();return fn.apply(this,args);};
        wrapped.__hwGhostCharacter=true;
        controller[key]=wrapped;
      }
    }
    function playerPhase(){
      if(!room)return 'offline';
      if(sameHeldLevel())return 'ingame';
      if(room.launchId){
        if(room.phase==='results')return 'lobby';
        if(room.phase==='racing'||room.phase==='countdown')return 'ingame';
        if(characterMenuOpen()||!session?.character)return 'selecting';
        if(preparedLaunch===room.launchId)return 'preparing';
        if(lab.download?.loading||playingLevelId()!==String(room.meta?.level||''))return 'loading';
        return 'selecting';
      }
      if(!room.launched&&!travelTarget)return 'lobby';
      if(characterSelected())return 'ingame';
      if(localCharacterEdit()&&(lastPhase==='ingame'||meta))return 'ingame';
      if(!room.meta&&!travelTarget)return 'lobby';
      if(selectingCharacter()&&!(meta&&samePublishedLevel()))return 'selecting';
      if(loadingHostLevel()||lab.download?.loading)return 'loading';
      return room.meta?'loading':'lobby';
    }
    function everyoneInGame(){
      if(!room?.players?.length)return false;
      if(room.launchId)return room.players.every(p=>p.id===selfId?preparedLaunch===room.launchId:!!p.prepared);
      if(!characterSelected())return false;
      return room.players.every(p=>{
        if(p.id===selfId)return characterSelected();
        if(p.phase==='ingame'||p.loaded)return true;
        if(p.phase==='selecting'||p.phase==='loading'||p.phase==='preparing')return false;
        return false;
      });
    }
    function reportPhase(){return publishPresence();}
    function publishPresence(){
      if(!network||!room)return playerPhase();
      const phase=playerPhase();
      const mapKey=(room.launchId||0)+':'+(room.meta?String(room.meta.level)+':'+String(room.meta.hash):'');
      if(mapKey!==lastMapKey){lastMapKey=mapKey;lastPhase='';lastPresenceKey='';}
      if(phase!==lastPhase||pendingStatus){
        lastPhase=phase;
        pendingStatus=false;
        send({type:'status',phase});
      }
      if(!room.launchId&&phase==='ingame'&&room.meta){
        if(room.launched||room.hostId!==selfId)adoptHostLevel();
        if(meta&&(room.hostId===selfId||core.compatible(meta,room.meta))){
          const key=mapKey+'|ingame';
          if(key!==lastPresenceKey){
            lastPresenceKey=key;
            send({type:'level',meta});
          }
        }
      }
      return phase;
    }
    function launchLive(){
      return !!(armedGen&&armedGen===playGen&&room?.launchId&&room.phase&&room.phase!=='lobby'&&room.phase!=='results');
    }
    function pullGuestLevel(){
      if(!launchLive())return;
      if(!room?.launched)return;
      if(sameHeldLevel())return;
      if(!network||!room||room.hostId===selfId||!room.meta)return;
      if(localCharacterEdit())return;
      if(settleGuestLoad())return;
      if(selectingCharacter())return;
      if(hostChecking()&&levelPlayable()){adoptHostLevel();return;}
      if(loadingHostLevel())return;
      travel(room.meta);
    }
    function hookLoader(){
      const hw=happyWheels();
      if(!hw||typeof hw.loadLevelByID!=='function'||hw._mpHooked)return;
      // Native openSessionController assigns the controller, then calls begin().
      // Gate it there, before fixed-character maps can auto-load a solo session.
      const proto=lab.require?.(0x183ff)?.xF?.prototype;
      if(proto&&typeof proto.begin==='function'&&!proto.begin.__jmp){
        const begin=proto.begin;
        const gated=function(...args){
          if(this===sessionController()&&launchLive()){
            this.__jmpTicket=armedGen;
            clearEntry(this);holdSelection();hookNativeLoad(this);
          }
          return begin.apply(this,args);
        };
        gated.__jmp=true;proto.begin=gated;
      }
      const orig=hw.loadLevelByID.bind(hw);
      hw._mpHooked=true;
      hw.loadLevelByID=function(id){
        holdSelection();
        return orig(id);
      };
    }
    async function changed(s){
      const ticket=playGen;
      // Native close leaves currentSession pointing at the disposed object until
      // the replacement is constructed. It must never be fingerprinted or held.
      if(s&&!s.isMenu&&(retiredSessions.has(s)||!s.m_world)){
        if(session===s)session=null;
        if(lab.session===s)lab.session=null;
        return;
      }
      const action=pendingAction;pendingAction=null;
      const incoming=String(lab.download?.level||'');
      const index=String(lab.state.levelIndex||'');
      const known=meta||characterHold?.meta;
      const switchedAway=!!known&&((!!incoming&&String(incoming)!==String(known.level))||(/^[1-9][0-9]{0,8}$/.test(index)&&index!==String(known.level)));
      if(switchedAway)characterHold=null;
      const hold=!switchedAway&&characterSwitching()?characterHold:null;
      const serverStart=room?.start&&room.launchId&&room.launchId===launchId?room.start:null;
      const keepStart=(hold?hold.raceStart:raceStart)||serverStart;
      const keepReady=hold?hold.ready:ready;
      const keepReleased=hold?hold.released:released;
      const prevMeta=hold?.meta||meta;
      const staying=!!(room&&prevMeta&&!switchedAway);
      const arrived=sessionPlayable(s)&&staying&&(index===String(prevMeta.level)||(room?.meta&&String(room.meta.level)===String(prevMeta.level)));
      if(staying&&!arrived&&(hold||characterMenuOpen()||pauseMenuOpen())){
        session=s;lab.session=s;
        meta=prevMeta;lab.meta=meta;
        raceStart=keepStart;ready=keepReady;released=keepReleased;
        if(action)action();
        return;
      }
      if(staying&&!arrived&&(!s||s.isMenu)){
        if(hold){
          session=s;lab.session=s;
          meta=prevMeta;lab.meta=meta;
          raceStart=keepStart;ready=keepReady;released=keepReleased;
          if(action)action();
          return;
        }
        session=s;lab.session=s;
        meta=null;lab.meta=null;
        ready=false;readyCheck=false;
        if(serverStart)raceStart=serverStart;else{raceStart=null;released=false;}
        finishSent=false;resetWatch();restoreChrome();ui?.hideReadyAsk?.();
        if(action)action();
        message('Pick a level to bring everyone.');
        return;
      }
      const sameRoomLevel=!!prevMeta&&!switchedAway&&(
        index===String(prevMeta.level)||
        (room?.meta&&String(room.meta.level)===String(prevMeta.level))
      );
      const respawn=!!(sessionPlayable(s)&&sameRoomLevel&&(keepStart||(room&&room.meta)));
      if(recording)stop();session=s;lab.session=s;playback=null;clear(localGroup,localSprites);layer.visible=!!s;
      if(respawn){
        if(travelTarget&&String(lab.state.levelIndex)===String(travelTarget.level)&&!lab.download?.loading){travelTarget=null;travelLock=null;}
        characterHold=null;
        if(room?.mode==='shared'&&released)thawWorld(s);
        try{s.inputAllowed=true;}catch{}
        if(keepStart&&keepReleased&&!sawDead)deaths++;
        sawDead=false;
        resetWatch();
        ready=false;raceStart=keepStart;released=keepReleased;finishSent=keepStart?finishSent:false;
        ids=new WeakMap();nextId=0;textureIds=new WeakMap();textures=[];lastCapture=-1;sessionStart=s.iteration||0;lastIteration=s.iteration||0;
        meta=prevMeta;lab.meta=meta;
        if(!released)freezeWorld(s);
        else resumeGameAudio();
        scanCourse(s);
        if(raceStart&&!released)placeOnCourse(s,selfId,courseApi.slotFor(course,seatIndex(selfId)));
        else if(released&&(course?.retry==='flag'||course?.retry==='start'||course?.starts.length))placeOnCourse(s,selfId,course?.retry==='start'?courseApi.slotFor(course,seatIndex(selfId)):(courseRun(selfId).last||courseApi.slotFor(course,seatIndex(selfId))));
        lastFrame=capture();
        if(released)publishFrame(true);
        if(action)action();
        return;
      }
      if(!keepStart){deaths=0;sawDead=false;bestProgress=0;liveProgress=0;trackBounds=null;resetWatch();chromeSnapshot=null;}
      if(!keepStart)for(const peer of peers.values()){peer.frames=[];clear(peer.group,peer.sprites);}
      meta=null;lab.meta=null;ready=false;
      if(serverStart){raceStart=serverStart;released=keepReleased;}
      else{raceStart=null;released=keepStart?keepReleased:false;}
      finishSent=keepStart?finishSent:false;
      ids=new WeakMap();nextId=0;textureIds=new WeakMap();textures=[];lastCapture=-1;sessionStart=s?.iteration||0;lastIteration=s?.iteration||0;
      if(!s||s.isMenu){message(room?'Lobby connected. The host can choose a level.':'');return;}
      const current=s,host=travelTarget||(room?.hostId!==selfId?room?.meta:null);
      const key=String(lab.state.levelIndex);
      const downloadedHash=lab.download?.level===key?lab.download.hash:null;
      const hash=downloadedHash||levelHashes.get(key)||await fingerprint(s);if(ticket!==playGen||session!==current)return;
      levelHashes.set(key,hash);
      meta={protocol:core.VERSION,game:'1.99',level:key,hash,character:lab.state.characterIndex,fingerprint:downloadedHash?'download-sha256':'initial-world-sha256'};
      lab.meta=meta;
      if(host&&!s.isEditorTest){
        if(key!==host.level){message('Waiting for host level '+host.level+' to load…');return;}
        const downloaded=lab.download?.level===key?lab.download.hash:'';
        if(lab.download?.loading&&!downloaded){message('Loading level '+key+'…');return;}
        meta={...meta,level:host.level,hash:downloaded||host.hash,fingerprint:downloaded?'download-sha256':'room-level'};
        lab.meta=meta;travelTarget=null;travelLock=null;
      }else if(travelTarget){
        if(key!==travelTarget.level){message('Waiting for host level '+travelTarget.level+' to load…');return;}
        travelTarget=null;travelLock=null;
      }
      const sameLevel=core.compatible(prevMeta,meta);
      if(keepStart&&sameLevel){raceStart=keepStart;ready=keepReady||!keepReleased;if(!released)freezeWorld(s);}
      else{
        if(!sameLevel&&!serverStart){raceStart=null;released=false;ready=false;readyCheck=false;}
        if(network&&room&&meta){
          if(sameRoomLevel||(room.meta&&String(room.meta.level)===String(meta.level))){
            if(room.launched||room.hostId!==selfId)adoptHostLevel();
            resumeGameAudio();
          }else if(room.launched&&room.meta&&(playingLevelId()===room.meta.level||onRoomLevel()||characterSelected())){adoptHostLevel();publishPresence();}
          else if(launchLive()&&room.meta&&!selectingCharacter()&&!localCharacterEdit())travel(room.meta);
        }
      }
      if(!keepStart||!sameLevel)message(room?(room.launched?(room.hostId===selfId?'Level loaded. Pick your character.':'Level loaded. Pick your character.'):(room.hostId===selfId?'Level is in the lobby. Ready when everyone is here.':'Waiting in the lobby.')):'Open Multiplayer to race with friends.');
      scanCourse(s);
      if(!keepStart)resetCourse();
      lastFrame=capture();
      if(action)action();
      reconcileLaunch();
      ui?.refresh();
    }
    function record(){
      if(network)throw Error('Leave the live room before recording a local ghost');
      if(!session||!meta)throw Error('Load a level first');if(session.paused)throw Error('Resume the level first');
      recording={meta:{...meta},textures,frames:[]};recordedBytes=0;lab.recording=recording;sessionStart=session.iteration;lastCapture=-1;message('Recording — use Stop when finished.');
    }
    function stop(){
      if(recording?.frames.length){saved={...recording,textures:JSON.parse(JSON.stringify(textures))};lab.saved=saved;persist(saved);}
      recording=null;lab.recording=null;message(saved?'Run saved in memory. Restart the level, then Play ghost.':'No run recorded.');return saved;
    }
    function play(){if(!saved)throw Error('Record or import a run first');if(!core.compatible(meta,saved.meta))throw Error('This ghost belongs to different level data');playback={record:saved,start:session.iteration};message('Playing your recorded ghost.');}
    function restartThen(fn){
      const controller=lab.state.rootApp.screenManager.currentScreen?.happyWheels?.sessionController;
      if(!controller||!session)throw Error('Load a level first');
      pendingAction=fn;message('Restarting level…');const ticket=playGen;controller.restartLevel();setTimeout(()=>{if(ticket!==playGen||pendingAction!==fn)return;pendingAction=null;try{fn();}catch(e){message(e.message||String(e));}},1200);
    }
    function send(data){
      if(network?.readyState!==1)return false;
      const at=performance.now(),encoded=JSON.stringify(data);
      networkMetrics.add('serializeMs',performance.now()-at);
      networkMetrics.add('packetBytes',packetEncoder.encode(encoded).length);
      networkMetrics.count('sent_'+data.type);
      return network.send(encoded)!==false;
    }
    function savedName(){try{return localStorage.getItem('hw-mp-name')||'Racer';}catch{return 'Racer';}}
    function displayName(){return steam.name||savedName();}
    async function loadSteam(){
      if(!hwGhostNet?.steamStatus){
        steam={ok:false,name:'',avatar:'',error:'Steam invite is not connected to this game window'};
        return steam;
      }
      try{
        const s=await hwGhostNet.steamStatus();
        steam={ok:!!s?.ok,name:String(s?.name||'').slice(0,24),avatar:String(s?.avatar||''),error:s?.ok?'':(s?.error||'Steam is not available.')};
        if(steam.name){try{localStorage.setItem('hw-mp-name',steam.name);}catch{}}
        if(steam.avatar){
          avatars.set('self',steam.avatar);
          if(selfId)avatars.set(selfId,steam.avatar);
        }
      }catch(e){
        steam={ok:false,name:'',avatar:'',error:e.message||'Steam is not available.'};
      }
      return steam;
    }
    function sendProfile(){
      if(profileSent||!network||network.readyState!==1||!steam.avatar)return;
      profileSent=true;
      pendingProfile=true;
      send({type:'profile',name:displayName(),avatar:steam.avatar});
    }
    function sendChat(text){
      const t=String(text||'').replace(/\s+/g,' ').trim().slice(0,200);
      if(!t)return;
      if(!network||!room)throw Error('Join a room first');
      const now=Date.now();
      while(chatTimes.length&&now-chatTimes[0]>5000)chatTimes.shift();
      if(chatTimes.length>=5)throw Error('Chat is limited to 5 messages every 5 seconds.');
      chatTimes.push(now);
      pendingChat=true;
      try{send({type:'chat',text:t});}
      catch(e){chatTimes.pop();pendingChat=false;throw e;}
    }
    function bindPageSocket(socket,url,epoch){
      const raw=new WebSocket(url);
      const queue=new window.HWNetworkQueue.SendQueue(raw,{notify:stats=>transportStats(stats,socket)});
      socket.send=data=>queue.send(data);
      socket.close=()=>{queue.stop();if(epoch===socketEpoch)socketEpoch++;socket.readyState=3;try{raw.close();}catch{}};
      raw.onopen=()=>{if(epoch!==socketEpoch)return;socket.opened=true;socket.readyState=1;socket.onopen?.();};
      raw.onmessage=event=>{if(epoch!==socketEpoch)return;socket.onmessage?.(event);};
      raw.onerror=event=>{if(epoch!==socketEpoch)return;socket.onerror?.(event);};
      raw.onclose=()=>{queue.stop();if(epoch!==socketEpoch)return;if(!socket.opened){socket.failed=true;}socket.readyState=3;socket.onclose?.();};
      return socket;
    }
    function makeSocket(url){
      const epoch=++socketEpoch;
      if(!hwGhostNet){
        const socket={readyState:0,epoch,opened:false};
        return bindPageSocket(socket,url,epoch);
      }
      const socket={readyState:0,epoch,opened:false,send:data=>hwGhostNet.send(data)};
      const unsubscribe=hwGhostNet.onEvent(event=>{
        if(epoch!==socketEpoch)return;
        if(event.type==='message'){if(!socket.opened){socket.opened=true;socket.readyState=1;}socket.onmessage?.({data:event.data});}
        if(event.type==='error')socket.onerror?.(event.data);
        if(event.type==='transport')transportStats(event.data,socket);
        if(event.type==='close'){
          if(!socket.opened)return;
          socket.readyState=3;unsubscribe();socket.onclose?.();
        }
      });
      socket.close=()=>{if(epoch===socketEpoch)socketEpoch++;unsubscribe();socket.readyState=3;hwGhostNet.disconnect();};
      hwGhostNet.connect(url).then(()=>{
        if(epoch!==socketEpoch)return;
        socket.opened=true;socket.readyState=1;socket.onopen?.();
      }).catch(()=>{
        if(epoch!==socketEpoch)return;
        unsubscribe();
        try{bindPageSocket(socket,url,epoch);}
        catch(e){socket.readyState=3;socket.onerror?.(e);socket.failed=true;socket.onclose?.();}
      });
      return socket;
    }
    function transportStats(stats,socket){
      if(!stats||socket!==network)return;
      for(const key of ['bufferedAmount','queuedBytes','queueAgeMs'])networkMetrics.add(key,stats[key]);
      shared.transportPressure(stats);
      if(stats.fatal){socket.failureReason=stats.reason;shared.transportIssue(stats);message(stats.reason);}
    }
    function connect(url,code,name,mode='ghost',capacity=8,options={}){
      code=String(code||'').trim().toUpperCase();const endpoint=new URL(url);if(!['ws:','wss:'].includes(endpoint.protocol))throw Error('Use a ws:// or wss:// relay address');
      relayUrl=endpoint.href;const seats=Math.max(2,Math.min(16,Number(capacity)||8));relaySeats=seats;
      disconnect();playback=null;clear(localGroup,localSprites);const socket=makeSocket(endpoint.href);network=socket;lab.socket=network;
      network.onopen=()=>{
        Promise.resolve(loadSteam()).then(()=>{
          if(network!==socket)return;
          send({type:code?'join':'create',mode,capacity:seats,code:code.trim().toUpperCase(),name:displayName()||String(name||'Racer').slice(0,24),protocol:core.VERSION,meta:session&&!session.isMenu&&!session.isEditorTest?meta:null,
            roomName:String(options.roomName||'').slice(0,48),visibility:options.visibility||'friends',password:options.password||''});
          options={}; // Passwords are never persisted or included in room state.
        }).catch(e=>message(e.message||String(e)));
      };
      network.onerror=()=>message('Cannot reach the multiplayer server. Check Server settings and that the server is running.');
      network.onclose=()=>{
        if(network!==socket)return;
        if(ready||raceStart)thawWorld(session);
        const failed=socket.failed||!room;
        disconnect();ui?.refresh();
        message(socket.failureReason||(failed?'Cannot reach the multiplayer server. Check Server settings and that the server is running.':'Disconnected from the multiplayer server.'));
      };
      network.onmessage=e=>{try{receive(JSON.parse(e.data));}catch(err){lab.errors.push(String(err));}};
    }
    function publishSteam(){
      if(!room||room.hostId!==selfId||!relayUrl||steamRoom===room.code||!hwGhostNet?.steamPublish)return;
      const code=room.code;steamRoom=code;
      hwGhostNet.steamPublish({code,server:relayUrl,mode:room.mode,seats:room.capacity||relaySeats}).then(result=>{
        if(room?.code!==code)return;
        if(!result?.ok)message('Room is ready. Share the code. Steam invites are unavailable.');
      }).catch(()=>{message('Room is ready. Share the code. Steam invites are unavailable.');});
    }
    function joinSteam(invite){
      if(!invite?.code||!invite.server)return;
      if(room){message('Leave this room before joining a Steam invite.');return;}
      if(ui?.joinCode){ui.joinCode(invite.code,invite.server);return;}
      message('Joining '+invite.code+' from Steam…');
      Promise.resolve(loadSteam()).then(()=>connect(invite.server,invite.code,displayName(),invite.mode==='shared'?'shared':'ghost',8));
    }
    function voidGeneration(){
      const controller=sessionController();
      if(controller?.__jmpTicket)deadGens.add(controller.__jmpTicket);
      if(armedGen)deadGens.add(armedGen);
      playGen++;
      armedGen=0;
    }
    function clearEntry(controller){
      if(!controller)return;
      controller.__jmpEntry='notRequested';
      controller.__jmpEntryTries=0;
      controller.__jmpEntryAt=0;
      controller.__jmpEntryNoted=false;
      controller.__jmpEntryLaunch=0;
      controller.__jmpEntryToken=(controller.__jmpEntryToken||0)+1;
      controller.__jmpAuthorized=0;
      controller.__jmpEntering=0;
    }
    function traceCharacter(step, characterId, extra){
      const row={launchId:launchId||0,step,characterId:Number(characterId)||0};
      if(extra&&typeof extra==='object')Object.assign(row,extra);
      characterTrace.push(row);
      if(characterTrace.length>80)characterTrace.shift();
      lab.characterTrace=characterTrace;
    }
    function disconnect(){steamRoom='';voidGeneration();clearTimeout(lobbyTimer);neutralizeInput();shared.stop();clearShared();seenLobbyRev=0;retiredLaunch=0;playerCollide=true;pendingCollide=false;pendingChat=false;pendingProfile=false;profileSent=false;avatars.clear();chatLog.length=0;chatTimes.length=0;inputBlocks.clear();characterHold=null;confirmedCharacter=0;confirmedSkin='';confirmedLaunch=0;launchId=0;launchRoster=[];lastAckKey='';entryError='';entryWait='';entryMilestone='';lastWaitKey='';clearTimeout(entryTimer);preparedLaunch=0;prepHold=0;prepSentFor=0;armedLaunch=0;committedLoad=0;pendingSelect=null;loadErrorFor=0;resultsRows=null;lingerUntil=0;resetCourse();course=courseApi?courseApi.empty():null;if(network){network.onclose=null;network.onmessage=null;network.close();network=null;}lab.socket=null;lab.forceLevelRestart=false;room=null;selfId=null;travelTarget=null;travelLock=null;pendingAction=null;raceStart=null;released=false;ready=false;readyCheck=false;hostReadyAt=0;askSuppressAt=0;lastHostReady=false;lastChecking=false;lastShareKey='';lastPhase='';lastPresenceKey='';lastMapKey='';lastCharacter=0;pendingStatus=false;ui?.hideReadyAsk?.();ui?.clearRaceChrome?.();resetWatch();for(const peer of peers.values()){dropTag(peer);releaseDisplay(peer.group);}peers.clear();}
    function followHostLevel(target){
      if(!target||room?.hostId===selfId)return;
      if(playingLevelId()===target.level&&session&&!session.isMenu&&!session.isEditorTest){
        travelTarget=null;travelLock=null;
        if(!core.compatible(meta,target))adoptHostLevel();
        if(meta)send({type:'level',meta});
        return;
      }
      travel(target);
    }
    function enterLobby(rev){
      if(rev&&rev<=seenLobbyRev)return;
      if(rev)seenLobbyRev=rev;
      const inPlay=!!(launchId||travelTarget||raceStart||(session&&!session.isMenu&&!session.isEditorTest));
      if(launchId)retiredLaunch=Math.max(retiredLaunch,launchId);
      voidGeneration();
      const ticket=playGen;
      if(room)room={...room,phase:'lobby',launchId:0,launched:false,gate:false,start:null,results:null,restartVote:null,players:(room.players||[]).map(p=>({...p,ready:false,confirmed:null,character:null,prepared:false,finished:false,phase:'lobby'}))};
      pendingAction=null;
      travelTarget=null;travelLock=null;
      raceStart=null;released=false;ready=false;readyCheck=false;
      prepHold=0;preparedLaunch=0;prepSentFor=0;armedLaunch=0;committedLoad=0;pendingSelect=null;loadErrorFor=0;
      confirmedCharacter=0;confirmedSkin='';confirmedLaunch=0;launchId=0;launchRoster=[];lastAckKey='';entryError='';entryWait='';entryMilestone='';lastWaitKey='';clearTimeout(entryTimer);
      characterHold=null;resultsRows=null;lingerUntil=0;
      clearEntry(sessionController());
      neutralizeInput();
      shared.stop();
      clearShared();
      resetWatch();
      resetCourse();
      for(const peer of peers.values()){dropTag(peer);releaseDisplay(peer.group);}
      peers.clear();
      layer.visible=false;
      hideTags();
      ui?.hideReadyAsk?.();
      ui?.clearRaceChrome?.();
      if(inPlay)try{happyWheels()?.closeSessionController?.();}catch(e){if(lab.errors.length<30)lab.errors.push(String(e.message||e));}
      session=null;lab.session=null;meta=null;lab.meta=null;lab.forceLevelRestart=false;
      lastFrame=null;lastPhase='';lastPresenceKey='';lastMapKey='';lastCharacter=0;
      clearTimeout(lobbyTimer);
      const deadline=Date.now()+2000;
      const show=()=>{
        if(ticket!==playGen)return;
        const menu=happyWheels()?.mainMenu;
        if((!menu||!(menu.parent||menu.pixiSprite?.parent))&&Date.now()<deadline){lobbyTimer=setTimeout(show,50);return;}
        ui?.open?.();
        message('Back in the lobby.');
      };
      lobbyTimer=setTimeout(show,50);
    }
    function returnToLobby(){
      if(!room||room.hostId!==selfId)throw Error('Only the host can return everyone to the lobby');
      send({type:'returnToLobby'});
      message('Returning everyone to the lobby…');
    }
    function travel(target,{fresh=false}={}){
      const ticket=playGen;
      if(!launchLive())return;
      if(!target||target.protocol!==core.VERSION||!/^[1-9][0-9]{0,8}$/.test(target.level))throw Error('Invalid host level');
      if(!fresh&&playingLevelId()===target.level&&session&&!session.isMenu&&!session.isEditorTest){
        travelTarget=null;travelLock=null;
        if(!core.compatible(meta,target))adoptHostLevel();
        if(meta)send({type:'level',meta});
        if(hostChecking())message((room.players.find(p=>p.id===room.hostId)?.name||'The host')+' is ready. Are you ready?');
        else message(room?.hostId===selfId?'Level is in the room.':'Host level loaded. Wait for the host to start a ready check.');
        return;
      }
      const now=Date.now();
      if(!fresh&&travelLock===target.level&&now-travelAt<8000)return;
      travelLock=target.level;travelAt=now;askSuppressAt=now;
      travelTarget=target;pendingAction=null;ready=false;readyCheck=false;ui?.hideReadyAsk?.();
      if(room?.mode==='shared')shared.stop();
      const keepRace=!!(raceStart&&room?.launchId&&room.launchId===launchId);
      if(!keepRace){raceStart=null;released=false;prepHold=0;thawWorld(session);}
      else freezeWorld(session);
      const hw=app.screenManager.currentScreen?.happyWheels;
      if(!hw?.loadLevelByID){travelLock=null;message('Waiting for the game to finish loading...');setTimeout(()=>{if(ticket!==playGen||!network||travelTarget!==target)return;travel(target,{fresh});},500);return;}
      message('Loading host level '+target.level+'…');
      if(session&&!session.isMenu)retiredSessions.add(session);
      const current=lab.state.currentSession;
      if(current&&!current.isMenu)retiredSessions.add(current);
      session=null;lab.session=null;meta=null;lab.meta=null;lastFrame=null;
      try{if(hw.sessionController)hw.closeSessionController();}catch{}
      const loaded=hw.loadLevelByID(Number(target.level));
      if(loaded?.catch)loaded.catch(error=>{if(ticket!==playGen)return;travelLock=null;entryError=String(error.message||error);message(entryError);ui?.refresh();});
      try{hw.closeMainMenu?.();}catch{}
    }
    function survivalCourse(){return room?.rules?room.rules.play==='survival':course?.play==='survival';}
    function requestRestartVote(){
      if(!network||!room||!survivalCourse())return false;
      if(!room.launchId||(!room.start&&!room.results)){message('Wait for the match to start before requesting a restart.');return true;}
      if(!room.capabilities?.includes('restart-vote-v1')){message('Restart voting needs the updated multiplayer server.');return true;}
      const vote=room.restartVote;
      if(vote){if(!vote.players?.find(p=>p.id===selfId)?.yes)voteRestart(true);return true;}
      send({type:'requestRestart',launchId:room.launchId});message('Asking everyone to restart…');return true;
    }
    function voteRestart(yes){const vote=room?.restartVote;if(!vote)return;send({type:'restartVote',id:vote.id,launchId:vote.launchId,yes:!!yes});}
    function summon(){if(!room||room.hostId!==selfId)throw Error('Only the host can bring everyone');if(survivalCourse()&&room.launchId&&(room.start||room.results)&&core.compatible(meta,room.meta))return requestRestartVote();if(!meta||!session||session.isMenu||session.isEditorTest||lab.download?.loading||String(lab.state.levelIndex)!==meta.level)throw Error('Wait for the new level to finish loading');send({type:'summon',meta,rules:{play:course?.play,waitSec:course?.waitSec,rider:course?.rider,seats:course?.seats,lingerMs:course?.lingerMs}});message('Resetting players on level '+meta.level+'…');}
    function resetWorld(){if(survivalCourse()&&room?.launchId&&(room.start||room.results))return requestRestartVote();if(!room||room.hostId!==selfId)throw Error('Only the host can reset the world');if(room.mode!=='shared')throw Error('Reset world is only for Shared Physics');if(!meta||!session||session.isMenu||session.isEditorTest||lab.download?.loading||String(lab.state.levelIndex)!==String(meta.level))throw Error('Wait for the level to finish loading');send({type:'restart',meta});message('Resetting the world…');}
    function receive(m){
      if(m.type==='authorityInput'||m.type==='authorityRequest'||m.type==='authorityState'||m.type==='sharedInput'||m.type==='sharedSignal'||m.type==='sharedState'||m.type==='sharedPose'||m.type==='sharedHit'){
        if(!room||room.mode!=='shared'||(m.launchId!=null&&m.launchId!==room.launchId))return;
        const staged=m.type==='authorityState'&&m.full&&m.epoch===0&&m.launchId===room.launchId&&room.phase==='loading';
        if(!staged&&(!raceStart||m.epoch!==raceStart))return;
        shared.setContext(sharedContext());shared.receive(m);return;
      }
      if(m.type==='restartVoteEnded'){
        if(!room||m.launchId!==room.launchId)return;
        if(room.restartVote?.id===m.id)room.restartVote=null;
        const copy={accepted:'Everyone agreed. Restarting the match…',declined:'Restart declined. The match continues.',expired:'Restart vote timed out. The match continues.',playersChanged:'Players changed. Request a new restart vote.',cancelled:'Restart vote cancelled.'};
        message(copy[m.outcome]||'Restart vote ended.');ui?.refresh();return;
      }
      if(m.type==='identity'){selfId=m.id;if(steam.avatar)avatars.set(selfId,steam.avatar);sendProfile();return;}
      if(m.type==='profile'){
        pendingProfile=false;
        if(m.id&&m.avatar)avatars.set(m.id,m.avatar);
        if(room&&m.id&&m.name){const p=room.players.find(x=>x.id===m.id);if(p)p.name=m.name;}
        ui?.refresh();
        return;
      }
      if(m.type==='chat'){
        pendingChat=false;
        const text=String(m.text||'').replace(/\s+/g,' ').trim().slice(0,200);
        if(!text)return;
        chatLog.push({id:m.id,name:String(m.name||'Racer').slice(0,24),text,at:Date.now()});
        if(chatLog.length>100)chatLog.shift();
        ui?.refresh();
        return;
      }
      if(m.type==='travel'){if(launchLive()&&m.meta)travel(m.meta);return;}
      if(m.type==='launch'){
        if(m.launchId&&m.launchId<=retiredLaunch)return;
        if(m.launchId&&launchId&&m.launchId<launchId)return;
        if(m.launchId===launchId&&armedGen===playGen&&armedGen)return;
        if(!m.launchId||m.launchId!==launchId||armedGen!==playGen||!armedGen){
          if(launchId&&launchId!==m.launchId)retiredLaunch=Math.max(retiredLaunch,launchId);
          voidGeneration();armedGen=playGen;clearTimeout(lobbyTimer);
          neutralizeInput();shared.stop();clearShared();resetWatch();resetCourse();
          pendingAction=null;travelTarget=null;travelLock=null;characterHold=null;
          ui?.hideReadyAsk?.();ui?.clearRaceChrome?.();
          launchId=m.launchId||0;preparedLaunch=0;prepSentFor=0;armedLaunch=0;prepHold=0;raceStart=null;released=false;
          committedLoad=0;pendingSelect=null;loadErrorFor=0;launchRoster=[];lastAckKey='';entryError='';entryWait='';entryMilestone='';lastWaitKey='';clearTimeout(entryTimer);
          confirmedCharacter=m.rider||0;confirmedSkin='';confirmedLaunch=m.rider?launchId:0;
          const kept=localRosterChoice(m.roster,selfId);
          if(kept){confirmedCharacter=kept.characterId;confirmedSkin=kept.skinId;confirmedLaunch=launchId;}
          const controller=sessionController();
          if(controller)clearEntry(controller);
        }
        resultsRows=null;lingerUntil=0;
        if(m.rider&&lab.state)lab.state.characterIndex=m.rider;
        room={...(room||{}),launchId,start:null,results:null,restartVote:null,countdownMs:m.countdownMs||room?.countdownMs,launched:true,gate:true,phase:'selecting',meta:m.meta||room?.meta,rules:m.rider?{...(room?.rules||{}),rider:m.rider}:(room?.rules||null)};
        ui?.closeForTransition?.(launchId);
        holdSelection();
        travel(m.meta,{fresh:true});
        message(m.rider?'This level locks the character. Waiting for everyone to load.':'Pick a character. The level starts when everyone has chosen.');
        return;
      }
      if(m.type==='loadRace'){
        if(playGen!==armedGen||(m.launchId&&m.launchId<=retiredLaunch))return;
        if(!m.launchId||(launchId&&m.launchId!==launchId)||committedLoad===m.launchId)return;
        if(m.launchId)launchId=m.launchId;
        launchRoster=(Array.isArray(m.roster)?m.roster:[]).map(p=>({id:p.id,characterId:Number(p.characterId??p.character),skinId:p.skinId||p.skin||''}));
        entryError='';entryWait='';lastWaitKey='';
        milestone('loadRace');
        const me=localRosterChoice(launchRoster, selfId);
        if(!me){entryWait='Waiting for your character in the roster.';message(entryWait);return;}
        milestone('choice');
        for(const row of launchRoster)traceCharacter('roster', row.characterId, {id:row.id,skin:row.skinId||''});
        committedLoad=m.launchId;
        confirmedCharacter=me.characterId;
        confirmedSkin=me.skinId||'';
        confirmedLaunch=launchId;
        const controller=sessionController();
        if(controller){
          controller.__jmpAuthorized=launchId;
          controller.__jmpEntry='notRequested';
          controller.__jmpEntryTries=0;
          controller.__jmpEntryNoted=false;
          controller.__jmpEntryLaunch=launchId;
          controller.__jmpEntering=0;
        }
        room={...(room||{}),phase:'loading',launchId};
        holdSelection();
        commitNativeLevel();
        message(loadingStatus());
        return;
      }
      if(m.type==='roster'){
        if(m.launchId&&m.launchId===launchId)shared.noteRoster?.(m);
        return;
      }
      if(m.type==='linger'){if(m.launchId!=null&&m.launchId!==launchId)return;lingerUntil=m.until||0;message('Finish window open.');return;}
      if(m.type==='results'){if(m.launchId!=null&&m.launchId!==launchId)return;resultsRows=m.rows||[];raceStart=null;released=false;lingerUntil=0;freezeWorld(session);message('Race finished.');ui?.refresh();return;}
      if(m.type==='kicked'){const text=m.message||'The host removed you from the room.';disconnect();message(text);return;}
      if(m.type==='error'){
        if(pendingPick&&/unknown message/i.test(m.message||'')){pendingPick=false;message('The multiplayer server does not have the new level picker yet. It is updating now — try the level again in a minute.');return;}
        if(pendingChat&&/unknown message/i.test(m.message||'')){pendingChat=false;message('Chat is not on this server yet.');return;}
        if(pendingProfile&&/unknown message/i.test(m.message||'')){pendingProfile=false;return;}
        if((pendingDecline||pendingStatus||pendingCollide)&&/unknown message/i.test(m.message||'')){pendingDecline=false;pendingStatus=false;pendingCollide=false;return;}
        pendingDecline=false;pendingStatus=false;
        if(m.message==='Invalid pose'){if(lab.errors.length<30)lab.errors.push(m.message);return;}
        const text=m.message==='Invalid authoritative controls'&&lab.lastControl?m.message+' ('+lab.lastControl+')':m.message;
        if(!room)disconnect();ready=false;if(session?.paused&&!raceStart&&!prepHold)thawWorld(session);message(text);return;
      }
      if(m.type==='returnToLobby'){
        enterLobby(m.rev||0);
        return;
      }
      if(m.type==='room'){
        if(room?.code===m.code&&((m.lobbyRev||0)<seenLobbyRev||(m.launchId&&m.launchId<=retiredLaunch)))return;
        const inPlay=!!(launchId||travelTarget||raceStart||(session&&!session.isMenu&&!session.isEditorTest));
        if(m.phase==='lobby'&&!m.launchId&&!m.launched&&(m.lobbyRev||0)>seenLobbyRev&&inPlay){
          room=m;
          enterLobby(m.lobbyRev);
          ui?.refresh();
          return;
        }
        if((m.lobbyRev||0)>seenLobbyRev)seenLobbyRev=m.lobbyRev;
        if((m.launchId||0)!==launchId){
          if(launchId)retiredLaunch=Math.max(retiredLaunch,launchId);
          armedGen=0;
          launchId=m.launchId||0;preparedLaunch=0;prepSentFor=0;armedLaunch=0;prepHold=0;raceStart=null;released=false;
          committedLoad=0;pendingSelect=null;loadErrorFor=0;launchRoster=[];lastAckKey='';entryError='';entryWait='';entryMilestone='';lastWaitKey='';clearTimeout(entryTimer);
          confirmedCharacter=m.rules?.rider||0;confirmedSkin='';confirmedLaunch=0;
          clearEntry(sessionController());
        }
        const me=m.players?.find(p=>p.id===selfId);
        if(me?.confirmed){
          confirmedCharacter=me.confirmed;confirmedSkin=me.skin||'';confirmedLaunch=launchId;
          const ackKey=launchId+':'+me.confirmed+':'+(me.skin||'');
          if(ackKey!==lastAckKey){lastAckKey=ackKey;traceCharacter('acked', me.confirmed, {skin:me.skin||''});}
        }
        if(m.phase==='selecting'&&pendingSelect&&me?.confirmed===pendingSelect.id&&(me.skin||'')===pendingSelect.skin){
          pendingSelect=null;
          const waiting=(m.players||[]).filter(p=>!Number.isInteger(p.confirmed)).map(p=>p.name||'A racer');
          message(waiting.length?'Selected — waiting for '+waiting.join(', ')+'.':'Selected — waiting for other players.');
        }else if(m.phase==='selecting'){
          const waiting=(m.players||[]).filter(p=>!Number.isInteger(p.confirmed)).map(p=>p.name||'A racer');
          if(waiting.length&&waiting.length<m.players.length)message('Waiting for '+waiting.join(', ')+' to pick a character.');
        }else if(m.phase==='loading'&&!raceStart){
          message(loadingStatus());
        }
        if(me?.prepared&&m.launchId===launchId)preparedLaunch=launchId;
        if(m.launchId&&m.launchId===launchId&&m.start)raceStart=m.start;
        else if(m.launchId===launchId&&!m.start&&(m.phase==='selecting'||m.phase==='preparing'||m.phase==='lobby'||m.phase==='results')){raceStart=null;released=false;armedLaunch=0;}
        if(room?.code&&m.code&&m.code!==room.code){chatLog.length=0;chatTimes.length=0;}
        room=m;if(Array.isArray(m.results))resultsRows=m.results;else if(!m.launched)resultsRows=null;if(m.hostId!==selfId&&typeof m.collide==='boolean')playerCollide=m.collide;panel.querySelector('#gh-summon').hidden=m.hostId!==selfId;codeInput.value=m.code;
        publishSteam();
        const waiting=m.players.filter(p=>!p.ready).length;
        roomLabel.textContent='Room '+m.code+' / Level '+(m.meta?.level||'not selected')+' / '+m.players.map(p=>p.name+(p.ready?' [READY]':' [not ready]')).join(', ');
        for(const [id,peer] of peers)ensureTag(peer,id);
        noteHostReady(m);
        if(launchLive()&&m.meta&&m.hostId!==selfId&&playingLevelId()!==String(m.meta.level)&&!loadingHostLevel()&&!selectingCharacter())travel(m.meta);
        readyCheck=shouldAskReady();
        publishPresence();
        const picking=m.phase==='selecting'||m.phase==='loading'||m.gate;
        if(!picking&&!ready&&!raceStart){
          const hostName=m.players.find(p=>p.id===m.hostId)?.name||'The host';
          if(!m.meta){if(m.hostId!==selfId)message('Waiting for the host to choose a level.');else if(lab.status==='Share your room code, then choose a level.')message('');}
          else if(m.hostId===selfId)message(m.checking?'Waiting for the other racers to ready up.':'Level is shared. Click Ready when everyone has loaded.');
          else if(m.checking||readyCheck)message(hostName+' is ready. Are you ready?');
          else message('Wait for the host to start a ready check.');
        }
        else if(ready&&!raceStart)message(waiting?'Ready - waiting for '+waiting+' more.':'Ready - starting...');
        ui?.refresh();
        return;
      }
      if(m.type==='readyCheck'){
        hostReadyAt=Date.now();lastHostReady=true;lastChecking=true;
        if(room)room.checking=true;
        readyCheck=true;
        if(room&&room.hostId!==selfId&&!ready&&!raceStart){
          message((m.name||'The host')+' is ready. Are you ready?');
          ui?.askReady?.(m.name);
        }
        ui?.refresh();
        return;
      }
      if(m.type==='readyDeclined'){
        pendingDecline=false;
        abortReadyCheck(m.name,m.message);
        return;
      }
      if(m.type==='pong'){networkMetrics.add('relayRoundTripMs',Date.now()-m.clientTime);clockOffset=m.serverTime-(Date.now()+m.clientTime)/2;return;}
      if(m.type==='start'){
        if(playGen!==armedGen||(m.launchId&&m.launchId<=retiredLaunch))return;
        if(m.launchId&&launchId&&m.launchId!==launchId)return;
        if(m.launchId)launchId=m.launchId;
        readyCheck=false;hostReadyAt=0;lastHostReady=true;lastChecking=false;resultsRows=null;lingerUntil=0;ui?.hideReadyAsk?.();
        raceStart=m.at;released=false;finishSent=false;deaths=0;sawDead=false;bestProgress=0;liveProgress=0;clearShared();resetWatch();resetCourse();if(session){sessionStart=session.iteration;trackBounds=measureBounds(session);}lastCapture=-1;noteChrome();
        if(room)room={...room,start:m.at,phase:'countdown'};
        for(const peer of peers.values()){peer.frames=[];peer.deaths=0;peer.best=0;peer.progress=0;clear(peer.group,peer.sprites);}
        prepHold=launchId;
        if(preparedLaunch!==launchId||!session||session.isMenu){message('Still preparing…');if(session&&!session.isMenu)freezeWorld(session);return;}
        armStart(session);
        message('Race countdown: '+String(Math.max(1,Math.round((m.countdownMs||3000)/1000))));return;
      }
      if(m.type==='cancel'){
        if(m.lobbyRev){enterLobby(m.lobbyRev);message(m.message||'Back in the lobby.');return;}
        if(/left/i.test(m.message||''))return;
        readyCheck=false;hostReadyAt=0;lastHostReady=false;lastChecking=false;ui?.hideReadyAsk?.();
        if(room?.mode==='shared')shared.reset(session);
        raceStart=null;released=false;ready=false;deaths=0;sawDead=false;bestProgress=0;liveProgress=0;clearShared();resetWatch();thawWorld(session);for(const peer of peers.values()){peer.frames=[];peer.deaths=0;peer.best=0;peer.progress=0;clear(peer.group,peer.sprites);}message(m.message);return;
      }
      if(m.type==='left'){
        const peer=peers.get(m.id);if(peer){dropTag(peer);releaseDisplay(peer.group);peers.delete(m.id);}
        avatars.delete(m.id);
        if(spectateId===m.id)spectateId=selfId;
        message((m.name||'A racer')+' left.');
        ui?.refresh();
        return;
      }
      if(m.type==='finish'){message(m.name+' finished in '+(m.time/1000).toFixed(2)+'s (client reported).');return;}
      if(m.type==='frame'&&!(m.launchId&&room?.launchId&&m.launchId!==room.launchId)&&core.validFrame(m.frame)&&Array.isArray(m.textures)&&m.textures.length<=4096&&m.textures.every(core.validTexture)){
        let peer=peers.get(m.id);if(!peer){const group=new Container();layer.addChild(group);peer={id:m.id,group,sprites:new Map(),frames:[],textures:[],lastArrival:0,deaths:0,best:0,progress:0};peers.set(m.id,peer);ensureTag(peer,m.id);}
        if(Number.isFinite(m.frame.deaths))peer.deaths=Math.max(peer.deaths,m.frame.deaths|0);
        const prev=peer.frames.at(-1);
        if(peer.frames.length&&m.frame.t<prev.t)return;
        if(prev?.dead&&!m.frame.dead)peer.frames=[];
        peer.textures=m.textures;peer.lastArrival=performance.now();
        peer.progress=Number.isFinite(m.frame.current)?m.frame.current:(Number.isFinite(m.frame.progress)?m.frame.progress:peer.progress);
        peer.best=Number.isFinite(m.frame.best)?Math.max(peer.best,m.frame.best):(Number.isFinite(m.frame.progress)?Math.max(peer.best,m.frame.progress):peer.best);
        if(!peer.frames.length||m.frame.t>peer.frames.at(-1).t)peer.frames.push(m.frame);
        while(peer.frames.length>100)peer.frames.shift();
      }
    }
    function adoptHostLevel(){
      const host=room?.meta;
      if(!host||!levelPlayable()||characterMenuOpen()||lab.download?.loading)return false;
      if(playingLevelId()!==String(host.level))return false;
      const downloaded=lab.download?.level===String(host.level)?lab.download.hash:'';
      meta={protocol:host.protocol||core.VERSION,game:host.game||'1.99',level:host.level,hash:downloaded||host.hash,character:confirmedCharacter||lab.state.characterIndex,fingerprint:downloaded?'download-sha256':'room-level'};
      lab.meta=meta;travelTarget=null;travelLock=null;return true;
    }
    function armStart(s){
      if(!s||s.isMenu)return;
      armedLaunch=launchId;prepHold=launchId;ready=true;
      scanCourse(s);placeOnCourse(s,selfId,courseApi.slotFor(course,seatIndex(selfId)));coursePlaced=true;
      freezeWorld(s);sessionStart=s.iteration||sessionStart;lastFrame=capture()||lastFrame;
    }
    function ownHold(s){
      if(!prepHold||prepHold!==launchId||released||!s||s.isMenu)return;
      freezeWorld(s);
    }
    function reconcileLaunch(){
      if(room&&playGen!==armedGen)return;
      if(!room?.launchId||launchId!==room.launchId||released||room.phase==='results'||room.results)return;
      holdSelection();
      if(room.phase==='selecting')acceptForced();
      if(room.phase==='loading'){
        commitNativeLevel();
        const created=sessionController()?.__jmpLaunchSession;
        const loadedId=created?String(lab.state?.levelIndex||''):'';
        if(created&&loadedId&&room.meta?.level&&loadedId!==String(room.meta.level)&&loadErrorFor!==launchId){
          loadErrorFor=launchId;
          failEntry(sessionController(),'Loaded level '+loadedId+' does not match lobby level '+room.meta.level+'.');
        }
        if(!entryCompleted())return;
      }
      if(room.phase==='selecting')return;
      ownHold(session);
      if(room.mode==='shared'){
        const status=shared.prepStatus?.();
        const me=room.players?.find(p=>p.id===selfId);
        if(status?.ready&&status.launchId===launchId&&!me?.prepared&&(prepSentFor!==launchId||Date.now()-prepSentAt>2000)){
          prepSentFor=launchId;prepSentAt=Date.now();prepHold=launchId;freezeWorld(session);
          const roster=room.hostId===selfId?room.players.filter(p=>Number.isInteger(p.confirmed)).map(p=>({id:p.id,character:p.confirmed,skin:p.skin||''})):undefined;
          if(entryMilestone!=='prepared')milestone('prepared');
          send({type:'playerPrepared',launchId,levelId:String(room.meta.level),levelHash:room.meta.hash,characterId:confirmedCharacter,skinId:confirmedSkin,snapshot:true,roster});
        }
        if(raceStart&&preparedLaunch===launchId&&armedLaunch!==launchId)armStart(session);
        return;
      }
      if(!sessionReadyForLaunch())return;
      const frame=capture();
      if(frame?.parts?.length)lastFrame=frame;
      if(!lastFrame?.parts?.length){message('Still preparing…');return;}
      prepHold=launchId;freezeWorld(session);
      const me=room.players?.find(p=>p.id===selfId);
      if(!me?.prepared&&(prepSentFor!==launchId||Date.now()-prepSentAt>2000)){
        prepSentFor=launchId;prepSentAt=Date.now();
        if(entryMilestone!=='prepared')milestone('prepared');
        send({type:'playerPrepared',launchId,levelId:String(room.meta.level),levelHash:room.meta.hash,characterId:confirmedCharacter,skinId:confirmedSkin});
      }
      if(raceStart&&preparedLaunch===launchId&&armedLaunch!==launchId)armStart(session);
    }
    function bindGuestToRoom(){
      if(!network||!room)return {ok:false,why:'offline'};
      if(!room.meta)return {ok:false,why:'nolevel'};
      if(onRoomLevel()||(hostChecking()&&levelPlayable())){
        if(!adoptHostLevel())return {ok:false,why:'offline'};
        send({type:'level',meta});
        return {ok:true,why:'synced'};
      }
      if(loadingHostLevel())return {ok:false,why:'loading'};
      travel(room.meta);
      return {ok:false,why:'travel'};
    }
    function ensureLevelSynced(){
      if(!network||!room)return false;
      if(room.hostId!==selfId)return bindGuestToRoom().ok;
      if(!levelPlayable()||!meta)return false;
      return !!room.meta&&String(room.meta.level)===String(meta.level);
    }
    function linkState(){
      const connected=!!(network&&room);
      const level=room?.meta?.level||'';
      const phase=playerPhase();
      const synced=connected&&(!level||onRoomLevel());
      const loading=phase==='loading';
      let label='Not connected';
      if(network&&!room)label='Connecting…';
      else if(connected&&!level)label='Connected · waiting for the host to pick a level';
      else if(phase==='selecting')label='Select your character for level '+level;
      else if(phase==='ingame'&&everyoneInGame())label='Connected · everyone is on level '+level;
      else if(phase==='ingame')label='Connected · on level '+level+' · waiting for others to select a character';
      else if(loading)label='Connected · loading host level '+level;
      else if(synced)label='Connected · on host level '+level;
      else if(connected)label='Connected · not on host level '+level;
      return {connected,synced,loading,label};
    }
    function readyUp(){
      if(!network||!room)throw Error('Join a room first');
      if(room.hostId!==selfId)return readyVote(true);
      if(!room.launched){
        if(!room.meta)throw Error('Pick a level first.');
        ready=true;send({type:'ready',meta:room.meta});message('Asked the other racers if they are ready.');
        return;
      }
      if(room.gate)throw Error('Pick your character. The race starts when everyone has chosen.');
      if(!ensureLevelSynced())throw Error('Wait for the level to finish loading');
      if(room?.mode==='shared')shared.reset(session);
      raceStart=null;released=false;ready=true;readyCheck=true;freezeWorld(session);send({type:'ready',meta});message('Asked the other racers if they are ready.');
    }
    function abortReadyCheck(name,text){
      readyCheck=false;hostReadyAt=0;lastHostReady=false;lastChecking=false;ready=false;raceStart=null;released=false;
      thawWorld(session);
      ui?.hideReadyAsk?.();
      message(text||((name||'A racer')+' declined ready. The host will have to ask again.'));
    }
    function readyVote(yes){
      if(!network||!room)throw Error('Join a room first');
      if(room.hostId===selfId)return readyUp();
      if(!yes){
        const name=room.players.find(p=>p.id===selfId)?.name||'A racer';
        pendingDecline=true;
        abortReadyCheck(name,name+' declined ready. The host will have to ask again.');
        send({type:'notReady'});
        return;
      }
      if(!room.launched){
        if(!room.meta)throw Error('The host has not picked a level yet.');
        ready=true;send({type:'ready',meta:room.meta});message('Ready — waiting for the other racers.');
        return;
      }
      if(room.gate)throw Error('Pick your character. The race starts when everyone has chosen.');
      const link=bindGuestToRoom();
      if(!link.ok){
        if(link.why==='nolevel')throw Error('The host has not shared a level yet.');
        if(link.why==='loading'||link.why==='travel')throw Error('Still loading the host level. Press Yes again when the map is in.');
        throw Error('Not connected to the room.');
      }
      ready=true;freezeWorld(session);send({type:'ready',meta});message('Ready — waiting for the other racers.');
    }
    function pickLevel(picked){
      if(!network||!room||room.hostId!==selfId)throw Error('Only the host can pick a level');
      if(!picked?.meta?.hash)throw Error('That level is missing its data');
      pendingPick=true;
      send({type:'pick',meta:picked.meta,rules:picked.rules||{}});
      message((picked.meta.title||('Level '+picked.meta.level))+' (id '+picked.meta.level+') is in the lobby. Ready when everyone is here.');
    }
    function holdSelection(){
      const controller=sessionController();
      if(!controller||typeof controller.loadSession!=='function')return;
      if(launchLive()&&controller.__jmpTicket==null)controller.__jmpTicket=armedGen;
      if(!controller.__jmpLoadGate){
        const orig=controller.loadSession;
        controller.__jmpOrigLoad=orig;
        controller.__jmpOrigBind=controller.loadSessionBind;
        const wrapped=function(event){
          if(controller.__jmpBypass)return orig.call(controller,event);
          if(deadGens.has(controller.__jmpTicket))return;
          if(room&&playGen!==armedGen)return;
          const choosing=!!(room?.launchId&&playGen===armedGen&&room.phase!=='loading'&&room.phase!=='countdown'&&room.phase!=='racing');
          if(room?.phase==='loading'){
            commitNativeLevel();
            return;
          }
          if(choosing){
            if(acceptForced())return;
            const choice=iconChoice(controller.characterMenu?.selectedIcon);
            if(choice){selectCharacter(choice.characterId,choice.skinId);return;}
            if(!characterMenuShowing()){try{controller.openCharacterMenu?.();}catch{}}
            return;
          }
          return orig.call(controller,event);
        };
        controller.loadSession=wrapped;
        controller.loadSessionBind=wrapped;
        controller.__jmpLoadGate=true;
        if(typeof controller.openCharacterMenu==='function'&&!controller.openCharacterMenu.__jmp){
          const origOpen=controller.openCharacterMenu;
          const wrappedOpen=function(){
            if(!controller.__jmpBypass&&launchLive()&&room.phase==='loading'){commitNativeLevel();return;}
            if(!controller.__jmpBypass&&acceptForced())return;
            return origOpen.apply(controller,arguments);
          };
          wrappedOpen.__jmp=true;
          controller.openCharacterMenu=wrappedOpen;
        }
      }
      const menu=controller.characterMenu;
      if(!menu)return;
      if(controller.__jmpOrigBind&&!menu.__jmpRebound){
        try{menu.removeEventListener('characterselected',controller.__jmpOrigBind);}catch{}
        try{menu.addEventListener('characterselected',controller.loadSessionBind);}catch{}
        menu.__jmpRebound=true;
      }
      const native=menu.iconMouseDownHandler;
      if(typeof native==='function'&&!native.__jmp){
        const wrappedDown=function(event){
          if(room?.phase==='loading'&&playGen===armedGen){
            if(event)event.__jmpSeen=true;
            try{event?.stopPropagation?.();event?.stopImmediatePropagation?.();}catch{}
            message(loadingStatus());
            return;
          }
          const choosing=!!(room?.launchId&&playGen===armedGen&&room.phase!=='loading'&&room.phase!=='countdown'&&room.phase!=='racing');
          if(controller.__jmpBypass||!choosing)return native.call(menu,event);
          if(event?.__jmpSeen)return;
          if(event)event.__jmpSeen=true;
          try{event.stopPropagation?.();event.stopImmediatePropagation?.();}catch{}
          const icon=event?.target;
          if(!icon||icon.selectable===false)return;
          try{
            if(menu.selectedIcon&&menu.selectedIcon!==icon)menu.selectedIcon.selected=false;
            icon.selected=true;
            menu.selectedIcon=icon;
          }catch{}
          const choice=iconChoice(icon);
          if(choice)selectCharacter(choice.characterId,choice.skinId);
        };
        wrappedDown.__jmp=true;
        menu.iconMouseDownHandler=wrappedDown;
      }
      const current=menu.iconMouseDownHandler;
      for(const icon of menu.icons||[]){
        if(typeof native==='function'&&native!==current){try{icon.removeEventListener('mouseDown',native);}catch{}}
        if(!icon.__jmpDown){
          icon.__jmpDown=true;
          icon.addEventListener('mouseDown',event=>menu.iconMouseDownHandler(event));
        }
      }
      const play=menu.mobilePlayButtonMouseDownHandler;
      if(typeof play==='function'&&!play.__jmp){
        const wrappedPlay=function(){
          if(room?.phase==='loading'&&playGen===armedGen){message(loadingStatus());return;}
          const choosing=!!(room?.launchId&&playGen===armedGen&&room.phase!=='loading'&&room.phase!=='countdown'&&room.phase!=='racing');
          if(!choosing)return play.apply(menu,arguments);
          const choice=iconChoice(menu.selectedIcon);
          if(choice)selectCharacter(choice.characterId,choice.skinId);
        };
        wrappedPlay.__jmp=true;
        menu.mobilePlayButtonMouseDownHandler=wrappedPlay;
      }
    }
    function iconChoice(icon){
      if(!icon)return null;
      if(icon.__customCharacter?.base)return {characterId:Number(icon.__customCharacter.base),skinId:String(icon.__customCharacter.id||'')};
      const index=Number(icon.index);
      if(Number.isInteger(index)&&index>=1&&index<=11)return {characterId:index,skinId:''};
      return null;
    }
    const entrySteps=['loadRace','choice','proceed','loadSession','menuClosed','loader','beginSession','session','prepared'];
    function milestone(name, extra){
      entryMilestone=name;
      lab.entryMilestone=name;
      traceCharacter('milestone', localRosterChoice(launchRoster, selfId)?.characterId||0, Object.assign({milestone:name}, extra||{}));
    }
    function entryCompleted(){
      const controller=sessionController();
      return !!controller&&controller.__jmpEntry==='completed'&&controller.__jmpEntryLaunch===launchId;
    }
    function failEntry(controller, text){
      entryError=text;
      entryWait='';
      clearTimeout(entryTimer);
      if(controller){controller.__jmpEntry='failed';controller.__jmpEntering=0;}
      traceCharacter('failed', localRosterChoice(launchRoster, selfId)?.characterId||0, {milestone:entryMilestone||'none',reason:text});
      message(text);
      try{ui?.open?.();}catch{}
    }
    function rigFor(kind, created){
      const v111=Number(created?.version)>=1.11;
      const vehicleKey={1:'Qd',2:v111?'HK':'ae',3:'jm',4:v111?'Rf':'_w',5:'eV',6:'V8',7:'AE',8:'sB',9:'yP',10:'Jw',11:'_0'}[kind];
      // Hide vehicle loads the native character-only Wf class, not the vehicle class.
      const key=vehicleKey&&(lab.state?.hideVehicle?'Wf':vehicleKey);
      try{const fn=key&&lab.require?.(34531)?.[key];return typeof fn==='function'?fn:null;}catch{return null;}
    }
    function noteWait(reason, controller, choice){
      const key=reason+':'+launchId+':'+(choice?.characterId||0)+':'+(lab.download?.loading?1:0)+':'+(lab.download?.level||'');
      if(key===lastWaitKey)return;
      lastWaitKey=key;
      traceCharacter('wait', choice?.characterId||0, {reason,launchId,playGen,armedGen,retiredLaunch,controller:controller?(controller.constructor?.name||'controller'):'none',downloading:!!lab.download?.loading,downloadLevel:lab.download?.level||''});
      const text={
        'no-controller':'Waiting for the level screen.',
        generation:'This launch was cancelled before the level could start.',
        retired:'This launch was cancelled before the level could start.',
        'no-choice':'Waiting for your character in the roster.',
        downloading:'Waiting for the level download to finish.',
        'no-loader':'The game level loader is not available yet.',
        'no-level':'Waiting for the character screen.'
      }[reason]||'';
      if(!text)return;
      entryWait=text;
      if(!entryError)message(text);
    }
    function loadingStatus(){
      if(entryError)return entryError;
      if(entryWait)return entryWait;
      if(entryMilestone)return 'Loading selected characters… ('+entryMilestone+')';
      return 'Loading selected characters…';
    }
    function localRosterChoice(roster, id){
      const row=(Array.isArray(roster)?roster:[]).find(player=>player&&player.id===id);
      if(!row)return null;
      const characterId=Number(row.characterId??row.character);
      if(!Number.isInteger(characterId)||characterId<1||characterId>11)return null;
      const skin=row.skinId??row.skin??'';
      return {characterId, skinId:typeof skin==='string'?skin:''};
    }
    function levelForcesCharacter(level, roomLevel){
      const levelId=String(level?.id??'');
      if(!/^[1-9][0-9]{0,8}$/.test(levelId)||levelId!==String(roomLevel||''))return 0;
      if(!(level.forceChar||level._forceChar))return 0;
      const n=Number(level.character??level.characterIndex);
      return Number.isInteger(n)&&n>=1&&n<=11?n:0;
    }
    function selectionReady(created, menuOpen, choice, levelId, rigOk){
      if(!choice||!created||created.isMenu||created.isEditorTest||!created.character||menuOpen)return false;
      if(created.__jmpLaunchId==null)return false;
      if(String(levelId||'')&&String(created.__jmpLevelId||'')!==String(levelId))return false;
      return rigOk===true;
    }
    function planEntry(entry, now, opts){
      const state=entry?.state||'notRequested';
      if(!opts||opts.cancelled)return {action:'wait', state, reason:'generation'};
      if(!opts.choice)return {action:'wait', state, reason:'no-choice'};
      if(opts.ready)return {action:'done', state:'completed', reason:'completed'};
      if(state==='inFlight')return {action:'wait', state:'inFlight', reason:'in-flight'};
      if(state==='completed')return {action:'wait', state:'completed', reason:'completed'};
      if(state==='failed')return {action:'wait', state:'failed', reason:'failed'};
      if(opts.downloading)return {action:'wait', state, reason:'downloading'};
      if(!opts.canCall)return {action:'wait', state, reason:opts.hasLoader?'no-level':'no-loader'};
      return {action:'start', state:'inFlight', reason:''};
    }
    function forcedCharacterId(controller){
      const forced=levelForcesCharacter(controller?.levelDataObject, room?.meta?.level);
      if(forced)return forced;
      const rider=Number(room?.rules?.rider);
      return Number.isInteger(rider)&&rider>=1&&rider<=11?rider:0;
    }
    function launchSession(controller, choice){
      const created=controller?.__jmpLaunchSession;
      if(!created)return null;
      const expected=rigFor(choice?.characterId, created);
      const rigOk=!!expected&&created.character?.constructor===expected;
      return selectionReady(created, characterMenuShowing(), choice, room?.meta?.level, rigOk)?created:null;
    }
    function hookNativeLoad(controller){
      if(controller.__jmpLoadHooks)return;
      controller.__jmpLoadHooks=true;
      for(const name of ['beginSession','beginSessionBind','IOErrorHandler','IOErrorHandlerBind','loadErrorHandler','loadErrorHandlerBind']){
        if(typeof controller[name]!=='function'||controller[name].__jmp)continue;
        const orig=controller[name];
        const wrapped=function(){
          if(controller.__jmpTicket!=null&&(deadGens.has(controller.__jmpTicket)||controller.__jmpTicket!==playGen||controller!==sessionController()))return;
          if(/beginSession/i.test(name))rememberLoadedCourse(controller);
          const result=orig.apply(this, arguments);
          if(/beginSession/i.test(name))noteBeginSession(controller);
          else noteLoadError(controller, name);
          return result;
        };
        wrapped.__jmp=true;
        controller[name]=wrapped;
      }
    }
    function rememberLoadedCourse(controller){
      if(!room?.meta||playGen!==armedGen||controller.__jmpEntryLaunch!==launchId)return;
      const level=String(controller.levelDataObject?.id||'');
      if(level!==String(room.meta.level))return;
      if(lab.download?.level===level&&lab.download.hash&&lab.download.hash!==room.meta.hash)return;
      const loader=controller.sessionContentLoader?.userLevelLoader;
      const xml=loader?.levelXML||loader?._levelXML;
      // beginSession destroys this loader synchronously. Capture before calling it,
      // so guests and cached native loads retain their complete map definition too.
      if(typeof xml?.toXMLString!=='function')return;
      try{window.HWJimbobLevels?.rememberCourse?.(room.meta,xml.toXMLString());}
      catch(e){if(lab.errors.length<30)lab.errors.push('Map definition: '+String(e?.message||e));}
    }
    function noteBeginSession(controller){
      if(!controller||controller.__jmpEntry!=='inFlight'||controller.__jmpEntryLaunch!==launchId||playGen!==armedGen)return;
      milestone('beginSession');
      const created=controller.session&&controller.session!==controller.__jmpSeenSession?controller.session:(lab.state?.currentSession&&lab.state.currentSession!==controller.__jmpSeenSession?lab.state.currentSession:null);
      if(!created)return;
      const choice=localRosterChoice(launchRoster, selfId);
      created.__jmpLaunchId=launchId;
      created.__jmpLevelId=String(lab.state?.levelIndex||controller.levelDataObject?.id||room?.meta?.level||'');
      controller.__jmpLaunchSession=created;
      session=created;
      lab.session=created;prepHold=launchId;freezeWorld(created);
      const expected=rigFor(choice?.characterId, created);
      if(!choice||!expected||created.character?.constructor!==expected||characterMenuShowing()||(room?.meta?.level&&created.__jmpLevelId!==String(room.meta.level))){
        created.__jmpLaunchId=null;
        controller.__jmpLaunchSession=null;
        failEntry(controller, 'The new session does not match character '+(choice?.characterId||'?')+' on level '+(room?.meta?.level||'')+'.');
        return;
      }
      entryError='';
      entryWait='';
      controller.__jmpEntry='completed';
      controller.__jmpEntering=launchId;
      clearTimeout(entryTimer);
      milestone('session', {className:created.character?.constructor?.name||''});
      traceCharacter('loaded', choice.characterId, {className:created.character?.constructor?.name||''});
    }
    function noteLoadError(controller, name){
      if(!controller||controller.__jmpEntry!=='inFlight'||controller.__jmpEntryLaunch!==launchId)return;
      failEntry(controller, 'The level loader reported an error ('+name+').');
    }
    function observeNative(controller){
      if(controller.__jmpEntry!=='inFlight')return;
      if(!characterMenuShowing()&&entryMilestone==='loadSession')milestone('menuClosed');
      if(controller.sessionContentLoader&&entryMilestone==='menuClosed')milestone('loader');
    }
    function armEntryTimeout(controller, token){
      clearTimeout(entryTimer);
      entryTimer=setTimeout(()=>{
        if(controller.__jmpEntryToken!==token||controller.__jmpEntry!=='inFlight'||playGen!==armedGen)return;
        const at=entrySteps.indexOf(entryMilestone);
        const missing=entrySteps[at+1]||entrySteps[0];
        failEntry(controller, 'Level entry stopped before '+missing+'. Last step: '+(entryMilestone||'none')+'.');
      }, 12000);
    }
    function applyNativeSelection(controller, choice){
      if(!choice)return;
      if(lab.state)lab.state.characterIndex=choice.characterId;
      try{window.HWCustomCharacters?.choose?.(choice.skinId||null);}catch{}
      const menu=controller?.characterMenu;
      const icons=menu?.icons||[];
      const icon=icons.find(item=>choice.skinId&&item.__customCharacter?.id===choice.skinId)||icons.find(item=>Number(item.index)===choice.characterId&&!item.__customCharacter)||icons.find(item=>Number(item.index)===choice.characterId);
      if(icon&&menu){
        try{
          if(menu.selectedIcon&&menu.selectedIcon!==icon)menu.selectedIcon.selected=false;
          icon.selected=true;
          menu.selectedIcon=icon;
          const index=Number(icon.index);
          if(lab.state&&Number.isInteger(index)&&index>=1&&index<=11)lab.state.characterIndex=index;
        }catch{}
      }
      traceCharacter('applied', lab.state?.characterIndex||choice.characterId, {skin:choice.skinId||''});
    }
    function acceptForced(){
      const controller=sessionController();
      const id=forcedCharacterId(controller);
      if(!id||!room||playGen!==armedGen)return false;
      if(room.phase==='selecting'){
        const pendingLocked=pendingSelect&&pendingSelect.id===id&&!pendingSelect.skin;
        const confirmedLocked=confirmedLaunch===launchId&&confirmedCharacter===id&&!pendingSelect;
        if(!pendingLocked&&!confirmedLocked){
          if(confirmedCharacter!==id)confirmedLaunch=0;
          message('This level locks the character.');
          selectCharacter(id);
        }
        if(characterMenuShowing()){try{controller?.closeCharacterMenu?.();}catch{}}
        return true;
      }
      if(room.phase==='loading'&&controller?.__jmpAuthorized===launchId){commitNativeLevel();return true;}
      return false;
    }
    function commitNativeLevel(){
      const controller=sessionController();
      const choice=localRosterChoice(launchRoster, selfId);
      if(!controller){noteWait('no-controller', null, choice);return;}
      if(!Number.isInteger(controller.__jmpEntryToken))controller.__jmpEntryToken=0;
      if(playGen!==armedGen){noteWait('generation', controller, choice);return;}
      if(launchId&&launchId<=retiredLaunch){noteWait('retired', controller, choice);return;}
      if(!choice){noteWait('no-choice', controller, choice);return;}
      if(controller.__jmpEntryLaunch&&controller.__jmpEntryLaunch!==launchId){
        controller.__jmpEntry='notRequested';
        controller.__jmpEntryTries=0;
        controller.__jmpEntryNoted=false;
      }
      observeNative(controller);
      const ready=!!launchSession(controller, choice);
      const plan=planEntry({state:controller.__jmpEntry||'notRequested'}, Date.now(), {
        cancelled:false,
        choice,
        ready,
        downloading:!!(lab.download?.loading&&!controller.levelDataObject&&!controller.characterMenu),
        hasLoader:typeof controller.__jmpOrigLoad==='function',
        canCall:typeof controller.__jmpOrigLoad==='function'&&!!(controller.characterMenu||controller.levelDataObject)
      });
      if(plan.action==='done')return;
      if(plan.action!=='start'){if(plan.reason&&plan.reason!=='in-flight'&&plan.reason!=='completed'&&plan.reason!=='failed')noteWait(plan.reason, controller, choice);return;}
      const forced=forcedCharacterId(controller);
      if(forced&&forced!==choice.characterId){
        failEntry(controller, 'This level locks the character, and it does not match the confirmed roster.');
        return;
      }
      entryWait='';
      lastWaitKey='';
      milestone('proceed');
      applyNativeSelection(controller, choice);
      hookNativeLoad(controller);
      controller.__jmpSeenSession=lab.state?.currentSession||session||null;
      const level=controller.levelDataObject;
      const suppressForce=!!(level&&(level.forceChar||level._forceChar)&&forced!==choice.characterId);
      const savedForce=suppressForce?{forceChar:level.forceChar,_forceChar:level._forceChar}:null;
      if(suppressForce){level.forceChar=false;level._forceChar=false;}
      const token=(controller.__jmpEntryToken||0)+1;
      controller.__jmpEntryToken=token;
      controller.__jmpEntry='inFlight';
      controller.__jmpEntryLaunch=launchId;
      controller.__jmpEntryTries=(controller.__jmpEntryTries||0)+1;
      controller.__jmpEntryAt=Date.now();
      controller.__jmpAuthorized=launchId;
      controller.__jmpEntering=0;
      const ticket=playGen;
      controller.__jmpBypass=true;
      let result;
      try{result=controller.__jmpOrigLoad.call(controller);}
      catch(e){
        failEntry(controller, 'The level loader did not start: '+(e?.message||e));
        if(lab.errors.length<30)lab.errors.push(String(e?.message||e));
        return;
      }finally{
        controller.__jmpBypass=false;
        if(savedForce){level.forceChar=savedForce.forceChar;level._forceChar=savedForce._forceChar;}
      }
      if(controller.__jmpEntryToken!==token||ticket!==playGen||controller.__jmpEntry!=='inFlight')return;
      milestone('loadSession', {menu:characterMenuShowing()?'open':'closed', loader:controller.sessionContentLoader?'yes':'no'});
      observeNative(controller);
      armEntryTimeout(controller, token);
      if(result&&typeof result.then==='function'){
        result.then(()=>{
          if(controller.__jmpEntryToken!==token||ticket!==playGen)return;
          observeNative(controller);
        }, err=>{
          if(controller.__jmpEntryToken!==token||ticket!==playGen||controller.__jmpEntry!=='inFlight')return;
          failEntry(controller, 'The level loader stopped: '+(err?.message||err));
        });
      }
    }
    function retryEntry(){
      const controller=sessionController();
      if(!room||room.phase!=='loading'||!launchRoster.length)throw Error('The level is not waiting to load.');
      entryError='';
      entryWait='';
      lastWaitKey='';
      clearTimeout(entryTimer);
      prepSentFor=0;
      if(controller){
        controller.__jmpEntry='notRequested';
        controller.__jmpEntryToken=(controller.__jmpEntryToken||0)+1;
        controller.__jmpLaunchSession=null;
        controller.__jmpEntering=0;
      }
      message('Retrying the level load…');
      commitNativeLevel();
    }
    function selectCharacter(id,skin){
      const n=Number(id);
      if(room?.phase!=='selecting'||!launchId||raceStart)return;
      if(!Number.isInteger(n)||n<1||n>11)return;
      if(room.rules?.rider&&n!==room.rules.rider)return;
      const clean=typeof skin==='string'&&/^[a-z0-9][a-z0-9-]{0,63}$/i.test(skin)?skin:'';
      if(pendingSelect&&pendingSelect.id===n&&pendingSelect.skin===clean)return;
      if(confirmedCharacter===n&&confirmedSkin===clean&&confirmedLaunch===launchId)return;
      pendingSelect={id:n,skin:clean};
      traceCharacter('clicked', n, {skin:clean});
      message(forcedCharacterId(sessionController())?'This level locks the character. Waiting for everyone to load.':'Confirming…');
      send({type:'selectCharacter',launchId,characterId:n,skinId:clean});
    }
    function raceAgain(){if(survivalCourse()&&room?.launchId&&(room.start||room.results))return requestRestartVote();if(!room||room.hostId!==selfId)throw Error('Only the host can race again');send({type:'again'});message('Loading the same level…');}
    function kickPlayer(id){if(!room||room.hostId!==selfId)throw Error('Only the host can remove a player');send({type:'kick',id});}
    function promotePlayer(id){if(!room||room.hostId!==selfId)throw Error('Only the host can hand off the room');send({type:'promote',id});}
    function lockRoom(on){if(!room||room.hostId!==selfId)throw Error('Only the host can lock the room');send({type:'lock',on:!!on});}
    lab.lobby=()=>{
      const host=!!room&&room.hostId===selfId;
      const lobby=!!room&&!room.launched&&!!room.meta&&!raceStart;
      const legacy=!!room&&room.launched&&!room.gate&&!raceStart;
      return {room,selfId,ready,connecting:!!network&&!room,meta,status:lab.status,entryError,canRetry:!!room&&room.phase==='loading'&&!!entryError,inLevel:levelPlayable(),loading:!onRoomLevel()&&(!!travelTarget||!!lab.download?.loading),phase:playerPhase(),allInGame:everyoneInGame(),canReady:host&&(lobby||(legacy&&characterSelected()&&!!meta)),canVoteReady:!host&&!!room&&!ready&&!raceStart&&((lobby&&(!!room.checking||readyCheck))||(legacy&&characterSelected()&&!!(room.meta||hostChecking()||onRoomLevel()))),canDecline:!host&&!!room&&!ready&&!raceStart&&!room.gate&&(hostChecking()||readyCheck),readyCheck:shouldAskReady()&&!room?.gate,checking:hostChecking(),link:linkState().label,isHost:host,raceStart,released,remaining:remainingMs(),collide:playerCollide,steam,avatars:Object.fromEntries(avatars),chat:chatLog.slice(),results:resultsRows,lingerUntil,course:courseApi&&courseApi.tagged(course)?{summary:courseApi.summary(course),warnings:course.warnings,bump:course.bump,rider:course.rider,seats:course.seats,play:course.play,tagged:true}:null};
    };
    lab.raceBoard=()=>{
      const racing=!!(raceStart&&(released||(raceStart-(Date.now()+clockOffset))<=0));
      const players=(room?.players||[]).map(p=>{
        if(room?.mode==='shared'){
          const score=sharedScores.get(p.id);
          return {id:p.id,name:p.name,you:p.id===selfId,deaths:score?.deaths||0,progress:score?.progress||0,best:score?.best||0,dead:!!score?.dead,finished:!!score?.finished};
        }
        if(p.id===selfId)return {id:p.id,name:p.name,you:true,deaths,progress:liveProgress,best:bestProgress,dead:!!session?.character?.dead,finished:finishSent};
        const peer=peers.get(p.id),f=peer?.frames?.at(-1);
        return {id:p.id,name:p.name,you:false,deaths:peer?.deaths||0,progress:peer?.progress||0,best:peer?.best||0,dead:!!f?.dead,finished:!!f?.finished};
      });
      return {racing,players,spectating:inPostFinish(),spectateId:spectateId||selfId,spectateName:spectateId&&spectateId!==selfId?playerName(spectateId):(selfId?'yourself':'')};
    };
    lab.inPostFinish=inPostFinish;lab.manualRestart=manualRestart;lab.onLocalRestart=onLocalRestart;lab.manualMenu=manualMenu;lab.allowGameMenu=allowGameMenu;lab.cycleSpectate=cycleSpectate;lab.spectatePlayer=spectatePlayer;
    lab.record=record;lab.stop=stop;lab.play=play;lab.capture=capture;lab.connect=connect;lab.disconnect=disconnect;lab.ready=readyUp;lab.readyVote=readyVote;lab.summon=summon;lab.restartThen=restartThen;
    lab.requestRestartVote=requestRestartVote;
    // Additive bridge for the separate Builder mod; normal multiplayer behavior is unchanged.
    lab.builderBridge={version:1,pickLevel,returnToLobby,openSecond,loadGuard:()=>{const generation=playGen,id=launchId;return ()=>generation===playGen&&(!id||id===launchId&&launchLive());}};
    lab.importRecording=r=>{saved=core.validateRecording(r);lab.saved=saved;persist(saved);message('Ghost imported. Load its level, then Play ghost.');};
    lab.diagnostics=()=>({meta,stats:lab.stats,status:lab.status,errors:lab.errors.slice(-5),characterTrace:characterTrace.slice(-20),recordedFrames:saved?.frames.length||recording?.frames.length||0,room:room?.code,peers:peers.size,visuals:{visible:layer.visible,attached:layer.parent===app.stage,parts:[...peers.values()].reduce((n,p)=>n+[...p.sprites.values()].filter(s=>s.visible).length,0)},raceStart,released,remaining:remainingMs(),paused:session?.paused,launch:{id:launchId,generation:playGen,armedGeneration:armedGen,retired:retiredLaunch,serverPhase:room?.phase,entry:sessionController()?.__jmpEntry,entryLaunch:sessionController()?.__jmpEntryLaunch,entryError,entryWait,entryMilestone,preparedLaunch,prepSentFor,sessionLaunch:session?.__jmpLaunchId,nativeSessionLaunch:lab.state.currentSession?.__jmpLaunchId,roster:launchRoster}});
    function publishFrame(force){
      if(room?.mode==='shared')return;
      if(room?.launchId&&room.start&&!raceStart)raceStart=room.start;
      if(!network||network.readyState!==1||!raceStart||!released||!lastFrame)return;
      if(!core.validFrame(lastFrame)||!Array.isArray(textures)||textures.length>4096||!textures.every(core.validTexture)||lastFrame.parts.some(p=>p[1]>=textures.length))return;
      const now=performance.now();
      if(!force&&now-lastSentAt<45)return;
      lastSentAt=now;
      if(lastFrame.finished&&!finishSent){finishSent=true;finishedRace=true;send({type:'frame',launchId:room?.launchId||0,frame:lastFrame,textures});send({type:'finish',launchId:room?.launchId||0,time:lastFrame.t});if(!spectateId)cycleSpectate(true);return;}
      if(inPostFinish())return;
      send({type:'frame',launchId:room?.launchId||0,frame:lastFrame,textures});
    }
    function netTick(){
      if(!network||network.readyState!==1)return;
      const now=performance.now();
      const current=lab.state.currentSession;
      if(raceStart&&!released&&current&&!current.isMenu)holdForCountdown(current);
      else ownHold(current);
      shared.update(sharedContext());publishFrame(false);
      if(now-networkAt>3000){networkAt=now;send({type:'ping',clientTime:Date.now()});}
    }
    function update(){
      try{hookLoader();hookNonPausingMenu();hookCharacterMenu();if(launchLive()&&room.hostId!==selfId)pullGuestLevel();publishPresence();reconcileLaunch();if(room?.launchId&&!raceStart)ui?.refresh();}catch(e){if(lab.errors.length<30)lab.errors.push(String(e));}
      if(room?.mode!=='shared')shared.update(sharedContext());
      const s=lab.state.currentSession;
      if(s&&!s.isMenu&&(retiredSessions.has(s)||!s.m_world)){layer.visible=false;hideTags();return;}
      const requestedLevel=lab.download?.level;
      // loadLevelByID changes levelIndex before its downloaded session replaces the old one.
      // Keep the old session out of room metadata/Ready while that request is pending.
      if(lab.download?.loading&&requestedLevel===String(lab.state.levelIndex)){if(!s||s.isMenu||!s.m_world){layer.visible=false;hideTags();}return;}
      if(lab.download?.loading&&(!s||s.isMenu||!s.m_world)){layer.visible=false;hideTags();return;}
      const downloadReady=!!(travelTarget&&lab.download&&!lab.download.loading&&lab.download.level===travelTarget.level&&String(lab.state.levelIndex)===String(travelTarget.level)&&meta?.fingerprint!=='download-sha256'&&meta?.fingerprint!=='room-level');
      if(downloadReady||s!==session||(meta&&String(lab.state.levelIndex)!==meta.level)||(meta?.fingerprint==='download-sha256'&&lab.download?.hash&&lab.download.level===meta.level&&meta.hash!==lab.download.hash)){changed(s).catch(e=>{lab.errors.push(String(e));session=null;});return;}
      if(s?.character)holdCharacterKeys(s.character);
      if(!s||s.isMenu||!s.m_world||!s.containerSprite){if(!s||s.isMenu){layer.visible=false;hideTags();}return;}
      window.HWJimbobCamera?.update(s,lab);
      if(s.iteration<lastIteration){changed(s);return;}lastIteration=s.iteration;const now=performance.now();
      layer.visible=true;if(layer.parent!==app.stage)app.stage.addChild(layer);app.stage.setChildIndex(layer,app.stage.children.length-1);
      if(raceStart&&!released)holdForCountdown(s);else ownHold(s);
      if(courseApi&&course)courseApi.hideMarks(course);
      tickCourse(s);paintCourse(s);
      if(shared.update(sharedContext())){layer.visible=false;hideTags();try{trackShared(s);}catch(e){if(lab.errors.length<30)lab.errors.push(String(e));}return;}
      if(s.replayData?.completed&&network&&released&&!course?.goal){finishedRace=true;if(!spectateId)cycleSpectate(true);}
      layer.transform.setFromMatrix(s.containerSprite.pixiSprite.worldTransform.clone().prepend(app.stage.worldTransform.clone().invert()));
      if(now-lastCapture>=50&&(!s.paused||(network&&released))){
        lastCapture=now;
        const next=capture();
        if(next)lastFrame=next;
        else if(lastFrame)decorate(lastFrame,s);
        if(lastFrame)lab.stats.captured++;
        if(recording&&lastFrame&&!s.paused){recording.frames.push(lastFrame);recordedBytes+=JSON.stringify(lastFrame).length;if(recording.frames.length>=3600||recordedBytes>48*1024*1024)stop();}
        publishFrame(false);
      }
      if(playback){const time=(s.iteration-playback.start)*s.m_timeStep*1000;draw(localGroup,localSprites,core.sample(playback.record.frames,time),playback.record.textures);lab.stats.ghostParts=[...localSprites.values()].filter(x=>x.visible).length;}
      let liveParts=0;
      for(const [id,peer] of peers){
        const fresh=peer.lastArrival&&now-peer.lastArrival<8000;
        peer.group.visible=fresh;
        if(!fresh){if(peer.tag)peer.tag.hidden=true;continue;}
        const shown=core.liveSample(peer.frames,now,peer.lastArrival);
        draw(peer.group,peer.sprites,shown,peer.textures);
        liveParts+=[...peer.sprites.values()].filter(x=>x.visible).length;
        ensureTag(peer,id);placeTag(peer,shown);
      }
      placeSelfTag(s);
      if(network&&raceStart&&!ready)lab.stats.ghostParts=liveParts;
    }
    const render=app.renderer.render;
    app.renderer.render=function(...args){
      try{
        const s=lab.state.currentSession;
        if(s&&!s.isMenu){
          if(s.replayData?.completed&&network&&released&&!course?.goal){finishedRace=true;if(!spectateId)cycleSpectate(true);}
          hideFinishChrome(s);
          applySpectate(s,false);
          if(s.m_world&&!retiredSessions.has(s))window.HWJimbobCamera?.update(s,lab);
        }
      }catch(e){if(lab.errors.length<30)lab.errors.push(String(e));}
      const value=render.apply(this,args);
      try{update();}catch(e){if(lab.errors.length<30)lab.errors.push(String(e));}
      return value;
    };
    if(app.ticker?.update){
      const tick=app.ticker.update.bind(app.ticker);
      app.ticker.update=function(...args){
        try{
          if(inputBlocks.has('chat'))neutralizeInput();
          const s=lab.state.currentSession;
          if(s?.character)holdCharacterKeys(s.character);
          if(s&&!s.isMenu&&inPostFinish())applySpectate(s,true);
        }catch(e){if(lab.errors.length<30)lab.errors.push(String(e));}
        return tick(...args);
      };
    }
    setInterval(()=>{try{netTick();}catch(e){if(lab.errors.length<30)lab.errors.push(String(e));}},50);
    const panel=document.createElement('section');panel.id='hw-ghost-panel';
    panel.innerHTML=`<style>#hw-ghost-panel{position:fixed;right:12px;top:12px;width:296px;background:#17212bef;color:#f1f5f9;border:1px solid #607080;border-radius:8px;padding:12px;font:13px/1.4 system-ui;z-index:10000}#hw-ghost-panel button,#hw-ghost-panel input{font:inherit;border:1px solid #63758a;border-radius:4px;padding:5px 7px;margin:3px 1px;background:#28384b;color:#fff}#hw-ghost-panel button{cursor:pointer}#hw-ghost-panel input{box-sizing:border-box;width:100%}#hw-ghost-panel small{color:#b8c6d6}#hw-ghost-panel details{margin-top:8px}#hw-ghost-panel p{margin:6px 0}#hw-ghost-panel .row{display:flex;flex-wrap:wrap;gap:3px}</style><strong>Jimbob's Multiplayer Mod</strong><button id="gh-collapse" style="float:right" title="Hide controls">−</button><div id="gh-body"><p id="gh-status">Finding the game…</p><div class="row"><button id="gh-record">Record</button><button id="gh-stop">Stop</button><button id="gh-play">Play ghost</button></div><div class="row"><button id="gh-export">Export run</button><button id="gh-import">Import run</button><button id="gh-clear">Hide ghosts</button></div><details><summary>Race with a friend</summary><button id="gh-second">Open second window</button><small>Join a room to load the host level automatically, then Ready.</small><input id="gh-url" aria-label="Relay address" value=""><input id="gh-name" aria-label="Racer name" value="Racer" maxlength="24"><input id="gh-code" aria-label="Room code" placeholder="Room code (blank creates a room)"><div class="row"><button id="gh-connect">Connect</button><button id="gh-ready">Ready</button><button id="gh-leave">Leave</button><button id="gh-summon" hidden>Reset players</button></div><p id="gh-room"></p></details><small>Visual ghosts only · F8 toggles controls</small></div>`;
    document.body.appendChild(panel);panel.hidden=!window.HWGhostConfig?.development;
    panel.querySelector('#gh-url').value=window.HWGhostConfig?.defaultRelayUrl||'wss://web-production-79ef3.up.railway.app';
    const status=panel.querySelector('#gh-status'),codeInput=panel.querySelector('#gh-code'),roomLabel=panel.querySelector('#gh-room');
    const act=(id,fn)=>panel.querySelector('#gh-'+id).onclick=async()=>{try{await fn();}catch(e){message(e.message||String(e));}};
    act('record',()=>{if(network)throw Error('Leave the room before recording');restartThen(record);});act('stop',stop);act('play',()=>{if(network)throw Error('Leave the room before local playback');if(!saved)throw Error('Record or import a run first');if(!core.compatible(meta,saved.meta))throw Error('Load the recorded level first');restartThen(play);});
    act('clear',()=>{playback=null;clear(localGroup,localSprites);message('Local ghost hidden.');});
    act('connect',()=>connect(panel.querySelector('#gh-url').value,codeInput.value,panel.querySelector('#gh-name').value));act('ready',readyUp);
    act('leave',()=>{disconnect();thawWorld(session);message('Left room.');});
    act('summon',summon);
    async function openSecond(){if(hwGhostNet?.openPeer){await hwGhostNet.openPeer();return;}lab.testPeer=window.open(location.href,'ghost-local-peer','width=1000,height=700');if(!lab.testPeer)throw Error('The second window was blocked');}
    act('second',openSecond);
    act('export',()=>{if(recording)stop();if(!saved)throw Error('Record a run first');const blob=new Blob([JSON.stringify(saved)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='happy-wheels-ghost-'+saved.meta.level+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),5000);});
    act('import',()=>{const input=document.createElement('input');input.type='file';input.accept='.json';input.onchange=async()=>{try{const file=input.files[0];if(!file)return;if(file.size>64*1024*1024)throw Error('Ghost file exceeds 64 MB');lab.importRecording(JSON.parse(await file.text()));}catch(e){message(e.message);}};input.click();});
    act('collapse',()=>{const body=panel.querySelector('#gh-body');body.hidden=!body.hidden;});
    panel.addEventListener('keydown',e=>e.stopPropagation());panel.addEventListener('keyup',e=>e.stopPropagation());
    window.addEventListener('keydown',e=>{if(window.HWGhostConfig?.development&&e.code==='F8'){panel.hidden=!panel.hidden;e.preventDefault();}},true);
    async function steamInvite(){
      if(!room||room.hostId!==selfId)throw Error('Only the host can invite Steam friends.');
      if(!hwGhostNet?.steamInvite||!hwGhostNet?.steamPublish)throw Error('Steam invite is not connected to this game window');
      const status=await hwGhostNet.steamStatus();
      if(!status?.ok)throw Error(status?.error||'Steam is not available. Launch Happy Wheels from Steam and try again.');
      if(steamRoom!==room.code){
        steamRoom='';
        await hwGhostNet.steamPublish({code:room.code,server:relayUrl,mode:room.mode,seats:room.capacity||relaySeats});
        steamRoom=room.code;
      }
      return hwGhostNet.steamInvite();
    }
    if(hwGhostNet?.onSteam)hwGhostNet.onSteam(event=>{if(event?.type==='invite')joinSteam(event);else if(event?.type==='error'&&event.message)message(event.message);});
    hwGhostNet?.steamTake?.().then(invite=>{if(invite)joinSteam(invite);}).catch(()=>{});
    ui=window.HWMultiplayerUI(lab,{connect,leave:()=>{const inPlay=!!(launchId||travelTarget||raceStart||(session&&!session.isMenu&&!session.isEditorTest));disconnect();if(inPlay){try{happyWheels()?.closeSessionController?.();}catch{}}thawWorld(session);message('Left room.');},ready:readyUp,readyVote,summon,resetWorld,returnToLobby,requestRestartVote,voteRestart,retryEntry,openSecond,message,steamInvite,sendChat,steamStatus:loadSteam,setCollide:on=>lab.setCollide(on),pickLevel,confirmCharacter:selectCharacter,selectCharacter,holdSelection,raceAgain,kick:kickPlayer,promote:promotePlayer,lockRoom});
    loadSteam().then(()=>ui?.refresh());
    lab.setMode=mode=>{if(!room||room.hostId!==selfId)throw Error('Only the host can change mode');if(mode==='shared'&&!room.capabilities?.includes('shared-authority-v3'))throw Error('This relay needs Shared Physics authority v3. Update the relay before starting.');send({type:'mode',mode});};
    lab.setCollide=on=>{if(!room||room.hostId!==selfId)throw Error('Only the host can change bumps');if(course?.bump!=null)throw Error('This course locks bumping.');if(room.mode!=='shared')return;playerCollide=!!on;pendingCollide=true;shared.setCollide?.(playerCollide);send({type:'collide',on:playerCollide});};
    lab.prepareCourse=s=>{if(s&&(s!==courseSession||(!course?.starts?.length&&window.HWBuilder?.active)))scanCourse(s);return course;};
    lab.courseSlot=(id,index,sourceSession)=>{lab.prepareCourse(sourceSession||session||lab.state.currentSession);return courseApi.slotFor(course,index!=null?index:seatIndex(id));};
    lab.courseRespawn=(id,index,sourceSession)=>{
      lab.prepareCourse(sourceSession||session||lab.state.currentSession);
      if(course?.play==='survival'||course?.retry==='off')return lab.courseSlot(id,index,sourceSession);
      if(course?.retry==='start')return lab.courseSlot(id,index,sourceSession);
      return courseRun(id).last||lab.courseSlot(id,index,sourceSession);
    };
    lab.courseDiagnostics=()=>({play:course?.play||null,starts:course?.starts||[],level:courseSession?.__jmpLevelId||null,source:lab.courseSource,canonicalDraft:!!(courseSession?.level||courseSession?._level)?.shapeGuide?.__jmpCourseBoxes});
    lab.courseFinished=(id)=>!!courseRun(id).done;
    lab.courseHasGoal=()=>!!course?.goal;
    lab.courseRetryBlocked=()=>course?.play==='survival'||course?.retry==='off';
    lab.ui=ui;
    message('');
    lab.probe={update,receive,noteSharedScore,state:()=>({raceStart,released,ready,deaths,level:meta?.level||null,hold:!!characterHold,session})};
    let db=null;
    const request=indexedDB.open('hw-ghost-recordings',1);
    request.onupgradeneeded=()=>request.result.createObjectStore('runs');
    request.onsuccess=()=>{db=request.result;const get=db.transaction('runs').objectStore('runs').get('last');get.onsuccess=()=>{if(get.result&&!saved){try{saved=core.validateRecording(get.result);lab.saved=saved;}catch{}}};};
    function persist(run){if(db){const tx=db.transaction('runs','readwrite');tx.objectStore('runs').put(run,'last');tx.onerror=()=>message('Recording is in memory; use Export run to keep it.');}}
  }
})();
