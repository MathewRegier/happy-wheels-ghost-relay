(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else{const api=root.HWJimbobCamera||factory();root.HWJimbobCamera=api;root.HWBuilderCamera=api;}})(typeof window==='object'?window:globalThis,()=>{
  'use strict';
  const cameras=new WeakMap();
  function valid(p){return p&&[p.x,p.y,p.width].every(Number.isFinite)&&Math.abs(p.x)<=1e6&&Math.abs(p.y)<=1e6&&p.width>=200&&p.width<=20000;}
  function apply(camera,session,profile){
    if(!valid(profile)||!session.containerSprite)return false;
    // Happy Wheels renders a 900 x 500 game viewport; window scaling happens outside it.
    const zoom=900/profile.width,container=session.containerSprite;
    camera.zoom=zoom;container.scaleX=container.scaleY=zoom;
    container.x=450-profile.x*zoom;container.y=250-profile.y*zoom;
    const bounds=camera.screenBounds;
    if(bounds){bounds.x=profile.x-profile.width/2;bounds.y=profile.y-250/zoom;bounds.width=profile.width;bounds.height=500/zoom;}
    const mid=camera.midScreenPoint;if(mid){mid.x=profile.x/(session.m_physScale||62.5);mid.y=profile.y/(session.m_physScale||62.5);}
    if(camera._screenMotion){camera._screenMotion.x=0;camera._screenMotion.y=0;}
    if(camera._buttonContainer){camera._buttonContainer.x=container.x;camera._buttonContainer.y=container.y;}
    camera.adjustBackDrops?.();return true;
  }
  function install(camera,session,profile){
    if(!camera||typeof camera.step!=='function')return;
    let entry=cameras.get(camera);
    if(!entry){
      entry={original:camera.step,zoom:camera.zoom,session,profile};cameras.set(camera,entry);
      camera.step=function(...args){const p=entry.profile;this.zoom=valid(p)?900/p.width:entry.zoom;const result=entry.original.apply(this,args);apply(this,entry.session,p);return result;};
    }
    entry.session=session;entry.profile=valid(profile)?profile:null;
    if(entry.profile)apply(camera,session,entry.profile);else camera.zoom=entry.zoom;
  }
  function update(session,lab){
    if(!session||session.isMenu||session.isEditorTest)return;
    const course=lab.prepareCourse?.(session);
    install(session.camera,session,course?.camera||null);
  }
  return {apply,install,update,valid};
});
