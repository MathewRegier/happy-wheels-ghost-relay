(() => {
  'use strict';
  const api = window.HWJimbobLevels = {errors: []};
  const courses = new Map();
  const requirementCache = new Map();
  // Browsing is not a native session download. Retain fetch before ghost.js
  // installs the gameplay download tracker, so inspecting a map cannot retire
  // the currently loaded world or mark another map as its replacement.
  const levelFetch = fetch.bind(window);

  function post(fields) {
    const body = new URLSearchParams();
    for (const [key, value] of Object.entries(fields)) {
      if (value != null && value !== '') body.set(key, String(value));
    }
    return levelFetch('/get_level.hw', {
      method: 'POST',
      headers: {'content-type': 'application/x-www-form-urlencoded'},
      body,
    });
  }

  function rowsFromXml(text) {
    if (!text || /<\s*html/i.test(text.slice(0, 80)) || /^\s*failure/i.test(text)) return [];
    const doc = new DOMParser().parseFromString(text, 'text/xml');
    return [...doc.getElementsByTagName('lv')].map((node) => ({
      id: node.getAttribute('id') || '',
      name: node.getAttribute('ln') || 'Untitled',
      author: node.getAttribute('un') || '',
      authorId: node.getAttribute('ui') || null,
      plays: node.getAttribute('ps') || node.getAttribute('pc') || '',
      rating: node.getAttribute('rg') || '',
      featured: node.getAttribute('df') || '',
    })).filter((row) => /^[1-9][0-9]{0,8}$/.test(row.id));
  }

  function featuredTime(value) {
    const text = String(value || '');
    if (text.length < 19) return null;
    const parts = [text.slice(0, 4), text.slice(5, 7), text.slice(8, 10), text.slice(11, 13), text.slice(14, 16), text.slice(17, 19)].map(Number);
    if (parts.some((part) => !Number.isFinite(part))) return null;
    return new Date(parts[0], parts[1] - 1, parts[2], parts[3], parts[4], parts[5]).getTime();
  }

  function orderFeatured(rows) {
    const now = Date.now();
    const recent = [];
    const older = [];
    for (const row of rows) {
      const time = featuredTime(row.featured);
      if (time != null && (now - time) / 86400000 < 14) recent.push(row);
      else older.push(row);
    }
    return recent.concat(older);
  }

  function customSort(value) {
    if (value === 'oldest' || value === 'rating' || value === 'plays') return value;
    return 'newest';
  }

  function uploadedRange(value) {
    if (value === 'today' || value === 'week' || value === 'month') return value;
    return 'anytime';
  }

  async function list(options) {
    const page = Math.max(1, Number(options?.page) || 1);
    const tab = options?.tab === 'custom' ? 'custom' : 'featured';
    const fields = {page};
    const query = String(options?.query || '').trim();
    if (tab === 'featured') fields.action = 'get_featured';
    else {
      const sortby = customSort(options?.sortby);
      const uploaded = uploadedRange(options?.uploaded);
      if (options?.jhwmp && !query) {
        fields.action = 'search_by_name';
        fields.sterm = 'JHWMP';
      } else if (query) {
        fields.action = options?.by === 'author' ? 'search_by_user' : 'search_by_name';
        fields.sterm = query;
      } else fields.action = 'get_all';
      fields.sortby = sortby;
      fields.uploaded = uploaded;
    }
    const text = await (await post(fields)).text();
    let rows = rowsFromXml(text);
    if (tab === 'featured') rows = orderFeatured(rows);
    if (tab === 'custom' && options?.jhwmp) {
      const seen = new Set(rows.map((row) => row.id));
      const browse = rowsFromXml(await (await post({
        action: 'get_all',
        page,
        sortby: fields.sortby,
        uploaded: fields.uploaded,
      })).text());
      for (const row of browse) {
        if (seen.has(row.id) || !/jhwmp/i.test(row.name)) continue;
        rows.push(row);
        seen.add(row.id);
      }
      rows = rows.filter((row) => /jhwmp/i.test(row.name));
    }
    return rows;
  }

  function courseFromXml(xml) {
    if (typeof xml !== 'string' || /<!DOCTYPE|<!ENTITY/i.test(xml)) throw Error('That level has invalid map data.');
    const doc = new DOMParser().parseFromString(xml, 'text/xml');
    if (doc.getElementsByTagName('parsererror').length || doc.documentElement?.tagName !== 'levelXML' || !doc.getElementsByTagName('info').length) {
      throw Error('That level has invalid map data.');
    }
    const courseApi = window.HWJimbobCourse;
    if (!courseApi?.compile) throw Error('Multiplayer map rules are not ready. Restart Happy Wheels through Steam.');
    // Native text boxes use p7 attributes or p7 CDATA nodes. Searching raw XML
    // also finds notes and appends CDATA delimiters to otherwise valid tags.
    const boxes = [...doc.getElementsByTagName('sp')].filter(node => node.getAttribute('t') === '16').map(node => ({
      text: node.getAttribute('p7') || node.getElementsByTagName('p7')[0]?.textContent || '',
      x: Number(node.getAttribute('p0')) || 0,
      y: Number(node.getAttribute('p1')) || 0,
    }));
    return courseApi.compile(boxes);
  }

  function rulesFor(compiled) {
    return {
      play: compiled.play || null,
      waitSec: compiled.waitSec || null,
      seats: compiled.seats || null,
      rider: compiled.rider || null,
      lingerMs: compiled.lingerMs || null,
    };
  }

  function courseKey(meta) {
    return /^[1-9][0-9]{0,8}$/.test(String(meta?.level || '')) && /^[a-f0-9]{64}$/.test(meta?.hash || '')
      ? String(meta.level) + ':' + meta.hash : null;
  }

  function rememberBoxes(meta, compiled) {
    const key = courseKey(meta);
    if (!key || courses.has(key)) return;
    // Retain immutable map coordinates, never native nodes or live transforms.
    const boxes = compiled.boxes.filter(box => /^#jmp\b/i.test(String(box.text).split(/\r?\n/)[0].trim()))
      .map(box => Object.freeze({text: box.text, x: box.x, y: box.y}));
    courses.set(key, Object.freeze(boxes));
    if (courses.size > 16) courses.delete(courses.keys().next().value);
  }

  function courseFor(meta) {
    const boxes = courses.get(courseKey(meta));
    return boxes ? window.HWJimbobCourse.compile(boxes.map(box => ({...box}))) : null;
  }

  function rememberCourse(meta, xml) {
    if (!courseKey(meta)) return null;
    if (!courses.has(courseKey(meta))) rememberBoxes(meta, courseFromXml(xml));
    return courseFor(meta);
  }

  function validAuthorId(value) {
    return value != null && /^\d+$/.test(String(value)) && Number.isSafeInteger(Number(value));
  }

  async function levelInfo(id, hint) {
    if (validAuthorId(hint?.authorId) && (hint.id == null || String(hint.id) === String(id))) return hint;
    const response = await post({action: 'get_level', level_id: id});
    if (!response.ok) throw Error('That level\'s author information could not be loaded.');
    const info = rowsFromXml(await response.text()).find(row => row.id === String(id));
    if (!info || !validAuthorId(info.authorId)) throw Error('That level\'s author information could not be loaded. Try choosing the map again.');
    return info;
  }

  async function sha256(buffer) {
    const digest = await crypto.subtle.digest('SHA-256', buffer);
    return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, '0')).join('');
  }

  async function readLevel(id, hint) {
    if (!/^[1-9][0-9]{0,8}$/.test(String(id || ''))) throw Error('Enter a level id.');
    // Happy Wheels returns an empty HTTP 200 when ip_tracking is absent.
    // Its native loader uses 4–8 digits, with an even final digit to inspect
    // the record without incrementing its play count.
    const ipTracking = String(Math.floor(10000 + Math.random() * 90000) * 10);
    const response = await post({action: 'get_record', level_id: id, ip_tracking: ipTracking});
    if (!response.ok) throw Error('That level could not be loaded.');
    const buffer = await response.arrayBuffer();
    if (!buffer.byteLength) throw Error('The level download was empty. Try choosing the map again.');
    const prefix = new TextDecoder().decode(new Uint8Array(buffer, 0, Math.min(buffer.byteLength, 80)));
    if (/^\s*failure/i.test(prefix) || /<\s*(?:html|!DOCTYPE\s+html)/i.test(prefix)) throw Error('That level could not be loaded.');
    const hash = await sha256(buffer);
    let text, info = hint;
    if (/<levelXML(?:\s|>)/.test(prefix)) text = new TextDecoder().decode(buffer);
    else {
      try {
        info = await levelInfo(id, hint);
        const req = window.HWGhost?.require || window.HWMod?.require;
        const decoder = typeof req === 'function' ? req(0xfc39)?.t7 : null;
        if (!decoder?.decryptBytes) throw Error('Native decoder is not ready');
        text = decoder.decryptBytes(new Uint8Array(buffer), 'eatshit' + info.authorId);
      } catch (error) {
        if (api.errors.length < 30) api.errors.push(String(error?.message || error));
        throw Error('Could not read this level\'s multiplayer rules. Try choosing the map again. ' + String(error?.message || error));
      }
    }
    return {text, info, hash};
  }

  function factsFor(compiled) {
    const facts = [];
    const name = window.HWJimbobCourse?.riderName?.(compiled.rider) || '';
    if (compiled.play === 'survival') facts.push('Survival');
    if (compiled.seats === 1) facts.push('Solo');
    else if (compiled.seats) facts.push('Forces ' + compiled.seats + ' players');
    if (compiled.rider) facts.push(name ? name.replace(/\b[a-z]/g, letter => letter.toUpperCase()) + ' only' : 'Locked character');
    if (compiled.bump === false) facts.push('Collisions off');
    else if (compiled.bump === true) facts.push('Collisions on');
    if (compiled.waitSec) facts.push(compiled.waitSec + 's countdown');
    if (compiled.clockMs) facts.push(Math.round(compiled.clockMs / 1000) + 's time limit');
    if (compiled.lingerMs) facts.push(Math.round(compiled.lingerMs / 1000) + 's finish window');
    if (compiled.loops) facts.push(compiled.loops + (compiled.loops === 1 ? ' lap' : ' laps'));
    if (compiled.retry === 'off' && compiled.play !== 'survival') facts.push('No retries');
    else if (compiled.retry === 'flag') facts.push('Retry at last flag');
    else if (compiled.retry === 'start') facts.push('Retry at start');
    return facts;
  }

  function requirements(id, hint) {
    const key = String(id);
    if (!requirementCache.has(key)) {
      const pending = readLevel(id, hint).then(({text}) => factsFor(courseFromXml(text))).catch(error => {
        requirementCache.delete(key);
        throw error;
      });
      requirementCache.set(key, pending);
    }
    return requirementCache.get(key);
  }

  async function inspect(id, hint) {
    const {text, info, hash} = await readLevel(id, hint);
    // Unknown rules must never become a normal race: that silently disables
    // both survival results and unanimous restart voting on the relay.
    const compiled = courseFromXml(text);
    const rules = rulesFor(compiled);
    rememberBoxes({level: String(id), hash}, compiled);
    const core = window.HWGhostCore;
    return {
      meta: {
        protocol: core.VERSION,
        level: String(id),
        hash,
        title: String(info?.name || ('Level ' + id)).slice(0, 80),
        author: String(info?.author || '').slice(0, 40),
      },
      rules,
    };
  }

  api.list = list;
  api.inspect = inspect;
  api.requirements = requirements;
  api.courseFor = courseFor;
  api.rememberCourse = rememberCourse;
})();
