(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.HWSharedNet=api;})(typeof window==='object'?window:globalThis,()=>{
  'use strict';
  class Metrics {
    constructor(){this.samples=new Map();this.counts=Object.create(null);}
    add(name,value){if(!Number.isFinite(value)||value<0)return;let row=this.samples.get(name);if(!row){row={values:[],cursor:0};this.samples.set(name,row);}if(row.values.length<256)row.values.push(value);else{row.values[row.cursor]=value;row.cursor=(row.cursor+1)%256;}}
    count(name,n=1){this.counts[name]=(this.counts[name]||0)+n;}
    summary(){const result={counts:{...this.counts}};for(const [name,row]of this.samples){const sorted=row.values.slice().sort((a,b)=>a-b);const q=p=>Math.round(sorted[Math.min(sorted.length-1,Math.floor((sorted.length-1)*p))]*100)/100;result[name]={samples:sorted.length,p50:q(.5),p95:q(.95),p99:q(.99)};}return result;}
  }
  // Input changes are consumed by simulation steps, never by advancing physics
  // from a socket callback. Equal held states coalesce without losing transitions.
  class InputQueue {
    constructor(){this.items=[];this.latest=null;this.held=null;this.dropped=0;}
    push(input){if(this.latest&&input.seq<=this.latest.seq)return false;if(this.latest&&input.life!==this.latest.life){this.items.length=0;this.held=null;}this.latest=input;if(input.enabled===false){this.items.length=0;this.held=input;return true;}const last=this.items[this.items.length-1]||this.held;if(last&&last.keys===input.keys&&last.enabled===input.enabled){if(this.items.length)this.items[this.items.length-1]=input;else this.items.push(input);}else this.items.push(input);if(this.items.length>8){this.dropped+=this.items.length-8;this.items.splice(0,this.items.length-8);}return true;}
    take(time,life,timeout=750){if(!this.latest||this.latest.life!=null&&this.latest.life!==life||time-this.latest.at>=timeout){this.items.length=0;this.held=null;return null;}while(this.items.length>1&&time-this.items[0].at>250){this.items.shift();this.dropped++;}if(this.items.length)this.held=this.items.shift();return this.held;}
  }
  class Timeline {
    constructor(){this.clear();}
    clear(){this.frames=[];this.world=new Map();this.offsets=[];this.interval=1000/30;this.jitter=0;this.cursor=-Infinity;this.revision=null;this.epoch=null;this.lastArrival=null;this.lastTime=null;this.baseline=null;this.missingBaseline=false;}
    push(message,arrival){
      const reset=message.revision!==this.revision||message.epoch!==this.epoch;
      if(reset)this.clear();
      this.revision=message.revision;this.epoch=message.epoch;
      if(message.baselineId!=null&&!message.full&&message.baselineId!==this.baseline){this.missingBaseline=true;return false;}
      if(message.full){this.world=new Map();this.baseline=message.snapshotId??null;this.missingBaseline=false;}
      const time=Number.isFinite(message.time)?message.time:arrival;
      if(this.lastTime!=null&&time<this.lastTime)return false;
      if(this.lastTime!=null&&time>this.lastTime){const span=time-this.lastTime;this.interval+=.1*(Math.min(150,Math.max(16,span))-this.interval);const variation=Math.abs((arrival-this.lastArrival)-span);this.jitter+=.1*(Math.min(200,variation)-this.jitter);}
      this.lastArrival=arrival;this.lastTime=time;
      this.offsets.push(arrival-time);if(this.offsets.length>90)this.offsets.shift();
      for(const id of message.removed||[])this.world.delete(id);
      for(const row of message.world||[])this.world.set(row[0],row);
      const frame={...message,time,at:arrival,worldMap:new Map(this.world),playerMap:new Map((message.players||[]).map(p=>[p.id,p]))};
      this.frames.push(frame);if(this.frames.length>12)this.frames.shift();return frame;
    }
    sample(time){
      if(!this.frames.length)return null;
      const last=this.frames[this.frames.length-1],delay=Math.max(33,Math.min(120,this.interval+this.jitter*2));
      const offset=Math.min(...this.offsets),target=Math.min(last.time,time-offset-delay);
      this.cursor=Math.max(this.cursor,target,this.frames[0].time);
      let a=this.frames[0],b=a;
      for(const frame of this.frames){if(frame.time<=this.cursor)a=frame;if(frame.time>=this.cursor){b=frame;break;}b=frame;}
      const t=b.time>a.time?Math.max(0,Math.min(1,(this.cursor-a.time)/(b.time-a.time))):1;
      return {a,b,t,delay,age:time-offset-this.cursor};
    }
  }
  return {Metrics,InputQueue,Timeline};
});
