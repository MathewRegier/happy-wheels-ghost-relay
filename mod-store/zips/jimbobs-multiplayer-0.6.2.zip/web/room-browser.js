(() => {
  'use strict';
  const PROTOCOL='lobby-directory-v1';
  async function listRooms(address){
    let url;try{url=new URL(address);}catch{throw Error('Enter a valid server address in Advanced settings.');}
    if(!['ws:','wss:'].includes(url.protocol)||url.username||url.password)throw Error('Use a ws:// or wss:// server address without credentials.');
    const bridge=window.hwGhostNet||window.hwGhostSteam;
    const result=bridge?.listRooms?await bridge.listRooms(url.href):await new Promise((resolve,reject)=>{
      const ws=new WebSocket(url.href);let done=false,directory=null,ping=null,pingTimer=null,sentAt=null;
      const timer=setTimeout(()=>finish(Error('The room browser timed out. Try refreshing.')),10000);
      function finish(error,value){if(done)return;done=true;clearTimeout(timer);clearTimeout(pingTimer);try{ws.close();}catch{}error?reject(error):resolve(value);}
      function settle(){if(directory&&ping!=null)finish(null,{...directory,ping});}
      ws.onopen=()=>{sentAt=Date.now();ws.send(JSON.stringify({type:'ping',clientTime:sentAt}));ws.send(JSON.stringify({type:'browse'}));};
      ws.onerror=()=>finish(Error('Cannot reach the server. Check Advanced settings and try again.'));
      ws.onclose=()=>finish(Error('The server closed the browser connection. Try refreshing.'));
      ws.onmessage=event=>{try{
        if(typeof event.data!=='string'||event.data.length>128*1024)throw Error('Invalid response.');
        const data=JSON.parse(event.data);
        if(data.type==='pong'&&data.clientTime===sentAt){const rtt=Date.now()-sentAt;if(rtt>=0&&rtt<=10000)ping=rtt;settle();return;}
        if(data.type==='error')return finish(Error(data.message==='Unknown message'?'This server needs the lobby browser update.':data.message));
        if(data.type!=='directory')return;
        directory=data;
        if(ping!=null)settle();else pingTimer=setTimeout(()=>finish(null,{...directory,ping:null}),400);
      }catch{finish(Error('Invalid room browser response.'));}};
    });
    if(result?.protocol!==PROTOCOL||!Array.isArray(result.rooms)||result.rooms.length>100)throw Error('This server needs the lobby browser update.');
    // Validate before rendering. Room titles and host names are always text, never HTML.
    if(!result.rooms.every(r=>r&&/^[A-F0-9]{16}$/.test(r.code)&&['ghost','shared'].includes(r.mode)&&Number.isInteger(r.players)&&r.players>=1&&Number.isInteger(r.capacity)&&r.capacity>=1&&r.capacity<=16&&r.players<=r.capacity&&typeof r.joinable==='boolean'))throw Error('Invalid room browser response.');
    const ping=Number.isInteger(result.ping)&&result.ping>=0&&result.ping<=10000?result.ping:null;
    return {...result,ping};
  }
  window.HWRoomDirectory=Object.freeze({listRooms,PROTOCOL});
  window.HWRoomBrowser=(mount,actions)=>{
    mount.innerHTML=`<style>
      #hw-multiplayer{--ink:#0d171c;--paper:#f5eedb;--coral:#ff8582;--gold:#f2cb64;--mint:#b7dfb6;--sky:#acd7e8;padding:clamp(20px,3vw,48px);background:radial-gradient(ellipse at 95% 0%,#45606c 0%,#283c47 35%,#1b2a32 75%);font-size:16px}
      #hw-multiplayer h1{font-size:clamp(38px,4.6vw,76px);font-weight:900;letter-spacing:-2px;text-shadow:2px 3px 0 var(--ink);margin-bottom:20px}
      #hw-multiplayer .eyebrow{color:var(--paper);letter-spacing:2px;font-weight:bold}
      #hw-multiplayer button{border:2px solid #0d171c;border-radius:8px;background:#334d59;box-shadow:0 3px 0 #0d171c;color:var(--paper);font-weight:bold;transition:transform .12s,background .12s}
      #hw-multiplayer button:hover:enabled{background:#44616e;transform:translateY(-1px)}
      #hw-multiplayer button:active:enabled{transform:translateY(2px);box-shadow:none}
      #hw-multiplayer button:disabled{transform:none;opacity:.5}
      #hw-multiplayer button:focus-visible,#hw-multiplayer input:focus-visible,#hw-multiplayer select:focus-visible{outline:3px solid var(--gold);outline-offset:3px}
      #hw-multiplayer .primary{background:var(--gold);color:var(--ink);border-color:var(--ink)}#hw-multiplayer .primary:hover:enabled{background:#ffe298}
      #hw-multiplayer .back{background:#17272f;border:2px solid var(--ink);padding:9px 16px;margin-left:16px}
      #hw-multiplayer input,#hw-multiplayer select{border:2px solid #536b75;border-radius:7px;background:#111f26;color:var(--paper);min-width:0}
      #hw-multiplayer .panel{border:2px solid var(--ink);border-radius:12px;background:#17272f;box-shadow:0 5px 0 #0d171c66;padding:22px}
      #hw-multiplayer .panel h2{color:var(--gold);font-weight:bold;letter-spacing:1px}
      #hw-multiplayer #mp-step-mode,#hw-multiplayer #mp-step-size,#hw-multiplayer #mp-step-code{max-width:800px;margin:0 auto;padding:26px;background:#17272f;border:2px solid var(--ink);border-radius:14px;box-shadow:0 6px 0 var(--ink)}
      #hw-multiplayer .choice{display:grid;grid-template-columns:1fr 1fr;gap:16px}#hw-multiplayer .choice button{border:2px solid var(--ink);border-radius:10px;background:#243b46}
      #hw-multiplayer .lobby-grid{grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:22px}#hw-multiplayer .room-code{overflow-wrap:anywhere;color:var(--gold)}
      #hw-multiplayer .mpb-hero{display:flex;justify-content:space-between;align-items:center;gap:24px;margin:-6px 0 26px;padding-bottom:24px;border-bottom:2px solid #526b77}
      #hw-multiplayer .mpb-hero p{margin:0;color:#d0dce0;font-size:17px}#hw-multiplayer .mpb-hero strong{color:var(--paper);font-size:26px;display:block;margin-bottom:6px}
      #hw-multiplayer .mpb-actions{display:flex;flex-wrap:wrap;gap:12px}#hw-multiplayer .mpb-actions button{padding:13px 22px;white-space:nowrap;font-size:18px}
      #hw-multiplayer:has(#mp-step-choice:not([hidden])){display:flex;flex-direction:column;overflow:hidden;padding-bottom:24px}
      #hw-multiplayer #mp-status{display:none!important}
      #hw-multiplayer.mp-centered .eyebrow,#hw-multiplayer.mp-centered #mp-title{text-align:center}
      #hw-multiplayer.mp-centered .back{position:absolute;top:clamp(20px,3vw,48px);right:clamp(20px,3vw,48px);float:none;margin:0}
      #hw-multiplayer:has(#mp-step-choice:not([hidden])) .back{position:absolute;top:clamp(20px,3vw,48px);right:clamp(20px,3vw,48px);float:none;margin:0}
      #hw-multiplayer:has(#mp-step-choice:not([hidden])) #mp-entry,#hw-multiplayer:has(#mp-step-choice:not([hidden])) #mp-step-choice,#hw-multiplayer #mp-room-browser{display:flex;flex-direction:column;flex:1;min-height:0}
      #hw-multiplayer .mpb-layout{display:grid;grid-template-columns:220px minmax(0,1fr);gap:24px;flex:1;min-height:0;align-items:stretch}
      #hw-multiplayer .mpb-side{align-self:start;display:flex;flex-direction:column;gap:16px;min-width:0}
      #hw-multiplayer .mpb-aside{padding:22px;border:2px solid var(--ink);border-radius:12px;background:#17272f;box-shadow:0 5px 0 #0d171c66}
      #hw-multiplayer .mpb-aside h2{font-size:20px;margin:0 0 20px;color:var(--gold)}#hw-multiplayer .mpb-aside h3{font-size:17px;color:var(--paper);margin:18px 0 6px}
      #hw-multiplayer .mpb-aside p{font-size:14px;line-height:1.6;color:#b8cbd3;margin:0}
      #hw-multiplayer .mpb-credit p{margin:0;color:var(--paper);font-size:15px}
      #hw-multiplayer .mpb-credit button{width:100%;padding:11px 14px}
      #hw-multiplayer .mpb-board{min-width:0;min-height:0;height:100%;display:flex;flex-direction:column;background:#17272f;border:2px solid var(--ink);border-radius:12px;box-shadow:0 5px 0 #0d171c66;overflow:hidden}
      #hw-multiplayer .mpb-toolbar{display:flex;align-items:center;flex-wrap:wrap;gap:12px;padding:18px 20px;border-bottom:1px solid #415d6b;background:#20343f}
      #hw-multiplayer .mpb-toolbar label{flex:1;min-width:160px}#hw-multiplayer .mpb-toolbar input{width:100%;margin:0;padding:10px 12px}
      #hw-multiplayer .mpb-toolbar select{width:auto;margin:0;padding:10px;max-width:100%}#hw-multiplayer .mpb-toolbar button{padding:10px 15px}
      #hw-multiplayer .mpb-rooms{flex:1;min-height:0;padding:18px;display:flex;flex-direction:column;gap:12px;overflow:auto}
      #hw-multiplayer .mpb-row{display:grid;grid-template-columns:minmax(0,1fr) 120px 92px 72px 104px;align-items:center;gap:16px;padding:18px;background:#263e49;border:1px solid #4d6a77;border-radius:9px}
      #hw-multiplayer .mpb-name{font:700 20px Georgia,serif;color:var(--paper);margin:0 0 4px;overflow-wrap:anywhere}
      #hw-multiplayer .mpb-info{font:14px/1.5 Georgia,serif;color:#b9d0d9;margin:0;overflow-wrap:anywhere}
      #hw-multiplayer .mpb-mode{color:var(--sky);font-size:14px;font-weight:bold}#hw-multiplayer .mpb-mode small{display:block;color:#b4cbd4;font-size:12px;margin-top:4px}
      #hw-multiplayer .mpb-seats{font-size:21px;font-weight:bold;color:var(--paper)}#hw-multiplayer .mpb-seats small{display:block;font-size:13px;font-weight:normal;color:var(--mint);margin-top:3px}
      #hw-multiplayer .mpb-ping{font-size:18px;font-weight:bold;color:var(--mint)}#hw-multiplayer .mpb-ping.ok{color:var(--gold)}#hw-multiplayer .mpb-ping.slow{color:var(--coral)}#hw-multiplayer .mpb-ping small{display:block;font-size:12px;font-weight:normal;color:#b4cbd4;margin-top:3px}
      #hw-multiplayer .mpb-row button{padding:9px 12px;box-shadow:0 3px 0 var(--ink)}
      #hw-multiplayer .mpb-empty{flex:1;display:flex;align-items:center;justify-content:center;text-align:center;padding:38px 20px;min-height:0;flex-direction:column;color:#b8cbd3}
      #hw-multiplayer .mpb-empty strong{display:block;color:var(--paper);font-size:26px;margin-bottom:10px}#hw-multiplayer .mpb-empty p{max-width:460px;margin:0}
      #hw-multiplayer .mpb-error{color:var(--coral);margin:0 20px 18px;overflow-wrap:anywhere}#hw-multiplayer .mpb-foot{display:flex;gap:16px;justify-content:space-between;flex-wrap:wrap;padding:14px 20px;border-top:1px solid #415d6b;color:#acbec7;font-size:13px}
      #hw-multiplayer .mpb-foot span:first-child{color:var(--mint)}#hw-multiplayer .mpb-foot span:first-child:before{content:'● ';font-size:11px}
      #hw-multiplayer .mp-code-label{margin:18px 0 4px;color:var(--gold);font:700 20px/1.2 Georgia,serif;letter-spacing:.04em}
      #hw-multiplayer #mp-room-code{margin:0 0 10px;color:var(--paper);font:900 clamp(28px,3.4vw,44px)/1.15 Georgia,serif;letter-spacing:3px}
      #hw-multiplayer #mp-ready{display:flex;width:100%;justify-content:center;margin:12px 0 10px;padding:18px 16px;font-size:30px;background:var(--gold);color:var(--ink)}
      #hw-multiplayer #mp-ready:hover:enabled{background:#ffe298}
      #hw-multiplayer #mp-not-ready{display:block;width:100%;margin:0 0 10px}
      #hw-multiplayer #mp-choose{display:flex;width:100%;justify-content:center;margin:0 0 16px;padding:14px 16px;font-size:20px}
      #hw-multiplayer .mp-tools{margin-top:4px;padding-top:14px;border-top:1px solid #415d6b}
      #hw-multiplayer .mp-tools h3{margin:0 0 10px;color:#9eb4be;font:700 13px/1 Georgia,serif;letter-spacing:.12em;text-transform:uppercase}
      #hw-multiplayer .mp-tools .actions{margin:0}
      #hw-multiplayer .mp-tools button{font-size:15px;padding:8px 12px}
      #hw-multiplayer .mp-mode-buttons{display:flex;gap:10px;flex-wrap:wrap;margin:12px 0}#hw-multiplayer .mp-mode-buttons [aria-pressed=true]{background:var(--gold);color:var(--ink)}
      #hw-multiplayer .mp-mode-buttons [aria-pressed=true]:disabled{opacity:1}
      #hw-multiplayer .mp-room-note{font-size:14px;color:var(--mint)}#hw-multiplayer .mp-form-grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}
      @media(min-width:1600px){#hw-multiplayer .mpb-layout{grid-template-columns:270px minmax(0,1fr)}#hw-multiplayer .mpb-row{padding:24px;grid-template-columns:minmax(0,1fr) 170px 120px 84px 130px}}
      @media(max-width:1100px){#hw-multiplayer .mpb-layout{grid-template-columns:1fr}#hw-multiplayer .mpb-aside{display:none}#hw-multiplayer .mpb-hero{align-items:flex-start}#hw-multiplayer .mpb-hero strong{font-size:21px}#hw-multiplayer .mpb-row{gap:12px;grid-template-columns:minmax(0,1fr) 105px 72px 64px 92px}}
      @media(max-width:800px){#hw-multiplayer .lobby-grid{grid-template-columns:1fr}}
      @media(max-width:620px){#hw-multiplayer{padding:18px}#hw-multiplayer h1{letter-spacing:-1px}#hw-multiplayer .mpb-hero{flex-direction:column;gap:16px}#hw-multiplayer .mpb-row{grid-template-columns:minmax(0,1fr) 85px;padding:12px}#hw-multiplayer .mpb-mode{grid-column:1;font-size:13px}#hw-multiplayer .mpb-seats{grid-column:2;grid-row:1;font-size:17px}#hw-multiplayer .mpb-ping{grid-column:1;grid-row:3;font-size:15px}#hw-multiplayer .mpb-row button{grid-column:2;grid-row:2}#hw-multiplayer .mpb-name{font-size:17px}#hw-multiplayer .mpb-rooms{padding:0 12px 12px}#hw-multiplayer .choice,#hw-multiplayer .mp-form-grid{grid-template-columns:1fr}#hw-multiplayer .mpb-toolbar{padding:12px}#hw-multiplayer .mpb-toolbar select{flex:1}#hw-multiplayer #mp-step-size,#hw-multiplayer #mp-step-code,#hw-multiplayer #mp-step-mode{padding:18px}}
      @media(prefers-reduced-motion:reduce){#hw-multiplayer button{transition:none}}
    </style>
    <div class="mpb-hero"><div><strong>Good company. Terrible landings.</strong><p>Find a public room and jump into the chaos.</p></div><div class="mpb-actions"><button class="primary" type="button" data-action="host">+ Host a room</button><button type="button" data-action="code">Join with code</button></div></div>
    <div class="mpb-layout"><div class="mpb-side"><aside class="mpb-aside"><h2>Pick your kind of chaos</h2><h3>Ghost Multiplayer</h3><p>Your own run, with everyone in sight. Race together without colliding.</p><h3>Shared Physics</h3><p>One world. Real collisions. A little friendly sabotage.</p></aside><div class="mpb-credit"><p>Created by Jimbob</p><button type="button" data-discord>Join the Discord</button></div></div>
    <section class="mpb-board" aria-label="Public rooms"><div class="mpb-toolbar"><label><span class="sr-only" style="position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%)">Search rooms</span><input data-search type="search" placeholder="Search rooms, hosts or levels" maxlength="80"></label><select data-filter aria-label="Filter by mode"><option value="all">All modes</option><option value="ghost">Ghost Multiplayer</option><option value="shared">Shared Physics</option></select><button data-refresh type="button">Refresh</button></div><div class="mpb-rooms" data-rooms></div><p class="mpb-error" data-error role="status" hidden></p><div class="mpb-foot"><span data-health>Connecting to server</span><span>Friends-only rooms use invites or codes.</span></div></section></div>`;
    const get=selector=>mount.querySelector(selector),list=get('[data-rooms]'),error=get('[data-error]'),health=get('[data-health]');
    let active=false,timer=0,token=0,busy=false,rows=[],lastKey='',loaded=false,failed=false,pingMs=null;
    function empty(title,copy){const box=document.createElement('div');box.className='mpb-empty';const strong=document.createElement('strong'),p=document.createElement('p');strong.textContent=title;p.textContent=copy;box.append(strong,p);list.replaceChildren(box);}
    function paint(){
      const query=get('[data-search]').value.trim().toLowerCase(),filter=get('[data-filter]').value;
      const visible=rows.filter(r=>(filter==='all'||r.mode===filter)&&[r.name,r.host,r.level?.title].join(' ').toLowerCase().includes(query));
      const key=JSON.stringify([visible,loaded,failed,query,filter,pingMs]);if(key===lastKey)return;lastKey=key;
      if(!visible.length){empty(!loaded?(failed?'Couldn’t load the rooms':'Finding your next race…'):rows.length?'No matching rooms':'The track is all yours',!loaded?'Refresh to try again, or press = for server settings.':rows.length?'Try another search or mode.':'No public rooms right now. Host one and get things rolling!');return;}
      const focusCode=document.activeElement?.dataset?.roomCode;
      const scroll=list.scrollTop;
      list.replaceChildren(...visible.map(r=>{
        const row=document.createElement('article');row.className='mpb-row';
        const main=document.createElement('div'),name=document.createElement('h3'),info=document.createElement('p');name.className='mpb-name';name.textContent=String(r.name||'Happy Wheels room').slice(0,48);info.className='mpb-info';info.textContent='Hosted by '+String(r.host||'Racer').slice(0,24)+' · '+String(r.level?.title||'Choosing a level').slice(0,80);main.append(name,info);
        const mode=document.createElement('div');mode.className='mpb-mode';mode.textContent=r.mode==='shared'?'Shared Physics':'Ghost Multiplayer';const privacy=document.createElement('small');privacy.textContent=r.passwordProtected?'Password required':'No password';mode.append(privacy);
        const seats=document.createElement('div');seats.className='mpb-seats';seats.textContent=r.players+' / '+r.capacity;const state=document.createElement('small');state.textContent=String(r.status||'Open').slice(0,20);seats.append(state);
        const ping=document.createElement('div');ping.className='mpb-ping'+(pingMs==null?'':pingMs<80?' good':pingMs<160?' ok':' slow');ping.textContent=pingMs==null?'—':String(pingMs);const unit=document.createElement('small');unit.textContent='Ping';ping.append(unit);
        const join=document.createElement('button');join.type='button';join.className=r.joinable?'primary':'';join.disabled=!r.joinable||failed;join.dataset.roomCode=r.code;join.textContent=r.joinable?(r.passwordProtected?'Unlock':'Join'):String(r.status||'Unavailable').slice(0,20);join.setAttribute('aria-label','Join '+name.textContent);join.onclick=()=>actions.join(r);
        row.append(main,mode,seats,ping,join);return row;
      }));
      list.scrollTop=scroll;if(focusCode){const btn=[...list.querySelectorAll('button')].find(b=>b.dataset.roomCode===focusCode);btn?.focus({preventScroll:true});}
    }
    async function refresh(){
      if(!active||busy)return;busy=true;const id=token;
      get('[data-refresh]').disabled=true;get('[data-refresh]').textContent='Refreshing…';
      try{
        const result=await listRooms(actions.server());if(!active||id!==token)return;
        rows=result.rooms;pingMs=result.ping;loaded=true;failed=false;error.hidden=true;health.textContent=pingMs==null?'Live · updates every 8 seconds':'Live · your ping '+pingMs+' ms';paint();
      }catch(e){if(!active||id!==token)return;failed=true;error.hidden=false;error.textContent=e.message||'Could not load rooms.';health.textContent='Connection unavailable · refresh to retry';paint();}
      finally{busy=false;get('[data-refresh]').disabled=false;get('[data-refresh]').textContent='Refresh';if(active)timer=setTimeout(refresh,8000);}
    }
    get('[data-search]').oninput=paint;get('[data-filter]').onchange=paint;
    get('[data-refresh]').onclick=()=>{clearTimeout(timer);refresh();};
    get('[data-action=host]').onclick=actions.host;get('[data-action=code]').onclick=actions.code;
    get('[data-discord]').onclick=()=>window.open('https://discord.gg/XcZePBgDBJ','_blank','noopener');
    function setActive(value){if(active===value)return;active=value;token++;clearTimeout(timer);if(value){paint();refresh();}}
    function reset(){rows=[];pingMs=null;loaded=false;failed=false;lastKey='';error.hidden=true;token++;clearTimeout(timer);paint();if(active&&!busy)refresh();}
    paint();return {setActive,refresh,reset};
  };
})();
