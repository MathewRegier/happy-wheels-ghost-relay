(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.HWNetworkQueue=api;})(typeof window==='object'?window:globalThis,()=>{
  'use strict';
  // Preserve reliable messages. Only adjacent, cumulative motion updates with
  // the same baseline and actor lifetimes may replace one another in the queue.
  function motionKey(data){
    let m;try{m=JSON.parse(data);}catch{return null;}
    if(m.type!=='authorityState'||m.baselineId==null||m.full||m.effects?.length||m.textures?.length||m.removed?.length||m.signature)return null;
    if((m.players||[]).some(p=>p.events?.length||p.resetEvents))return null;
    return JSON.stringify([m.epoch,m.launchId,m.revision,m.baselineId,(m.players||[]).map(p=>[p.id,p.life,p.character,p.rebuild,p.request,p.dead,p.finished,p.eventBase])]);
  }
  class SendQueue {
    constructor(socket,{bytes=s=>new TextEncoder().encode(s).length,now=()=>Date.now(),schedule=(fn,ms)=>setTimeout(fn,ms),cancel=id=>clearTimeout(id),notify=()=>{}}={}){
      Object.assign(this,{socket,bytes,now,schedule,cancel,notify});this.items=[];this.queued=0;this.timer=null;this.closed=false;this.coalesced=0;this.lastStats=-Infinity;
    }
    stop(){this.closed=true;if(this.timer!=null)this.cancel(this.timer);this.timer=null;this.items.length=0;this.queued=0;}
    fail(reason){this.notify({reason,fatal:true,bufferedAmount:this.socket.bufferedAmount||0,queuedBytes:this.queued});this.stop();try{this.socket.close(1013,reason);}catch{}}
    send(data){
      if(this.closed||this.socket.readyState!==1)return false;
      if(typeof data!=='string')return false;
      const size=this.bytes(data);
      if(size>512*1024){this.fail('Shared world exceeds the relay packet limit');return false;}
      const item={data,size,at:this.now()};
      if(this.items.length){
        const last=this.items[this.items.length-1],key=motionKey(data);
        if(key&&key===motionKey(last.data)){this.queued-=last.size;item.at=last.at;this.items.pop();this.coalesced++;}
      }
      this.items.push(item);this.queued+=size;
      if(this.queued+(this.socket.bufferedAmount||0)>1024*1024){this.fail('Connection cannot keep up; reconnect');return false;}
      this.flush();return !this.closed;
    }
    flush(){
      if(this.timer!=null)this.cancel(this.timer);this.timer=null;if(this.closed)return;
      if(this.socket.readyState!==1){this.stop();return;}
      const at=this.now();
      if(this.items.length&&at-this.items[0].at>1000){this.fail('Connection stalled; reconnect');return;}
      try{while(this.items.length&&(this.socket.bufferedAmount||0)<128*1024){const item=this.items.shift();this.queued-=item.size;this.socket.send(item.data);}}catch{this.fail('Connection send failed; reconnect');return;}
      const pressure=this.queued+(this.socket.bufferedAmount||0)>64*1024;
      if(at-this.lastStats>=(pressure?100:1000)){this.lastStats=at;this.notify({bufferedAmount:this.socket.bufferedAmount||0,queuedBytes:this.queued,queueAgeMs:this.items.length?at-this.items[0].at:0,coalesced:this.coalesced});}
      if(this.items.length&&this.timer==null)this.timer=this.schedule(()=>this.flush(),10);
    }
  }
  return {SendQueue,motionKey};
});
