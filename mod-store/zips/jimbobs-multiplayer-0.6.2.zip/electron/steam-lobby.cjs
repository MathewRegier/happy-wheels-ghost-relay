'use strict';
const path = require('node:path');
const zlib = require('node:zlib');
const {BrowserWindow} = require('electron');

const MARKER = 'jhwml';
const JOIN_REQUESTED = 8;
const AVATAR_MAX = 80000;
let api = null;
let lobby = null;
let pending = null;
let cachedAvatar = '';

function relayUrl(value) {
  let parsed;
  try { parsed = new URL(String(value || '')); } catch { return ''; }
  if (parsed.username || parsed.password || parsed.hash) return '';
  const local = parsed.hostname === '127.0.0.1' || parsed.hostname === 'localhost';
  if (parsed.protocol === 'wss:' || (parsed.protocol === 'ws:' && local)) return parsed.href;
  return '';
}

function fromCache() {
  for (const key of Object.keys(require.cache)) {
    if (!/steamworksjs\..+\.node$/i.test(key)) continue;
    const loaded = require.cache[key]?.exports;
    if (loaded?.localplayer?.getName && loaded?.matchmaking?.createLobby) return loaded;
  }
  return null;
}

function nativeApi() {
  const cached = fromCache();
  if (cached) return cached;
  const roots = [
    path.join(process.resourcesPath, 'app.asar.unpacked', 'node_modules', 'steamworks.js'),
    path.join(process.resourcesPath, 'app', 'node_modules', 'steamworks.js'),
  ];
  let reason = 'Steamworks is not in this Happy Wheels install.';
  for (const root of roots) {
    try {
      const native = require(path.join(root, 'dist', 'win64', 'steamworksjs.win32-x64-msvc.node'));
      if (native?.localplayer?.getName && native?.matchmaking?.createLobby) return native;
      reason = 'Steamworks loaded without a lobby API.';
    } catch (error) { reason = error.message; }
  }
  throw Error(reason);
}

function emit(payload) {
  for (const win of BrowserWindow.getAllWindows()) {
    if (!win.isDestroyed()) win.webContents.send('ghost:steam', payload);
  }
}

function crc32(buf) {
  let crc = ~0;
  for (let i = 0; i < buf.length; i++) {
    crc ^= buf[i];
    for (let j = 0; j < 8; j++) crc = (crc >>> 1) ^ (0xedb88320 & -(crc & 1));
  }
  return (~crc) >>> 0;
}

function pngFromRgba(width, height, rgba) {
  const row = width * 4;
  const raw = Buffer.alloc((row + 1) * height);
  for (let y = 0; y < height; y++) {
    raw[y * (row + 1)] = 0;
    rgba.copy(raw, y * (row + 1) + 1, y * row, y * row + row);
  }
  const compressed = zlib.deflateSync(raw);
  function chunk(type, data) {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length);
    const body = Buffer.concat([Buffer.from(type), data]);
    const c = Buffer.alloc(4);
    c.writeUInt32BE(crc32(body));
    return Buffer.concat([len, body, c]);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;
  ihdr[9] = 6;
  return Buffer.concat([
    Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    chunk('IHDR', ihdr),
    chunk('IDAT', compressed),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

function asBuffer(value) {
  if (!value) return null;
  if (Buffer.isBuffer(value)) return value;
  if (value instanceof Uint8Array) return Buffer.from(value);
  if (typeof value === 'string') return Buffer.from(value, 'base64');
  return null;
}

function avatarDataUrl(steam) {
  let raw = null;
  try { raw = steam.localplayer.getAvatar?.() || steam.localplayer.getMediumAvatar?.() || null; } catch {}
  if (!raw) {
    try {
      const id = steam.localplayer.getSteamId?.();
      const steamId = id?.steamId64 ?? id;
      if (steamId != null && steam.friends?.getFriendAvatar) {
        raw = steam.friends.getFriendAvatar(typeof steamId === 'bigint' ? steamId : BigInt(steamId));
      }
    } catch {}
  }
  if (!raw) return '';
  if (typeof raw === 'string' && raw.startsWith('data:image/')) return raw.slice(0, AVATAR_MAX);
  const width = Number(raw.width) || 0;
  const height = Number(raw.height) || 0;
  const pixels = asBuffer(raw.data || raw.rgba || raw);
  if (pixels && pixels.length >= 8 && pixels[0] === 0x89 && pixels[1] === 0x50) {
    return ('data:image/png;base64,' + pixels.toString('base64')).slice(0, AVATAR_MAX);
  }
  if (width > 0 && height > 0 && pixels && pixels.length >= width * height * 4) {
    const png = pngFromRgba(width, height, pixels.subarray(0, width * height * 4));
    return ('data:image/png;base64,' + png.toString('base64')).slice(0, AVATAR_MAX);
  }
  return '';
}

function identity() {
  const steam = client();
  const name = String(steam.localplayer.getName() || '').slice(0, 24);
  if (!cachedAvatar) {
    try { cachedAvatar = avatarDataUrl(steam); } catch { cachedAvatar = ''; }
  }
  return {ok: true, name, avatar: cachedAvatar};
}

function client() {
  if (api) return api;
  const next = nativeApi();
  next.localplayer.getName();
  api = next;
  try {
    api.callback.register(JOIN_REQUESTED, (event) => {
      const id = event?.lobby_steam_id ?? event?.lobbySteamId ?? event?.lobby;
      if (id) accept(id).catch((error) => emit({type: 'error', message: error.message || 'Could not join that Steam invite.'}));
    });
  } catch {}
  const invited = commandLobby();
  if (invited) accept(invited).catch((error) => emit({type: 'error', message: error.message || 'Could not join that Steam invite.'}));
  return api;
}

function commandLobby() {
  const args = process.argv;
  for (let i = 0; i < args.length; i++) {
    const arg = String(args[i] || '');
    if (arg === '+connect_lobby' && /^\d{2,}$/.test(args[i + 1] || '')) return args[i + 1];
    const inline = arg.match(/^\+connect_lobby(?:=|\s+)(\d{2,})$/);
    if (inline) return inline[1];
  }
  return '';
}

function lobbyId(value) {
  if (typeof value === 'bigint') return value;
  const id = value?.id ?? value;
  return typeof id === 'bigint' ? id : BigInt(id);
}

async function publish(info) {
  const steam = client();
  const code = String(info.code || '').trim().toUpperCase();
  const server = relayUrl(info.server);
  if (!/^[A-F0-9]{16}$/.test(code) || !server) throw Error('The room is not ready for a Steam invite.');
  if (lobby) { try { lobby.leave(); } catch {} lobby = null; }
  const seats = Math.max(2, Math.min(16, Number(info.seats) || 8));
  const created = await steam.matchmaking.createLobby(0, seats);
  created.setData('marker', MARKER);
  created.setData('code', code);
  created.setData('server', server);
  created.setData('mode', info.mode === 'shared' ? 'shared' : 'ghost');
  lobby = created;
  const id = identity();
  return {ok: true, name: id.name, avatar: id.avatar};
}

function invite() {
  if (!lobby) throw Error('Create a room before inviting Steam friends.');
  const steam = client();
  if (typeof lobby.openInviteDialog === 'function') lobby.openInviteDialog();
  else steam.overlay.activateInviteDialog(lobbyId(lobby));
  return {ok: true};
}

async function accept(id) {
  const steam = client();
  const joinedLobby = await steam.matchmaking.joinLobby(lobbyId(id));
  const marker = joinedLobby.getData('marker');
  const code = String(joinedLobby.getData('code') || '').toUpperCase();
  const server = relayUrl(joinedLobby.getData('server'));
  const mode = joinedLobby.getData('mode') === 'shared' ? 'shared' : 'ghost';
  try { joinedLobby.leave(); } catch {}
  if (marker !== MARKER || !/^[A-F0-9]{16}$/.test(code) || !server) throw Error('That Steam lobby is not a multiplayer room.');
  pending = {code, server, mode};
  emit({type: 'invite', code, server, mode});
  return pending;
}

function close() {
  try { lobby?.leave(); } catch {}
  lobby = null;
}

function status() {
  try {
    return {...identity(), invite: pending};
  } catch (error) {
    return {ok: false, error: error.message || 'Steam is not available.', name: '', avatar: ''};
  }
}

function takeInvite() {
  const invite = pending;
  pending = null;
  return invite;
}

module.exports = {publish, invite, close, status, takeInvite, relayUrl, pngFromRgba, avatarDataUrl};
