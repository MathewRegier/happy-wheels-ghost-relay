'use strict';
// Discovery owns a short-lived socket. It never closes or replaces the game socket.
function listRooms(WebSocket,address){
  let url;try{url=new URL(address);}catch{throw Error('Enter a valid server address.');}
  if(!['ws:','wss:'].includes(url.protocol)||url.username||url.password)throw Error('Use a ws:// or wss:// server address without credentials.');
  return new Promise((resolve,reject)=>{
    const socket=new WebSocket(url.href,{maxPayload:128*1024,perMessageDeflate:false,handshakeTimeout:8000,followRedirects:false});
    let done=false,directory=null,ping=null,pingTimer=null,sentAt=null;
    const timer=setTimeout(()=>finish(Error('The room browser timed out. Check the server address and try again.')),10000);
    function finish(error,value){if(done)return;done=true;clearTimeout(timer);clearTimeout(pingTimer);socket.removeAllListeners('message');try{socket.close();}catch{}if(error)reject(error);else resolve(value);}
    function settle(){if(directory&&ping!=null)finish(null,{...directory,ping});}
    socket.on('error',()=>finish(Error('Cannot reach the room browser. Check the server address and try again.')));
    socket.on('close',()=>finish(Error('The server closed the room browser connection.')));
    socket.on('open',()=>{sentAt=Date.now();socket.send(JSON.stringify({type:'ping',clientTime:sentAt}));socket.send(JSON.stringify({type:'browse'}));});
    socket.on('message',raw=>{
      try{
        const result=JSON.parse(raw);
        if(result.type==='pong'&&result.clientTime===sentAt){
          const rtt=Date.now()-sentAt;
          if(rtt>=0&&rtt<=10000)ping=rtt;
          settle();
          return;
        }
        if(result.type==='error')return finish(Error(result.message==='Unknown message'?'This server needs the lobby browser update. Choose an updated server in Advanced settings.':result.message));
        if(result.type!=='directory')return;
        if(result.protocol!=='lobby-directory-v1'||!Array.isArray(result.rooms)||result.rooms.length>100)throw Error('Invalid room browser response.');
        directory=result;
        if(ping!=null)settle();
        else pingTimer=setTimeout(()=>finish(null,{...directory,ping:null}),400);
      }catch{finish(Error('The server sent an invalid room browser response.'));}
    });
  });
}
module.exports={listRooms};
