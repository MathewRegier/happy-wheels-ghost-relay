(() => {
  const {contextBridge,ipcRenderer}=require('electron');
  const api={
    listRooms:url=>ipcRenderer.invoke('ghost:list-rooms',url),
    connect:url=>ipcRenderer.invoke('ghost:connect',url),
    send:data=>ipcRenderer.send('ghost:send',data),
    disconnect:()=>ipcRenderer.send('ghost:disconnect'),
    openPeer:()=>ipcRenderer.invoke('ghost:open-peer'),
    onEvent:fn=>{const listener=(_event,data)=>fn(data);ipcRenderer.on('ghost:network',listener);return()=>ipcRenderer.removeListener('ghost:network',listener);},
    steamStatus:()=>ipcRenderer.invoke('ghost:steam-status'),
    steamPublish:info=>ipcRenderer.invoke('ghost:steam-publish',info),
    steamInvite:()=>ipcRenderer.invoke('ghost:steam-invite'),
    steamTake:()=>ipcRenderer.invoke('ghost:steam-take'),
    onSteam:fn=>{const listener=(_event,data)=>fn(data);ipcRenderer.on('ghost:steam',listener);return()=>ipcRenderer.removeListener('ghost:steam',listener);}
  };
  try{contextBridge.exposeInMainWorld('hwGhostNet',api);}catch(e){}
  try{contextBridge.exposeInMainWorld('hwGhostSteam',api);}catch(e){}
})();
