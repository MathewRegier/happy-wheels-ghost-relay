'use strict';
const fs = require('node:fs');
const path = require('node:path');

function writeIndex(dir) {
  if (!fs.existsSync(dir) || !fs.statSync(dir).isDirectory()) return;
  const ids = [];
  for (const item of fs.readdirSync(dir, {withFileTypes: true})) {
    if (!item.isDirectory()) continue;
    if (!/^[a-z0-9][a-z0-9-]*$/i.test(item.name)) continue;
    if (fs.existsSync(path.join(dir, item.name, 'character.json'))) ids.push(item.name);
  }
  ids.sort((a, b) => a.localeCompare(b));
  fs.writeFileSync(path.join(dir, 'index.json'), `${JSON.stringify({characters: ids}, null, 2)}\n`);
}

writeIndex(path.join(__dirname, 'web', 'characters'));
writeIndex(path.join(__dirname, '..', '..', 'resources', 'webroot', 'js', 'jimbobs-custom-characters', 'characters'));
