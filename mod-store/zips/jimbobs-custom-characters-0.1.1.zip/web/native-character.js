(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.HWNativeCharacter = api;
})(globalThis, () => {
  'use strict';
  const snapshots = new WeakMap();
  const hooked = new WeakSet();

  function validate(profile) {
    if (!profile || profile.mode !== 'native-parts') throw Error('Expected a native-parts character profile');
    for (const key of ['bodyScale', 'headScale', 'torsoWidth']) {
      if (!Number.isFinite(profile[key]) || profile[key] < 0.2 || profile[key] > 3) throw Error('Invalid profile ' + key);
    }
    if (profile.vehicleScale != null && (!Number.isFinite(profile.vehicleScale) || profile.vehicleScale < 0.2 || profile.vehicleScale > 3)) {
      throw Error('Invalid profile vehicleScale');
    }
    if (profile.guides) {
      for (const value of Object.values(profile.guides)) {
        for (const [key, n] of Object.entries(value)) {
          if (!['x', 'y', 'scaleX', 'scaleY', 'rotation'].includes(key) || !Number.isFinite(n) || Math.abs(n) > 2000) {
            throw Error('Invalid shape-guide override');
          }
        }
      }
    }
    return profile;
  }

  function partKind(key) {
    if (/^(frame|rod|handle|foot|spring|seat|fork|wheel)/i.test(key)) return 'vehicle';
    if (/^helmet/i.test(key) || /^(head|brain|spineAnchor)/i.test(key)) return 'head';
    if (/^(chest|pelvis)/i.test(key)) return 'torso';
    return 'body';
  }

  function snapshotNode(node) {
    return {
      x: node.x,
      y: node.y,
      scaleX: node.scaleX,
      scaleY: node.scaleY,
      rotation: node.rotation
    };
  }

  function remember(target) {
    let saved = snapshots.get(target);
    if (saved) return saved;
    saved = {};
    for (const [key, node] of Object.entries(target)) {
      if (node && (node.pixiSprite || node.scaleX != null) && /(Shape|Anchor|Vert\d+|Outer\d*|arm\d+|leg\d+|head|chest|pelvis|helmet|upperArm|lowerArm|upperLeg|lowerLeg)$/i.test(key)) {
        saved[key] = snapshotNode(node);
      }
    }
    snapshots.set(target, saved);
    return saved;
  }

  function applySnapshot(target, profile, extras) {
    const saved = remember(target);
    for (const [key, values] of Object.entries(saved)) {
      const node = target[key];
      if (!node) continue;
      Object.assign(node, values);
      if (!profile) continue;
      const kind = partKind(key);
      const scale = kind === 'vehicle' ? (profile.vehicleScale ?? 1) : profile.bodyScale;
      const head = kind === 'head' ? profile.headScale : 1;
      const torso = kind === 'torso' ? profile.torsoWidth : 1;
      const layout = /^(headOuter|arm\d+|leg\d+|pelvis)$/i.test(key);
      const guidePoint = /(Anchor|Vert\d+)$/i.test(key);
      const move = /Vert\d+$/i.test(key) && kind === 'head' ? scale * head : scale;
      if (layout || guidePoint) {
        node.x *= move;
        node.y *= move;
      }
      if (/Shape$/i.test(key)) {
        if (node.scaleX != null) node.scaleX *= scale * head * torso;
        if (node.scaleY != null) node.scaleY *= scale * head;
      }
      if (extras?.[key]) Object.assign(node, extras[key]);
    }
  }

  function transformPlaceholder(placeholder, profile) {
    if (!placeholder) return;
    const npc = placeholder.npcSprite;
    const guide = placeholder.shapeGuide;
    if (npc) applySnapshot(npc, profile, profile?.guides);
    if (guide) applySnapshot(guide, profile, profile?.guides);
    if (npc) {
      for (const child of npc.children || []) {
        if (child?.name && /helmet/i.test(child.name) && profile?.helmet === false) child.visible = false;
      }
    }
  }

  function scaleParts(character) {
    const profile = character.__nativeProfile;
    if (!profile) return;
    const seen = new Set();
    const apply = (node, key) => {
      if (!node || seen.has(node)) return;
      seen.add(node);
      const kind = partKind(key);
      const scale = kind === 'vehicle' ? (profile.vehicleScale ?? 1) : profile.bodyScale;
      const head = kind === 'head' ? profile.headScale : 1;
      const torso = kind === 'torso' ? profile.torsoWidth : 1;
      if (node.pixiSprite || node.scaleX != null) {
        const sign = node.scaleX < 0 ? -1 : 1;
        node.scaleX = sign * scale * head * torso / character.mc_scale;
        node.scaleY = scale * head / character.mc_scale;
      }
    };
    for (const [key, node] of Object.entries(character)) {
      if (/MC$/.test(key)) apply(node, key);
      if (/MCs$/.test(key) && Array.isArray(node)) for (const part of node) apply(part, key);
    }
  }

  function hideHelmetGraphic(character) {
    const visit = (node, depth) => {
      if (!node || depth > 8) return;
      const name = String(node.name || '');
      if (/helmet/i.test(name)) node.visible = false;
      if (node.helmet && node.helmet !== node) {
        node.helmet.visible = false;
        visit(node.helmet, depth + 1);
      }
      for (const child of node.children || []) visit(child, depth + 1);
      if (node.pixiMovieClip) visit(node.pixiMovieClip, depth + 1);
      if (node.pixiSprite && node.pixiSprite !== node) visit(node.pixiSprite, depth + 1);
    };
    visit(character.headMC, 0);
    if (character.helmetMC) character.helmetMC.visible = false;
  }

  function finishSetup(character, profile) {
    scaleParts(character);
    if (typeof character.brainRadius === 'number') character.brainRadius *= profile.bodyScale * profile.headScale;
    for (const key of ['bounceTranslation', 'jumpTranslation', 'reAttachDistance']) {
      if (typeof character[key] === 'number') character[key] *= profile.bodyScale;
    }
    if (profile.helmet === false) hideHelmetGraphic(character);
  }

  function wrapMethod(object, name, before, after) {
    let owner = object;
    while (owner && !Object.prototype.hasOwnProperty.call(owner, name)) owner = Object.getPrototypeOf(owner);
    if (!owner || typeof owner[name] !== 'function' || owner[name].__hwNative) return;
    const original = owner[name];
    const wrapped = function (...args) {
      if (before) before.call(this, args);
      const result = original.apply(this, args);
      if (after) after.call(this, args, result);
      return result;
    };
    wrapped.__hwNative = true;
    owner[name] = wrapped;
  }

  function hook(character, choose) {
    if (!character) return;
    let owner = Object.getPrototypeOf(character);
    while (owner && !Object.prototype.hasOwnProperty.call(owner, 'create')) owner = Object.getPrototypeOf(owner);
    if (!owner || hooked.has(owner)) return;
    hooked.add(owner);

    wrapMethod(owner, 'create', function () {
      const entry = choose(this);
      const profile = entry?.profile;
      if (profile) {
        validate(profile);
        this.__nativeProfile = profile;
        this.__customCharacterId = entry.id;
      } else {
        this.__nativeProfile = null;
      }
    }, function () {
      if (this.__nativeProfile) finishSetup(this, this.__nativeProfile);
    });

    wrapMethod(owner, 'createBodies', function (args) {
      transformPlaceholder(args[0], this.__nativeProfile || null);
    });

    wrapMethod(owner, 'createJoints', function (args) {
      if (this.__nativeProfile) transformPlaceholder(args[0], this.__nativeProfile);
    });

    wrapMethod(owner, 'createMovieClips', null, function () {
      if (this.__nativeProfile?.helmet === false) hideHelmetGraphic(this);
    });

    wrapMethod(owner, 'paint', null, function () {
      if (!this.__nativeProfile) return;
      scaleParts(this);
      if (this.__nativeProfile.helmet === false) hideHelmetGraphic(this);
    });
  }

  return { validate, transformPlaceholder, scaleParts, hideHelmetGraphic, hook };
});
