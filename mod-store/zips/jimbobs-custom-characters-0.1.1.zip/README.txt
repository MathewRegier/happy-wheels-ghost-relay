Jimbob's Custom Characters
Created by Jimbob · Discord jimbob1111


What this is
------------
Extra slots on the official character menu. Each folder in
web\characters\ with a valid character.json becomes a playable
slot. Vanilla characters stay vanilla.


Make your own
-------------
Open custom-characters-template\README.txt

That kit has Tung Tung Tung Sahur, a blank starter folder, and
the json fields you need. Vanilla sheets stay in the local kit
and are not in the public launcher download.

Short version:

  your-character-id\
    character.json
    sheet.png
    icon.png

Drag that folder into web\characters\ and restart Happy Wheels.


character.json
--------------
{
  "name": "My New Character",
  "base": 2,
  "sheet": "sheet.png",
  "icon": "icon.png"
}

base is the vanilla ragdoll to clone (1-11). Segway Guy is 2.


Install
-------
Install the Happy Wheels Mod Launcher first, then enable Jimbob's
Custom Characters. Or drop this folder into Happy Wheels\mods
after the launcher has made the game moddable.
