1. Copy a vanilla sheet from ..\vanilla into this folder as sheet.png
2. Paint over it. Do not change the image size or move the parts.
3. Make a small square icon.png (the face that appears on the character grid).
4. Edit character.json: name, and base (which vanilla ragdoll to clone).
5. Rename this folder to a-lowercase-id, for example my-new-guy
6. Drag the folder into Happy Wheels\mods\jimbobs-custom-characters\web\characters\
7. Restart Happy Wheels.
