Lawnmower Man uses more than one vanilla atlas:
  sheet-a.png
  sheet-b.png

The current loader paints one sheet over character6.png. Start with a single-sheet base (1-5, 7, 9-11) if this is your first character.
