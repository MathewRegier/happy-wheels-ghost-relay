'use strict';
// Development-only local inspection channel. Never exposed over the network.
const electron = require('electron');
const {app, ipcMain, session, shell} = electron;
const fs = require('node:fs');
const path = require('node:path');
function mark(name, extra){
  try{
    fs.mkdirSync(path.join(process.resourcesPath,'mod-runtime'),{recursive:true});
    fs.writeFileSync(path.join(process.resourcesPath,'mod-runtime',name),JSON.stringify({t:Date.now(),...extra||{}}));
  }catch{}
}
mark('ghost-main-boot.json',{ready:app.isReady()});
try{
  const Original=electron.BrowserWindow;
  if(Original&&!Original.__hwGhostPatched){
    class Patched extends Original {
      constructor(options){
        const opts=Object.assign({},options||{});
        const wp=Object.assign({},opts.webPreferences||{});
        wp.sandbox=false;
        opts.webPreferences=wp;
        super(opts);
      }
    }
    Patched.__hwGhostPatched=true;
    try{electron.BrowserWindow=Patched;}
    catch{Object.defineProperty(electron,'BrowserWindow',{configurable:true,enumerable:true,value:Patched});}
  }
}catch(error){mark('ghost-main-err.json',{step:'browserwindow',error:String(error)});}
const BrowserWindow=electron.BrowserWindow;
function loadWs(){
  if(loadWs.mod)return loadWs.mod;
  const tries=['ws',path.join(process.resourcesPath,'app.asar','node_modules','ws'),path.join(process.resourcesPath,'app.asar.unpacked','node_modules','ws')];
  for(const id of tries){try{loadWs.mod=require(id);return loadWs.mod;}catch{}}
  throw Error('WebSocket support is not available in this Happy Wheels install.');
}
let steamLobby;
try{steamLobby=require('./steam-lobby.cjs');}
catch(error){
  mark('ghost-main-err.json',{step:'steam-lobby',error:String(error)});
  steamLobby={status:()=>({ok:false,error:'Steam lobby failed to load',name:'',avatar:''}),publish:async()=>({ok:false}),invite:()=>({ok:false}),close(){},takeInvite:()=>null};
}
const sockets=new Map();
const browsing=new Map();
const GAME_ORIGIN='https://totaljerkface.com/__hw_app__/';
const TRANSPORT_PRELOAD=path.join(__dirname,'transport-preload.cjs');
// The Shared Physics host simulates every rider, so a covered or unfocused window must keep full frame rate.
try{for(const flag of ['disable-renderer-backgrounding','disable-background-timer-throttling','disable-backgrounding-occluded-windows'])app.commandLine.appendSwitch(flag);}catch{}
function childPrefs(){
  return {preload:TRANSPORT_PRELOAD,devTools:false,contextIsolation:true,nodeIntegration:false,sandbox:false,backgroundThrottling:false,spellcheck:false,enableWebSQL:false,webviewTag:false};
}
function attachBridge(){
  try{
    const list=session.defaultSession.getPreloads();
    if(!list.includes(TRANSPORT_PRELOAD))session.defaultSession.setPreloads([...list,TRANSPORT_PRELOAD]);
    session.defaultSession.registerPreloadScript?.({type:'frame',filePath:TRANSPORT_PRELOAD});
  }catch{}
  mark('ghost-main-ok.json',{ready:app.isReady(),windows:BrowserWindow.getAllWindows().length});
}
if(app.isReady())attachBridge();
else app.whenReady().then(attachBridge);
function senderUrl(event){
  try{const url=event.senderFrame?.url||'';if(url.startsWith(GAME_ORIGIN))return url;}catch{}
  try{const url=event.sender?.getURL?.()||'';if(url.startsWith(GAME_ORIGIN))return url;}catch{}
  return '';
}
function check(event){if(!senderUrl(event))throw Error('Invalid ghost sender');}
function handle(channel,fn){try{ipcMain.removeHandler(channel);}catch{}ipcMain.handle(channel,fn);}
handle('ghost:list-rooms',(event,url)=>{
  check(event);const id=event.sender.id;
  const pending=browsing.get(id);
  if(pending){if(pending.url===url)return pending.task;throw Error('Wait for the current room refresh, then try the new server.');}
  const task=require('./room-directory.cjs').listRooms(loadWs(),url).finally(()=>browsing.delete(id));
  browsing.set(id,{url,task});return task;
});
handle('ghost:connect',async(event,url)=>{
  check(event);const parsed=new URL(url);
  if(!['ws:','wss:'].includes(parsed.protocol)||parsed.username||parsed.password)throw Error('Invalid relay address');
  const id=event.sender.id;
  const previous=sockets.get(id);
  if(previous){previous.removeAllListeners('close');previous.removeAllListeners('error');previous.removeAllListeners('message');previous.close();}
  const WebSocket=loadWs();
  const ws=new WebSocket(parsed.href,{maxPayload:512*1024,perMessageDeflate:false,handshakeTimeout:8000,followRedirects:false});sockets.set(id,ws);
  const emit=(type,data)=>{if(sockets.get(id)===ws&&!event.sender.isDestroyed())event.sender.send('ghost:network',{type,data});};
  ws.on('message',data=>emit('message',data.toString()));ws.on('error',()=>emit('error','Relay connection failed'));
  ws.on('close',()=>{if(sockets.get(id)===ws){emit('close');sockets.delete(id);}});
  event.sender.once('destroyed',()=>ws.close());
  await new Promise((resolve,reject)=>{ws.once('open',resolve);ws.once('error',reject);});return true;
});
ipcMain.on('ghost:send',(event,data)=>{check(event);const ws=sockets.get(event.sender.id);if(typeof data==='string'&&Buffer.byteLength(data)<=512*1024&&ws?.readyState===1&&ws.bufferedAmount<1024*1024)ws.send(data);});
ipcMain.on('ghost:disconnect',event=>{check(event);sockets.get(event.sender.id)?.close();steamLobby.close();});
handle('ghost:steam-status',event=>{check(event);return steamLobby.status();});
handle('ghost:steam-publish',async(event,info)=>{check(event);return steamLobby.publish(info||{});});
handle('ghost:steam-invite',event=>{check(event);return steamLobby.invite();});
handle('ghost:steam-take',event=>{check(event);return steamLobby.takeInvite();});
handle('ghost:open-peer',event=>{
  check(event);
  const win=new BrowserWindow({width:1000,height:700,backgroundColor:'#000000',webPreferences:childPrefs()});
  win.loadURL(event.sender.getURL()||'https://totaljerkface.com/__hw_app__/index.html');
  return true;
});
try{
for(const win of BrowserWindow.getAllWindows())try{win.webContents.setBackgroundThrottling(false);}catch{}
app.on('web-contents-created',(_event,contents)=>{
  try{contents.setBackgroundThrottling(false);}catch{}
  contents.setWindowOpenHandler(({url})=>{
    if(url.startsWith(GAME_ORIGIN))return{action:'allow',overrideBrowserWindowOptions:{width:1000,height:700,backgroundColor:'#000000',webPreferences:childPrefs()}};
    if(/^https?:/.test(url))shell.openExternal(url);
    return{action:'deny'};
  });
});
app.whenReady().then(()=>{
  session.defaultSession.on('will-download',(event,item)=>{
    if(/^happy-wheels-ghost-\d+\.json$/.test(item.getFilename())&&item.getURL().startsWith('blob:')){
      const dir=path.resolve(process.resourcesPath,'../../recordings');fs.mkdirSync(dir,{recursive:true});
      item.setSavePath(path.join(dir,Date.now()+'-'+item.getFilename()));
    }
  });
});
app.on('will-quit',()=>{for(const ws of sockets.values())ws.close();});
}catch(error){mark('ghost-main-err.json',{step:'windows',error:String(error)});}
if (process.env.HW_GHOST_DEV === '1') {
  const dir = path.resolve(process.resourcesPath, '../../dev');
  fs.mkdirSync(dir, {recursive:true});
  let busy = false;
  const timer = setInterval(async () => {
    if (busy) return;
    const request = path.join(dir, 'request.json');
    if (!fs.existsSync(request)) return;
    busy = true;
    let id;
    try {
      const command = JSON.parse(fs.readFileSync(request, 'utf8'));
      fs.unlinkSync(request);
      id = command.id;
      const windows=BrowserWindow.getAllWindows().sort((a,b)=>a.id-b.id);
      const win = windows[command.window||0];
      if (!win) throw new Error('Game window not ready');
      const result = await win.webContents.executeJavaScript(command.code, true);
      fs.writeFileSync(path.join(dir, 'response.json'), JSON.stringify({id,result}));
    } catch (error) {
      fs.writeFileSync(path.join(dir, 'response.json'), JSON.stringify({id,error:String(error)}));
    } finally {busy = false;}
  }, 100);
  app.on('will-quit', () => clearInterval(timer));
}
