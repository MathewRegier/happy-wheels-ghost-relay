Jimbob's Multiplayer Mod 0.7.5
Created by Jimbob
Discord: jimbob1111

Need help? Add me on Discord: jimbob1111


You must install the launcher first
-----------------------------------
Happy Wheels is not moddable until you run the Happy Wheels Mod Launcher.
Do not only drop this folder in. Install the launcher first.

Launcher download:
https://gamebanana.com/tools/24249


What this is
------------
Race friends on the same Happy Wheels level.

Ghost Multiplayer shows other players as ghosts you can see. They do
not push you.

Shared Physics is experimental. Everyone shares one world, so you can
see each other and bump for real. The host runs the physics.

Custom character skins show on other players when both of you have the
same character pack from Jimbob's Custom Characters.


Requirements
------------
- Windows
- A legal Steam copy of Happy Wheels 1.99.2
- Steam installed
- Happy Wheels Mod Launcher (link above)
- Close Happy Wheels before installing
- Every player needs this same 0.7.5 version


Install
-------
1. Download and install the Happy Wheels Mod Launcher:
   https://gamebanana.com/tools/24249
2. Unzip the launcher, close Happy Wheels, and run
   "Happy Wheels Mod Launcher.exe".
3. Let it find your Steam Happy Wheels folder and install the mods loader.
   This is what makes the game moddable.
4. In the launcher, check Jimbob's Multiplayer Mod and install.
   Or unzip this file and copy the "jimbobs-multiplayer" folder into:
   your Happy Wheels folder \ mods
   Example:
   C:\Program Files (x86)\Steam\steamapps\common\Happy Wheels\mods\jimbobs-multiplayer
5. Fully quit Happy Wheels if it was open, then launch it from Steam.
6. Open the Multiplayer menu.


Play
----
1. Open Multiplayer for the full-screen public room browser. Search by room,
   host or level, filter by mode, and click Join. The list refreshes every
   8 seconds while it is open. Full, locked and running rooms cannot be joined.
2. To host, click Host a room, choose a mode, name your room and choose
   2 to 16 players. Public rooms appear in the browser. Friends only rooms
   are hidden; share a code or Steam invite with the people you want to join.
   Friends only means invite/code discovery, not a Steam friendship check.
3. Add an optional password to either kind of room. Joiners must enter it,
   including when using a code or Steam invite. Passwords are case-sensitive
   and can be up to 64 characters. They are not saved to disk or shown in
   the room list. The relay stores a salted password hash.
4. Join with code is always available. Friends need the same relay address;
   Advanced server settings lets you change it or test a local relay.
5. The host can switch Ghost Multiplayer / Shared Physics in the lobby.
   This clears Ready votes. During a race or character loading, use Back
   to lobby first so everyone's previous simulation is cleaned up.
6. The host chooses a level. Everyone presses Ready. If the map allows
   character selection, all players choose before the level begins.
7. Race results offer Race again or a new map. In survival, the last living
   rider wins, and restarting requires a unanimous vote.

Only Multiplayer is needed to play published multiplayer maps. Builder is
optional for creators and local unpublished draft tests. Private local draft
rooms do not appear on the public relay browser.

#jmp wait changes the countdown. #jmp seats sizes the room. #jmp rider
locks everyone to that character and skips character select. The host
can kick, hand off host, or lock the room from the player list.

Shared Physics has a switch, "Players bump into each other". It starts
on. The host can turn it off during a level and riders pass through
each other right away.

The scoreboard counts a death each time someone respawns.

Making Jimbob maps
------------------
Players need this Multiplayer update for published maps, including
left-facing starts, fixed cameras, tycoon maps and Studio maps. Builder is
optional for creators who want editor tools and private unpublished draft tests.

Use the normal Happy Wheels editor. Add text boxes that start with #jmp
(not #mp). Put JHWMP in the published level name.

  #jmp start 1          extra start. Number them 1, 2, 3...
  #jmp start 2 left     face left (Shared Physics, with or without a vehicle)
  #jmp camera fixed 1400 fixed view, width in map pixels; box sets its centre
  #jmp flag 1           checkpoint. R sends you back here
  #jmp goal             your finish line (replaces the level's)
  #jmp loops 2          pass flags in order, then the goal, this many times
  #jmp bump on          lock Shared Physics bumping
  #jmp rider segway     intended character (name or 1-11)
  #jmp clock 3:00       time limit
  #jmp linger 60        extra seconds after the first finish (shown in lobby)
  #jmp retry flag       flag, start, or off
  #jmp wait 5           countdown length (shown in lobby)
  #jmp seats 6          intended lobby size
  #jmp play survival    last rider standing; retries off

Load the level in a room before Ready to see S/F/G marks. Tag text is
hidden during a race. Notes can go on the lines under the first tag line.


What's new in 0.5.1
-------------------
Survival restart voting: a restart key or menu restart asks the whole room.
The requester votes Yes automatically. Everyone must vote Yes within 30
seconds; No, timeout, or a membership change cancels the vote. Eliminated
players can vote too. Accepted votes keep individual character choices and
skins and load a fresh round after every player finishes preparation.

Map changes and lobby returns retire the old simulation, remote bodies,
inputs, character hooks, and loading acknowledgements. Old-world packets
cannot affect the next round. Reconnecting clears previous room launch IDs.

The public server must run the updated relay/server.cjs and shared-protocol.cjs.
The client shows a message when connected to a relay without restart voting.
The Builder local test server includes the matching update.

What's new in 0.5.0
-------------------
- The host picks the level inside the lobby. Players stay there until
  everyone is Ready, then the level loads.
- Character select shows every player's name on the character they chose.
  The race starts when the last player has picked.
- #jmp wait, seats, rider, and linger are enforced.
- After the finish window, results offer Race again or a new map.
- Host tools: kick, make host, lock lobby.

What's new in 0.4.4
-------------------
- Jimbob map tags: #jmp text boxes and JHWMP in the level name.

Changing character in Ghost Multiplayer keeps you in the same race.
In Shared Physics, pick a new character from the in-race list, including
custom characters when that mod is installed.


What's new in 0.4.3
-------------------
- The Multiplayer menu shows up again on Happy Wheels 1.99.2.

What's new in 0.4.2
-------------------
- Level complete works for every player in Shared Physics, not just the host.
- "Reset players" replaces "Bring everyone to my level".
- Shared Physics hosts get "Reset world": restarts the level for everyone and
  starts the countdown from 3 right away.
- A body that falls off the map no longer stops the whole shared session.
- Fixing a guest's character no longer respawns the host's copy.
- Moped companion and Santa's ropes clean up on respawn.
- The progress bar only shows 100% when a player actually finishes.
- Shared Physics limb breaks stay in sync, including shoulders, elbows, hips, and knees.
- A character that falls out of sync is rebuilt instead of pausing the race.
- Blood bursts still play after the hit destroys the body part.
- Your own key bindings are used for movement and restart.
- Shared Physics, an experimental shared world.
- Ghost Multiplayer still works.
- Host or Join, then pick the mode.
- Room size from 2 to 16 players. The stats page shows 3/12 when 3
  people are in a room of 12.
- Shared Physics bump switch, on by default, and it works mid-level.
- The scoreboard adds a death on every respawn.
- Changing character in Ghost Multiplayer no longer drops you from the race.
- The relay stats page shows the room code, the mode, and how full the
  room is.


Updates
-------
Open the Happy Wheels Mod Launcher again later to check for updates.

A Steam update or "Verify integrity of game files" can remove the
mods loader. If that happens, run the launcher again first, then
reinstall this mod.


Credits
-------
Created by Jimbob
Discord: jimbob1111

If you need any help, add me on Discord: jimbob1111

Loading fix in 0.5.2
--------------------
Guest worlds persist while waiting for the host snapshot. Early snapshots are buffered, and hosts resend complete preparation snapshots until clients acknowledge. Native fixed-character entry is gated before it starts. Retired sessions and cancelled loaders cannot recreate a solo world. Both windows remain paused until preparation and countdown complete.

Map gameplay support in 0.5.3
-----------------------------
Facing and fixed-camera runtime support now ships with Multiplayer. The
working reflection and controls are preserved; camera rules apply to both
Ghost and Shared Physics and reapply after respawns and map changes. No
Builder installation is required for players of published maps. Map creators
should update to Builder 0.2.19, which uses these runtime modules and never
patches Multiplayer files. Left-facing riders can drive their vehicles in
Shared Physics. Ghost mode does not mirror them.

Survival map rules fix in 0.5.5
------------------------------
Published records are decoded with the native game decoder before the lobby
reads their multiplayer tags. CDATA captions and attribute captions both
work. Survival rules now reach the relay before Ready, enabling restart
votes and last-survivor results with Multiplayer alone. Browsing maps does
not change the active session download tracker. Survival ignores the native
finish line without requiring Builder. The 0.5.4 level-browser fixes remain.

After updating, fully quit all game windows, launch through Steam, and
choose the map in the lobby again so its rules are refreshed. All players
should use 0.5.5. The existing public relay already supports this update.

Survival downloads fix in 0.5.6
------------------------------
Map inspection now includes the native ip_tracking field required by the
level server, using an even last digit so inspection does not add plays.
Empty HTTP success responses and unreadable rules show an error instead
of silently changing a survival map into a normal race. This restores
unanimous restart votes and last-survivor results with Multiplayer alone.

Fully quit all game windows, launch through Steam, and select the map in
the lobby again to replace any room rules saved by the previous version.
Everyone should use 0.5.6. No relay update is required.

Lobby and level browser in 0.6.0
-------------------------------
The lobby matches the full-screen multiplayer screens. Public rooms fill
the list, the room code is shown in gold, and Ready and Choose a level are
separate buttons. Room tools hold lock, player collisions, and the resets.
Press = for server settings. Escape closes that popup first.

Choose a level is a full-screen card grid. Bigger windows show more cards
per row, up to five. Featured and Custom cards show the map rating.
Multiplayer Maps is its own section and shows the map rules, such as
survival or a forced player count, instead of a rating.

Spawn positions, facing, checkpoints and fixed cameras still retain the
original map XML across Race Again, unanimous restarts and returning to
the lobby. No Builder installation or relay update is needed.

Fully quit all game windows and launch through Steam to load this update.

Ping and shared physics in 0.6.1
--------------------------------
The public room list shows your ping to the relay on every room, and again
at the bottom of the list. Under 80 ms is green, under 160 ms is gold, and
slower is coral.

Shared Physics sends world changes against periodic full snapshots, keeps
short button presses until the host simulates them, and smooths what you
see between those snapshots. The public relay is updated with this release.
You do not install a relay yourself. Update this mod, fully quit every
Happy Wheels window, and launch through Steam.

Everyone should use Multiplayer 0.6.1.

Left-facing vehicles in 0.6.2
-----------------------------
A rider facing left can spawn with a bike, segway, or other vehicle and
drive it in Shared Physics. Screen left and right still match the way the
rider is facing. Ghost mode does not mirror facing. No relay update is
required.

Fully quit every Happy Wheels window and launch through Steam.

Jimbob Maps in 0.7.0
--------------------
The Multiplayer Maps tab loads maps from Jimbob Maps. Browse them, preview
them, or open a JM code. Everyone in the room gets the same verified
revision. You do not need Builder to play.

This release needs the updated relay. Fully quit every Happy Wheels window,
install 0.7.0, and launch through Steam.

Everyone should use Multiplayer 0.7.0.

What's new in 0.7.5
-------------------
You can start a solo room and play a level by yourself. Solo rooms stay
off the public browser. Survival maps still need at least two players.

Published tycoon and Studio maps run with Multiplayer alone. You do not
need Builder. Buys, prompts, cameras, checkpoints and on-screen counters
from those maps work in the room, including for guests in Shared Physics.
Host-only actions stay with the host.

Watching another player no longer leaves the map blank when they are far
away. The multiplayer results window stays in charge when someone finishes,
instead of the normal Happy Wheels win screen taking over. If a level
cannot load, you get a clear message instead of a broken world.

The Multiplayer button hides while you are in the game's other menus and
comes back on the title screen.

Fully quit every Happy Wheels window, install 0.7.5, and launch through
Steam. Everyone in a room should use 0.7.5. The public server already
accepts this update.
