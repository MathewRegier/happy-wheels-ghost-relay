(() => {
 'use strict';if(window.HWFactoryUI)return;const owners=new Map();let previousBlocked=false,lab=null,previous=null,wrapper=null;
 const visible=e=>e?.isVisible?e.isVisible():!!e&&!e.hidden&&e.getClientRects().length>0&&getComputedStyle(e).display!=='none';
 const api=window.HWFactoryUI={register(id,element){owners.set(id,element);return()=>owners.delete(id);},blocked(){return [...owners.values()].some(visible);},owners(){return [...owners].filter(([,e])=>visible(e)).map(([id])=>id);}};
 setInterval(()=>{for(const id of ['jhw-tycoon-builder','jhw-factory-editor','jhw-builder','jhw-map-publisher','jhw-jimbob-publisher','jhw-character-creator']){const e=document.getElementById(id);if(e)owners.set(id,e);}const current=window.HWGhost;if(current&&(lab!==current||current.inputBlocked!==wrapper)){if(lab?.inputBlocked===wrapper)lab.inputBlocked=previous;lab=current;previous=current.inputBlocked;wrapper=mode=>api.blocked()||!!previous?.(mode);current.inputBlocked=wrapper;}const blocked=api.blocked();if(blocked&&!previousBlocked){window.HWGhost?.sharedWorld?.dropHeldInput?.();window.dispatchEvent(new Event('blur'));}previousBlocked=blocked;},200);
})();
