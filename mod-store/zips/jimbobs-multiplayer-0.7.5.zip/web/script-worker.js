importScripts('scene-data.js','vendor/acorn.js','script-vm.js','script-runtime.js');
const runner=new HWScriptRuntime.Runner();
self.onmessage=event=>{if(event.data.stop){runner.stop();self.close();return;}try{self.postMessage(runner.process(event.data));}catch(error){self.postMessage({generation:event.data.generation,commands:[],logs:[{severity:'error',message:error.message}]});}};
