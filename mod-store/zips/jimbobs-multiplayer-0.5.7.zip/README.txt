Jimbob's Multiplayer Mod 0.5.7
Created by Jimbob
Discord: jimbob1111

Need help? Add me on Discord: jimbob1111


You must install the launcher first
-----------------------------------
Happy Wheels is not moddable until you run the Happy Wheels Mod Launcher.
Do not only drop this folder in. Install the launcher first.

Launcher download:
https://gamebanana.com/tools/24249


What this is
------------
Race friends on the same Happy Wheels level.

Ghost Multiplayer shows other players as ghosts you can see. They do
not push you.

Shared Physics is experimental. Everyone shares one world, so you can
see each other and bump for real. The host runs the physics.

Custom character skins show on other players when both of you have the
same character pack from Jimbob's Custom Characters.


Requirements
------------
- Windows
- A legal Steam copy of Happy Wheels 1.99.2
- Steam installed
- Happy Wheels Mod Launcher (link above)
- Close Happy Wheels before installing
- Every player needs this same 0.5.7 version


Install
-------
1. Download and install the Happy Wheels Mod Launcher:
   https://gamebanana.com/tools/24249
2. Unzip the launcher, close Happy Wheels, and run
   "Happy Wheels Mod Launcher.exe".
3. Let it find your Steam Happy Wheels folder and install the mods loader.
   This is what makes the game moddable.
4. In the launcher, check Jimbob's Multiplayer Mod and install.
   Or unzip this file and copy the "jimbobs-multiplayer" folder into:
   your Happy Wheels folder \ mods
   Example:
   C:\Program Files (x86)\Steam\steamapps\common\Happy Wheels\mods\jimbobs-multiplayer
5. Fully quit Happy Wheels if it was open, then launch it from Steam.
6. Open the Multiplayer menu.


Play
----
1. Type your name. This is the name other players see.
2. Choose Host or Join.
3. Host: pick Ghost Multiplayer or Shared Physics, then choose how many
   players the room allows (2 to 16).
4. Host: share the room code.
5. Join: paste that room code.
6. Host picks a level inside the Multiplayer menu. Featured, search by
   name or author, a level id, or JHWMP maps. Nobody loads the map yet.
7. Everyone presses Ready in the lobby. Then the level opens.
8. If the map does not lock a character, each player picks one. Names
   stack on the character they picked. The race starts only after every
   player has chosen.
9. After the first finish, the others get a finish window (45 seconds,
   or #jmp linger). Then the results screen offers Race again or a new map.

#jmp wait changes the countdown. #jmp seats sizes the room. #jmp rider
locks everyone to that character and skips character select. The host
can kick, hand off host, or lock the room from the player list.

Shared Physics has a switch, "Players bump into each other". It starts
on. The host can turn it off during a level and riders pass through
each other right away.

The scoreboard counts a death each time someone respawns.

Making Jimbob maps
------------------
Players only need Multiplayer 0.5.3 or newer for published maps, including
left-facing character-only starts and fixed camera/zoom. Builder is optional
for creators who want editor tools and private unpublished draft tests.

Use the normal Happy Wheels editor. Add text boxes that start with #jmp
(not #mp). Put JHWMP in the published level name.

  #jmp start 1          extra start. Number them 1, 2, 3...
  #jmp start 2 left     face left (Shared Physics, Hide vehicle enabled)
  #jmp camera fixed 1400 fixed view, width in map pixels; box sets its centre
  #jmp flag 1           checkpoint. R sends you back here
  #jmp goal             your finish line (replaces the level's)
  #jmp loops 2          pass flags in order, then the goal, this many times
  #jmp bump on          lock Shared Physics bumping
  #jmp rider segway     intended character (name or 1-11)
  #jmp clock 3:00       time limit
  #jmp linger 60        extra seconds after the first finish (shown in lobby)
  #jmp retry flag       flag, start, or off
  #jmp wait 5           countdown length (shown in lobby)
  #jmp seats 6          intended lobby size
  #jmp play survival    last rider standing; retries off

Load the level in a room before Ready to see S/F/G marks. Tag text is
hidden during a race. Notes can go on the lines under the first tag line.


What's new in 0.5.1
-------------------
Survival restart voting: a restart key or menu restart asks the whole room.
The requester votes Yes automatically. Everyone must vote Yes within 30
seconds; No, timeout, or a membership change cancels the vote. Eliminated
players can vote too. Accepted votes keep individual character choices and
skins and load a fresh round after every player finishes preparation.

Map changes and lobby returns retire the old simulation, remote bodies,
inputs, character hooks, and loading acknowledgements. Old-world packets
cannot affect the next round. Reconnecting clears previous room launch IDs.

The public server must run the updated relay/server.cjs and shared-protocol.cjs.
The client shows a message when connected to a relay without restart voting.
The Builder local test server includes the matching update.

What's new in 0.5.0
-------------------
- The host picks the level inside the lobby. Players stay there until
  everyone is Ready, then the level loads.
- Character select shows every player's name on the character they chose.
  The race starts when the last player has picked.
- #jmp wait, seats, rider, and linger are enforced.
- After the finish window, results offer Race again or a new map.
- Host tools: kick, make host, lock lobby.

What's new in 0.4.4
-------------------
- Jimbob map tags: #jmp text boxes and JHWMP in the level name.

Changing character in Ghost Multiplayer keeps you in the same race.
In Shared Physics, pick a new character from the in-race list, including
custom characters when that mod is installed.


What's new in 0.4.3
-------------------
- The Multiplayer menu shows up again on Happy Wheels 1.99.2.

What's new in 0.4.2
-------------------
- Level complete works for every player in Shared Physics, not just the host.
- "Reset players" replaces "Bring everyone to my level".
- Shared Physics hosts get "Reset world": restarts the level for everyone and
  starts the countdown from 3 right away.
- A body that falls off the map no longer stops the whole shared session.
- Fixing a guest's character no longer respawns the host's copy.
- Moped companion and Santa's ropes clean up on respawn.
- The progress bar only shows 100% when a player actually finishes.
- Shared Physics limb breaks stay in sync, including shoulders, elbows, hips, and knees.
- A character that falls out of sync is rebuilt instead of pausing the race.
- Blood bursts still play after the hit destroys the body part.
- Your own key bindings are used for movement and restart.
- Shared Physics, an experimental shared world.
- Ghost Multiplayer still works.
- Host or Join, then pick the mode.
- Room size from 2 to 16 players. The stats page shows 3/12 when 3
  people are in a room of 12.
- Shared Physics bump switch, on by default, and it works mid-level.
- The scoreboard adds a death on every respawn.
- Changing character in Ghost Multiplayer no longer drops you from the race.
- The relay stats page shows the room code, the mode, and how full the
  room is.


Updates
-------
Open the Happy Wheels Mod Launcher again later to check for updates.

A Steam update or "Verify integrity of game files" can remove the
mods loader. If that happens, run the launcher again first, then
reinstall this mod.


Credits
-------
Created by Jimbob
Discord: jimbob1111

If you need any help, add me on Discord: jimbob1111

Loading fix in 0.5.2
--------------------
Guest worlds persist while waiting for the host snapshot. Early snapshots are buffered, and hosts resend complete preparation snapshots until clients acknowledge. Native fixed-character entry is gated before it starts. Retired sessions and cancelled loaders cannot recreate a solo world. Both windows remain paused until preparation and countdown complete.

Map gameplay support in 0.5.3
-----------------------------
Facing and fixed-camera runtime support now ships with Multiplayer. The
working reflection and controls are preserved; camera rules apply to both
Ghost and Shared Physics and reapply after respawns and map changes. No
Builder installation is required for players of published maps. Map creators
should update to Builder 0.2.19, which uses these runtime modules and never
patches Multiplayer files. Left-facing vehicle rigs still require Hide vehicle;
left-facing gameplay remains supported in Shared Physics only.

Survival map rules fix in 0.5.5
------------------------------
Published records are decoded with the native game decoder before the lobby
reads their multiplayer tags. CDATA captions and attribute captions both
work. Survival rules now reach the relay before Ready, enabling restart
votes and last-survivor results with Multiplayer alone. Browsing maps does
not change the active session download tracker. Survival ignores the native
finish line without requiring Builder. The 0.5.4 level-browser fixes remain.

After updating, fully quit all game windows, launch through Steam, and
choose the map in the lobby again so its rules are refreshed. All players
should use 0.5.5. The existing public relay already supports this update.

Survival downloads fix in 0.5.6
------------------------------
Map inspection now includes the native ip_tracking field required by the
level server, using an even last digit so inspection does not add plays.
Empty HTTP success responses and unreadable rules show an error instead
of silently changing a survival map into a normal race. This restores
unanimous restart votes and last-survivor results with Multiplayer alone.

Fully quit all game windows, launch through Steam, and select the map in
the lobby again to replace any room rules saved by the previous version.
Everyone should use 0.5.6. No relay update is required.

Rematch spawn fix in 0.5.7
--------------------------
Spawn positions, facing, checkpoints and fixed cameras retain the original
map XML across Race Again, unanimous restarts and returning to the lobby.
Definitions are tied to both level ID and its data fingerprint, so another
map or a revised draft cannot inherit old spawns. Shared Physics resolves
starts against its active world and launch roster, not character previews
or a changed lobby order. No Builder installation or relay update is needed.

Fully quit all game windows and launch through Steam to load this update.
Everyone should use Multiplayer 0.5.7.
